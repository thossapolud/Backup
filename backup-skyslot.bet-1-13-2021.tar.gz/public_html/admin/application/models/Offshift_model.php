<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Offshift_model extends CI_Model{
			
	public function get_all(){
		$this->db->select('offshift_id, offshift_date');
		$this->db->order_by('offshift_date', 'desc');
		return $this->db->get('tb_offshift');
	}
	
	public function get_by_id($offshift_id){
		$this->db->select('*');
		$this->db->where('offshift_id',$offshift_id);
		return $this->db->get('tb_offshift')->row();
	}
	
	public function get_less_than($offshift_id){
		$this->db->select('*');
		$this->db->where('offshift_id <',$offshift_id);
		$this->db->order_by('offshift_date', 'desc');
		$this->db->limit(2);
		return $this->db->get('tb_offshift');
	}
			
	public function __destruct(){
		$this->db->close();
	}
	
}