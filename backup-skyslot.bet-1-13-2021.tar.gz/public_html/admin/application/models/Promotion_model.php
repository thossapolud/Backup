<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Promotion_model extends CI_Model{
		
	public function get_by_id($id){
		$this->db->select('*');
		$this->db->where('status', 'ใช้');
		$this->db->where('pr_id', $id);
		return $this->db->get('tb_promotion')->row();
	}
	
	public function get_all(){
		$this->db->select('*');
		$this->db->where('status', 'ใช้');
		$this->db->order_by('created','asc');
		return $this->db->get('tb_promotion');
	}
	
	public function get_to_edit($id){
		$this->db->select('*');
		//$this->db->where('status', 'ใช้');
		$this->db->where('pr_id', $id);
		return $this->db->get('tb_promotion')->row();
	}
					
	public function __destruct(){
		$this->db->close();
	}
	
}