<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Deposit_model extends CI_Model{
		
	/*
	public function get_sumcountcredit($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->select("COUNT(de_id) AS listtotal, SUM(credit) AS credittotal");
		if($dealer)$this->db->where('dealer',$dealer);
		//$this->db->where('created BETWEEN "'.date('Y-m-d').' 00:00:00" AND "'.date('Y-m-d').' 11:59:59"');
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		//$this->db->where('add_by_name !=', 'เพิ่มผ่านการเลือกโปรโมชั่น');
		//$this->db->where('add_by_name !=', 'เพิ่มผ่านการเลือกโปรโมชั่นฟรี');
		//$this->db->where('add_by_name !=', 'เพิ่มผ่านโปรแนะนำเพื่อน');
		$this->db->where_not_in('add_by_name', array('เพิ่มผ่านการเลือกโปรโมชั่น','เพิ่มผ่านการเลือกโปรโมชั่นฟรี','เพิ่มผ่านโปรแนะนำเพื่อน'));
		return $this->db->get('tb_deposit')->row();
	}
	*/
	
	public function get_sumcountcredit($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent=NULL){
		$this->db->select("COUNT(de_id) AS listtotal, SUM(credit) AS credittotal");
		if($site_id)$this->db->where('site_id',$site_id);
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where_not_in('add_by_name', array('เพิ่มผ่านการเลือกโปรโมชั่น','เพิ่มผ่านการเลือกโปรโมชั่นฟรี','เพิ่มผ่านโปรแนะนำเพื่อน'));
		$this->db->not_like('add_by_name', 'โยกเครดิต', 'both');
		return $this->db->get('tb_deposit')->row();
	}
	
	public function get_sumcountcreditpromotion($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent=NULL){
		$this->db->select("COUNT(de_id) AS listtotal, SUM(credit) AS credittotal");
		if($site_id)$this->db->where('site_id',$site_id);
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where_in('add_by_name', array('เพิ่มผ่านการเลือกโปรโมชั่น','เพิ่มผ่านการเลือกโปรโมชั่นฟรี','เพิ่มผ่านโปรแนะนำเพื่อน'));
		return $this->db->get('tb_deposit')->row();
	}
	
	public function get_sumcountcredittransfer($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent=NULL){
		$this->db->select("COUNT(de_id) AS listtotal, SUM(credit) AS credittotal");
		if($site_id)$this->db->where('site_id',$site_id);
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		//$this->db->where_in('add_by_name', array('โยกเครดิตโดยสมาชิก'));
		$this->db->like('add_by_name', 'โยกเครดิต', 'both');
		return $this->db->get('tb_deposit')->row();
	}

	/*
	public function get_sumcountcreditpromotion($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->select("COUNT(de_id) AS listtotal, SUM(credit) AS credittotal");
		if($dealer)$this->db->where('dealer',$dealer);
		//$this->db->where('created BETWEEN "'.date('Y-m-d').' 00:00:00" AND "'.date('Y-m-d').' 11:59:59"');
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where_in('add_by_name', array('เพิ่มผ่านการเลือกโปรโมชั่น','เพิ่มผ่านการเลือกโปรโมชั่นฟรี','เพิ่มผ่านโปรแนะนำเพื่อน'));
		//$this->db->where('add_by_name', 'เพิ่มผ่านการเลือกโปรโมชั่น');
		//$this->db->or_where('add_by_name', 'เพิ่มผ่านการเลือกโปรโมชั่นฟรี');
		return $this->db->get('tb_deposit')->row();
	}
	*/
	
	public function get_depositwithdraw($dealer=NULL){		
		// Query #1
		$this->db->select('"ฝาก" AS type, agent, name, username, creditbefore, credit, add_by_name, created');
		$this->db->from('tb_deposit');
		if($dealer)$this->db->where('dealer',$dealer);
		//$this->db->where('created BETWEEN "'.date('Y-m-d').' 00:00:00" AND "'.date('Y-m-d').' 11:59:59"');
		if($this->session->userdata('level')!= 'admin')$this->db->where('add_by_id', $this->session->userdata('ac_id'));
		$query1 = $this->db->get_compiled_select();		
		// Query #2		
		$this->db->select('"ถอน" AS type, agent, name, username, creditbefore, credit, add_by_name, created');
		$this->db->from('tb_withdraw');
		if($dealer)$this->db->where('dealer',$dealer);
		//$this->db->where('created BETWEEN "'.date('Y-m-d').' 00:00:00" AND "'.date('Y-m-d').' 11:59:59"');
		if($this->session->userdata('level')!= 'admin')$this->db->where('add_by_id', $this->session->userdata('ac_id'));
		$this->db->order_by('created', 'DESC');
		$this->db->limit(70);
		$query2 = $this->db->get_compiled_select();		
		// Merge both query results
		$Result = $this->db->query($query1." UNION ALL ".$query2);
		return $Result;
	}
	
	public function get_depositwithdraw_useractive($dealer=NULL,$start=NULL,$end=NULL){		
		// Query #1
		$this->db->select('de_id AS id');
		$this->db->from('tb_deposit');
		if($dealer)$this->db->where('dealer',$dealer);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');	
		$this->db->group_by('username');	
		$query1 = $this->db->get_compiled_select();		
		// Query #2		
		$this->db->select('wi_id AS id');
		$this->db->from('tb_withdraw');
		if($dealer)$this->db->where('dealer',$dealer);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->group_by('username');
		$query2 = $this->db->get_compiled_select();		
		// Merge both query results
		$Result = $this->db->query($query1." UNION ALL ".$query2);
		return $Result->num_rows();
	}
	
	public function get_sumcountcredit_user($dealer=NULL,$username=NULL,$start=NULL,$end=NULL){
		$this->db->select("COUNT(de_id) AS listtotal, COALESCE(SUM(credit),0) AS credittotal");
		if($dealer)$this->db->where('dealer',$dealer);
		if($username)$this->db->where('username',$username);
		if($start && $end)$this->db->where('created BETWEEN "'.$start.' 11:00:00" AND "'.$end.' 11:00:00"');
		//$this->db->where('created BETWEEN "'.$start.' 00:00:00" AND "'.$end.' 23:59:59"');
		//$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		return $this->db->get('tb_deposit')->row();
	}
	
	public function get_listdeposit_user($dealer=NULL,$username=NULL,$start=NULL,$end=NULL){
		$this->db->select("creditbefore, credit, tb_deposit.created, tb_worksheet.ws_id,pr_user_id,tb_promotion.pr_type,tb_promotion.title");
		$this->db->join('tb_worksheet','tb_deposit.de_id=tb_worksheet.de_id','left');
		$this->db->join('tb_promotion_user','tb_deposit.de_id=tb_promotion_user.de_id','left');
		$this->db->join('tb_promotion','tb_promotion_user.pr_id=tb_promotion.pr_id','left');
		if($dealer)$this->db->where('dealer',$dealer);
		if($username)$this->db->where('username',$username);
		$this->db->where('tb_deposit.created BETWEEN "'.$start.' 11:00:00" AND "'.$end.' 11:00:00"');
		//$this->db->where('created BETWEEN "'.$start.' 00:00:00" AND "'.$end.' 23:59:59"');
		//$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->order_by('tb_deposit.created', 'DESC');
		return $this->db->get('tb_deposit');
	}
	
	public function get_deposit_shift($dealer=NULL,$agent=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('"ฝาก" AS type, agent, name, username, creditbefore, credit, add_by_name, created');
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		return $this->db->get('tb_deposit');
	}
	
	public function get_sumcountcredit_top($start=NULL,$end=NULL,$limit){
		$this->db->select("wb.site_name, de.dealer, de.name, de.username, COUNT(de.de_id) AS listtotal, SUM(de.credit) AS credittotal");
		$this->db->from('tb_deposit de');
		$this->db->join('tb_website wb', 'de.site_id=wb.site_id', 'LEFT');
		$this->db->where('de.created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('de.add_by_name !=', 'เพิ่มผ่านการเลือกโปรโมชั่น');
		$this->db->where('de.add_by_name !=', 'เพิ่มผ่านการเลือกโปรโมชั่นฟรี');
		//$this->db->where('de.add_by_name !=', 'โยกเครดิตโดยสมาชิก');
		$this->db->not_like('add_by_name', 'โยกเครดิต', 'both');
		$this->db->group_by('de.username');	
		$this->db->order_by('credittotal','DESC');
		$this->db->limit($limit);
		return $this->db->get();
	}
	
	public function get_sumcountcreditnotwithdraw_top($start=NULL,$end=NULL,$limit){
		/*
		// Query #1
		$sql = '
			SELECT t.dealer,t.`name`,t.`username`,SUM(delisttotal) AS delisttotal,SUM(decredittotal) AS decredittotal,SUM(wilisttotal) AS wilisttotal,SUM(wicredittotal) AS wicredittotal
			FROM
			(
			SELECT dealer,`name`,`username`, COUNT(de_id) AS delisttotal,SUM(credit) AS decredittotal, 0 `wilisttotal`, 0 `wicredittotal`
			FROM tb_deposit WHERE `created` BETWEEN "'.$start.'" AND "'.$end.'" AND `add_by_name` != \'เพิ่มผ่านการเลือกโปรโมชั่น\'
			AND `add_by_name` != \'เพิ่มผ่านการเลือกโปรโมชั่นฟรี\'
			GROUP BY `username`
			
			union all
			
			SELECT dealer,`name`,`username`, 0 `delisttotal`, 0 `decredittotal`, COUNT(wi_id) AS wilisttotal,SUM(credit) AS wicredittotal
			FROM tb_withdraw WHERE `created` BETWEEN "'.$start.'" AND "'.$end.'"
			GROUP BY `username`
			) t
			GROUP BY t.`username`
			HAVING SUM(wilisttotal)=0
			ORDER BY t.decredittotal DESC
			LIMIT '.$limit.'
		';
		*/
		// Query #1
		$sql = '
			SELECT wb.site_name,t.dealer,t.`name`,t.`username`,SUM(delisttotal) AS delisttotal,SUM(decredittotal) AS decredittotal,SUM(wilisttotal) AS wilisttotal,SUM(wicredittotal) AS wicredittotal
			FROM
			(
			SELECT site_id, dealer,`name`,`username`, COUNT(de_id) AS delisttotal,SUM(credit) AS decredittotal, 0 `wilisttotal`, 0 `wicredittotal`
			FROM tb_deposit WHERE `created` BETWEEN "'.$start.'" AND "'.$end.'" AND `add_by_name` != \'เพิ่มผ่านการเลือกโปรโมชั่น\'
			AND `add_by_name` != \'เพิ่มผ่านการเลือกโปรโมชั่นฟรี\' AND `add_by_name` NOT LIKE \'%โยกเครดิต%\'
			GROUP BY `username`
			
			union all
			
			SELECT site_id, dealer,`name`,`username`, 0 `delisttotal`, 0 `decredittotal`, COUNT(wi_id) AS wilisttotal,SUM(credit) AS wicredittotal
			FROM tb_withdraw WHERE `created` BETWEEN "'.$start.'" AND "'.$end.'"
			GROUP BY `username`
			) t
			LEFT JOIN tb_website wb on wb.site_id = t.site_id
			GROUP BY t.`username`
			HAVING SUM(wilisttotal)=0
			ORDER BY t.decredittotal DESC
			LIMIT '.$limit.'
		';
		$Result = $this->db->query($sql);
		return $Result;
	}
	
	public function get_depositwithdraw_last($dealer=NULL,$agent=NULL,$enddate=NULL){		
		// Query #1
		$this->db->select('"ฝาก" AS type, creditagentbefore, credit, created');
		$this->db->from('tb_deposit');
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created <="'.$enddate.'"');
		$query1 = $this->db->get_compiled_select();		
		// Query #2		
		$this->db->select('"ถอน" AS type, creditagentbefore, credit, created');
		$this->db->from('tb_withdraw');
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created  <="'.$enddate.'"');
		$this->db->order_by('created', 'DESC');
		$this->db->limit(1);
		$query2 = $this->db->get_compiled_select();		
		// Merge both query results
		$Result = $this->db->query($query1." UNION ALL ".$query2);
		return $Result->row();
	}
	
	public function get_depositwithdraw_begin($dealer=NULL,$agent=NULL,$startdate=NULL){		
		// Query #1
		$this->db->select('"ฝาก" AS type, creditagentbefore, credit, created');
		$this->db->from('tb_deposit');
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created <="'.$startdate.'"');
		$query1 = $this->db->get_compiled_select();		
		// Query #2		
		$this->db->select('"ถอน" AS type, creditagentbefore, credit, created');
		$this->db->from('tb_withdraw');
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created  <="'.$startdate.'"');
		$this->db->order_by('created', 'DESC');
		$this->db->limit(1);
		$query2 = $this->db->get_compiled_select();		
		// Merge both query results
		$Result = $this->db->query($query1." UNION ALL ".$query2);
		return $Result->row();
	}
					
	// public function __destruct(){
	// 	$this->db->close();
	// }
	
}