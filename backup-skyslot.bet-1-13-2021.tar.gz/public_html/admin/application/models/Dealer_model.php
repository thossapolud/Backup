<?php if (!defined('BASEPATH')) {exit('No direct script access allowed');}

class Dealer_model extends CI_Model {

	public function get_by_code($dl_code){
		$this->db->where('dl_code', $dl_code);
		return $this->db->get('tb_dealer')->row();
	}

	// 0 = inactive / 1 = active
	public function get_by_dealer_status($dl_status){
		$this->db->where('dl_status', $dl_status);
		$this->db->order_by('dl_id', 'asc');
		return $this->db->get('tb_dealer');
	}

    public function __destruct(){
		$this->db->close();
	}

}