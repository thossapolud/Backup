<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Transfer_channel_model extends CI_Model{

	public function get_all(){
		return $this->db->get('tb_xfer_channel');
	}

	public function get_detail_all(){
		return $this->db->get('tb_xfer_channel_detail');
	}

	public function get_by_userpass_id($userpass_id){
		$this->db->select('xh.xfer_h_id, xh.site_id, xh.xfer_h_name, xh.xfer_h_desc, xh.xfer_h_type, xh.xfer_h_status, xd.xfer_d_id, xd.userpass_id');
		$this->db->from('tb_xfer_channel xh');
		$this->db->join('tb_xfer_channel_detail xd', 'xd.xfer_h_id = xh.xfer_h_id');
		$this->db->where('xd.userpass_id', $userpass_id);
		return $this->db->get()->row();
		// $this->db->select('xh.xfer_h_id, xh.site_id, xh.xfer_h_name, xh.xfer_h_desc, xh.xfer_h_type, xh.xfer_h_status, xd.xfer_d_id, xd.userpass_id, up.up_status');
		// $this->db->from('tb_xfer_channel xh');
		// $this->db->join('tb_xfer_channel_detail xd', 'xd.xfer_h_id = xh.xfer_h_id');
		// $this->db->join('tb_userpass up', 'xd.userpass_id = up.userpass_id');
		// $this->db->where('xd.userpass_id', $userpass_id);
		// return $this->db->get()->row();
	}

	public function get_by_xfer_h_id($xfer_h_id){
		$this->db->where('xfer_h_id', $xfer_h_id);
		return $this->db->get('tb_xfer_channel')->row();
	}

	public function get_detail_by_xfer_h_id($xfer_h_id){
		$this->db->select('xd.xfer_d_id, xd.userpass_id, up.type, up.bankname, up.acnum');
		$this->db->from('tb_xfer_channel_detail xd');
		$this->db->join('tb_userpass up', 'up.userpass_id = xd.userpass_id');
		$this->db->where('xd.xfer_h_id', $xfer_h_id);
		return $this->db->get();
	}

	public function get_by_xfer_h_name($xfer_h_name){
		$this->db->where('xfer_h_name', $xfer_h_name);
		return $this->db->get('tb_xfer_channel')->row();
	}

	public function get_by_xfer_h_status($xfer_h_status){
		$this->db->where('xfer_h_status', $xfer_h_status);
		$this->db->order_by('xfer_h_created', 'asc');
		return $this->db->get('tb_xfer_channel');
	}

	public function get_deposit_by_site_id($site_id){
		$this->db->where('site_id', $site_id);
		$this->db->where('xfer_h_type', 'deposit');
		$this->db->where('xfer_h_status', 1);
		$this->db->order_by('xfer_h_created', 'asc');
		return $this->db->get('tb_xfer_channel');
	}

	public function get_withdraw_by_site_id($site_id){
		$this->db->where('site_id', $site_id);
		$this->db->where('xfer_h_type', 'withdraw');
		$this->db->where('xfer_h_status', 1);
		$this->db->order_by('xfer_h_created', 'asc');
		return $this->db->get('tb_xfer_channel');
	}

	public function add_xfer_h($data){
		return $this->db->insert('tb_xfer_channel', $data);
	}

	public function add_xfer_d($data){
		return $this->db->insert('tb_xfer_channel_detail', $data);
	}

	public function edit_xfer_h($data, $cond){
		return $this->db->update('tb_xfer_channel', $data, $cond);
	}

	public function delete_xfer_d($cond){
		return $this->db->delete('tb_xfer_channel_detail', $cond);
	}

	public function __destruct(){
		$this->db->close();
	}
	
}