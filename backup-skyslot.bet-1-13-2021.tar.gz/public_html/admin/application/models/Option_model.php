<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Option_model extends CI_Model {

	public function get_by_opt_code($opt_code){
		$this->db->where('opt_code', $opt_code);
		$this->db->order_by('opt_code', 'asc');
		$this->db->order_by('opt_name', 'asc');
		$this->db->order_by('opt_value', 'asc');
		return $this->db->get('tb_options');
	}

	public function get_by_opt_name($opt_code,$opt_name){
		$this->db->where('opt_code', $opt_code);
		$this->db->where('opt_name', $opt_name);
		$this->db->order_by('opt_value', 'asc');
		return $this->db->get('tb_options');
	}
	
	public function get_by_opt_name_value($opt_code,$opt_name,$opt_value){
		$this->db->where('opt_code', $opt_code);
		$this->db->where('opt_name', $opt_name);
		$this->db->where('opt_value', $opt_value);
		return $this->db->get('tb_options')->row();
	}

	public function add_option($data){
		return $this->db->insert('tb_options', $data);
	}

	public function delete_option($cond){
		return $this->db->delete('tb_options', $cond);
	}

    public function __destruct(){
		$this->db->close();
	}

}