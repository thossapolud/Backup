<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Worksheet_model extends CI_Model{
	
	/************************ ดึงใบงาน ด้วย ID*************************/
	public function get_worksheet_by_id($ws_id=NULL){
		$this->db->select('free, free_img, free_img1,ws_code,ws_type,ws.site_id,site.site_name,ws_dealer,ws_debank,ws_debankname,ws_debankac,ws_debankacnum, uag1.username AS u1username, u1.phone, u1.nickname AS u1nickname, u1.accountname, u1.bankno, u1.bank, u1.withdrawcode, uag2.username AS u2username, u2.nickname AS u2nickname, ws_dealer_target, ws_date, ws_credit, ws_pro, ws_total, ws_deimg, ws_wiimg, ws_wibank, ws_wibankname, ws.created, ws_id,st_in,st_datein,st_comment,a1.name as a1name, a2.name as a2name,a3.name as a3name,b_date,b_status,b_comment,m_date,m_status,c_comment,b_comment,title,m_comment,n_status,n_date,n_id');
		$this->db->join('tb_users u1', 'u1.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag1', 'uag1.user_id=u1.user_id AND uag1.dealer=ws.ws_dealer', 'LEFT');
		$this->db->join('tb_users u2', 'u2.user_id=ws.user_id_target', 'LEFT');
		$this->db->join('tb_users_agent uag2', 'uag2.user_id=u2.user_id AND uag2.dealer=ws.ws_dealer_target', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=ws.c_id', 'LEFT');
		$this->db->join('tb_account a2', 'a2.ac_id=ws.b_id', 'LEFT');
		$this->db->join('tb_account a3', 'a3.ac_id=ws.m_id', 'LEFT');
		$this->db->join('tb_statement', 'tb_statement.st_id=ws.st_id', 'LEFT');
		$this->db->join('tb_promotion', 'tb_promotion.pr_id=ws.promotion_id', 'LEFT');
		$this->db->join('tb_website site', 'site.site_id=ws.site_id', 'LEFT');
		$this->db->where('ws_id', $ws_id);
		return $this->db->get('tb_worksheet ws');
	}
	
	/************************ ดึงใบงานค้างของ User *************************/	
	public function get_remain_by_userid($user_id=NULL){
		$this->db->where('user_id', $user_id);
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 0);
		$this->db->where('m_status', 0);
		return $this->db->count_all_results('tb_worksheet');
	}
	
	/************************ ดึงใบงานที่ยังไม่ได้ปรับสถานะของ Bank ด้วย ID*************************/
	public function get_worksheet_bank_by_id($ws_id=NULL){
		$this->db->select('ws_code, ws_type,ws.site_id,site.site_name, ws_dealer,ws_debank,ws_debankname,ws_debankac,ws_debankacnum, nickname, accountname, bankno, bank, withdrawcode, uag.username, ws_date, ws_credit, ws_pro,ws_total, ws_deimg, ws.created, name, ws_id, c_comment,title,b_flag,b_flag_expire');
		$this->db->join('tb_users', 'tb_users.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws.ws_dealer', 'LEFT');
		$this->db->join('tb_account', 'tb_account.ac_id=ws.c_id', 'LEFT');
		$this->db->join('tb_promotion', 'tb_promotion.pr_id=ws.promotion_id', 'LEFT');
		$this->db->join('tb_website site', 'site.site_id=ws.site_id', 'LEFT');
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 0);
		$this->db->where('m_status', 0);
		$this->db->where('ws_id', $ws_id);
		return $this->db->get('tb_worksheet ws');
	}
	
	/************************ ดึงใบงาน Withdraw ที่ยังไม่ได้ปรับสถานะของ Bank ด้วย ID*************************/
	public function get_worksheet_witdraw_bank_by_id($ws_id=NULL){
		$this->db->select('ws.user_id, ws_code, ws_type,ws.site_id,site.site_name, ws_dealer,ws_debank,ws_debankname,ws_debankac,ws_debankacnum, nickname, accountname, bankno, bank, withdrawcode, uag.username, uag.userpass_id, ws_date, ws_credit, ws_deimg, ws.created, a1.name as a1name, ws_id, c_comment,title,m_status,m_date,a3.name as a3name,b_flag,b_flag_id,b_flag_expire');
		$this->db->join('tb_users', 'tb_users.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws.ws_dealer', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=ws.c_id', 'LEFT');
		//$this->db->join('tb_account a2', 'a2.ac_id=ws.b_id', 'LEFT');
		$this->db->join('tb_account a3', 'a3.ac_id=ws.m_id', 'LEFT');
		$this->db->join('tb_promotion', 'tb_promotion.pr_id=ws.promotion_id', 'LEFT');
		$this->db->join('tb_website site', 'site.site_id=ws.site_id', 'LEFT');
		$this->db->where('ws_type', 'withdraw');
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 0);
		$this->db->where('m_status', 1);
		$this->db->where('ws_id', $ws_id);
		return $this->db->get('tb_worksheet ws');
	}
	
	/************************ ดึงใบงาน Withdraw ที่รอจัดการของ Bank ด้วย ID*************************/
	public function get_worksheet_withdraw_auto_bank_by_id($ws_id=NULL){
		$this->db->select('ws.user_id, ws_code, ws_type, ws_dealer,ws_debank,ws_debankname,ws_debankac,ws_debankacnum, nickname, accountname, bankno, bank, withdrawcode, uag.username, uag.userpass_id, ws_date, ws_credit, ws_deimg, ws.created, a1.name as a1name, ws_id, c_comment,title,m_status,m_date,a3.name as a3name,b_flag,b_flag_id,b_flag_expire,ws_wibank,ws_wibankac,ws_wibankname,b_status,ws.site_id');
		$this->db->join('tb_users', 'tb_users.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws.ws_dealer', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=ws.c_id', 'LEFT');
		//$this->db->join('tb_account a2', 'a2.ac_id=ws.b_id', 'LEFT');
		$this->db->join('tb_account a3', 'a3.ac_id=ws.m_id', 'LEFT');
		$this->db->join('tb_promotion', 'tb_promotion.pr_id=ws.promotion_id', 'LEFT');
		$this->db->where('ws_type', 'withdraw');
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 4);
		$this->db->where('m_status', 1);
		$this->db->where('ws_id', $ws_id);
		return $this->db->get('tb_worksheet ws');
	}
	/************************ ดึงใบงานที่ยังไม่ได้ปรับสถานะของ Manage ทั้งหมด แยกตาม Dealer *************************/
	public function get_worksheet_manage_all($dealer=NULL){
		$this->db->select('ws_id, ws_type, uag.username');
		$this->db->join('tb_users', 'tb_users.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws.ws_dealer', 'LEFT');
		//$this->db->join('tb_account', 'tb_account.ac_id=ws.c_id', 'LEFT');
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 0);
		$this->db->where('ws_dealer',$dealer);
		return $this->db->get('tb_worksheet ws');
	}
	
	/************************ ดึงใบงาน Withdraw ที่ยังไม่ได้ปรับสถานะของ Manage ด้วย ID*************************/
	public function get_worksheet_withdraw_manage_by_id($ws_id=NULL,$dealer=NULL){
		$this->db->select('ws_code, ws_type,ws.site_id,site.site_name, ws_dealer,ws_debank,ws_debankname,ws_debankac,ws_debankacnum, tb_users.user_id, uag.userpass_id, tb_users.phone, nickname, accountname, bankno, bank, withdrawcode, uag.username, ws_date, ws_credit, ws_deimg, ws_wiimg, ws_total, ws.created, ws_id,st_in,st_datein,st_comment,a1.name as a1name, a2.name as a2name,b_date,c_comment,m_flag,m_flag_expire');
		$this->db->join('tb_users', 'tb_users.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws.ws_dealer', 'LEFT');
		//$this->db->join('tb_account', 'tb_account.ac_id=ws.c_id', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=ws.c_id', 'LEFT');
		$this->db->join('tb_account a2', 'a2.ac_id=ws.b_id', 'LEFT');
		$this->db->join('tb_statement', 'tb_statement.st_id=ws.st_id', 'LEFT');
		$this->db->join('tb_website site', 'site.site_id=ws.site_id', 'LEFT');
		$this->db->where('ws_type', 'withdraw');
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 0);
		$this->db->where('m_status', 0);
		$this->db->where('ws_id', $ws_id);
		if($dealer)$this->db->where('ws_dealer',$dealer);
		return $this->db->get('tb_worksheet ws');
	}
	
	/************************ ดึงใบงานที่ยังไม่ได้ปรับสถานะของ Manage ด้วย ID*************************/
	public function get_worksheet_manage_by_id($ws_id=NULL,$dealer=NULL){
		$this->db->select('ws.user_id, free, free_img,free_img1,promotion_id,ws_code,ws_type,ws.site_id,site.site_name,ws_dealer,ws_debank,ws_debankname,ws_debankac,ws_debankacnum, tb_users.phone,uag.usercredit, nickname, accountname, bankno, bank, withdrawcode, uag.username, uag.userpass_id ,tb_users.newmember, ws_date, ws_credit, ws_pro,ws_total, ws_deimg, ws_wiimg, ws.created, ws_id,st_in,st_datein,st_comment,a1.name as a1name, a2.name as a2name,b_date,c_comment,b_comment,m_flag,m_flag_expire');
		$this->db->join('tb_users', 'tb_users.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws.ws_dealer', 'LEFT');
		//$this->db->join('tb_account', 'tb_account.ac_id=ws.c_id', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=ws.c_id', 'LEFT');
		$this->db->join('tb_account a2', 'a2.ac_id=ws.b_id', 'LEFT');
		$this->db->join('tb_statement', 'tb_statement.st_id=ws.st_id', 'LEFT');
		$this->db->join('tb_website site', 'site.site_id=ws.site_id', 'LEFT');
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 0);
		$this->db->where('ws_id', $ws_id);
		if($dealer)$this->db->where('ws_dealer',$dealer);
		return $this->db->get('tb_worksheet ws');
	}
	
	/************************ ดึงใบงาน โยกเครดิต ที่ยังไม่ได้ปรับสถานะของ Manage ด้วย ID*************************/
	public function get_worksheet_transfer_manage_by_id($ws_id=NULL,$dealer=NULL){
		$this->db->select('ws.site_id,site.site_name,ws_code, ws_type, ws_dealer,ws_debank,ws_debankname,ws_debankac,ws_debankacnum, u1.user_id AS u1user_id, uag1.userpass_id AS u1userpass_id, uag1.username AS u1username, u1.phone, u1.nickname AS u1nickname, u1.accountname, u1.bankno, u1.bank, u1.withdrawcode, ws_dealer_target, u2.user_id AS u2user_id, uag2.userpass_id AS u2userpass_id, uag2.username AS u2username, u2.nickname AS u2nickname, ws_date, ws_credit, ws_pro, ws_total, ws.created, ws_id, a1.name as a1name, c_comment,m_flag,m_flag_expire');		
		$this->db->join('tb_users u1', 'u1.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag1', 'uag1.user_id=u1.user_id AND uag1.dealer=ws.ws_dealer', 'LEFT');
		$this->db->join('tb_users u2', 'u2.user_id=ws.user_id_target', 'LEFT');
		$this->db->join('tb_users_agent uag2', 'uag2.user_id=u2.user_id AND uag2.dealer=ws.ws_dealer_target', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=ws.c_id', 'LEFT');
		$this->db->join('tb_website site', 'site.site_id=ws.site_id', 'LEFT');
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 0);
		$this->db->where('ws_id', $ws_id);
		if($dealer)$this->db->where('ws_dealer',$dealer);
		return $this->db->get('tb_worksheet ws');
	}
	
		
	/************************ ดึงยอดใบงาน ฝาก ตามเวลาปิดกะ แยกตามเอเย่นต์ อ้างอิงด้วย วันที่แจ้งลูกค้า  *************************/
	public function get_worksheet_deposit_shiftdate($dealer=NULL,$userpass_id=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('uag.userpass_id, IFNULL(SUM(ws_credit), 0)  AS ws_credit, IFNULL(SUM(ws_pro), 0) AS ws_pro, IFNULL(SUM(ws_total), 0) AS ws_total');
		$this->db->join('tb_users', 'tb_users.user_id=ws.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws.ws_dealer', 'LEFT');
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 1);
		$this->db->where('n_status', 1);
		$this->db->where('ws_type', 'deposit');
		$this->db->where('userpass_id', $userpass_id);
		$this->db->where('ws_dealer',$dealer);
		$this->db->where('n_date BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		return $this->db->get('tb_worksheet ws')->row();
	}
	
	/************************ ดึงยอดใบงาน ฝาก ตามเวลาปิดกะ อ้างอิงด้วย แบงค์  *************************/
	public function get_worksheet_deposit_credit($ws_debank=NULL,$ws_debankac=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('COUNT(ws_id) AS listtotal, IFNULL(SUM(ws_credit), 0)  AS ws_credit',false);
		$this->db->where('ws_debank', $ws_debank);
		$this->db->where('ws_debankac', $ws_debankac);
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 1);
		$this->db->where('n_status', 1);
		$this->db->where('ws_type', 'deposit');
		$this->db->where('n_date BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		return $this->db->get('tb_worksheet')->row();
	}
	
	/************************ ดึงยอดใบงาน ถอน ตามเวลาปิดกะ อ้างอิงด้วย แบงค์  *************************/
	public function get_worksheet_withdraw_credit($ws_wibank=NULL,$ws_wibankac=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('COUNT(ws_id) AS listtotal, IFNULL(SUM(ws_credit), 0)  AS ws_credit',false);
		$this->db->where('ws_wibank', $ws_wibank);
		$this->db->where('ws_wibankac', $ws_wibankac);
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 1);
		$this->db->where('n_status', 1);
		$this->db->where('ws_type', 'withdraw');
		$this->db->where('n_date BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		return $this->db->get('tb_worksheet')->row();
	}
	
	/************************ ดึงยอดรวมใบงาน ถอน ตามเวลาเปิดใบงาน อ้างอิงด้วย แบงค์  *************************/
	public function get_worksheet_withdraw_sumcredit($ws_wibank=NULL,$ws_wibankac=NULL,$ws_wibankname=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('COUNT(ws_id) AS listtotal, IFNULL(SUM(ws_credit), 0)  AS ws_credit',false);
		if($ws_wibank)$this->db->where('ws_wibank', $ws_wibank);
		if($ws_wibankac)$this->db->where('ws_wibankac', $ws_wibankac);
		if($ws_wibankname)$this->db->where('ws_wibankname', $ws_wibankname);		
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 1);
		//$this->db->where('n_status', 1);
		$this->db->where('ws_type', 'withdraw');
		$this->db->where('ws_date BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		return $this->db->get('tb_worksheet')->row();
	}
	
	/************************ ดึงยอดรวมใบงาน ถอน ตามเวลาเปิดใบงาน อ้างอิงด้วย แบงค์  *************************/
	public function get_worksheet_withdraw_report($ws_wibank=NULL,$ws_wibankac=NULL,$ws_wibankname=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('ws_date, ws_credit');
		$this->db->where('ws_wibank', $ws_wibank);
		$this->db->where('ws_wibankac', $ws_wibankac);
		$this->db->where('ws_wibankname', $ws_wibankname);		
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 1);
		//$this->db->where('n_status', 1);
		$this->db->where('ws_type', 'withdraw');
		$this->db->where('ws_date BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		return $this->db->get('tb_worksheet');
	}
	
	/************************ ดึงยอดรวมใบงาน ถอน ตามเวลาเปิดใบงาน อ้างอิงด้วย แบงค์ และกรุ๊ปตามสินค้า  *************************/
	public function get_worksheet_withdraw_sumcredit_group($ws_wibank=NULL,$ws_wibankac=NULL,$ws_wibankname=NULL,$startdate=NULL,$enddate=NULL,$dealer=NULL){
		$this->db->select('COUNT(ws_id) AS listtotal, IFNULL(SUM(ws_credit), 0)  AS ws_credit,ws_dealer',false);
		$this->db->where('ws_wibank', $ws_wibank);
		$this->db->where('ws_wibankac', $ws_wibankac);
		$this->db->where('ws_wibankname', $ws_wibankname);		
		$this->db->where('c_status', 1);
		$this->db->where('b_status', 1);
		$this->db->where('m_status', 1);
		$this->db->where('ws_type', 'withdraw');
		if($dealer)$this->db->where('ws_dealer',$dealer);
		$this->db->where('ws_date BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		$this->db->group_by('ws_dealer');
		return $this->db->get('tb_worksheet');
	}
				
	public function __destruct(){
		$this->db->close();
	}
	
}