<?php if (!defined('BASEPATH')) { exit('No direct script access allowed'); }

class Agent_model extends CI_Model {

	// Get agent data by agent userpass_id
	public function get_by_agent_id($userpass_id) {
		$this->db->select('*');
		$this->db->where('userpass_id', $userpass_id);
		$this->db->where('acnum', 'dealer');
		return $this->db->get('tb_userpass')->row();
	}

	// Get agents data by dealer code
	public function get_by_dealer($dealer = NULL) {
		$this->db->select('*');
		$this->db->where('type', $dealer);
		$this->db->where('acnum', 'dealer');
		$this->db->order_by('created', 'asc');
		return $this->db->get('tb_userpass');
	}

	// Get agents data by site id and dealer code
	public function get_by_site_id_and_dealer($site_id = NULL, $dealer = NULL) {
		$this->db->select('*');
		$this->db->where('site_id', $site_id);
		$this->db->where('type', $dealer);
		$this->db->where('acnum', 'dealer');
		$this->db->order_by('created', 'asc');
		return $this->db->get('tb_userpass');
	}

	// Get agents data by site id and dealer code
	public function get_default_by_site_id_and_dealer($site_id = NULL, $dealer = NULL) {
		$this->db->select('*');
		$this->db->where('site_id', $site_id);
		$this->db->where('type', $dealer);
		$this->db->where('acnum', 'dealer');
		$this->db->where('default_agent', 1);
		return $this->db->get('tb_userpass')->row();
	}

	// Get agent interface data by agent userpass_id
	public function get_interface_by_agent_id($agent_id) {
		$this->db->where('itf_agent_id', $agent_id);
		return $this->db->get('tb_interface_agent')->row();
	}

	// Get agent interface data by agent userpass_id
	public function get_interface_by_itf_auth($itf_auth) {
		$this->db->where('itf_auth', $itf_auth);
		return $this->db->get('tb_interface_agent')->row();
	}
	
   public function __destruct(){
		$this->db->close();
	}

}