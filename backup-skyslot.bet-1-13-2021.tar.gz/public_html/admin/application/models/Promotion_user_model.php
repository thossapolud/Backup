<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Promotion_user_model extends CI_Model{
		
	/************************ ดึงยอดรวม โปรโมชั่นที่ลูกค้ารับ *************************/
	public function get_promotion_sumcredit($dealer=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('tb_promotion_user.pr_id, tb_promotion.pr_type, tb_promotion.title, SUM(rate_pro) AS credit',false);
		$this->db->join('tb_promotion','tb_promotion.pr_id=tb_promotion_user.pr_id');
		$this->db->where('tb_promotion_user.created BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		if($dealer)$this->db->where('pr_user_dealer',$dealer);
		$this->db->group_by('tb_promotion_user.pr_id');
		$this->db->order_by('credit', 'desc');
		return $this->db->get('tb_promotion_user');
	}
	
	/************************ ดึงยอดรวม โปรโมชั่นที่ลูกค้ารับ *************************/
	public function get_promotion_sumcreditall($startdate=NULL,$enddate=NULL){
		$this->db->select('SUM(rate_pro) AS credit');
		//$this->db->join('tb_promotion','tb_promotion.pr_id=tb_promotion_user.pr_id');
		$this->db->where('tb_promotion_user.created BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		//$this->db->group_by('tb_promotion_user.pr_id');
		//$this->db->order_by('credit', 'desc');
		return $this->db->get('tb_promotion_user')->row();
	}
	
	/************************ ดึง โปรโมชั่นที่ลูกค้ารับ *************************/
	public function get_promotion_report($dealer=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('tb_users_agent.username, tb_promotion.pr_type, tb_promotion.title, rate_pro, tb_promotion_user.created');
		$this->db->join('tb_promotion','tb_promotion.pr_id=tb_promotion_user.pr_id');
		$this->db->join('tb_users','tb_users.user_id=tb_promotion_user.user_id');
		$this->db->join('tb_users_agent','tb_users.user_id=tb_users_agent.user_id AND tb_users_agent.dealer="'.$dealer.'"');
		$this->db->where('tb_promotion_user.created BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		if($dealer)$this->db->where('pr_user_dealer',$dealer);
		$this->db->order_by('created', 'desc');
		return $this->db->get('tb_promotion_user');
	}
					
	public function __destruct(){
		$this->db->close();
	}
	
}