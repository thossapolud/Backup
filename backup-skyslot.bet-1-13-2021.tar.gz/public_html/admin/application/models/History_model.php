<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class History_model extends CI_Model{
		
	public function get_by_acid($acid=NULL){
		$this->db->select('action, ip_address, detail, created');
		$this->db->where('ac_id', $acid);
		$this->db->order_by('created', 'desc');
		$this->db->limit(200);
		return $this->db->get('tb_history');
	}
				
	public function __destruct(){
		$this->db->close();
	}
	
}