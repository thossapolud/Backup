<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Account_model extends CI_Model{
		
	public function get_by_id($id=NULL){
		$this->db->select('*');
		$this->db->where('ac_id', $id);
		return $this->db->get('tb_account')->row();
	}
	
	public function get_by_userpass($username=NULL,$password=NULL,$status=NULL){
		$this->db->select('*');
		$this->db->where('username', $username);
		$this->db->where('password', md5($password));
		$this->db->where('status', $status);
		return $this->db->get('tb_account');
	}
	
	public function get_by_username($username=NULL,$accountid=NULL){
		$this->db->select('*');
		$this->db->where('username', $username);
		if($accountid)$this->db->where('ac_id !=',$accountid);
		return $this->db->get('tb_account');
	}
			
	public function __destruct(){
		$this->db->close();
	}
	
}