<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model{
		
	public function get_by_id($id=NULL,$dealer=NULL){
		$this->db->select('tb_users.*,uag.user_agid,uag.site_id,uag.userpass_id,uag.dealer,uag.username,uag.password,uag.default_deposit,tb_userpass.username AS agusername,tb_userpass.password AS agpassword');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->join('tb_userpass', 'tb_userpass.userpass_id=uag.userpass_id', 'LEFT');
		$this->db->where('uag.dealer', $dealer);
		$this->db->where('tb_users.user_id', $id);
		return $this->db->get('tb_users')->row();
	}
	
	public function get_user_by_bankno($bankno = NULL, $site_id = NULL, $dealer = NULL, $userpass_id = NULL) {
		$this->db->select('*');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->where('bankno', $bankno);
		if($site_id)$this->db->where('site_id', $site_id);
		if($dealer)$this->db->where('uag.dealer', $dealer);
		if($userpass_id)$this->db->where('userpass_id', $userpass_id);
		return $this->db->get('tb_users');
	}
	public function get_by_bankno($bankno=NULL){
		$this->db->select('*');
		$this->db->where('bankno', $bankno);
		return $this->db->get('tb_users')->row();
	}
	
	public function get($dealer=NULL, $limit=NULL){
		$this->db->select('user_id, type, status, username, accountname, refer, created');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->where('uag.dealer', $dealer);
		$this->db->limit($limit);
		$this->db->order_by('created', 'desc');
		return $this->db->get('tb_users');
	}
	
	public function get_by_username($dealer=NULL,$username=NULL){
		$this->db->select('us.*,up.username AS agusername,uag.site_id,uag.dealer,uag.username');
		$this->db->join('tb_users_agent uag', 'uag.user_id=us.user_id', 'LEFT');
		$this->db->join('tb_userpass up', 'up.userpass_id=uag.userpass_id', 'LEFT');
		if($dealer)$this->db->where('uag.dealer', $dealer);
		$this->db->where('uag.username', $username);
		$this->db->limit(1);
		return $this->db->get('tb_users us')->row();
	}
	
	public function get_by_phone($phone=NULL){
		$this->db->select('uag.site_id,uag.dealer,uag.username,uag.default_deposit,us.accountname,us.phone,us.bank,us.bankno,up.username AS agusername,us.withdrawcode AS withdrawcode,uag.uag_created');
		$this->db->join('tb_users_agent uag', 'uag.user_id=us.user_id', 'LEFT');
		$this->db->join('tb_userpass up', 'up.userpass_id=uag.userpass_id', 'LEFT');
		$this->db->where('us.phone', $phone);
		return $this->db->get('tb_users us');
	}
		
	public function get_numrows_register_today($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->select('user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		if($dealer)$this->db->where('uag.dealer', $dealer);
		$this->db->where('uag_status', 'ใช้');
		//return $this->db->get('tb_users')->num_rows();
		return $this->db->count_all_results('tb_users');
	}
	/**
	 * Get total number of users register by date
	 */
	public function get_num_register_by_date($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent_id=NULL){
		$this->db->select('user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		if($site_id)$this->db->where('site_id', $site_id);
		if($dealer)$this->db->where('uag.dealer', $dealer);
		if($agent_id)$this->db->where('userpass_id', $agent_id);
		$this->db->where('uag_status', 'ใช้');
		return $this->db->count_all_results('tb_users');
	}
	public function get_num_register_deposit_by_date($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent_id=NULL){
		$this->db->select('tb_users.user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->join('tb_worksheet','tb_users.user_id=tb_worksheet.user_id','right');
		$this->db->where('tb_users.created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('tb_worksheet.ws_type','deposit');
		if($site_id)$this->db->where('tb_users.site_id', $site_id);
		if($dealer)$this->db->where('tb_users.dealer', $dealer);
		if($agent_id)$this->db->where('tb_users.userpass_id', $agent_id);
		//$this->db->where('nickname !=','Username ซ้ำ');
		$this->db->group_by('tb_users.user_id');
		return $this->db->get('tb_users')->num_rows();
		//return $this->db->count_all_results('tb_users');
	}
	
	/**
	 * Get total number of users active (do deposit or withdraw) by date
	 */
	public function get_num_active_by_date($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent=NULL){
		// Query #1
		$this->db->select('username AS username');
		$this->db->from('tb_deposit');
		if($site_id)$this->db->where('site_id', $site_id);
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent', $agent);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$query1 = $this->db->get_compiled_select();
		// Query #2
		$this->db->select('username AS username');
		$this->db->from('tb_withdraw');
		if($site_id)$this->db->where('site_id', $site_id);
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent', $agent);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$query2 = $this->db->get_compiled_select();
		// Merge both query results
		// $Result = $this->db->query($query1." UNION ".$query2);
		
		return $this->db->count_all_results(" ( ".$query1." UNION ".$query2." ) as t ");
	}
	public function get_numrows_registerdeposit_todby_($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->select('tb_users.user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->join('tb_worksheet','tb_users.user_id=tb_worksheet.user_id','right');
		$this->db->where('tb_users.created BETWEEN "'.$start.'" AND "'.$end.'"');
		if($dealer)$this->db->where('uag.dealer', $dealer);
		//$this->db->where('nickname !=','Username ซ้ำ');
		$this->db->where('uag_status', 'ใช้');
		$this->db->group_by('tb_users.user_id');
		return $this->db->get('tb_users')->num_rows();
		//return $this->db->count_all_results('tb_users');
	}
	
	public function get_numrows_open_today($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->select('user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('open_date BETWEEN "'.$start.'" AND "'.$end.'"');
		if($dealer)$this->db->where('uag.dealer', $dealer); $this->db->where('waitopen', 'N');
		$this->db->where('uag_status', 'ใช้');
		//return $this->db->get('tb_users')->num_rows();
		return $this->db->count_all_results('tb_users');
	}
	
	public function get_numrows_oldopen_today($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->select('user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->where('open_date BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('created NOT BETWEEN "'.$start.'" AND "'.$end.'"', NULL, FALSE);
		$this->db->where('open_date !=', 'NULL');
		if($dealer)$this->db->where('uag.dealer', $dealer); $this->db->where('waitopen', 'N');
		$this->db->where('uag_status', 'ใช้');
		//return $this->db->get('tb_users')->num_rows();
		return $this->db->count_all_results('tb_users');
	}
	/**
	 * Get total number of user
	 *
	 * @param string $dealer  Dealer
	 * @return integer  Total number of user
	 */
	public function get_numrows_register($dealer=NULL){
		$this->db->select('user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		if($dealer)$this->db->where('uag.dealer', $dealer);
		$this->db->where('uag_status', 'ใช้');
		//return $this->db->get('tb_users')->num_rows();
		return $this->db->count_all_results('tb_users');
	}
	/**
	 * Get total number of users
	 */
	public function get_num_register($site_id=NULL, $dealer=NULL, $agent_id=NULL){
		$this->db->select('user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		if($site_id)$this->db->where('site_id', $site_id);
		if($dealer)$this->db->where('uag.dealer', $dealer);
		if($agent_id)$this->db->where('userpass_id', $agent_id);
		$this->db->where('uag_status', 'ใช้');
		return $this->db->count_all_results('tb_users');
	}
	/**
	 * Get total unique website among users
	 */
	public function get_num_register_site(){
		$this->db->distinct();
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		$this->db->select('site_id');
		$this->db->where('uag_status', 'ใช้');
		return $this->db->count_all_results('tb_users');
	}
	
	public function get_numrows_open($dealer=NULL){
		$this->db->select('user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		if($dealer)$this->db->where('uag.dealer', $dealer); 
		$this->db->where('waitopen', 'N');
		$this->db->where('uag_status', 'ใช้');
		//return $this->db->get('tb_users')->num_rows();
		return $this->db->count_all_results('tb_users');
	}
	
	public function get_numrows_waitopen($dealer=NULL){
		$this->db->select('user_id');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id', 'LEFT');
		if($dealer)$this->db->where('uag.dealer', $dealer); $this->db->where('waitopen', 'Y');
		$this->db->where('uag_status', 'ใช้');
		//return $this->db->get('tb_users')->num_rows();
		return $this->db->count_all_results('tb_users');
	}
	
	/**
	 * Get total number of new user register between datetime range
	 *
	 * @param string $dealer  Dealer
	 * @param string $start  Start datetime to count
	 * @param string $end  End datetime to count
	 * @return integer  Total number of new user register
	 */
	public function get_numrows_register_by_date($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer="'.$dealer.'"', 'LEFT');
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('uag.dealer', $dealer); 
		$this->db->where('uag_status', 'ใช้');
		return $this->db->count_all_results('tb_users');
	}
	
	public function get_numrows_open_by_date($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer="'.$dealer.'"', 'LEFT');
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('open_date BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('uag.dealer', $dealer); 
		$this->db->where('uag_status', 'ใช้');
		$this->db->where('waitopen', 'N');
		return $this->db->count_all_results('tb_users');
	}
	
	public function get_numrows_oldopen_by_date($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer="'.$dealer.'"', 'LEFT');
		$this->db->where('open_date BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('created NOT BETWEEN "'.$start.'" AND "'.$end.'"', NULL, FALSE);
		$this->db->where('uag.dealer', $dealer); 
		$this->db->where('uag_status', 'ใช้');
		$this->db->where('open_date !=', 'NULL');
		$this->db->where('waitopen', 'N');
		return $this->db->count_all_results('tb_users');
	}
	
	/************************ *************************/
	public function get_user_by_dealer($dealer,$user_id=NULL){
		$this->db->select('user_id, uag.username, nickname, accountname, phone, bankno, bank, withdrawcode');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer="'.$dealer.'"', 'LEFT');
		$this->db->where('uag.dealer', $dealer); 
		$this->db->where('username !=',''); 
		$this->db->where('waitopen', 'N');
		$this->db->where('uag_status','ใช้');
		$this->db->where('nickname !=','');
		$this->db->where('nickname !=','ว่าง');
		if($user_id)$this->db->where('user_id !=', $user_id);
		return $this->db->get('tb_users');
	}
	public function search_by_username($site_id = NULL, $dealer = NULL, $username = NULL, $limit = NULL){
		$this->db->select('tb_users.user_id, uag.username, nickname, accountname, phone, bankno, bank, withdrawcode');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer="'.$dealer.'"', 'LEFT');
		$this->db->where('site_id', $site_id);
		$this->db->where('uag.dealer', $dealer);
		$this->db->like('username', $username, 'both');
		$this->db->where('username !=','');
		$this->db->where('waitopen', 'N');
		$this->db->where('uag_status','ใช้');
		$this->db->where('nickname !=','');
		$this->db->where('nickname !=','ว่าง');
		if ($limit) {
			$this->db->limit($limit);
		}
		return $this->db->get('tb_users');
	}
	/************************ *************************/
	
	/************************ Get User With UserPassAgent *************************/
	public function get_by_agent_id($userpass_id=NULL,$limit=10){
		$this->db->select('us.dealer, uag.userpass_id, us.user_id, uag.username, us.nickname, up.username AS ag_username, us.phone');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.userpass_id="'.$userpass_id.'"', 'LEFT');
		$this->db->join('tb_userpass up', 'uag.userpass_id=up.userpass_id');
		$this->db->where('uag.userpass_id', $userpass_id);
		$this->db->where('us.status','ใช้');
		$this->db->where('uag.username !=','');
		if ($limit) {
			$this->db->limit($limit);
		}
		return $this->db->get('tb_users us');
	}
	
	/************************ Get User With UserPassAgent *************************/
	public function get_by_like_username($site_id=NULL,$dealer=NULL,$username=NULL,$userpass_id=NULL,$limit=10){
		$this->db->select('uag.dealer, uag.userpass_id, us.user_id, uag.username, us.nickname, up.username AS ag_username,us.phone');
		$this->db->join('tb_users_agent uag', 'uag.user_id=us.user_id AND uag.dealer="'.$dealer.'"', 'LEFT');
		$this->db->join('tb_userpass up', 'uag.userpass_id=up.userpass_id');
		$this->db->where('uag.site_id', $site_id);
		$this->db->where('uag.dealer', $dealer);
		$this->db->where('uag.uag_status','ใช้');
		$this->db->where('uag.username !=','');
		$this->db->where('uag.userpass_id !=', '');
		if($site_id)$this->db->where('uag.site_id', $site_id);
		if($dealer)$this->db->where('uag.dealer', $dealer);
		if($userpass_id)$this->db->where('uag.userpass_id', $userpass_id);
		$this->db->like('uag.username', $username);
		return $this->db->get('tb_users us');
	}
	/************************ Get User Like Username *************************/	
	
	/************************ Get Numrows User เพื่อสร้าง Username Slotxo *************************/	
	public function get_numrows_userslotxo($dealer=NULL){
		$this->db->join('tb_users_agent uag', 'uag.user_id=us.user_id', 'LEFT');
		$this->db->where('uag.dealer', 'Slotxo');
		$this->db->where('uag.dealer', $dealer);
		//return $this->db->get('tb_users')->num_rows();
		return $this->db->count_all_results('tb_users');
	}
	/************************ Get Numrows User เพื่อสร้าง Username Slotxo *************************/	
		
	public function __destruct(){
		$this->db->close();
	}
	
}