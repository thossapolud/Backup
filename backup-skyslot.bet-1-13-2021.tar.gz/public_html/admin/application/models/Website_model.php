<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Website_model extends CI_Model{

	public function get_by_site_id($site_id){
		$this->db->where('site_id', $site_id);
		return $this->db->get('tb_website')->row();
	}

	public function get_by_site_name($site_name){
		$this->db->where('site_name', $site_name);
		return $this->db->get('tb_website')->row();
	}

	public function get_by_status($site_status){
		$this->db->where('site_status', $site_status);
		$this->db->order_by('site_created', 'asc');
		return $this->db->get('tb_website');
	}

	public function add_website($data){
		return $this->db->insert('tb_website', $data);
	}

	public function edit_website($data, $cond){
		return $this->db->update('tb_website', $data, $cond);
	}

	public function __destruct(){
		$this->db->close();
	}
	
}