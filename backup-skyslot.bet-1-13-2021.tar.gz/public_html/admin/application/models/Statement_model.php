<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Statement_model extends CI_Model{
		
	public function get_sumin($bank=NULL,$ac=NULL,$start=NULL,$end=NULL,$open=NULL,$dealer=NULL){
		$this->db->select('COUNT(tb_statement.st_id) AS listtotal, COALESCE(SUM(replace(tb_statement.st_in,",","")),0) AS stintotal',false);
		if($dealer)$this->db->join('tb_worksheet ws', 'ws.st_id=tb_statement.st_id', 'LEFT');
		if($bank)$this->db->where('st_bank', $bank);
		if($ac)$this->db->where('st_ac', $ac);
		//$this->db->where('st_datein BETWEEN "'.date('Y-m-d').' 00:00:00" AND "'.date('Y-m-d').' 11:59:59"');
		$this->db->where('st_datein BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('st_in is NOT NULL', NULL, FALSE);
		$this->db->where('st_in !=',' ');
		$this->db->where('st_in !=',' ');		
		if($open!==NULL)$this->db->where('st_status',$open);
		if($dealer)$this->db->where('ws_dealer',$dealer);
		return $this->db->get('tb_statement')->row();
	}
	
	public function get_st_in_report($bank=NULL,$ac=NULL,$start=NULL,$end=NULL,$open=NULL){
		$this->db->select('st_datein, st_in, st_acc, st_balance, st_comment');
		$this->db->where('st_bank', $bank);
		$this->db->where('st_ac', $ac);
		$this->db->where('st_datein BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where('st_in is NOT NULL', NULL, FALSE);
		$this->db->where('st_in !=',' ');
		$this->db->where('st_in !=',' ');
		if($open!==NULL)$this->db->where('st_status',$open);
		return $this->db->get('tb_statement');
	}
	
	public function get_st_in($bank=NULL,$ac=NULL,$datein=NULL){
		$this->db->select('st_id,st_in,st_acc,st_datein,st_comment');
		if($bank)$this->db->where('st_bank', $bank);
		if($ac)$this->db->where('st_ac', $ac);
		//$this->db->where('st_datein', $datein);
		$this->db->where('DATE_FORMAT(st_datein, "%Y-%m-%d %H:%i") =', $datein);		
		$this->db->where('st_in is NOT NULL', NULL, FALSE);
		$this->db->where('st_in !=',' ');
		$this->db->where('st_in !=',' ');
		//$this->db->where('st_status', 0);		
		return $this->db->get('tb_statement');
	}
	
	public function get_st_shift($bank=NULL,$ac=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('st_in,st_out,st_datein');
		if($bank)$this->db->where('st_bank', $bank);
		if($ac)$this->db->where('st_ac', $ac);
		$this->db->where('st_datein BETWEEN "'.$startdate.'" AND "'.$enddate.'"', NULL, FALSE);
		$this->db->order_by('st_datein', 'asc');	
		return $this->db->get('tb_statement');
	}
				
	public function __destruct(){
		$this->db->close();
	}
	
}