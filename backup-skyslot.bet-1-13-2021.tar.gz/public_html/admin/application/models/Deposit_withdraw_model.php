<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Deposit_withdraw_model extends CI_Model {
	
	public function get_deposit_withdraw($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent=NULL,$limit=NULL){		
		// Query #1
		$this->db->select('"ฝาก" AS type, wb.site_name, de.dealer, de.agent, de.name, de.username, de.creditbefore, de.credit, de.add_by_name, de.created');
		$this->db->from('tb_deposit de');
		$this->db->join('tb_website wb', 'de.site_id=wb.site_id', 'LEFT');
		if($site_id)$this->db->where('de.site_id', $site_id);
		if($dealer)$this->db->where('de.dealer',$dealer);
		if($agent)$this->db->where('de.agent', $agent);
		if($start && $end)$this->db->where('de.created BETWEEN "'.$start.'" AND "'.$end.'"');
		// if($this->session->userdata('level')!= 'admin')$this->db->where('add_by_id', $this->session->userdata('ac_id'));
		$query1 = $this->db->get_compiled_select();		
		// Query #2		
		$this->db->select('"ถอน" AS type, wb.site_name, wi.dealer, wi.agent, wi.name, wi.username, wi.creditbefore, wi.credit, wi.add_by_name, wi.created');
		$this->db->from('tb_withdraw wi');
		$this->db->join('tb_website wb', 'wi.site_id=wb.site_id', 'LEFT');
		if($site_id)$this->db->where('wi.site_id', $site_id);
		if($dealer)$this->db->where('wi.dealer',$dealer);
		if($agent)$this->db->where('wi.agent', $agent);
		if($start && $end)$this->db->where('wi.created BETWEEN "'.$start.'" AND "'.$end.'"');
		// if($this->session->userdata('level')!= 'admin')$this->db->where('add_by_id', $this->session->userdata('ac_id'));
		
		$this->db->order_by('created', 'DESC');
		if($limit)$this->db->limit($limit);
		$query2 = $this->db->get_compiled_select();		
		// Merge both query results
		return $this->db->query($query1." UNION ".$query2);
	}

	public function get_deposit_withdraw_last($dealer=NULL,$agent=NULL,$enddate=NULL){		
		// Query #1
		$this->db->select('"ฝาก" AS type, creditagentbefore, credit, created');
		$this->db->from('tb_deposit');
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created <="'.$enddate.'"');
		$query1 = $this->db->get_compiled_select();		
		// Query #2		
		$this->db->select('"ถอน" AS type, creditagentbefore, credit, created');
		$this->db->from('tb_withdraw');
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created  <="'.$enddate.'"');
		$this->db->order_by('created', 'DESC');
		$this->db->limit(1);
		$query2 = $this->db->get_compiled_select();		
		// Merge both query results
		$Result = $this->db->query($query1." UNION ALL ".$query2);
		return $Result->row();
	}
					
	public function __destruct(){
		$this->db->close();
	}
	
}