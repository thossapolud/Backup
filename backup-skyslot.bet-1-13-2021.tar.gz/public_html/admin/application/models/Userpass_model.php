<?php if (!defined('BASEPATH')) {exit('No direct script access allowed');}

class Userpass_model extends CI_Model {

	public function get_userpass_scr() {
		$this->db->select('userpass_id,username,password');
		$this->db->where('type', 'scr');
		$this->db->order_by('created', 'asc');
		return $this->db->get('tb_userpass');
	}
	
	public function get_userpass_gclub() {
		$this->db->select('userpass_id,username,password');
		$this->db->where('type', 'gclub');
		$this->db->order_by('created', 'asc');
		//$this->db->limit(1);
		return $this->db->get('tb_userpass');
	}
	
	public function get_by_slotxoid($id) {
		$this->db->select('*');
		$this->db->where('type', 'slotxo');
		$this->db->where('userpass_id', $id);
		return $this->db->get('tb_userpass')->row();
	}
	
	public function get_userpass_slotxo() {
		$this->db->select('userpass_id,username,password');
		$this->db->where('type', 'slotxo');
		$this->db->order_by('created', 'asc');
		//$this->db->limit(1);
		return $this->db->get('tb_userpass');
	}
	
	public function get_by_sbobetid($id) {
		$this->db->select('*');
		$this->db->where('type', 'sbobet');
		$this->db->where('userpass_id', $id);
		return $this->db->get('tb_userpass')->row();
	}
	
	public function get_userpass_sbobet() {
		$this->db->select('userpass_id,username,password');
		$this->db->where('type', 'sbobet');
		$this->db->order_by('created', 'asc');
		//$this->db->limit(1);
		return $this->db->get('tb_userpass');
	}
	
	public function get_by_holidayid($id) {
		$this->db->select('*');
		$this->db->where('type', 'holiday');
		$this->db->where('userpass_id', $id);
		return $this->db->get('tb_userpass')->row();
	}
	
	public function get_userpass_holiday() {
		$this->db->select('userpass_id,username,password');
		$this->db->where('type', 'holiday');
		$this->db->order_by('created', 'asc');
		//$this->db->limit(1);
		return $this->db->get('tb_userpass');
	}
	
	/************************ User Pass Bank For Edit *************************/
	public function get_userpass_bank_edit() {
		$this->db->select('*');
		$this->db->where_in('type', array('kbank', 'scb', 'bbl', 'ktb'));
		//$this->db->where('bankname !=','-');
		$this->db->order_by('FIELD(type, "kbank","scb","bbl","ktb") ASC', '', false);
		return $this->db->get('tb_userpass');
	}
	
	/************************ User Pass Bank For Edit *************************/
	public function get_userpass_bank() {
		$this->db->select('*');
		$this->db->where_in('type', array('kbank', 'scb', 'bbl', 'ktb', 'tmb', 'bay'));
		$this->db->where('bankname !=', '-');
		$this->db->order_by('FIELD(type, "kbank","scb","bbl","ktb","tmb","bay") ASC', '', false);
		return $this->db->get('tb_userpass');
	}
	
	/************************ *************************/
	public function get_userpass_bank_order_by_bankname() {
		$this->db->select('*');
		$this->db->where_in('type', array('kbank', 'scb', 'bbl', 'ktb', 'tmb', 'bay'));
		$this->db->where('bankname !=', '-');
		$this->db->order_by('bankname', 'DESC');
		return $this->db->get('tb_userpass');
	}
	/************************ *************************/
	public function get_by_bank($bank) {
		$this->db->select('*');
		$this->db->where_not_in('type', array('gclub', 'scr'));
		$this->db->where_in('type', $bank);
		return $this->db->get('tb_userpass');
	}
	
	// Get bank data by bank type and bank acnum and banknum
	public function get_by_bankac($bank, $ac, $tobanknum=NULL) {
		$this->db->select('*');
		$this->db->where_in('type', $bank);
		$this->db->where_in('acnum', $ac);
		if($tobanknum)$this->db->where('REPLACE(banknum, "-", "") LIKE "%'.$tobanknum.'"', NULL, FALSE);
		return $this->db->get('tb_userpass')->row();
	}
	
	public function get_by_bankid($id) {
		$this->db->select('*');
		$this->db->where_in('type', array('kbank', 'scb', 'bbl', 'ktb', 'tmb', 'bay'));
		$this->db->where('userpass_id', $id);
		return $this->db->get('tb_userpass')->row();
	}
	
	public function get_bank_type_by_actype($actype) {
		$this->db->distinct();
		$this->db->select('type');
		$this->db->where('actype', $actype);
		$this->db->where('acnum !=', 'dealer');
		return $this->db->get('tb_userpass');
	}
	
	// Get all active withdraw bank by site_id
	// Don't care about tranfer chanenel status
	public function get_deposit_bank_by_site_id($site_id) {
		$this->db->from('tb_userpass');
		$this->db->where('site_id', $site_id);
		$this->db->where('actype', 'deposit');
		$this->db->where('acnum !=', 'dealer');
		$this->db->where('up_status', 1);
		$this->db->order_by('bankname', 'ASC');
		// $this->db->select('up.*');
		// $this->db->from('tb_website site');
		// $this->db->join('tb_xfer_channel xh', 'xh.site_id = site.site_id');
		// $this->db->join('tb_xfer_channel_detail xd', 'xd.xfer_h_id = xh.xfer_h_id');
		// $this->db->join('tb_userpass up', 'up.userpass_id = xd.userpass_id');
		// $this->db->where('up.site_id', $site_id);
		// $this->db->where('xh.xfer_h_type', 'deposit');
		// $this->db->where('up.actype', 'deposit');
		// $this->db->where('up.acnum !=', 'dealer');
		// $this->db->where('up.up_status', 1);
		// $this->db->order_by('up.bankname', 'ASC');
		return $this->db->get();
	}
	
	// Main purpose is for showing bank account to user to deposit money
	// Get all active deposit bank by username
	// Don't care about tranfer chanenel status
	public function get_deposit_bank_by_username($username=NULL) {
		$this->db->select('uag.dealer,us.bank,uag.username,us.status,up.bankname,up.banknum,up.type,up.up_status,op.opt_name,op.opt_value');
		$this->db->from('tb_users us');
		$this->db->join('tb_users_agent uag', 'us.user_id=uag.user_id', 'LEFT');
		$this->db->join('tb_xfer_channel xh', 'us.xfer_h_id_deposit = xh.xfer_h_id');
		$this->db->join('tb_xfer_channel_detail xd', 'xd.xfer_h_id = xh.xfer_h_id');
		$this->db->join('tb_userpass up', 'up.userpass_id = xd.userpass_id');
		$this->db->join('tb_options op', 'op.opt_code = "BANK_DEPOSIT_POLICY" AND op.opt_value = us.bank AND op.opt_name = up.type');
		$this->db->where('us.username', $username);
		$this->db->where('up.up_status', 1);
		$this->db->order_by('up.type', 'ASC');
		return $this->db->get();
		/*
			SELECT
				us.dealer,
				us.bank,
				us.username,
				us.status,
				up.bankname,
				up.banknum,
				up.type,
				up.up_status,
				op.opt_name,
				op.opt_value
			FROM
				tb_users us
			INNER JOIN tb_xfer_channel xh ON
				us.xfer_h_id_deposit = xh.xfer_h_id
			INNER JOIN tb_xfer_channel_detail xd ON
				xd.xfer_h_id = xh.xfer_h_id
			INNER JOIN tb_userpass up ON
				up.userpass_id = xd.userpass_id
			INNER JOIN tb_options op ON
				op.opt_code = 'BANK_DEPOSIT_POLICY' AND op.opt_value = us.bank AND op.opt_name = up.type
			WHERE
				us.username = 'ufsnett70254'
		*/
	}
	
	// Get all active withdraw bank by site_id
	// Don't care about tranfer chanenel status
	public function get_withdraw_bank_by_site_id($site_id) {
		$this->db->from('tb_userpass');
		$this->db->where('site_id', $site_id);
		$this->db->where('actype', 'withdraw');
		$this->db->where('acnum !=', 'dealer');
		$this->db->where('up_status', 1);
		$this->db->order_by('bankname', 'ASC');
		// $this->db->select('up.*');
		// $this->db->from('tb_website site');
		// $this->db->join('tb_xfer_channel xh', 'xh.site_id = site.site_id');
		// $this->db->join('tb_xfer_channel_detail xd', 'xd.xfer_h_id = xh.xfer_h_id');
		// $this->db->join('tb_userpass up', 'up.userpass_id = xd.userpass_id');
		// $this->db->where('site.site_id', $site_id);
		// $this->db->where('xh.xfer_h_type', 'withdraw');
		// $this->db->where('up.actype', 'withdraw');
		// $this->db->where('up.acnum !=', 'dealer');
		// $this->db->where('up.up_status', 1);
		// $this->db->order_by('up.bankname', 'ASC');
		return $this->db->get();
	}
	
	public function get_active_deposit_withdraw_bank($site_id=NULL, $bank=NULL,$actype=NULL) {
		$this->db->select('*');
		$this->db->from('tb_userpass');
		$this->db->where('up_status', 1);
		$this->db->where('acnum !=', 'dealer');
		if($site_id) {
			$this->db->where('site_id', $site_id);
		}
		if($bank) {
			$this->db->where('type', $bank);
		}
		if($actype) {
			$this->db->where('actype', $actype);
		}
		$this->db->order_by('type', 'ASC');
		$this->db->order_by('actype', 'ASC');
		$this->db->order_by('acnum', 'ASC');
		$this->db->order_by('bankname', 'ASC');
		return $this->db->get();
	}
	
	// Get bank data by bank type and bank username
	public function get_by_bankusername($bank, $username) {
		$this->db->select('*');
		$this->db->where('type', $bank);
		$this->db->where('username', $username);
		return $this->db->get('tb_userpass')->row();
	}
	
	// AGENT : Get agents data by dealer
	public function get_agent_by_dealer($dealer = NULL) {
		$this->db->select('userpass_id,username,password');
		$this->db->where('type', $dealer);
		$this->db->where('acnum', 'dealer');
		$this->db->order_by('created', 'asc');
		return $this->db->get('tb_userpass');
	}
	
	// AGENT : Get agents data by dealer
	public function get_dealers() {
		$this->db->distinct();
		$this->db->select('type');
		$this->db->where('acnum', 'dealer');
		$this->db->order_by('created', 'asc');
		return $this->db->get('tb_userpass');
	}
	
	public function get_dealer_by_site_id($site_id) {
		$this->db->distinct();
		$this->db->select('dl.dl_code, dl.dl_name, up.type');
		$this->db->join('tb_dealer dl', 'dl.dl_name = up.type');
		$this->db->where('up.site_id', $site_id);
		$this->db->where('up.acnum', 'dealer');
		$this->db->order_by('up.type', 'asc');
		return $this->db->get('tb_userpass up');
	}
	
	// BANK : 
	public function get_bank_by_site_id_actype_and_not_in_userpass_id($site_id, $actype, $arr_userpass_id) {
		$this->db->distinct();
		$this->db->select('userpass_id, type, bankname,created');
		$this->db->where('site_id', $site_id);
		$this->db->where('acnum !=', 'dealer');
		$this->db->where('actype', $actype);
		$this->db->where('up_status', 1);
		if($arr_userpass_id) {
			$this->db->where_not_in('userpass_id', $arr_userpass_id);
		}
		$this->db->order_by('created', 'asc');
		return $this->db->get('tb_userpass');
	}
	
	public function __destruct(){
		$this->db->close();
	}
}