<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Withdraw_model extends CI_Model{
		
	/*
	public function get_sumcountcredit($dealer=NULL,$start=NULL,$end=NULL){
		$this->db->select("COUNT(wi_id) AS listtotal, SUM(credit) AS credittotal");
		if($dealer)$this->db->where('dealer',$dealer);
		//$this->db->where('created BETWEEN "'.date('Y-m-d').' 00:00:00" AND "'.date('Y-m-d').' 11:59:59"');
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		return $this->db->get('tb_withdraw')->row();
	}
	*/

	public function get_sumcountcredit($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent=NULL){
		$this->db->select("COUNT(wi_id) AS listtotal, SUM(credit) AS credittotal");
		if($site_id)$this->db->where('site_id',$site_id);
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where_not_in('add_by_name', array('โยกเครดิตโดยสมาชิก'));
		//$this->db->not_like('add_by_name', 'โยกเครดิต', 'both');
		return $this->db->get('tb_withdraw')->row();
	}
	
	public function get_sumcountcredittransfer($start=NULL,$end=NULL,$site_id=NULL,$dealer=NULL,$agent=NULL){
		$this->db->select("COUNT(wi_id) AS listtotal, SUM(credit) AS credittotal");
		if($site_id)$this->db->where('site_id',$site_id);
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where_in('add_by_name', array('โยกเครดิตโดยสมาชิก'));
		//$this->db->like('add_by_name', 'โยกเครดิต', 'both');
		return $this->db->get('tb_withdraw')->row();
	}
	
	public function get_sumcountcredit_user($dealer=NULL,$username=NULL,$start=NULL,$end=NULL){
		$this->db->select("COUNT(wi_id) AS listtotal, COALESCE(SUM(credit),0) AS credittotal");
		if($dealer)$this->db->where('dealer',$dealer);
		if($username)$this->db->where('username',$username);
		if($start && $end)$this->db->where('created BETWEEN "'.$start.' 11:00:00" AND "'.$end.' 11:00:00"');
		//$this->db->where('created BETWEEN "'.$start.' 00:00:00" AND "'.$end.' 23:59:59"');
		//$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		return $this->db->get('tb_withdraw')->row();
	}
	
	public function get_listwithdraw_user($dealer=NULL,$username=NULL,$start=NULL,$end=NULL){
		$this->db->select("creditbefore, credit, created");
		if($dealer)$this->db->where('dealer',$dealer);
		if($username)$this->db->where('username',$username);
		$this->db->where('created BETWEEN "'.$start.' 11:00:00" AND "'.$end.' 11:00:00"');
		//$this->db->where('created BETWEEN "'.$start.' 00:00:00" AND "'.$end.' 23:59:59"');
		//$this->db->where('created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->order_by('created', 'DESC');
		return $this->db->get('tb_withdraw');
	}
	
	public function get_withdraw_shift($dealer=NULL,$agent=NULL,$startdate=NULL,$enddate=NULL){
		$this->db->select('"ถอน" AS type, agent, name, username, creditbefore, credit, add_by_name, created');
		if($dealer)$this->db->where('dealer',$dealer);
		if($agent)$this->db->where('agent',$agent);
		$this->db->where('created BETWEEN "'.$startdate.'" AND "'.$enddate.'"');
		return $this->db->get('tb_withdraw');
	}
	
	public function get_sumcountcredit_top($start=NULL,$end=NULL,$limit){
		//$this->db->select("ANY_VALUE(dealer), ANY_VALUE(name), ANY_VALUE(username), COUNT(wi_id) AS listtotal, SUM(credit) AS credittotal");
		$this->db->select("wb.site_name, wi.dealer, wi.name, wi.username, COUNT(wi.wi_id) AS listtotal, SUM(wi.credit) AS credittotal");
		$this->db->from('tb_withdraw wi');
		$this->db->join('tb_website wb', 'wi.site_id=wb.site_id', 'LEFT');
		$this->db->where('wi.created BETWEEN "'.$start.'" AND "'.$end.'"');
		$this->db->where_not_in('add_by_name', array('โยกเครดิตโดยสมาชิก'));
		$this->db->group_by('wi.username');	
		$this->db->order_by('credittotal','DESC');
		$this->db->limit($limit);
		return $this->db->get();
	}
				
	// public function __destruct(){
	// 	$this->db->close();
	// }
	
}