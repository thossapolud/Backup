<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Account_loginout_model extends CI_Model{
		
	public function get_by_acid($acid=NULL){
		$this->db->select('*');
		$this->db->where('ac_id', $acid);
		$this->db->order_by('created', 'desc');
		$this->db->limit(100);
		return $this->db->get('tb_account_loginout');
	}
				
	public function __destruct(){
		$this->db->close();
	}
	
}