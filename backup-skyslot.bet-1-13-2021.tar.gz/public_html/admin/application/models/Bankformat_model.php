<?php
	class Bankformat_model extends CI_Model{

        public function get_Bankinitials($string_json=NULL){
            $data = array(
                "SCB" => "ไทยพาณิชย์",
                "KBNK" => "ธนาคารกสิกรไทย",
                "KTBA" => "ธนาคารกรุงไทย",
                "BBLA" => "บัวหลวง",
                "GSBA" => "ออมสิน",
                "TMBA" => "ทหารไทย",
            );
            foreach($data as $x){
                if(strpos($string_json, $x) !== false){
                    return array_search($x, $data);
                }
            }
            return NULL;
        }
}
?>