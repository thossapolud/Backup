<div class="">
  <div class="page-header-title">  	
    <h4 class="page-title">รายงาน รับโปรโมชั่น <?php echo $this->uri->segment(3,'') ?></h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container">

        <div class="row">                                     
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                    	<form id="form-get-promotion" action="" class="col-sm-12 col-md-9 form-inline" method="post">
                        <div class="input-group date date-main col-md-3" data-link-field="datestart" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
                            <input class="form-control" size="16" type="text" value="<?php echo $datestart ?>" readonly required="required">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                        </div>
                        <input type="hidden" id="datestart" name="datestart" value="<?php echo $datestart ?>" required="required" />                
                        <label>:</label>
                        <div class="input-group date date-main col-md-3" data-link-field="dateend" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
                            <input class="form-control" size="16" type="text" value="<?php echo $dateend ?>" readonly required="required">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                        </div>
                        <input type="hidden" id="dateend" name="dateend" value="<?php echo $dateend ?>" required="required" />
                        <button class="btn btn-lg btn-success" type="submit"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ดึงข้อมูล</button>
                        </form>
                    </div>
                </div>
            </div>                                     
        </div>
        
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables1" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th width="20%">โปรโมชั่น</th>
                             <th>รายละเอียด</th>                      
                             <th width="20%">ยอดรวม</th>
                            </tr>
                          </thead>
                          	<?php if(isset($rs_promotionuser)){ if($rs_promotionuser->num_rows()>0){ $i=1; $credit = 0;?>
                            <tbody>
                        		<?php foreach($rs_promotionuser->result() as $row){ ?>
                                <tr>
                                	<td><?php echo $i++ ?></td>
                                	<td><?php echo $row->pr_type ?></td>
                                    <td><?php echo $row->title ?></td>
                                    <td><?php echo number_format($row->credit,2); $credit += $row->credit; ?></td>
                                </tr>
                                <?php } ?>
                                <tr>
                                	<td></td>
                                	<td><strong>รวม</strong></td>
                                    <td></td>
                                    <td><?php echo number_format($credit,2); ?></td>
                                </tr>
                            </tbody>
                            <?php } }?>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- END Row -->
		
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables2" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>
                              <th>Username</th>
                              <th width="20%">รับโปรโมชั่น</th>
                              <th>รายละเอียด</th>                      
                              <th width="5%">จำนวน</th>
                              <th>วันที่</th>
                            </tr>
                          </thead>
                          	<?php if(isset($rs_promotionuserlist)){ if($rs_promotionuserlist->num_rows()>0){ $i=1;?>
                            <tbody>
                        		<?php foreach($rs_promotionuserlist->result() as $row){ ?>
                                <tr>
                                	<td><?php echo $i++ ?></td>
                                	<td><?php echo $row->username ?></td>
                                    <td><?php echo $row->pr_type ?></td>
                                    <td><?php echo $row->title ?></td>
                                    <td><?php echo $row->rate_pro ?></td>
                                    <td><?php echo $row->created ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                            <?php } }?>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- END Row -->
        
      </div>  
  <!-- container -->   
</div>
<!-- Page content Wrapper -->
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$('#datatables2').DataTable({
		"lengthMenu": [[10, 25, 50,100, -1], [10, 25, 50,100,"All"]],
		"iDisplayLength": 100,
		"bPaginate": true, 
		"bLengthChange": true, //+ แสดงจำนวนต่อหน้า
		"bFilter": true, //+ ช่องค้นหา
		"bInfo": false, //+ รายละเอียดจำนวนแถว
		"columnDefs": [
			{"targets":[0],'className':'text-center'}
		],
		//"order": [1, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
	});
});
</script>