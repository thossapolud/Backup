<div class="">
  <div class="page-header-title <?php echo $type ?>-bg">  	
    <h4 class="page-title"><i class="thbanks thbanks-<?php echo $type ?>"></i> รายงาน : ธนาคารถอน</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container">

        <div class="row">                                     
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                    	<form id="form-bank-withdraw" action="" class="col-sm-12 col-md-9 form-inline" method="post">
                    	<?php if($rs_bank->num_rows()>0){ ?>
                        <select name="ac" id="ac" class="form-control">
                            <option value="">=== เลือก ===</option>
                            <?php foreach ($rs_bank->result() as $row_bank){ ?>
                            <option value="<?php echo $row_bank->userpass_id ?>" <?php echo ($ac==$row_bank->userpass_id)?'selected':'' ?> ><?php echo '[ '.$row_bank->type.' ] '.$row_bank->bankname ?></option>
                            <?php } ?>
                        </select> 
                        <?php } ?>
                        <div class="input-group date date-main col-md-3" data-link-field="datestart" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
                            <input class="form-control" size="16" type="text" value="<?php echo $datestart ?>" readonly required="required">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                        </div>
                        <input type="hidden" id="datestart" name="datestart" value="<?php echo $datestart ?>" required="required" />                
                        <label>:</label>
                        <div class="input-group date date-main col-md-3" data-link-field="dateend" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
                            <input class="form-control" size="16" type="text" value="<?php echo $dateend ?>" readonly required="required">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                        </div>
                        <input type="hidden" id="dateend" name="dateend" value="<?php echo $dateend ?>" required="required" />
                        <button class="btn btn-lg btn-success" type="submit"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ดึงข้อมูล</button>
                        </form>
                        <button class="btn btn-default btn-lg pull-right" type="button">ยอดรวม : <?php echo number_format($row_statement->ws_credit,2) ?></button>
                    </div>
                </div>
            </div>                                     
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th width="20%">วันที่</th>
                             <th>ถอน</th>                      
                               <!--<th>เลขบัญชี</th>
                              <th>ยอดคงเหลือ</th>
                              <th width="35%">หมายเหตุ</th>-->
                            </tr>
                          </thead>
                          	<?php if(isset($rs_statement)){ if($rs_statement->num_rows()>0){ $i=1;?>
                            <tbody>
                        		<?php foreach($rs_statement->result() as $row_statement){ ?>
                                <tr>
                                	<td><?php echo $i++ ?></td>
                                	<td><?php echo $row_statement->ws_date ?></td>
                                    <td><?php echo $row_statement->ws_credit ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                            <?php } }?>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- END Row -->
        
      </div>  
  <!-- container -->   
</div>
<!-- Page content Wrapper -->
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$('#datatables').DataTable({
		"lengthMenu": [[10, 25, 50,100, -1], [10, 25, 50,100,"All"]],
		"iDisplayLength": 100,
		"bPaginate": true, 
		"bLengthChange": true, //+ แสดงจำนวนต่อหน้า
		"bFilter": false, //+ ช่องค้นหา
		"bInfo": false, //+ รายละเอียดจำนวนแถว
		"columnDefs": [
			{"targets":[0,1],'className':'text-center'}
		],
		//"order": [1, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
	});
});
</script>