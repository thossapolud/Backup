<div class="">
  <div class="page-header-title">  	
    <h4 class="page-title">รายงาน การทำงาน</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container">

        <div class="row">                                     
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                    	<form id="form-account-summary" action="" class="col-sm-12 col-md-9 form-inline" method="post">
							<div class="input-group date date-main col-md-4" data-link-field="datestart" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
								<input class="form-control" size="16" type="text" value="<?php echo $datestart ?>" readonly required="required">
								<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
							</div>
							<input type="hidden" id="datestart" name="datestart" value="<?php echo $datestart ?>" required="required" />                
							<label>:</label>
							<div class="input-group date date-main col-md-4" data-link-field="dateend" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
								<input class="form-control" size="16" type="text" value="<?php echo $dateend ?>" readonly required="required">
								<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
							</div>
							<input type="hidden" id="dateend" name="dateend" value="<?php echo $dateend ?>" required="required" />
							<button class="btn btn-lg btn-success" type="submit"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ดึงข้อมูล</button>
                        </form>
                    </div>
                </div>
            </div>                                     
        </div>
        
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
							<thead>
								<tr role="row">
									<th width="5%"></th>	
									<th>Username</th>
									<th>Login</th>
									<th>Logout</th>
									<th>ใบงาน Call</th>
									<th>ใบงาน Bank</th>
									<th>ใบงาน Manage</th>
									<th></th>
								</tr>
							</thead>
							<?php if(isset($rs_account_summary)){ ?>
								<?php if($rs_account_summary->num_rows()>0){ $i=1; ?>
									<tbody>
										<?php foreach($rs_account_summary->result() as $row) { ?>
											<tr>
												<td><?php echo $i++ ?></td>
												<td><?php echo $row->username ?></td>
												<td><?php echo $row->total_login ?></td>
												<td><?php echo $row->total_logout ?></td>
												<td><?php echo $row->worksheet_call ?></td>
												<td><?php echo $row->worksheet_bank ?></td>
												<td><?php echo $row->worksheet_manage ?></td>
												<td>
													<a data-toggle="modal" data-target="#account-detail" 
														data-acid="<?php echo $row->ac_id ?>" class="btn btn-xs btn-default">
														ดูรายละเอียด
													</a>
												</td>
											</tr>
										<?php } ?>
									</tbody>
								<?php } ?>
							<?php }?>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- END Row -->
        
      </div>  
  <!-- container -->   
</div>
<!-- Page content Wrapper -->

<!-- AccountDetail Modals -->
<div class="modal fade" id="account-detail" tabindex="-1" role="dialog" aria-labelledby="AccountDetail" aria-hidden="false" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog modal-lg">
		<div class="modal-content" id="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="myModalLabel">
					รายละเอียด
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				</h4>
			</div>
			<div class="modal-body">
			</div>
		</div>
	</div>
</div>
<!-- END AccountDetail Modals -->

<!-- View Worksheet Modals -->
<div class="modal fade" id="worksheet-view-modal" tabindex="-1" role="dialog" aria-labelledby="WorksheetView" aria-hidden="false" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content" id="modal-content">
      <form class="form-horizontal" id="form-worksheet-view" action="" method="POST" role="form">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">รายละเอียดใบงาน</h4>
        </div>
        <div class="modal-body">
        </div>
      </form>
    </div>
  </div>
</div>
<!-- END View Worksheet Modals -->

<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$('#datatables').DataTable({
		"lengthMenu": [[10, 25, 50,100, -1], [10, 25, 50,100,"All"]],
		"iDisplayLength": 100,
		"bPaginate": true, 
		"bLengthChange": true, //+ แสดงจำนวนต่อหน้า
		"bFilter": true, //+ ช่องค้นหา
		"bInfo": false, //+ รายละเอียดจำนวนแถว
		"columnDefs": [
			{"targets":[0],'className':'text-center'}
		],
		//"order": [1, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
	});

	$('#account-detail').on('show.bs.modal', function (e){
		$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('report/account-summary-detail')?>?datestart=<?php echo urlencode($datestart)?>&dateend=<?php echo urlencode($dateend)?>&acid='+$(e.relatedTarget).attr('data-acid'));
	});
});
</script>