<div class="row">
	<div class="col-sm-12">
		<h5>การเข้า-ออกระบบ</h5>
		<table class="table table-striped table-bordered table-hover" id="table-list-transfer-detail" width="100%" style="font-size:11px;">
			<thead>
			<tr role="row">
				<th class="text-center">ACTION</th>
				<th class="text-center">เวลา</th>
				<th class="text-center">IP</th>
				<th class="text-center">USER AGENT</th>
			</tr>
			</thead>
			<tbody>
			<?php if($rs_loginout_history->num_rows()>0){ ?>
				<?php foreach($rs_loginout_history->result() as $row_loginout_history){ ?>
					<tr>
						<td class="text-center"><?php echo $row_loginout_history->action ?></td>
						<td class="text-center"><?php echo $row_loginout_history->created ?></td>
						<td class="text-center"><?php echo $row_loginout_history->ip_address ?></td>
						<td class="text-center"><?php echo $row_loginout_history->user_agent ?></td>
					</tr>
				<?php } ?>
			<?php } ?>
			</tbody>
		</table>
		<hr>
		<h5>การจัดการใบงาน</h5>
		<table class="table table-striped table-bordered table-hover" id="table-list-transfer-detail" width="100%" style="font-size:11px;">
			<thead>
			<tr role="row">
				<th class="text-center">ประเภท</th>
				<th class="text-center">เครดิต</th>
				<th class="text-center">ยอดโปร</th>
				<th class="text-center">ยอดรวม</th>
				<th class="text-center">เวลา</th>
				<th class="text-center"></th>
			</tr>
			</thead>
			<tbody>
			<?php if($rs_worksheet_history->num_rows()>0){ ?>
				<?php foreach($rs_worksheet_history->result() as $row_worksheet_history){ ?>
					<tr>
						<td class="text-center"><?php echo conv_ws_type($row_worksheet_history->ws_type) ?></td>
						<td class="text-center"><?php echo $row_worksheet_history->ws_credit ?></td>
						<td class="text-center"><?php echo $row_worksheet_history->ws_pro ?></td>
						<td class="text-center"><?php echo $row_worksheet_history->ws_total ?></td>
						<td class="text-center"><?php echo $row_worksheet_history->datetime ?></td>
						<td class="text-center">
							<a data-toggle="modal" data-target="#worksheet-view-modal" data-wsid="<?php echo $row_worksheet_history->ws_id ?>" class="btn btn-xs btn-default"><span class="ti-search"></span></a>
						</td>
					</tr>
				<?php } ?>
			<?php } ?>
			</tbody>
		</table>
	</div>
</div>

<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
		$('#worksheet-view-modal').on('show.bs.modal', function (e){
			$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('worksheet/view')?>?wsid='+$(e.relatedTarget).attr('data-wsid'));
		});
	});
</script>