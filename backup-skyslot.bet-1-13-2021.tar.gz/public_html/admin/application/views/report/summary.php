<div class="">
  <div class="page-header-title">  	
    <h4 class="page-title">สรุปยอด [<?php echo $datestart ?>] ถึง [<?php echo $dateend ?>]</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container">

        <div class="row">                                     
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                    	<form id="form-summary2" action="" class="col-sm-12 col-md-9 form-inline" method="post">
                        <div class="input-group col-md-2">
                            <select name="dealer" id="dealer" class="form-control">
                            	<option value="All" <?php echo ($dealer=='All')?'selected':''; ?>>= ทั้งหมด =</option>
                                <option value="Pussy888" <?php echo ($dealer=='Pussy888')?'selected':''; ?>>= Pussy888 =</option>
                                <option value="918kiss" <?php echo ($dealer=='918kiss')?'selected':''; ?>>= 918kiss =</option>
                            </select>
                        </div>
                        <div class="input-group date date-main col-md-4" data-link-field="datestart" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
                            <input class="form-control" size="16" type="text" value="<?php echo $datestart ?>" readonly required="required">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                        </div>
                        <input type="hidden" id="datestart" name="datestart" value="<?php echo $datestart ?>" required="required" />                
                        <label>:</label>
                        <div class="input-group date date-main col-md-4" data-link-field="dateend" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
                            <input class="form-control" size="16" type="text" value="<?php echo $dateend ?>" readonly required="required">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                        </div>
                        <input type="hidden" id="dateend" name="dateend" value="<?php echo $dateend ?>" required="required" />
                        <button class="btn btn-lg btn-success" type="submit"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ดึงข้อมูล</button>
                        </form>
                    </div>
                </div>
            </div>                                     
        </div>
        
        <?php if($dealer=='All'||$dealer=='Pussy888'){ ?>
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel panel-color panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title">Pussy888</h3>
                    </div>
                    <div class="panel-body table-responsive">
                    	<div class="col-sm-6 col-md-6">
                        <h3>เครดิต</h3>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="2%"></th>	
                                <th width="23%">เอเย่นต์</th>                 
                                <th width="25%">เครดิตเริ่มต้น</th>
                                <th width="25%">เครดิตคงเหลือ</th>
                                <th width="25%">เครดิตใช้ไป</th>
                            </tr>
                          </thead>
                          	<?php if($rs_pussy->num_rows()>0){ $i=1;$creditagentlaststarttotal=0;$creditagentlastendtotal=0;$creditusedtotal=0;?>
                            <tbody>
                        		<?php foreach($rs_pussy->result() as $row){ ?>
                                <tr>
                                	<td><?php echo $i++; ?></td>
                                	<td><?php echo $row->username ?></td>
                                    <td>
										<?php
											$row_lastcreditagent = $this->deposit_model->get_depositwithdraw_last('Pussy888',$row->username,$datestart);
											$creditagentlaststart = ($row_lastcreditagent->type=='ฝาก')?$row_lastcreditagent->creditagentbefore-$row_lastcreditagent->credit:$row_lastcreditagent->creditagentbefore+$row_lastcreditagent->credit;
											echo number_format($creditagentlaststart,2);
											$creditagentlaststarttotal+=$creditagentlaststart;
										?>
                                    </td>
                                    <td>
										<?php 
											$row_lastcreditagent = $this->deposit_model->get_depositwithdraw_last('Pussy888',$row->username,$dateend);
											$creditagentlastend = ($row_lastcreditagent->type=='ฝาก')?$row_lastcreditagent->creditagentbefore-$row_lastcreditagent->credit:$row_lastcreditagent->creditagentbefore+$row_lastcreditagent->credit;
											echo number_format($creditagentlastend,2);
											$creditagentlastendtotal+=$creditagentlastend;
										?>
                                    </td>
                                    <td>
                                    	<?php $creditused = $creditagentlaststart-$creditagentlastend; echo number_format($creditused,2); ?>
                                        <?php $creditusedtotal+=$creditused; ?>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot> 
                                <tr>
                                	<td></td>
                                    <td><strong>รวม</strong></td>                                    
                                    <td><?php echo number_format($creditagentlaststarttotal,2); ?></td>
                                    <td><?php echo number_format($creditagentlastendtotal,2); ?></td>
                                    <td><?php echo number_format($creditusedtotal,2); ?></td>
                                </tr>
                            </tfoot>
                            <?php }?>
                        </table>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="2%"></th>	
                                <th width="20%"></th>                 
                                <th width="19%">ใบงานฝาก</th>
                                <th width="19%">ใบงานถอน</th>
                                <th width="19%">เครดิตโยกเข้า</th>
                                <th width="19%">เครดิตโยกออก</th>
                                <th width="19%">เครดิตโปร</th>
                                <th width="19%">เครดิตใช้ไป</th>
                            </tr>
                          </thead>
                            <?php if($rs_pussy->num_rows()>0){ $i=1; $creditdeposittotal=0;$creditwithdrawtotal=0;$creditdeposittransfertotal=0;$creditwithdrawtransfertotal=0;$creditprototal=0;$creditwsusedtotal=0;$creditwsusedwithoutprototal=0?>
                            <tbody>
                                <?php foreach($rs_pussy->result() as $row){ ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><?php echo $row->username ?></td>
                                    <td>
                                        <?php 
                                            $row_creditdepositagent = $this->deposit_model->get_sumcountcredit($datestart,$dateend,NULL,'Pussy888',$row->username);
                                            $creditdepositagent = $row_creditdepositagent->credittotal; $creditdeposittotal+=$creditdepositagent;
                                            echo number_format($creditdepositagent,2);
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                            $row_creditwithdrawagent = $this->withdraw_model->get_sumcountcredit($datestart,$dateend,NULL,'Pussy888',$row->username);
                                            $creditwithdrawagent = $row_creditwithdrawagent->credittotal; $creditwithdrawtotal+=$creditwithdrawagent;
                                            echo number_format($creditwithdrawagent,2);
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $row_creditdeposittransfer = $this->deposit_model->get_sumcountcredittransfer($datestart,$dateend,NULL,'Pussy888',$row->username);
                                            $creditdeposittransfer = $row_creditdeposittransfer->credittotal; $creditdeposittransfertotal+=$creditdeposittransfer;
                                            echo number_format($creditdeposittransfer,2);
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                            $row_creditwithdrawtransfer = $this->withdraw_model->get_sumcountcredittransfer($datestart,$dateend,NULL,'Pussy888',$row->username);
                                            $creditwithdrawtransfer = $row_creditwithdrawtransfer->credittotal; $creditwithdrawtransfertotal+=$creditwithdrawtransfer;
                                            echo number_format($creditwithdrawtransfer,2);
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $row_creditproagent = $this->deposit_model->get_sumcountcreditpromotion($datestart,$dateend,NULL,'Pussy888',$row->username);
                                            $creditproagent = $row_creditproagent->credittotal; $creditprototal+=$creditproagent;
                                            echo number_format($creditproagent,2);
                                        ?>
                                    </td>
                                    <td>
                                    <?php $creditwsused =  ($creditdepositagent-$creditwithdrawagent)+$creditproagent+ $creditdeposittransfer+ $creditwithdrawtransfer; echo number_format($creditwsused,2);?>
                                    <?php $creditwsusedtotal += $creditwsused; ?>                                    
                                    <?php $creditwsusedwithoutpro =  ($creditdepositagent-$creditwithdrawagent);?>
                                    <?php $creditwsusedwithoutprototal += $creditwsusedwithoutpro; ?>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot> 
                                <tr>
                                	<td></td>
                                    <td><strong>รวม</strong></td>                                    
                                    <td><?php echo number_format($creditdeposittotal,2); ?></td>
                                    <td><?php echo number_format($creditwithdrawtotal,2); ?></td>
                                    <td><?php echo number_format($creditdeposittransfertotal,2); ?></td>
                                    <td><?php echo number_format($creditwithdrawtransfertotal,2); ?></td>
                                    <td><?php echo number_format($creditproagent,2); ?></td>
                                    <td><?php echo number_format($creditwsusedtotal,2); ?></td>
                                </tr>
                            </tfoot>
                            <?php }?>
                        </table>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="100%"><h4>รวมเครดิตขยับ</h4></th>         
                            </tr>
                          </thead>
                            <tbody>
                                <tr>
                                    <td><h4><?php $creditmove = $creditwsusedtotal; echo number_format($creditmove,2); ?></h4></td>
                                </tr>
                            </tbody>
                        </table>                        
                        </div>
                        <div class="col-sm-6 col-md-6">
                        <h3>ธนาคาร</h3>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="2%"></th>	
                              <th width="38%">ธนาคารฝาก</th>                 
                             <th width="20%">ใบงานฝาก</th>
                             <th width="20%">ไม่มีใบงาน</th>
                             <th width="20%">รวม</th>
                            </tr>
                          </thead>
                            <tbody>
                            	<?php $bankin=0;$bankinnotopen=0;$bankintotal=0; ?>
                            	<?php if ($rs_bank_deposit->num_rows() > 0) {?>
								<?php foreach ($rs_bank_deposit->result() as $row_bank) {?>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo $row_bank->type ?> (<?php echo $row_bank->bankname ?>)</td>
                                    <td><?php echo number_format($depussy[$row_bank->userpass_id]->stintotal,2) ?></td>
                                    <td><?php echo number_format($denotopenpussy[$row_bank->userpass_id]->stintotal,2) ?></td>
                                    <td><?php echo number_format($depussy[$row_bank->userpass_id]->stintotal+$denotopenpussy[$row_bank->userpass_id]->stintotal,2) ?></td>
                                </tr>
                                <?php $bankin += $depussy[$row_bank->userpass_id]->stintotal; ?>
                                <?php $bankinnotopen += $denotopenpussy[$row_bank->userpass_id]->stintotal; ?>
                                <?php $bankintotal += $bankin+$bankinnotopen ?>
                                <?php } ?>
                                <?php } ?>
                            </tbody>
                            <tfoot> 
                                <tr>
                                	<td></td>
                                    <td><strong>รวมทุกบัญชี</strong></td>                                    
                                    <td><?php echo number_format($bankin,2); ?></td>
                                    <td><?php echo number_format($bankinnotopen,2); ?></td>
                                    <td><?php echo number_format($bankintotal,2); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="2%"></th>	
                                <th width="38%">ธนาคารถอน</th>                 
                                <th width="60%">ใบงานถอน</th>
                            </tr>
                          </thead>
                            <tbody>
                            	<?php $bankout = 0; ?>
                                <?php if ($rs_bank_withdraw->num_rows() > 0) {?>
								<?php foreach ($rs_bank_withdraw->result() as $row_bank) {?>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo $row_bank->type ?> (<?php echo $row_bank->bankname ?>)</td>
                                    <td><?php echo number_format($wipussy[$row_bank->userpass_id]->ws_credit,2) ?></td>
                                </tr>
                                <?php $bankout += $wipussy[$row_bank->userpass_id]->ws_credit ?>
                                <?php } ?>
                                <?php } ?>                                
                            </tbody>
                            <tfoot> 
                                <tr>
                                	<td></td>
                                    <td><strong>รวมทุกบัญชี</strong></td>                                    
                                    <td><?php echo number_format($bankout,2); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="100%"><h4>รวมธนาคารขยับ</h4></th>         
                            </tr>
                          </thead>
                            <tbody>
                                <tr>
                                    <td><h4><?php $bankmove = $bankin-$bankout; echo number_format($bankmove,2); ?></h4></td>
                                </tr>
                            </tbody>
                        </table>
                        </div>
                        <div class="clearfix"></div>  
                        <div class="col-sm-6 col-md-6">
                        <h3>ชนยอด</h3>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                        	<thead>
                            <tr role="row">
                                <th width="40%"></th>	
                                <th width="20%"></th>
                                <th width="20%"></th>
                                <th width="20%">เช็ค</th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>ยอดขยับใบงานเครดิตกับธนาคาร</td>
                                    <td><?php echo number_format($creditwsusedwithoutprototal,2); ?></td>
                                    <td><?php echo number_format($bankmove,2); ?></td>
                                    <td><?php echo number_format($creditwsusedwithoutprototal-$bankmove,2); ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><strong>เครดิต</strong></td>
                                    <td><strong>ใบงาน</strong></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>เครดิตกับใบงาน</td>
                                    <td><?php echo number_format($creditusedtotal,2); ?></td>
                                    <td><?php echo number_format($creditwsusedtotal,2); ?></td>
                                    <td><?php echo number_format($creditusedtotal-$creditwsusedtotal,2); ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><strong>เครดิต</strong></td>
                                    <td><strong>ธนาคาร</strong></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>ชนยอดใบงานฝาก</td>
                                    <td><?php echo number_format($creditdeposittotal,2); ?></td>
                                    <td><?php echo number_format($bankin,2); ?></td>
                                    <td><?php echo number_format($creditdeposittotal-$bankin,2); ?></td>
                                </tr>
                                <tr>
                                    <td>ชนยอดใบงานถอน</td>
                                    <td><?php echo number_format($creditwithdrawtotal,2); ?></td>
                                    <td><?php echo number_format($bankout,2); ?></td>
                                    <td><?php echo number_format($creditwithdrawtotal-$bankout,2); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        </div>                   
                    </div>
                </div>
            </div>
        </div>
        <!-- END Row -->
        <?php } ?>
        
        <?php if($dealer=='All'||$dealer=='918kiss'){ ?>
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel panel-color panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title">918kiss</h3>
                    </div>
                    <div class="panel-body table-responsive">
                    	<div class="col-sm-6 col-md-6">
                        <h3>เครดิต</h3>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="2%"></th>	
                                <th width="23%">เอเย่นต์</th>                 
                                <th width="25%">เครดิตเริ่มต้น</th>
                                <th width="25%">เครดิตคงเหลือ</th>
                                <th width="25%">เครดิตใช้ไป</th>
                            </tr>
                          </thead>
                          	<?php if($rs_scr->num_rows()>0){ $i=1;$creditagentlaststarttotal=0;$creditagentlastendtotal=0;$creditusedtotal=0;?>
                            <tbody>
                        		<?php foreach($rs_scr->result() as $row){ ?>
                                <tr>
                                	<td><?php echo $i++; ?></td>
                                	<td><?php echo $row->username ?></td>
                                    <td>
										<?php
											$row_lastcreditagent = $this->deposit_model->get_depositwithdraw_last('918kiss',$row->username,$datestart);
											$creditagentlaststart = ($row_lastcreditagent->type=='ฝาก')?$row_lastcreditagent->creditagentbefore-$row_lastcreditagent->credit:$row_lastcreditagent->creditagentbefore+$row_lastcreditagent->credit;
											echo number_format($creditagentlaststart,2);
											$creditagentlaststarttotal+=$creditagentlaststart;
										?>
                                    </td>
                                    <td>
										<?php 
											$row_lastcreditagent = $this->deposit_model->get_depositwithdraw_last('918kiss',$row->username,$dateend);
											$creditagentlastend = ($row_lastcreditagent->type=='ฝาก')?$row_lastcreditagent->creditagentbefore-$row_lastcreditagent->credit:$row_lastcreditagent->creditagentbefore+$row_lastcreditagent->credit;
											echo number_format($creditagentlastend,2);
											$creditagentlastendtotal+=$creditagentlastend;
										?>
                                    </td>
                                    <td>
                                    	<?php $creditused = $creditagentlaststart-$creditagentlastend; echo number_format($creditused,2); ?>
                                        <?php $creditusedtotal+=$creditused; ?>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot> 
                                <tr>
                                	<td></td>
                                    <td><strong>รวม</strong></td>                                    
                                    <td><?php echo number_format($creditagentlaststarttotal,2); ?></td>
                                    <td><?php echo number_format($creditagentlastendtotal,2); ?></td>
                                    <td><?php echo number_format($creditusedtotal,2); ?></td>
                                </tr>
                            </tfoot>
                            <?php }?>
                        </table>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="2%"></th>	
                                <th width="20%"></th>                 
                                <th width="19%">ใบงานฝาก</th>
                                <th width="19%">ใบงานถอน</th>
                                <th width="19%">เครดิตโยกเข้า</th>
                                <th width="19%">เครดิตโยกออก</th>
                                <th width="19%">เครดิตโปร</th>
                                <th width="19%">เครดิตใช้ไป</th>
                            </tr>
                          </thead>
                            <?php if($rs_scr->num_rows()>0){ $i=1;$creditdeposittotal=0;$creditwithdrawtotal=0;$creditdeposittransfertotal=0;$creditwithdrawtransfertotal=0;$creditprototal=0;$creditwsusedtotal=0;$creditwsusedwithoutprototal=0?>
                            <tbody>
                                <?php foreach($rs_scr->result() as $row){ ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><?php echo $row->username ?></td>
                                    <td>
                                        <?php 
                                            $row_creditdepositagent = $this->deposit_model->get_sumcountcredit($datestart,$dateend,NULL,'918kiss',$row->username);
                                            $creditdepositagent = $row_creditdepositagent->credittotal; $creditdeposittotal+=$creditdepositagent;
                                            echo number_format($creditdepositagent,2);
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                            $row_creditwithdrawagent = $this->withdraw_model->get_sumcountcredit($datestart,$dateend,NULL,'918kiss',$row->username);
                                            $creditwithdrawagent = $row_creditwithdrawagent->credittotal; $creditwithdrawtotal+=$creditwithdrawagent;
                                            echo number_format($creditwithdrawagent,2);
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $row_creditdeposittransfer = $this->deposit_model->get_sumcountcredittransfer($datestart,$dateend,NULL,'918kiss',$row->username);
                                            $creditdeposittransfer = $row_creditdeposittransfer->credittotal; $creditdeposittransfertotal+=$creditdeposittransfer;
                                            echo number_format($creditdeposittransfer,2);
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                            $row_creditwithdrawtransfer = $this->withdraw_model->get_sumcountcredittransfer($datestart,$dateend,NULL,'918kiss',$row->username);
                                            $creditwithdrawtransfer = $row_creditwithdrawtransfer->credittotal; $creditwithdrawtransfertotal+=$creditwithdrawtransfer;
                                            echo number_format($creditwithdrawtransfer,2);
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $row_creditproagent = $this->deposit_model->get_sumcountcreditpromotion($datestart,$dateend,NULL,'918kiss',$row->username);
                                            $creditproagent = $row_creditproagent->credittotal; $creditprototal+=$creditproagent;
                                            echo number_format($creditproagent,2);
                                        ?>
                                    </td>
                                    <td>
                                    <?php $creditwsused =  ($creditdepositagent-$creditwithdrawagent)+$creditdeposittransfer+$creditwithdrawtransfer+$creditproagent; echo number_format($creditwsused,2);?>
                                    <?php $creditwsusedtotal += $creditwsused; ?>                                    
                                    <?php $creditwsusedwithoutpro =  ($creditdepositagent-$creditwithdrawagent);?>
                                    <?php $creditwsusedwithoutprototal += $creditwsusedwithoutpro; ?>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot> 
                                <tr>
                                	<td></td>
                                    <td><strong>รวม</strong></td>                                    
                                    <td><?php echo number_format($creditdeposittotal,2); ?></td>
                                    <td><?php echo number_format($creditwithdrawtotal,2); ?></td>
                                    <td><?php echo number_format($creditdeposittransfertotal,2); ?></td>
                                    <td><?php echo number_format($creditwithdrawtransfertotal,2); ?></td>
                                    <td><?php echo number_format($creditproagent,2); ?></td>
                                    <td><?php echo number_format($creditwsusedtotal,2); ?></td>
                                </tr>
                            </tfoot>
                            <?php }?>
                        </table>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>

                            <tr role="row">
                                <th width="100%"><h4>รวมเครดิตขยับ</h4></th>         
                            </tr>
                          </thead>
                            <tbody>
                                <tr>
                                    <td><h4><?php $creditmove = $creditwsusedtotal; echo number_format($creditmove,2); ?></h4></td>
                                </tr>
                            </tbody>
                        </table>                        
                        </div>
                        <div class="col-sm-6 col-md-6">
                        <h3>ธนาคาร</h3>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="2%"></th>	
                              <th width="38%">ธนาคารฝาก</th>                 
                             <th width="20%">ใบงานฝาก</th>
                             <th width="20%">ไม่มีใบงาน</th>
                             <th width="20%">รวม</th>
                            </tr>
                          </thead>
                            <tbody>
                            	<?php $bankin=0;$bankinnotopen=0;$bankintotal=0; ?>
                            	<?php if ($rs_bank_deposit->num_rows() > 0) {?>
								<?php foreach ($rs_bank_deposit->result() as $row_bank) {?>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo $row_bank->type ?> (<?php echo $row_bank->bankname ?>)</td>
                                    <td><?php echo number_format($descr[$row_bank->userpass_id]->stintotal,2) ?></td>
                                    <td><?php echo number_format($denotopenscr[$row_bank->userpass_id]->stintotal,2) ?></td>
                                    <td><?php echo number_format($descr[$row_bank->userpass_id]->stintotal+$denotopenscr[$row_bank->userpass_id]->stintotal,2) ?></td>
                                </tr>
                                <?php $bankin += $descr[$row_bank->userpass_id]->stintotal; ?>
                                <?php $bankinnotopen += $denotopenscr[$row_bank->userpass_id]->stintotal; ?>
                                <?php $bankintotal += $bankin+$bankinnotopen ?>
                                <?php } ?>
                                <?php } ?>
                            </tbody>
                            <tfoot> 
                                <tr>
                                	<td></td>
                                    <td><strong>รวมทุกบัญชี</strong></td>                                    
                                    <td><?php echo number_format($bankin,2); ?></td>
                                    <td><?php echo number_format($bankinnotopen,2); ?></td>
                                    <td><?php echo number_format($bankintotal,2); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="2%"></th>	
                                <th width="38%">ธนาคารถอน</th>                 
                                <th width="60%">ใบงานถอน</th>
                            </tr>
                          </thead>
                            <tbody>
                            	<?php $bankout = 0; ?>
                                <?php if ($rs_bank_withdraw->num_rows() > 0) {?>
								<?php foreach ($rs_bank_withdraw->result() as $row_bank) {?>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo $row_bank->type ?> (<?php echo $row_bank->bankname ?>)</td>
                                    <td><?php echo number_format($wiscr[$row_bank->userpass_id]->ws_credit,2) ?></td>
                                </tr>
                                <?php $bankout += $wiscr[$row_bank->userpass_id]->ws_credit ?>
                                <?php } ?>
                                <?php } ?>                                
                            </tbody>
                            <tfoot> 
                                <tr>
                                	<td></td>
                                    <td><strong>รวมทุกบัญชี</strong></td>                                    
                                    <td><?php echo number_format($bankout,2); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                          <thead>
                            <tr role="row">
                                <th width="100%"><h4>รวมธนาคารขยับ</h4></th>         
                            </tr>
                          </thead>
                            <tbody>
                                <tr>
                                    <td><h4><?php $bankmove = $bankin-$bankout; echo number_format($bankmove,2); ?></h4></td>
                                </tr>
                            </tbody>
                        </table>
                        </div>
                        <div class="clearfix"></div>  
                        <div class="col-sm-6 col-md-6">
                        <h3>ชนยอด</h3>
                        <table class="table table-striped table-bordered table-hover datatables" width="100%">
                        	<thead>
                            <tr role="row">
                                <th width="40%"></th>	
                                <th width="20%"></th>
                                <th width="20%"></th>
                                <th width="20%">เช็ค</th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>ยอดขยับใบงานเครดิตกับธนาคาร</td>
                                    <td><?php echo number_format($creditwsusedwithoutprototal,2); ?></td>
                                    <td><?php echo number_format($bankmove,2); ?></td>
                                    <td><?php echo number_format($creditwsusedwithoutprototal-$bankmove,2); ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><strong>เครดิต</strong></td>
                                    <td><strong>ใบงาน</strong></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>เครดิตกับใบงาน</td>
                                    <td><?php echo number_format($creditusedtotal,2); ?></td>
                                    <td><?php echo number_format($creditwsusedtotal,2); ?></td>
                                    <td><?php echo number_format($creditusedtotal-$creditwsusedtotal,2); ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><strong>เครดิต</strong></td>
                                    <td><strong>ธนาคาร</strong></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>ชนยอดใบงานฝาก</td>
                                    <td><?php echo number_format($creditdeposittotal,2); ?></td>
                                    <td><?php echo number_format($bankin,2); ?></td>
                                    <td><?php echo number_format($creditdeposittotal-$bankin,2); ?></td>
                                </tr>
                                <tr>
                                    <td>ชนยอดใบงานถอน</td>
                                    <td><?php echo number_format($creditwithdrawtotal,2); ?></td>
                                    <td><?php echo number_format($bankout,2); ?></td>
                                    <td><?php echo number_format($creditwithdrawtotal-$bankout,2); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        </div>                   
                    </div>
                </div>
            </div>
        </div>
        <!-- END Row -->
        <?php } ?>
        
      </div>  
  <!-- container -->   
</div>
<!-- Page content Wrapper -->