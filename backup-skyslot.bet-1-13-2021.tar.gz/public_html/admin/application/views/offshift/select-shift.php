<!-- selectize CSS -->

<link href="<?php echo base_url('assets/plugins/selectize/selectize.bootstrap3.css') ?>" rel="stylesheet">

<!-- selectize JavaScript -->

<script src="<?php echo base_url('assets/plugins/selectize/selectize.min.js') ?>"></script>



<div class="">

  <div class="page-header-title">

    <h4 class="page-title">เลือกกะ SCR1688</h4>

  </div>

</div>

<div class="page-content-wrapper ">

    <div class="container">



    <div class="row">                                     

        <div class="col-sm-12 col-md-12">

            <div class="panel">

                <div class="panel-body">

                    <form id="form-offshift" action="<?php echo site_url('offshift/report') ?>" class="col-sm-12 col-md-4" method="get">

                    <?php if($rs_offshift->num_rows()>0){ ?>

                    <select name="offshift_id" id="offshift_id" class="form-control">

                        <option value="">== เลือกกะ ==</option>

                        <?php foreach ($rs_offshift->result() as $offshift){ ?>

                        <option value="<?php echo $offshift->offshift_id ?>" <?php echo (isset($_GET['offshift_id'])&&$_GET['offshift_id']==$offshift->offshift_id)?'selected':'' ?> ><?php echo $offshift->offshift_date ?></option>

                        <?php } ?>

                    </select> 

                    <?php } ?>

                    </form>

                </div>

            </div>

        </div>                                     

    </div>

    <!-- END Row -->

  

  </div>

  <!-- container -->   

</div>

<!-- Page content Wrapper -->

<script language="javascript">

$(function(){

	$("#offshift_id").change(function() {

		if($(this).val()!=''){

			$('#form-offshift').submit();

		}

	});

});

$('#offshift_id').selectize({

	create: true,

	dropdownParent: 'body'

});

</script>