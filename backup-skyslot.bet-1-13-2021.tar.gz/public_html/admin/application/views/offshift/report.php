<div class="">
  <div class="page-header-title">
    <h4 class="page-title">รายงานปิดกะ SCR1688 [ <?php echo $titlereport ?> ]</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container">
    <div class="row">
      <div class="col-sm-6 col-md-6">
        <div class="panel warm-blue-bg">
          <div class="panel-body">
            <div class="icon-bg"> <i class="ti-stats-up"></i> </div>
            <div class="text-right">
              <h4>918kiss</h4>
            </div>
            <?php foreach($rs_scr->result() as $row){ ?>
            <?php $rs_worksheetbefore = $this->worksheet_model->get_worksheet_deposit_shiftdate('918kiss',$row->userpass_id,$startshiftbefore, $endshiftbefore); ?>
            <?php $rs_worksheet = $this->worksheet_model->get_worksheet_deposit_shiftdate('918kiss',$row->userpass_id,$startshift, $endshift); ?>
            <hr / style="border-color:#7B7A7A;">
            <div class="text-center">
              <h4><strong><?php echo $row->username ?></strong></h4>
            </div>
            <hr / style="border-color:#7B7A7A;">
            <div class="text-right">
              <h4>เริ่มกะ <?php echo $rs_worksheetbefore->ws_total ?></h4>
              <h4>ปิดกะ <?php echo $rs_worksheet->ws_total ?></h4>
            </div>
            <?php } ?>        
          </div>
        </div>
      </div>  
      <div class="col-sm-6 col-md-6">
        <div class="panel warm-blue-bg">
          <div class="panel-body">
            <div class="icon-bg"> <i class="ti-stats-up"></i> </div>
            <div class="text-right">
              <h4>Slot Xo</h4>
            </div>
            <?php foreach($rs_slotxo->result() as $row){ ?>
            <?php $rs_worksheetbefore = $this->worksheet_model->get_worksheet_deposit_shiftdate('Slotxo',$row->userpass_id,$startshiftbefore, $endshiftbefore); ?>
            <?php $rs_worksheet = $this->worksheet_model->get_worksheet_deposit_shiftdate('Slotxo',$row->userpass_id,$startshift, $endshift); ?>
             <hr / style="border-color:#7B7A7A;">
            <div class="text-center">
              <h4><strong><?php echo $row->username ?></strong></h4>
            </div>
            <hr / style="border-color:#7B7A7A;">
            <div class="text-right">
              <h4>เริ่มกะ <?php echo $rs_worksheetbefore->ws_total ?></h4>
              <h4>ปิดกะ <?php echo $rs_worksheet->ws_total ?></h4>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>  
    </div>
    <!-- END Row -->
    <div class="row">
        <?php $bank = explode('(',$row_shift->bank); //print_r($bank_balance); ?>
        <?php 
            $bank = array_filter($bank);
            foreach($bank as $row){
                $row_bank = explode(')',$row);
                $bank_ac = explode('-',$row_bank[0]);
        ?>
          <div class="col-sm-4 col-md-4">
            <div class="panel <?php echo $bank_ac[0]; ?>-bg">
              <div class="panel-body table-responsive">
                <div class="icon-bg"><i class="thbanks thbanks-<?php echo $bank_ac[0]; ?>"></i></div>
                <div class="text-right">
                    <h4 style="margin-left:30px;"><?php echo rtrim($row_bank[1],', '); ?></h4>
                    
                    <?php $row_inbank = $this->statement_model->get_sumin($bank_ac[0],$bank_ac[1],$startshift,$endshift); // ?>
                    <h4>ยอดจากรายการ แบงค์</h4>
                    <h4>
                    ฝาก <?php echo $row_inbank->listtotal ?> รายการ<br />          	
                    จำนวน <?php echo number_format($row_inbank->stintotal) ?> บาท<br />            
                    </h4>
                    <hr / style="border-color:#fff;">
                    <h4>ยอดจากรายการ ใบงาน</h4> 
                    <?php $row_wscredit = $this->worksheet_model->get_worksheet_deposit_credit($bank_ac[0],$bank_ac[1],$startshift,$endshift); // ?>
                    <h4>
                    ฝาก <?php echo $row_wscredit->listtotal ?> รายการ<br />          	
                    จำนวน <?php echo number_format($row_wscredit->ws_credit) ?> บาท<br />            
                    </h4>
                    <hr / style="border-color:#fff;">
                    <h4>= <?php echo number_format($row_inbank->stintotal-$row_wscredit->ws_credit) ?></h4>
                </div>            
              </div>
            </div>  
          </div><!-- End bank -->
        <?php  } ?>
    </div>
    <!-- END Row BANK -->
    <div class="row">
        <h3>ยอด ธนาคารถอน</h3>
        <?php $bankwithdraw = explode('(',$row_shift->bankwithdraw); //print_r($bank_balance); ?>
        <?php 
            $bankwithdraw = array_filter($bankwithdraw);
            foreach($bankwithdraw as $row){
                $row_bankwithdraw = explode(')',$row);
                $bank_ac = explode('-',$row_bankwithdraw[0]);
        ?>
          <div class="col-sm-4 col-md-4">
            <div class="panel <?php echo $bank_ac[0]; ?>-bg">
              <div class="panel-body table-responsive">
                <div class="icon-bg"><i class="thbanks thbanks-<?php echo $bank_ac[0]; ?>"></i></div>
                <div class="text-right">
                    <h4 style="margin-left:30px;"><?php echo rtrim($row_bankwithdraw[1],', '); ?></h4>
                    <h4>ยอดจากรายการ ใบงาน</h4> 
                    <?php $row_wscredit = $this->worksheet_model->get_worksheet_withdraw_credit($bank_ac[0],$bank_ac[1],$startshift,$endshift); // ?>
                    <h4>
                    ถอน <?php echo $row_wscredit->listtotal ?> รายการ<br />          	
                    จำนวน <?php echo number_format($row_wscredit->ws_credit) ?> บาท<br />            
                    </h4>
                </div>            
              </div>
            </div>  
          </div><!-- End bankwithdraw -->
        <?php  } ?>
    </div>
    <!-- END Row BANKWITHDRAW -->
    
  </div>
  <!-- container -->   
</div>
<!-- Page content Wrapper -->