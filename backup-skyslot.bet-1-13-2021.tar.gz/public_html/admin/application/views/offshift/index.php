<div class="">

  <div class="page-header-title">

    <h4 class="page-title">ปิดกะ Scr1688</h4>

  </div>

</div>

<div class="page-content-wrapper ">

    <div class="container">



    <div class="row">                                     

        <div class="col-sm-12 col-md-12">

            <div class="panel">

                <div class="panel-body">

                    <a href="javascript:void(0);" class="btn btn-info btn-lg" id="offshift"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ปิดกะ</a>

                </div>

            </div>

        </div>                                     

    </div>

    <!-- END Row -->

	<?php if($this->session->userdata('level')=='admin'){ ?>

    <div class="row">

        <div class="col-sm-12 col-md-12">

            <div class="panel">

                <div class="panel-heading">

                    <h2 class="panel-title">รายการปิดกะ</h2>

                </div>

                <div class="panel-body table-responsive">

                    <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">

                      <thead>

                        <tr role="row">

                          <th width="5%"></th>	

                          <th width="87%">วันที่ / เวลา ปิดกะ</th>

                          <th class="text-center" width="5%"></th>

                        </tr>

                      </thead>

                        <tbody>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>                                   

    </div>

    <!-- END Row -->

  

  </div>

  <!-- container -->   

</div>

<!-- Page content Wrapper -->

<script type="text/javascript" charset="utf-8">

    $(document).ready(function() {

        var t = $('#datatables').DataTable({

			"bPaginate": true, 

			//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า

			//"bFilter": false, //+ ช่องค้นหา

			//"bInfo": false, //+ รายละเอียดจำนวนแถว

            "bProcessing": true,

            "bServerSide": true,

            "sServerMethod": "GET",

            "sAjaxSource": '<?php echo base_url('offshift/list-shift-all'); ?>',

            "iDisplayLength": 50,

			"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort

				{"searchable": true, "orderable": false, "targets":0,'className':'text-center'},

				{

					"searchable": false, 

					"orderable": false, 

					'className':'text-center',

					"targets":2,

					"render": function(data, type, row) { // Available data available for you within the row

						var x = '<div class="btn-group btn-group-xs" align="center"><a href="<?php echo site_url('offshift/delete') ?>/'+data+'" class="open_modal btn btn-default" onclick="return confirm (\'ต้องการลบจริง ๆ หรือ ?\')"><i class="mdi mdi-delete"></i> ลบ</a></div>';

						return x;

					}

				}

			],

			"order": [1, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ

        });

    });

</script>

<?php } ?>

<script language="javascript">

$(function(){

	$.fn.modal.Constructor.prototype.enforceFocus = function(){};

	$('#offshift').click(function(){

		swal({

		  title: "ยืนยัน ปิดกะ ?",

		  type: "warning",

		  showCancelButton: true,

		  cancelButtonText: "ยกเลิก",

		  confirmButtonText: "ยืนยัน",

		  closeOnConfirm: false

		},function(){

			//$('#offshift span.glyphicon-refresh').show();

			$.LoadingOverlay("show");

			$.ajax({

				type: 'POST',

				dataType: 'json',

				cache: false,

				url: '<?php echo site_url('offshift/operate') ?>',

				data:{'method':'offshift'},

				success: function(resp){

					var msg = '';

					//$('#offshift span.glyphicon-refresh').hide('slow');

					$.LoadingOverlay("hide");

					if(resp.error==1){

						swal({title:'ไม่สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false});

					}else{

						swal({title:'สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false},function(){

							window.location.reload();	

						});

					}

				}

			});

		});

	});

});

</script>