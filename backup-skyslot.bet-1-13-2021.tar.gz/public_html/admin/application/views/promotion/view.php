<div class="">
  <div class="page-header-title">
    <h4 class="page-title">โปรโมชั่น : <?php echo $row_promotion->title ?></h4>
  </div>
</div>
<div class="page-content-wrapper ">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12">
        <div class="panel">
          <div class="panel-heading"> 
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">General Info</a></li>
              <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Edit</a></li>
              <!--<li role="presentation"><a href="#other-admin" aria-controls="other-admin" role="tab" data-toggle="tab">Other Admin Features</a></li>-->
            </ul>
          </div>
          <div class="panel-body"> 
            <!-- Tab panes -->
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="home">
                <form class="form-horizontal" method="POST" role="form">
                  <div class="form-group">
                    <label for="pr_type" class="col-sm-4 col-md-4 control-label">โปรโมชั่น:</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->pr_type ?></p>
                    </div>
                  </div>                    
                  <div class="form-group">
                    <label for="username" class="col-sm-4 col-md-4 control-label">รายละเอียดโปรโมชั่น:</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->title ?></p>
                    </div>
                  </div>
                  <?php if($row_promotion->fixedrate=='n'){ ?>
                  <div class="form-group">
                    <label for="percent" class="col-sm-4 col-md-4 control-label">เปอร์เซ็นที่ได้(%):</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->percent ?></p>
                    </div>
                  </div>
				  <div class="form-group">
                    <label for="maximum_receive" class="col-sm-4 col-md-4 control-label">ได้โบนัสสูงสุด:</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->maximum_receive ?></p>
                    </div>
                  </div>
                  <?php } ?>
				  <div class="form-group">
                    <label for="minimum" class="col-sm-4 col-md-4 control-label">ยอดขั้นต่ำ:</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->minimum ?></p>
                    </div>
                  </div>
                  <?php if($row_promotion->fixedrate=='y'){ ?>
                  <div class="form-group">
                    <label for="rate" class="col-sm-4 col-md-4 control-label">ยอดเงินที่ได้:</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->rate ?></p>
                    </div>
                  </div>
                  <?php } ?>
                  <div class="form-group">
                    <label for="turn" class="col-sm-4 col-md-4 control-label">ยอดเทิร์น(เท่า):</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->turn ?></p>
                    </div>
                  </div>
				  <div class="form-group">
                    <label for="withdraw_limit" class="col-sm-4 col-md-4 control-label">ถอนสูงสุด:</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->withdraw_limit ?></p>
                    </div>
                  </div>
				  <div class="form-group">
                    <label for="created" class="col-sm-4 col-md-4 control-label">วันที่สร้าง:</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->created ?></p>
                    </div>
                  </div>
				  <div class="form-group">
                    <label for="modified" class="col-sm-4 col-md-4 control-label">วันที่แก้ไข:</label>
                    <div class="col-sm-8 col-md-8">
                      <p class="form-control-static"><?php echo $row_promotion->modified ?></p>
                    </div>
                  </div>
                </form>
              </div>
              <div role="tabpanel" class="tab-pane" id="profile">
                <div class="modal-content" id="modal-content">
                  <form class="form-horizontal" id="admin-edit-account" action="<?php echo site_url('promotion/edit') ?>" method="POST" role="form">
                    <div class="form-group">
                      <div class="col-sm-4 col-md-3 col-lg-3"> </div>
                    </div>
                    <div class="form-group">
                        <label for="pr_type" class="col-sm-4 col-md-4 control-label">โปรโมชั่น :</label>
                        <div class="col-sm-7">
                            <select name="pr_type" id="pr_type" class="form-control" required>
                                <option value="">== เลือก ==</option>                                
                                <option value="ฝากประจำ" <?php echo ($row_promotion->pr_type=='ฝากประจำ')?'selected':'' ?> disabled>ฝากประจำ</option>
                                <option value="โบนัสสมาชิกใหม่" <?php echo ($row_promotion->pr_type=='โบนัสสมาชิกใหม่')?'selected':'' ?>>โบนัสสมาชิกใหม่</option>  
                                <option value="โบนัสแจกฟรี" <?php echo ($row_promotion->pr_type=='โบนัสแจกฟรี')?'selected':'' ?> disabled>โบนัสแจกฟรี</option>                              
                                <option value="ชั่วโมงเงิน" <?php echo ($row_promotion->pr_type=='ชั่วโมงเงิน')?'selected':'' ?> disabled>ชั่วโมงเงิน (10:00 - 12:00)</option>
                                <option value="ชั่วโมงทอง" <?php echo ($row_promotion->pr_type=='ชั่วโมงทอง')?'selected':'' ?> disabled>ชั่วโมงทอง (15:00 - 17:00)</option>
                                <option value="ช่วงเวลาฟ้าแลบ" <?php echo ($row_promotion->pr_type=='ช่วงเวลาฟ้าแลบ')?'selected':'' ?> disabled>ช่วงเวลาฟ้าแลบ (20:00 - 22:00)</option>
                                <option value="ชั่วโมงรวย" <?php echo ($row_promotion->pr_type=='ชั่วโมงรวย')?'selected':'' ?> disabled>ชั่วโมงรวย (00:00 - 02:00)</option>
                                <option value="โปรสุ่มแจก" <?php echo ($row_promotion->pr_type=='โปรสุ่มแจก')?'selected':'' ?> disabled>โปรสุ่มแจก</option>
								<option value="ฟรีเครดิต" <?php echo ($row_promotion->pr_type=='ฟรีเครดิต')?'selected':'' ?>>ฟรีเครดิต</option>
                            </select>
                        </div>
                    </div>                    
                    <div class="form-group ">
                      <label for="inputUsername" class="col-sm-4 control-label">รายละเอียดโปรโมชั่น :</label>
                      <div class="col-sm-7">
                        <textarea rows="3" class="form-control" name="title" placeholder="รายละเอียดโปรโมชั่น" required><?php echo $row_promotion->title ?></textarea>
                      </div>
                    </div>
                    <?php if($row_promotion->fixedrate=='n'){ ?>
                    <div class="form-group">
                      <label for="percent" class="col-sm-4  control-label">เปอร์เซ็นที่ได้(%) :</label>
                      <div class="col-sm-7">
                        <input type="text" name="percent" class="form-control" id="percent" placeholder="เปอร์เซ็นที่ได้ของโปร" onfocus="this.select();" required value="<?php echo $row_promotion->percent ?>" maxlength="3">
                      </div>
                    </div>
					<div class="form-group">
                      <label for="maximum_receive" class="col-sm-4  control-label">ได้โบนัสสูงสุด :</label>
                      <div class="col-sm-7">
                        <input type="text" name="maximum_receive" class="form-control" id="maximum_receive" placeholder="ได้โบนัสสูงสุดจากเปอร์เซ็นที่ได้" onfocus="this.select();" required value="<?php echo $row_promotion->maximum_receive ?>" maxlength="5">
                      </div>
                    </div>
                    <?php } ?>
					<div class="form-group">
                      <label for="minimum" class="col-sm-4  control-label">ยอดขั้นต่ำ :</label>
                      <div class="col-sm-7">
                        <input type="text" name="minimum" class="form-control" id="minimum" placeholder="ยอดขั้นต่ำ" onfocus="this.select();" required value="<?php echo $row_promotion->minimum ?>">
                      </div>
                    </div>
                    <?php if($row_promotion->fixedrate=='y'){ ?>
                    <div class="form-group">
                      <label for="rate" class="col-sm-4  control-label">ยอดเงินที่ได้ :</label>
                      <div class="col-sm-7">
                        <input type="text" name="rate" class="form-control" id="rate" placeholder="ยอดเงินที่ได้" onfocus="this.select();" required value="<?php echo $row_promotion->rate ?>">
                      </div>
                    </div>
                    <?php } ?>
                    <div class="form-group">
                      <label for="turn" class="col-sm-4  control-label">ยอดเทิร์น(เท่า) :</label>
                      <div class="col-sm-7">
                        <input type="text" name="turn" class="form-control" id="turn" placeholder="ยอดเทิร์นของโปร" onfocus="this.select();" required value="<?php echo $row_promotion->turn ?>" maxlength="3">
                      </div>
                    </div>
					<div class="form-group">
                      <label for="withdraw_limit" class="col-sm-4  control-label">ถอนสูงสุด :</label>
                      <div class="col-sm-7">
                        <input type="text" name="withdraw_limit" class="form-control" id="withdraw_limit" placeholder="ถอนได้สูงสุด" onfocus="this.select();" required value="<?php echo $row_promotion->withdraw_limit ?>">
                      </div>
                    </div>
                    <div class="form-group  ">
                      <label for="inputType" class="col-sm-4 control-label">สถานะ:</label>
                      <div class="col-sm-4 col-md-4">
                        <select  class="form-control" name="status" id="inputStatus">
                          <option value="ใช้" <?php echo ($row_promotion->status=='ใช้')?'selected':'' ?>>ใช้</option>
                          <option value="เลิกใช้" <?php echo ($row_promotion->status=='เลิกใช้')?'selected':'' ?>>เลิกใช้</option>
                		</select>
					  </div>
					</div>
					<?php if ($row_promotion->pr_type == 'ฟรีเครดิต') { ?>
					<div class="form-group  ">
                      <label for="inputType" class="col-sm-4 control-label">แสดงผล:</label>
                      <div class="col-sm-7">
					  	<input type="checkbox" id="promotion_status" name="promotion_status" value="Y">
					  </div>
					</div>
					<div class="form-group  ">
                      <label for="inputType" class="col-sm-4 control-label">ลิงค์ Promotion:</label>
                      <div class="col-sm-7">
					  	<input type="text" class="form-control" id="promotion_url" name="promotion_url" value="">
					  </div>
					</div>
					<?php } ?>
					<div class="form-group">
						<label for="image" class="col-sm-4 control-label">ไฟล์รูปเดิม:</label>
						<div class="col-sm-6">
							<?php if ($row_promotion->pr_img) { ?>
								<img id="example-image" src="<?php echo $row_promotion->pr_img ?>" />
							<?php } else { ?>
								-
							<?php } ?>
						</div>
					</div>
					<div class="form-group">
						<label for="image" class="col-sm-4 control-label">เปลี่ยนไฟล์รูป:</label>
						<div class="col-sm-6">
							<input type="file"  id="image-upload" name="image-upload"/>
							<div id="image-queue" class="queue"></div>
							<input type="hidden" id="pr-img" name="pr_img" value="" />
						</div>
					</div>
                    <div class="form-group text-center">
						<small style="color: red;">** ขณะอัพโหลด รอให้ขึ้น สถานะ Completed และห้ามทำการ Refresh หน้าเว็บ **</small>
					</div>
                    <div class="form-group">
                      <div class="col-sm-4 col-md-4"></div>
                      <div class="col-sm-4 col-md-4">
                      	<input type="hidden" name="fixedrate" value="<?php echo $row_promotion->fixedrate ?>">
                        <input name="promotiontoedit" value="<?php echo $row_promotion->pr_id ?>" type="hidden">
                        <button type="submit" id="submit" name="button" value="Edit Account" class="btn btn-default"><i class=" fa fa-refresh "></i> Submit Changes</button>
                      </div>
                    </div>
                  </form>
                </div>
                <!-- End <div class="modal-content" id="modal-content"> --> 
              </div>
              <!-- End <div role="tabpanel" class="tab-pane" id="profile"> -->
            </div>
          </div>
        </div>
        <!-- End panel --> 
      </div>
    </div>
    <!-- End row --> 
  </div>
  <!-- container --> 
</div>
<!-- Page content Wrapper --> 
<script type="text/javascript">
$(function() {
	// Javascript to enable link to tab
	var hash = document.location.hash;
	if (hash) {
		console.log(hash);
		$('.nav-tabs a[href='+hash+']').tab('show');
	}	
	// Change hash for page-reload
	$('a[data-toggle="tab"]').on('show.bs.tab', function (e) {
		window.location.hash = e.target.hash;
	});
	$("#percent,#maximum_receive,#turn,#minimum,#rate,#withdraw_limit").on("input", function(evt) {
	   var self = $(this);
	   self.val(self.val().replace(/[^\-0-9\.]/g, ''));
	});
	$("#percent,#maximum_receive,#turn,#minimum,#rate").on("blur", function() {
		if($(this).val().length == 0){
	  		$(this).val(1);
		}
	});
	$("#withdraw_limit").on("blur", function() {
		if($(this).val().length == 0){
			$(this).val(0);
		}
	});

	<?php if ($row_promotion->pr_type == 'ฟรีเครดิต') { ?>
		$.ajax({
			type: 'GET',
			url: '<?php echo site_url('promotion/get_promotion_settings/'.$row_promotion->pr_id) ?>',
			dataType: 'json',
			success: function(response) {
				if(response!='' && response != null){
					$('#promotion_url').val(response.promotion_url);
					if(response.promotion_status == true) {
						$('#promotion_status').prop('checked', true);
					}
				}
			}
		});
	<?php } ?>
});
</script>
<link href="<?php echo base_url('assets/plugins/uploadifive/uploadifive.css') ?>" type="text/css" media="screen" rel="stylesheet"/>
<script src="<?php echo base_url('assets/plugins/uploadifive/jquery.uploadifive.min.js') ?>" type="text/javascript"></script>
<script type="text/javascript">
$(function(){
	var base_url = '<?php echo base_url(); ?>';
	$('#image-upload').uploadifive({
		'auto' : true,
		'buttonText':'เลือกไฟล์ (JPG | PNG) และ ขนาดไม่เกิน 2 Mb.',
		'fileType' : new Array("image"),
		'removeCompleted' : false,
		'multi' : false,
		//'formData':{'image_old':''},
		'fileObjName':'promotionimg',
		'fileSizeLimit' : 2048,
		'width' :300,
		'queueID' : 'image-queue',
		'uploadScript' : '<?php echo base_url('promotion/upload-img') ?>',
		'onUploadComplete' : function(file, data){
			var d = new Date();
			var obj = $.parseJSON(data);
			//alert('The file ' + obj.name + ' Success ');
			//$('#example-image').attr('src', base_url+'images/'+obj.name+'?d='+d.getTime());
			$('#pr-img').val(obj.name);
		}
	});
});
</script>