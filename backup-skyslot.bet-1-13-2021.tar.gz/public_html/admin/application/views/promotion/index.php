<div class="">
	<div class="page-header-title">
		<h4 class="page-title">โปรโมชั่น</h4>
	</div>
</div>
<div class="page-content-wrapper ">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body">
						<button class="btn btn-primary" href="#createPromotion" type="button" data-toggle="modal">สร้าง โปรโมชั่น</button>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body table-responsive">
						<table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
							<thead>
								<tr role="row">
									<th width="5%"></th>
									<th width="5%"></th>
									<th width="14%">โปรโมชั่น</th>
									<th width="20%">รายละเอียด</th>
									<th width="7%">(%)</th>
									<th width="10%">รับสูงสุด</th>
									<th width="8%">ขั้นต่ำ</th>
									<th width="10%">ยอดที่ได้</th>
									<th width="10%">เทิร์น(เท่า)</th>
									<th width="16%">ถอนสูงสุด</th>
									<th class="text-center" width="8%"></th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<!-- END Row --> 
	</div>
</div>
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
		var t = $('#datatables').DataTable({
			"bPaginate": true, 
			//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
			//"bFilter": false, //+ ช่องค้นหา
			//"bInfo": false, //+ รายละเอียดจำนวนแถว
			"bProcessing": true,
			"bServerSide": true,
			"sServerMethod": "GET",
			"sAjaxSource": '<?php echo base_url('promotion/all'); ?>',
			"iDisplayLength": 50,
			"columnDefs": [	//+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
				{"searchable": true, "orderable": false, "targets":[0,1],'className':'text-center'},
				{
					"searchable": false, 
					"orderable": false, 
					'className':'text-center',
					"targets":10,
					"render": function(data, type, row) { // Available data available for you within the row
						var x = '<div class="btn-group btn-group-xs" align="center"><a href="<?php echo site_url('promotion/view') ?>/'+data+'" class="open_modal btn btn-default"><i class="ti-search"></i> ดูข้อมูล</a></div>';
						return x;
					}
				}
			],
			"order": [2, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
		});
	});
</script> 
<!-- Modals -->
<div class="modal fade" id="createPromotion" tabindex="-1" role="dialog" aria-labelledby="createPromotion" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">สร้าง โปรโมชั่น</h4>
			</div>
			<div class="modal-body">
				<ul class="nav nav-tabs navtab-bg">
					<li class="active">
						<a href="#pro-percent" data-toggle="tab" aria-expanded="false">
							<span class="visible-xs"><i class="fa fa-home"></i></span>
							<span class="hidden-xs">โปรโมชั่นแบบ %</span>
						</a>
					</li>
					<li>
						<a href="#pro-fixed" data-toggle="tab" aria-expanded="true">
							<span class="visible-xs"><i class="fa fa-user"></i></span>
							<span class="hidden-xs">โปรโมชั่นแบบ Fixed</span>
						</a>
					</li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="pro-percent">
						<form class="form-horizontal" action="<?php echo site_url('promotion/add') ?>" method="POST" role="form"> 
							<div class="form-group">
								<label for="pr_type" class="col-sm-5 control-label">โปรโมชั่น :</label>
								<div class="col-sm-6">
									<select name="pr_type" id="pr_type" class="form-control" required>
										<option value="">== เลือก ==</option>
										<option value="ฝากประจำ" disabled>ฝากประจำ</option>
										<option value="โบนัสสมาชิกใหม่">โบนัสสมาชิกใหม่</option>
										<option value="โบนัสแจกฟรี" disabled>โบนัสแจกฟรี</option>
										<option value="ชั่วโมงเงิน" disabled>ชั่วโมงเงิน (10:00 - 12:00)</option>
										<option value="ชั่วโมงทอง" disabled>ชั่วโมงทอง (15:00 - 17:00)</option>
										<option value="ช่วงเวลาฟ้าแลบ" disabled>ช่วงเวลาฟ้าแลบ (20:00 - 22:00)</option>
										<option value="ชั่วโมงรวย" disabled>ชั่วโมงรวย (00:00 - 02:00)</option>
										<option value="โปรสุ่มแจก" disabled>โปรสุ่มแจก</option>
										<option value="ฟรีเครดิต" disabled>ฟรีเครดิต</option>
									</select>
								</div>
							</div>
							<div class="form-group ">
								<label for="title" class="col-sm-5 control-label">รายละเอียดโปรโมชั่น :</label>
								<div class="col-sm-6">
									<textarea rows="3" class="form-control" name="title" placeholder="รายละเอียดโปรโมชั่น" required></textarea>
								</div>
							</div>
							<div class="form-group">
								<label for="percent" class="col-sm-5 control-label">เปอร์เซ็นที่ได้(%) :</label>
								<div class="col-sm-6">
									<input type="text" name="percent" class="form-control" id="percent" placeholder="เปอร์เซ็นที่ได้ของโปร" onfocus="this.select();" required maxlength="3">
								</div>
							</div>
							<div class="form-group">
								<label for="maximum_receive" class="col-sm-5 control-label">ได้โบนัสสูงสุด :</label>
								<div class="col-sm-6">
									<input type="text" name="maximum_receive" class="form-control" id="maximum_receive" placeholder="ได้โบนัสสูงสุดจากเปอร์เซ็นที่ได้" onfocus="this.select();" required maxlength="5">
								</div>
							</div>
							<div class="form-group">
								<label for="minimum" class="col-sm-5 control-label">ยอดเงินขั้นต่ำ :</label>
								<div class="col-sm-6">
									<input type="text" name="minimum" class="form-control" id="minimum" placeholder="ยอดเงินขั้นต่ำ" onfocus="this.select();" required>
								</div>
							</div>
							<div class="form-group">
								<label for="turn" class="col-sm-5 control-label">ยอดเทิร์น(เท่า) :</label>
								<div class="col-sm-6">
									<input type="text" name="turn" class="form-control" id="turn" placeholder="ยอดเทิร์นของโปร" onfocus="this.select();" required maxlength="3">
								</div>
							</div>
							<div class="form-group">
								<label for="withdraw_limit" class="col-sm-5 control-label">ถอนสูงสุด :</label>
								<div class="col-sm-6">
									<input type="text" name="withdraw_limit" class="form-control" id="withdraw_limit" placeholder="ถอนได้สูงสุด" onfocus="this.select();" required maxlength="6">
								</div>
							</div>
							<div class="form-group">
								<label for="image" class="col-sm-5 control-label">ไฟล์รูป:</label>
								<div class="col-sm-6">
									<input type="file"  id="image-upload-percent" name="image-upload-percent"/>
									<div id="image-queue-percent" class="queue"></div>
									<input type="hidden" id="pr-img-percent" name="pr_img_percent" value="" />
								</div>
							</div>
							<div class="form-group text-center">
								<small style="color: red;">** ขณะอัพโหลด รอให้ขึ้น สถานะ Completed และห้ามทำการ Refresh หน้าเว็บ **</small>
							</div>
							<div class="form-group">
								<label for="turn" class="col-sm-5 control-label"></label>
								<div class="col-sm-6">
									<input type="hidden" name="fixedrate" value="n">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									<button type="submit" class="btn btn-primary" id="submit" >Create New</button>
								</div>
							</div>
						</form>
					</div>
					<div class="tab-pane" id="pro-fixed">
						<form class="form-horizontal" action="<?php echo site_url('promotion/add') ?>" method="POST" role="form">
							<div class="form-group">
								<label for="pr_type" class="col-sm-5 control-label">โปรโมชั่น :</label>
								<div class="col-sm-6">
									<select name="pr_type" id="pr_type" class="form-control" required>
										<option value="">== เลือก ==</option>
										<option value="ฝากประจำ" disabled>ฝากประจำ</option>
										<option value="โบนัสสมาชิกใหม่">โบนัสสมาชิกใหม่</option>
										<option value="โบนัสแจกฟรี" disabled>โบนัสแจกฟรี</option>
										<option value="ชั่วโมงเงิน" disabled>ชั่วโมงเงิน (10:00 - 12:00)</option>
										<option value="ชั่วโมงทอง" disabled>ชั่วโมงทอง (15:00 - 17:00)</option>
										<option value="ช่วงเวลาฟ้าแลบ" disabled>ช่วงเวลาฟ้าแลบ (20:00 - 22:00)</option>
										<option value="ชั่วโมงรวย" disabled>ชั่วโมงรวย (00:00 - 02:00)</option>
										<option value="โปรสุ่มแจก" disabled>โปรสุ่มแจก</option>
										<option value="ฟรีเครดิต">ฟรีเครดิต</option>
									</select>
								</div>
							</div>
							<div class="form-group ">
								<label for="title" class="col-sm-5 control-label">รายละเอียดโปรโมชั่น :</label>
								<div class="col-sm-6">
									<textarea rows="3" class="form-control" name="title" placeholder="รายละเอียดโปรโมชั่น" required></textarea>
								</div>
							</div>
							<div class="form-group">
								<label for="percent" class="col-sm-5 control-label">ยอดเงินขั้นต่ำ :</label>
								<div class="col-sm-6">
									<input type="text" name="minimum" class="form-control" id="minimum" placeholder="ยอดเงินขั้นต่ำ" onfocus="this.select();" required>
								</div>
							</div>
							<div class="form-group">
								<label for="turn" class="col-sm-5 control-label">ยอดเงินที่ได้ :</label>
								<div class="col-sm-6">
									<input type="text" name="rate" class="form-control" id="rate" placeholder="ยอดเงินที่ได้" onfocus="this.select();" required>
								</div>
							</div>
							<div class="form-group">
								<label for="turn" class="col-sm-5 control-label">ยอดเทิร์น(เท่า) :</label>
								<div class="col-sm-6">
									<input type="text" name="turn" class="form-control" id="turn" placeholder="ยอดเทิร์นของโปร" onfocus="this.select();" required maxlength="3">
								</div>
							</div>
							<div class="form-group">
								<label for="withdraw_limit" class="col-sm-5 control-label">ถอนสูงสุด :</label>
								<div class="col-sm-6">
									<input type="text" name="withdraw_limit" class="form-control" id="withdraw_limit" placeholder="ถอนได้สูงสุด" onfocus="this.select();" required maxlength="6">
								</div>
							</div>
							<div class="form-group">
								<label for="image" class="col-sm-5 control-label">ไฟล์รูป :</label>
								<div class="col-sm-6">
									<input type="file"  id="image-upload-fixed" name="image-upload"/>
									<div id="image-queue-fixed" class="queue"></div>
									<input type="hidden" id="pr-img-fixed" name="pr_img_fixed" value="" />
								</div>
							</div>
							<div class="form-group text-center">
								<small style="color: red;">** ขณะอัพโหลด รอให้ขึ้น สถานะ Completed และห้ามทำการ Refresh หน้าเว็บ **</small>
							</div>
							<div class="form-group">
								<label for="turn" class="col-sm-5 control-label"></label>
								<div class="col-sm-6">
									<input type="hidden" name="fixedrate" value="y">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									<button type="submit" class="btn btn-primary" id="submit" >Create New</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- END Modals -->
<script type="text/javascript">
$(function() {
	$("#percent,#maximum_receive,#turn,#minimum,#rate,#withdraw_limit").on("input", function(evt) {
		var self = $(this);
		self.val(self.val().replace(/[^\-0-9\.]/g, ''));
	});
	$("#percent,#maximum_receive,#turn,#minimum,#rate").on("blur", function() {
		if($(this).val().length == 0){
			$(this).val(1);
		}
	});
	$("#withdraw_limit").on("blur", function() {
		if($(this).val().length == 0){
			$(this).val(0);
		}
	});
});
</script>
<link href="<?php echo base_url('assets/plugins/uploadifive/uploadifive.css') ?>" type="text/css" media="screen" rel="stylesheet"/>
<script src="<?php echo base_url('assets/plugins/uploadifive/jquery.uploadifive.min.js') ?>" type="text/javascript"></script>
<script type="text/javascript">
$(function(){
	var base_url = '<?php echo base_url(); ?>';
	$('#image-upload-percent').uploadifive({
		'auto' : true,
		'buttonText':'เลือกไฟล์ (JPG | PNG) และ ขนาดไม่เกิน 2 Mb.',
		'fileType' : new Array("image"),
		'removeCompleted' : false,
		'multi' : false,
		//'formData':{'image_old':''},
		'fileObjName':'promotionimg',
		'fileSizeLimit' : 2048,
		'width' :300,
		'queueID' : 'image-queue-percent',
		'uploadScript' : '<?php echo base_url('promotion/upload-img') ?>',
		'onUploadComplete' : function(file, data){
			var d = new Date();
			var obj = $.parseJSON(data);
			//alert('The file ' + obj.name + ' Success ');
			//$('#example-image').attr('src', base_url+'images/'+obj.name+'?d='+d.getTime());
			$('#pr-img-percent').val(obj.name);
		}
	});
	$('#image-upload-fixed').uploadifive({
		'auto' : true,
		'buttonText':'เลือกไฟล์ (JPG | PNG) และ ขนาดไม่เกิน 2 Mb.',
		'fileType' : new Array("image"),
		'removeCompleted' : false,
		'multi' : false,
		//'formData':{'image_old':''},
		'fileObjName':'promotionimg',
		'fileSizeLimit' : 2048,
		'width' :300,
		'queueID' : 'image-queue-fixed',
		'uploadScript' : '<?php echo base_url('promotion/upload-img') ?>',
		'onUploadComplete' : function(file, data){
			var d = new Date();
			var obj = $.parseJSON(data);
			//alert('The file ' + obj.name + ' Success ');
			//$('#example-image').attr('src', base_url+'images/'+obj.name+'?d='+d.getTime());
			$('#pr-img-fixed').val(obj.name);
		}
	});
});
</script>