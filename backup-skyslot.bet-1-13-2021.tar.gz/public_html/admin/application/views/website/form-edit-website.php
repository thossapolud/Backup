<?php if($row_website) { ?>
<div class="form-group">
	<input name="site_id" value="<?php echo $row_website->site_id ?>" type="hidden">
	<label for="acnum" class="col-sm-3 control-label">SITE ID:</label>
	<div class="col-sm-8">
		<input type="text" class="form-control" disabled="disabled" value="<?php echo $row_website->site_id ?>">
	</div>
</div>
<div class="form-group">
	<label for="site_name" class="col-sm-3 control-label">ชื่อเว็บไซต์:</label>
	<div class="col-sm-8">
		<input type="text" name="site_name" class="form-control" id="site_name" value="<?php echo $row_website->site_name ?>" disabled="disabled">
	</div>
</div>
<div class="form-group">
	<label for="site_url" class="col-sm-3 control-label">โดเมนเนม:</label>
	<div class="col-sm-8">
		<input type="url" name="site_url" class="form-control" id="site_url" value="<?php echo $row_website->site_url ?>" placeholder="โดเมนเนม" required>
	</div>
</div>
<div class="form-group">
	<label for="site_def_xfer_h_id_deposit" class="col-sm-3 control-label">กลุ่มลูกค้าฝาก:</label>
	<div class="col-sm-8">
		<select class="form-control" name="site_def_xfer_h_id_deposit" id="site_def_xfer_h_id_deposit" required="required">
			<option value="">==เลือก==</option>
			<?php foreach ($rs_xfer_deposit->result() as $row_xfer) { ?>
			<option value="<?php echo $row_xfer->xfer_h_id ?>"
				<?php echo ($row_xfer->xfer_h_id == $row_website->site_def_xfer_h_id_deposit) ? 'selected' : '' ?>>
				<?php echo $row_xfer->xfer_h_name ?>: <?php echo $row_xfer->xfer_h_desc ?></option>
			<?php } ?>
		</select>
		<span class="help-block"><small>ค่าเริ่มต้นเมื่อลูกค้าสมัครสมาชิกใหม่</small></span>
	</div>
</div>
<div class="form-group">
	<label for="site_def_xfer_h_id_withdraw" class="col-sm-3 control-label">กลุ่มลูกค้าถอน:</label>
	<div class="col-sm-8">
		<select class="form-control" name="site_def_xfer_h_id_withdraw" id="site_def_xfer_h_id_withdraw" required="required">
			<option value="">==เลือก==</option>
			<?php foreach ($rs_xfer_withdraw->result() as $row_xfer) { ?>
			<option value="<?php echo $row_xfer->xfer_h_id ?>"
			<?php echo ($row_xfer->xfer_h_id == $row_website->site_def_xfer_h_id_withdraw) ? 'selected' : '' ?>>
				<?php echo $row_xfer->xfer_h_name ?>: <?php echo $row_xfer->xfer_h_desc ?></option>
			<?php } ?>
		</select>
		<span class="help-block"><small>ค่าเริ่มต้นเมื่อลูกค้าสมัครสมาชิกใหม่</small></span>
	</div>
</div>
<hr>
<div class="form-group">
	<label for="site_line_chat_url" class="col-sm-3 control-label">Line Chat URL:</label>
	<div class="col-sm-8">
		<input type="url" name="site_line_chat_url" class="form-control" id="site_line_chat_url" value="<?php echo $row_website->site_line_chat_url ?>" placeholder="https://xxx.com/lineadmin2">
	</div>
</div>
<div class="form-group">
	<label for="site_line_callback_url" class="col-sm-3 control-label">Line Callback URL:</label>
	<div class="col-sm-8">
		<input type="url" name="site_line_callback_url" class="form-control" id="site_line_callback_url" value="<?php echo $row_website->site_line_callback_url ?>" placeholder="https://xxx.com/line/callbackall.php">
		<span class="help-block"><small>ไม่ต้องมี "/"  และ groupline id</small></span>
	</div>
</div>
<hr>
<div class="form-group">
	<label for="site_announcement" class="col-sm-3 control-label">ข้อความประชาสัมพันธ์:</label>
	<div class="col-sm-8">
		<textarea name="site_announcement" id="site_announcement" class="form-control" rows="5"><?php echo $row_website->site_announcement ?></textarea>
		<span class="help-block"><small>แสดงที่ระบบสมาชิก</small></span>
	</div>
</div>
<hr>
<div class="form-group">
	<label for="site_status" class="col-sm-3 control-label">สถานะ:</label>
	<div class="col-sm-8">
		<div class="radio radio-success form-check-inline">
			<input type="radio" id="site_status_active" value="1" name="site_status" <?php echo ($row_website->site_status == 1) ? 'checked="checked"':'' ?> required>
			<label for="site_status_active">ใช้งาน</label>
		</div>
		<div class="radio form-primary-inline">
			<input type="radio" id="site_status_inactive" value="0" name="site_status" <?php echo ($row_website->site_status == 0) ? 'checked="checked"':'' ?> required>
			<label for="site_status_inactive">ปิดใช้งาน</label>
		</div>
	</div>
</div>
<?php } ?>