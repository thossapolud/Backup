<div class="">
	<div class="page-header-title">
		<h4 class="page-title">จัดการเว็บไซต์</h4>
	</div>
</div>
<div class="page-content-wrapper ">
    <div class="container"> 
    
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <button class="btn btn-success btn-lg" href="#addWebsite" type="button" data-toggle="modal">เพิ่มเว็บไซต์</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th>เว็บไซต์</th>
                              <th>โดเมนเนม</th>
                              <th>สถานะ</th> 
                              <th></th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Row -->
        
     </div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->
<!-- Create Modals -->
<div class="modal fade" id="addWebsite" tabindex="-1" role="dialog" aria-labelledby="addWebsite" aria-hidden="true" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<form class="form-horizontal" id="form-add-website" action="#" method="POST" role="form">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">เพิ่มเว็บไซต์</h4>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="site_name" class="col-sm-3 control-label">ชื่อเว็บไซต์:</label>
						<div class="col-sm-8">
							<input type="text" name="site_name" class="form-control" id="site_name" placeholder="ชื่อเว็บไซต์" required="required">
						</div>
					</div>
					<div class="form-group">
						<label for="site_url" class="col-sm-3 control-label">โดเมนเนม:</label>
						<div class="col-sm-8">
							<input type="url" name="site_url" class="form-control" id="site_url" placeholder="โดเมนเนม" required="required">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
					<button type="button" class="btn btn-success" id="submit-add-website" >เพิ่มเว็บไซต์</button>
					<button type="submit" style="display: none;" id="submit-hidden"></button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- END Create Modals -->
<!-- View Worksheet Modals -->
<div class="modal fade" id="edit-website-modal" tabindex="-1" role="dialog" aria-labelledby="websiteView" aria-hidden="false" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<form class="form-horizontal" id="form-edit-website" action="<?php echo base_url('website/edit'); ?>" method="POST" role="form">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">แก้ไขข้อมูลเว็บไซต์</h4>
				</div>
				<div class="modal-body">				 
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
					<button type="submit" class="btn btn-success" >แก้ไข</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- END View Worksheet Modals -->

<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$.fn.modal.Constructor.prototype.enforceFocus = function(){};
	var base_url = '<?php echo site_url() ?>';
	var t = $('#datatables').DataTable({
		"bPaginate": true, 
		//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
		//"bFilter": false, //+ ช่องค้นหา
		//"bInfo": false, //+ รายละเอียดจำนวนแถว
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": '<?php echo base_url('website/get-website'); ?>',
		"iDisplayLength": 50,
		"columnDefs": [	//+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
			{"searchable": true, "orderable": false, "targets":0,'className':'text-center text-vertical'},
			{"searchable": true, "orderable": true, "targets":[1,2,3],'className':'text-center text-vertical'},	
			{"searchable": false, "orderable": false, "targets":4,'className':'text-center text-vertical',
				"render": function(data, type, row) { // Available data available for you within the row	
					var button = '<a data-toggle="modal" data-target="#edit-website-modal" data-stid="'+data+'" class="btn btn-xs btn-default"><span class="ti-pencil"> แก้ไขข้อมูล</span></a>';					
					return button;
				}	
			}
		],
		"order": [[1, 'asc'],[ 2, "asc" ],[ 3, "asc" ]] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
	});
	$('#addWebsite').on('hidden.bs.modal', function () {
		document.getElementById('form-add-website').reset();
	});
	$('#submit-add-website').click(function(){
		if ($('#form-add-website')[0].checkValidity()) {
			swal({
				title: "ยืนยัน เพิ่มเว็บไซต์ ?",
				type: "warning",
				showCancelButton: true,
				cancelButtonText: "ยกเลิก",
				confirmButtonText: "ยืนยัน",
				closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					cache: false,
					url: '<?php echo site_url('website/add') ?>',
					data: $("#form-add-website").serialize(),
					success: function(resp){
						$.LoadingOverlay("hide");
						swal({title:resp,confirmButtonText: 'OK'},function(){window.location.reload();});
					}
				});
			});
		} else {
			$("#form-add-website").find("#submit-hidden").click();
		}
	});
	$('#edit-website-modal').on('show.bs.modal', function (e){
		$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('website/form-edit-website')?>?stid='+$(e.relatedTarget).attr('data-stid'));
	});
	$('#datatables tbody').on('click', 'td > a.pop', function (e) {
			 $('.imagepreview').attr('src', $(this).attr('data-img'));
		 $('#ImageModal').modal('show'); 
			 return false;
		});
});
</script>
<link href="<?php echo base_url('assets/plugins/uploadifive/uploadifive.css') ?>" type="text/css" media="screen" rel="stylesheet"/>
<script src="<?php echo base_url('assets/plugins/uploadifive/jquery.uploadifive.min.js') ?>" type="text/javascript"></script>