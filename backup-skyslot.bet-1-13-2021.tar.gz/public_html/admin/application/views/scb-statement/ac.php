<div class="">
	<div class="page-header-title scb-bg">
		<h4 class="page-title"><i class="thbanks thbanks-scb"></i> SCB <?=$row_userpass->acnum?> Statement</h4>
	</div>
</div>
<div class="page-content-wrapper ">
	<div class="container">

		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body">
						<button class="btn btn-lg scb-bg" type="button" id="get-scb-statement"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ดึงข้อมูล SCB <?php echo $row_userpass->bankname ?></button>
						<button class="btn btn-default btn-lg pull-right" type="button">เลขบัญชี : <?php echo $row_userpass->banknum ?> || ยอดเงินคงเหลือ : <?php echo $row_userpass->balance ?> || ยอดเงินใช้ได้ : <?php echo $row_userpass->available ?></button>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body table-responsive">
						<table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
							<thead>
								<tr role="row">
									<th width="5%"></th>
									<th>วันที่</th>
									<th>ธนาคาร</th>
									<th>เลขบัญชี</th>
									<th>ฝาก</th>
									<th>ถอน</th>
									<th>ยอดคงเหลือ</th>
									<th width="40%">หมายเหตุ</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<!-- END Row -->

	</div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	var t = $('#datatables').DataTable({
		"bPaginate": true, 
		//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
		//"bFilter": false, //+ ช่องค้นหา
		//"bInfo": false, //+ รายละเอียดจำนวนแถว
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": '<?php echo base_url('scb-statement/ac-all?acnum='.$row_userpass->acnum); ?>',
		"iDisplayLength": 50,
		"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
			{"searchable": true, "orderable": false, "targets":0,'className':'text-center'},
			{"targets":[1,2,3,4,5,6,7],'className':'text-center'},
			{"visible": false,"searchable": false, "orderable": false, "targets":8},
		],
		"order": [1, 'desc'], //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
		"createdRow": function ( row, data, index ) {
			var bg;
			if(data[4]!=''){
				switch (data[8]){
					case '0':
						bg = "withdraw-bg";
						break;
				}			
				$(row).addClass(bg);
			}
		}
	});
	$('#get-scb-statement').click(function(){
		$.LoadingOverlay("show");
		$.ajax({
			type: 'GET',
			cache: false,
			url: '<?php echo site_url('get-scbstatement-all/get/scb/'.$row_userpass->acnum) ?>',
			success: function(resp){
				$.LoadingOverlay("hide");
				swal({ title: resp, confirmButtonText: 'OK' },function(){document.location.reload();});
			}
		});
	});
});
</script>