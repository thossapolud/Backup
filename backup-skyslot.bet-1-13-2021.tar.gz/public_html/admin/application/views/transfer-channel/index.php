<div class="">
	<div class="page-header-title">
		<h4 class="page-title">กลุ่มลูกค้า</h4>
	</div>
</div>
<div class="page-content-wrapper ">
    <div class="container"> 
    
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <button class="btn btn-success btn-lg" data-xfer-h-type="deposit" href="#addTransferChannel" type="button" data-toggle="modal" data-target="#addTransferChannel">เพิ่มกลุ่มลูกค้า(ฝาก)</button>
						<button class="btn btn-primary btn-lg" data-xfer-h-type="withdraw" href="#addTransferChannel" type="button" data-toggle="modal" data-target="#addTransferChannel">เพิ่มกลุ่มลูกค้า(ถอน)</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th>เว็บไซต์</th>
                              <th>ชื่อกลุ่มลูกค้า</th>
                              <th>รายละเอียด</th> 
                              <th>ประเภท</th>
							  <th>สถานะ</th>
                              <th></th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Row -->
        
     </div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->
<!-- Create Modals -->
<div class="modal fade" id="addTransferChannel" tabindex="-1" role="dialog" aria-labelledby="addTransferChannel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<form class="form-horizontal" id="form-add-transfer-channel" action="<?php echo base_url('transfer-channel/add'); ?>" method="POST" role="form">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">เพิ่มกลุ่มลูกค้า</h4>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="site_id" class="col-sm-3 control-label">สำหรับเว็บไซต์:</label>
						<div class="col-sm-8">
							<select name="site_id" id="site_id" class="form-control" required="required">
								<option value="">== เลือก ==</option>
								<?php foreach ($rs_website->result() as $row_website) {?>
								<option value="<?=$row_website->site_id?>"><?=$row_website->site_name?></option>
								<?php }?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="xfer_h_name" class="col-sm-3 control-label">ชื่อกลุ่มลูกค้า:</label>
						<div class="col-sm-8">
							<input type="text" name="xfer_h_name" class="form-control" id="xfer_h_name" placeholder="ชื่อกลุ่มลูกค้า" required="required">
						</div>
					</div>
					<div class="form-group">
						<label for="xfer_h_desc" class="col-sm-3 control-label">รายละเอียด:</label>
						<div class="col-sm-8">
							<input type="text" name="xfer_h_desc" class="form-control" id="xfer_h_desc" placeholder="รายละเอียด" required="required">
						</div>
					</div>
					<input name="xfer_h_type" id="xfer_h_type" class="xfer_h_type" type="hidden">
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
					<button type="button" class="btn btn-success" id="submit-add-transfer-channel">เพิ่มกลุ่มลูกค้า</button>
					<button type="submit" style="display: none;" id="submit-hidden"></button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- END Create Modals -->
<!-- View Worksheet Modals -->
<div class="modal fade" id="edit-transfer-channel-modal" tabindex="-1" role="dialog" aria-labelledby="TransferChannelView" aria-hidden="false" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<div class="div-for-load-edit-form">
			</div>
		</div>
	</div>
</div>
<!-- END View Worksheet Modals -->

<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$.fn.modal.Constructor.prototype.enforceFocus = function(){};
	var base_url = '<?php echo site_url() ?>';
	var t = $('#datatables').DataTable({
		"bPaginate": true, 
		//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
		//"bFilter": false, //+ ช่องค้นหา
		//"bInfo": false, //+ รายละเอียดจำนวนแถว
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": '<?php echo base_url('transfer-channel/get-transfer-channel'); ?>',
		"iDisplayLength": 50,
		"columnDefs": [	//+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
			{"searchable": true, "orderable": false, "targets":0,'className':'text-center text-vertical'},
			{"searchable": false, "orderable": true, "targets":[4,5],'className':'text-center text-vertical'},		
			{"targets":[1,2,3,4,5],'className':'text-center text-vertical'},
			{"searchable": false, "orderable": false, "targets":6,'className':'text-center text-vertical',
				"render": function(data, type, row) { // Available data available for you within the row	
					var button = '<a data-toggle="modal" data-target="#edit-transfer-channel-modal" data-xcid="'+data+'" class="btn btn-xs btn-default"><span class="ti-pencil"> แก้ไขข้อมูล</span></a>';					
					return button;
				}	
			}
		],
		// "order": [[6, 'asc'],[ 1, "asc" ],[ 4, "asc" ],[ 5, "asc" ]] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
	});
	$('#addTransferChannel').on('hidden.bs.modal', function () {
		document.getElementById('form-add-transfer-channel').reset();
	});
	$('#addTransferChannel').on('show.bs.modal', function (e) {
		$(this).find('.xfer_h_type').val($(e.relatedTarget).attr('data-xfer-h-type'));
	});
	$('#submit-add-transfer-channel').click(function(){
		if ($('#form-add-transfer-channel')[0].checkValidity()) {
			swal({
				title: "ยืนยัน เพิ่มกลุ่มลูกค้า ?",
				type: "warning",
				showCancelButton: true,
				cancelButtonText: "ยกเลิก",
				confirmButtonText: "ยืนยัน",
				closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$('#form-add-transfer-channel').submit();
			});
		} else {
			$("#form-add-transfer-channel").find("#submit-hidden").click();
		}
	});
	$('#edit-transfer-channel-modal').on('show.bs.modal', function (e){
		$(this).find('.div-for-load-edit-form').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('transfer-channel/form-edit-transfer-channel')?>?xcid='+$(e.relatedTarget).attr('data-xcid'));
	});
});
</script>
<link href="<?php echo base_url('assets/plugins/uploadifive/uploadifive.css') ?>" type="text/css" media="screen" rel="stylesheet"/>
<script src="<?php echo base_url('assets/plugins/uploadifive/jquery.uploadifive.min.js') ?>" type="text/javascript"></script>