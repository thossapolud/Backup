<form class="form-horizontal" id="form-edit-transfer-channel" action="<?php echo base_url('transfer-channel/edit'); ?>" method="POST" role="form">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h4 class="modal-title" id="myModalLabel">แก้ไขกลุ่มลูกค้า(<?=conv_ws_type($row_xfer_h->xfer_h_type)?>)</h4>
	</div>
	<div class="modal-body">
	<?php if($row_xfer_h) { ?>
		<div class="form-group">
			<input name="xfer_h_id" id="xfer_h_id" value="<?php echo $row_xfer_h->xfer_h_id ?>" type="hidden">
			<label for="site_name" class="col-sm-3 control-label">สำหรับเว็บไซต์:</label>
			<div class="col-sm-8">
				<input type="text" class="form-control" value="<?php echo $row_website->site_name ?>" disabled="disabled">
			</div>
		</div>
		<div class="form-group">
			<label for="xfer_h_name" class="col-sm-3 control-label">ชื่อกลุ่มลูกค้า:</label>
			<div class="col-sm-8">
				<input type="text" class="form-control" value="<?php echo $row_xfer_h->xfer_h_name ?>" disabled="disabled">
			</div>
		</div>
		<div class="form-group">
			<label for="xfer_h_desc" class="col-sm-3 control-label">รายละเอียด:</label>
			<div class="col-sm-8">
				<input type="text" name="xfer_h_desc" class="form-control" id="xfer_h_desc" value="<?php echo $row_xfer_h->xfer_h_desc ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="xfer_h_status" class="col-sm-3 control-label">สถานะ:</label>
			<div class="col-sm-8">
				<div class="radio radio-success form-check-inline">
					<input type="radio" id="xfer_h_status_active" value="1" name="xfer_h_status" <?php echo ($row_xfer_h->xfer_h_status == 1) ? 'checked="checked"':'' ?> required>
					<label for="xfer_h_status_active">ใช้งาน</label>
				</div>
				<div class="radio form-primary-inline">
					<input type="radio" id="xfer_h_status_inactive" value="0" name="xfer_h_status" <?php echo ($row_xfer_h->xfer_h_status == 0) ? 'checked="checked"':'' ?> required>
					<label for="xfer_h_status_inactive">ปิดใช้งาน</label>
				</div>
			</div>
		</div>
		<hr>
		<div class="form-group">
			<label for="bank_account" class="col-sm-3 control-label">บัญชี:</label>
			<div class="col-sm-6">
				<select id="bank_account" class="form-control">
					<option value="">== เลือก ==</option>
					<?php if($rs_avail_bank){ ?>
					<?php foreach ($rs_avail_bank->result() as $row_avail_bank) {?>
					<option value="<?php echo $row_avail_bank->userpass_id ?>">[<?php echo strtoupper($row_avail_bank->type) ?>] <?php echo $row_avail_bank->bankname ?></option>
					<?php }?>
					<?php }?>
				</select>
			</div>
			<div class="col-sm-2">
				<button type="button" class="btn btn-success form-control" id="add-transfer-channel-detail">เพิ่ม</button>
			</div>
		</div>
		<div class="form-group">
			<label for="bank_account" class="col-sm-3 control-label">บัญชี:</label>
			<div class="col-sm-8">
				<table class="table table-striped table-bordered table-hover" id="table-list-transfer-detail" width="100%" style="font-size:11px;">
					<thead>
					<tr role="row">
						<th class="text-center" width="5%"></th>
						<th class="text-center" width="20%">BANK</th>
						<th class="text-center" width="10%">ACNUM</th>
						<th class="text-center">ชื่อบัญชี</th>
					</tr>
					</thead>
					<tbody>
					<?php echo $x ?>
					<?php if($rs_current_bank->num_rows()>0){ ?>
					<?php foreach($rs_current_bank->result() as $row_current_bank){ ?>
					<tr>
						<td class="text-center"><input type="radio" name="xfer_d_id" id="xfer_d_id" class="xfer_d_id" value="<?php echo $row_current_bank->xfer_d_id ?>" /></td>
						<td class="text-center"><?php echo strtoupper($row_current_bank->type) ?></td>
						<td class="text-center"><?php echo $row_current_bank->acnum ?></td>
						<td class="text-center"><?php echo $row_current_bank->bankname ?></td>
					</tr>
					<?php } ?>
					<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
		<div class="form-group">
			<label for="" class="col-sm-3 control-label"></label>
			<div class="col-sm-6">
			</div>
			<div class="col-sm-2">
				<button type="button" class="btn btn-primary form-control" id="delete-transfer-channel-detail">ลบ</button>
			</div>
		</div>
	<?php } ?>
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
		<button type="submit" class="btn btn-success" >แก้ไขกลุ่มลูกค้า</button>
	</div>
</form>

<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	var base_url = '<?php echo site_url() ?>';
	function setBankAccountSelectList() {
		$.LoadingOverlay("show");
		$('#bank_account').empty();
		$.ajax({
			cache: false,
			type: 'POST',
			dataType: 'json',
			url: '<?php echo site_url('transfer-channel/get-bank-by-site-id-actype-and-not-in-userpass-id') ?>',
			data: {site_id:'<?php echo $row_xfer_h->site_id ?>',xfer_h_type:'<?php echo $row_xfer_h->xfer_h_type ?>'},
			success: function(data){
				$.LoadingOverlay("hide");
				if(data!=''){
					var select = document.getElementById('bank_account');
					$(select).append('<option value="">== เลือก ==</option>');
					$.each(data,function(index, val){
						$(select).append('<option value="'+val.userpass_id+'">['+val.type+'] '+val.bankname+'</option>');
					});
					$(select).val($(select).find('option').first().val());
				}else{
					swal({title:'ไม่มีบัญชีให้เพิ่มแล้ว',confirmButtonText: 'OK' })
				}					
			}
		});
	}
	function setTransferChannelAccountTable() {
		$.LoadingOverlay("show");
		$('#table-list-transfer-detail tbody').empty();
		$.ajax({
			cache: false,
			type: 'POST',
			dataType: 'json',
			url: '<?php echo site_url('transfer-channel/get-transfer-channel-detail') ?>',
			data: {xfer_h_id:'<?php echo $row_xfer_h->xfer_h_id ?>'},
			success: function(data){
				$.LoadingOverlay("hide");
				if(data!=''){
					var tr = '';
					$.each(data,function(index, val){
						tr += '<tr>';
						tr += '<td class=" text-center"><input type="radio" name="xfer_d_id" id="xfer_d_id" class="xfer_d_id" value="'+val.xfer_d_id+'" /></td>';
						tr += '<td class="text-center">'+val.type+'</td>';
						tr += '<td class="text-center">'+val.acnum+'</td>';
						tr += '<td class=" text-center">'+val.bankname+'</td>';
						tr += '</tr>';
					});
					$('#table-list-transfer-detail tbody').append(tr);
				}else{
					swal({title:'ไม่มีบัญชีในกลุ่มลูกค้านี้แล้ว',confirmButtonText: 'OK' })
				}					
			}
		});
	}
	$('#add-transfer-channel-detail').click(function(){
		if($('#bank_account').val()!='') {
			swal({
				title: "ยืนยัน เพิ่มบัญชี ?",
				type: "warning",
				showCancelButton: true,
				cancelButtonText: "ยกเลิก",
				confirmButtonText: "ยืนยัน",
				closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				userpass_id = $('#bank_account').val();
				$.ajax({
					type: 'POST',
					//dataType: 'json',
					cache: false,
					url: '<?php echo site_url('transfer-channel/add-detail') ?>',
					data: { 'xfer_h_id': <?php echo $row_xfer_h->xfer_h_id ?>, 'userpass_id': userpass_id },
					success: function(resp){
						$.LoadingOverlay("hide");
						swal({title:resp,confirmButtonText: 'OK'},function(){
							setBankAccountSelectList();
							setTransferChannelAccountTable();
						});
					}
				});
			});
		} else {
			swal({title:'เลือก บัญชี ก่อน!',confirmButtonText: 'OK'});
		}
	});
	$('#delete-transfer-channel-detail').click(function(){
		var xfer_d_id = '';
		$.each($("input[name='xfer_d_id']:checked"), function(){            
			xfer_d_id = $(this).val();
		});
		if (xfer_d_id.length > 0) {
			swal({
				title: "ยืนยัน ลบบัญชี ?",
				type: "warning",
				showCancelButton: true,
				cancelButtonText: "ยกเลิก",
				confirmButtonText: "ยืนยัน",
				closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					cache: false,
					url: '<?php echo site_url('transfer-channel/delete-detail') ?>',
					data: { 'xfer_h_id': <?php echo $row_xfer_h->xfer_h_id ?>, 'xfer_d_id': xfer_d_id },
					success: function(resp){
						$.LoadingOverlay("hide");
						swal({title:resp,confirmButtonText: 'OK'},function(){
							setBankAccountSelectList();
							setTransferChannelAccountTable();
						});
					}
				});
			});
		} else {
			swal({title:'เลือก บัญชี ก่อน!',confirmButtonText: 'OK'});
		}
	});
});
</script>