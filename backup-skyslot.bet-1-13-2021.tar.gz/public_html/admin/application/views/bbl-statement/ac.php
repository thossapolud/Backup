<div class="">
  <div class="page-header-title bbl-bg">  	
    <h4 class="page-title"><i class="thbanks thbanks-bbl"></i> BBL <?=$row_userpass->acnum?> Statement</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container">

        <div class="row">                                     
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <button class="btn btn-lg bbl-bg" type="button" id="get-bbl-statement"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ดึงข้อมูล BBL <?php echo $row_userpass->bankname ?></button>
                        <button class="btn btn-default btn-lg pull-right" type="button">เลขบัญชี : <?php echo $row_userpass->banknum ?> || ยอดเงินคงเหลือ : <?php echo number_format($row_userpass->balance,2) ?> || ยอดเงินใช้ได้ : <?php echo number_format($row_userpass->available,2) ?></button>
                    </div>
                </div>
            </div>                                     
        </div>
        
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th>วันที่</th>
                              <th>ฝาก</th>
                              <th>ถอน</th>                      
                              <th>เลขบัญชี</th>
                              <th>ยอดคงเหลือ</th>
                              <th width="40%">หมายเหตุ</th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- END Row -->
        
     </div>  
  <!-- container -->   
</div>
<!-- Page content Wrapper -->
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	var t = $('#datatables').DataTable({
		"bPaginate": true, 
		//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
		//"bFilter": false, //+ ช่องค้นหา
		//"bInfo": false, //+ รายละเอียดจำนวนแถว
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": '<?php echo base_url('bbl-statement/ac-all?acnum='.$row_userpass->acnum); ?>',
		"iDisplayLength": 50,
		"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
			{"searchable": true, "orderable": false, "targets":0,'className':'text-center'},
			{"targets":[1,2,3,4,5,6],'className':'text-center'},
			{"visible": false,"searchable": false, "orderable": false, "targets":7},
		],
		"order": [1, 'desc'], //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
		"createdRow": function ( row, data, index ) {		
			var bg;
			if(data[2]!=''){
				switch (data[7]){
					case '0':
						bg = "withdraw-bg";
						break;
				}			
				$(row).addClass(bg);
			}
        }
	});		
	$('#get-bbl-statement').click(function(){
		$.LoadingOverlay("show");
		$.ajax({
			type: 'GET', // type: 'POST',
			//dataType: 'json',
			cache: false,
			url: '<?php echo site_url('get-bblstatement-all/get/bbl/').$row_userpass->acnum ?>',
			// data: {bank:'bbl'},
			success: function(resp){
				$.LoadingOverlay("hide");
				swal({ title: resp, confirmButtonText: 'OK' },function(){document.location.reload();});
			}
		});
	});
});
</script>