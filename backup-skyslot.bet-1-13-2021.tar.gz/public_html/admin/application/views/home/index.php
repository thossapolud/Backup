<script type="text/javascript">
$(function(){
	$('#search').click(function(){
		if($('#start-date').val()!=''&&$('#end-date').val()!=''){
			var $this = $(this);
			$this.find('span.glyphicon-refresh').show();
			$.ajax({
				cache: false,
				type: 'POST',
				dataType: 'json',
				url: '<?php echo site_url('home/register_bydate') ?>',
				data:{datestart:$('#start-date').val(),dateend:$('#end-date').val()},
				success: function(resp){
					$('#result-from-search').empty();
					$.each(resp, function(idx, obj){
						$('#result-from-search').append('<strong>'+idx+'</strong> สมัคร '+obj.userregister+' / เปิดยูส '+obj.useropen+' / สมัครเก่าเปิดยูส '+obj.useroldopen+'<br>');
				    });
					$this.find('.glyphicon-refresh').hide();
				}
			});
		}else{
			alert('เลือกวัน');
		}
	});
});
</script>
<div class="">
  <div class="page-header-title">
    <h4 class="page-title">แผงควบคุมหลัก</h4>
  </div>
</div>
<div class="page-content-wrapper ">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">สมาชิกทั้งหมด</h4>
					</div>
					<div class="panel-body p-t-10">
						<h3 class="m-t-0 m-b-15">
							<i class="mdi mdi-account-multiple text-default m-r-10"></i><b><?php echo number_format($total_register) ?></b>
						</h3>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?php echo number_format($total_register_site) ?></b> เว็บไซต์</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">สมาชิกใหม่</h4>
					</div>
					<div class="panel-body p-t-10">
						<h3 class="m-t-0 m-b-15"><i
								class="fa fa-user-plus text-success m-r-10"></i><b><?php echo number_format($total_register_today) ?></b>
						</h3>
						<p class="text-muted m-b-0 m-t-15">ทำการสมัคร</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">สมาชิกใหม่ฝาก</h4>
					</div>
					<div class="panel-body p-t-10">
						<h3 class="m-t-0 m-b-15"><i
								class="fa fa-plus-square text-success m-r-10"></i><b><?php echo number_format($total_register_deposit_today) ?></b>
						</h3>
						<p class="text-muted m-b-0 m-t-15">สมัครใหม่ทำการฝากเงิน</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">Active User</h4>
					</div>
					<div class="panel-body p-t-10">
						<h3 class="m-t-0 m-b-15"><i
								class="fa fa-bell text-info m-r-10"></i><b><?php echo number_format($total_active_today) ?></b>
						</h3>
						<p class="text-muted m-b-0 m-t-15">สมาชิกที่ทำรายการ</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">ยอดเติมเครดิต</h4>
					</div>
					<div class="panel-body p-t-10">
						<h4 class="m-t-0 m-b-15">
							<i class="fa fa-plus-square text-success m-r-10"></i><b><?php echo number_format($deposit_credit_today->credittotal, 2) ?> บาท</b>
						</h4>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?php echo number_format($deposit_credit_today->listtotal) ?></b> รายการ</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">ยอดถอนเครดิต</h4>
					</div>
					<div class="panel-body p-t-10">
						<h4 class="m-t-0 m-b-15"><i
								class="fa fa-minus-square text-primary m-r-10"></i><b><?php echo number_format($withdraw_credit_today->credittotal, 2) ?> บาท</b>
						</h4>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?php echo number_format($withdraw_credit_today->listtotal) ?></b> รายการ</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">ยอดเติมโบนัส</h4>
					</div>
					<div class="panel-body p-t-10">
						<h4 class="m-t-0 m-b-15"><i
								class="fa fa-gift text-info m-r-10"></i><b><?php echo number_format($depositpromotion_credit_today->credittotal, 2) ?> บาท</b>
						</h4>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?php echo number_format($depositpromotion_credit_today->listtotal) ?></b> รายการ</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">สรุปเครดิตขยับ</h4>
					</div>
					<div class="panel-body p-t-10">
						<h4 class="m-t-0 m-b-15"><i
								class="fa fa-money text-danger m-r-10"></i><b><?=number_format($deposit_credit_today->credittotal + $depositpromotion_credit_today->credittotal - $withdraw_credit_today->credittotal, 2)?></b>
						</h4>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?=$deposit_credit_today->listtotal + $depositpromotion_credit_today->listtotal + $withdraw_credit_today->listtotal?></b> รายการฝาก+โบนัส-ถอน</p>
					</div>
				</div>
			</div>
		</div>
        <div class="row">
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading transfer-bg">
						<h4 class="panel-title text-muted font-weight-light mb-0">ยอดเครดิตโยกเข้า</h4>
					</div>
					<div class="panel-body p-t-10">
						<h4 class="m-t-0 m-b-15">
							<i class="fa fa-plus-square text-success m-r-10"></i><b><?php echo number_format($tin_credit_today->credittotal, 2) ?> บาท</b>
						</h4>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?php echo number_format($tin_credit_today->listtotal) ?></b> รายการ</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading transfer-bg">
						<h4 class="panel-title text-muted font-weight-light mb-0">ยอดเครดิตโยกออก</h4>
					</div>
					<div class="panel-body p-t-10">
						<h4 class="m-t-0 m-b-15"><i
								class="fa fa-minus-square text-primary m-r-10"></i><b><?php echo number_format($tout_credit_today->credittotal, 2) ?> บาท</b>
						</h4>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?php echo number_format($tout_credit_today->listtotal) ?></b> รายการ</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">ยอดฝากธนาคาร</h4>
					</div>
					<div class="panel-body p-t-10">
						<h4 class="m-t-0 m-b-15">
							<i class="fa fa-plus-square text-success m-r-10"></i><b><?php echo number_format($deposit_today->stintotal, 2) ?> บาท</b>
						</h4>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?php echo number_format($deposit_today->listtotal) ?></b> รายการ</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">ยอดถอนธนาคาร</h4>
					</div>
					<div class="panel-body p-t-10">
						<h4 class="m-t-0 m-b-15"><i
								class="fa fa-minus-square text-primary m-r-10"></i><b><?php echo number_format($withdraw_today->ws_credit, 2) ?> บาท</b>
						</h4>
						<p class="text-muted m-b-0 m-t-15">จาก <b><?php echo number_format($withdraw_today->listtotal) ?></b> รายการ</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6 col-lg-3">
				<div class="panel text-center">
					<div class="panel-heading">
						<h4 class="panel-title text-muted font-weight-light mb-0">รายการ</h4>
					</div>
					<div class="panel-body p-t-10">
						<h3 class="m-t-0 m-b-15"><i
								class="fa fa-files-o text-danger m-r-10"></i><b><?=$deposit_credit_today->listtotal + $withdraw_credit_today->listtotal + $depositpromotion_credit_today->listtotal?></b>
						</h3>
						<p class="text-muted m-b-0 m-t-15"><b>ฝาก <?=$deposit_credit_today->listtotal?>:ถอน <?=$withdraw_credit_today->listtotal?>:โบนัส <?=$depositpromotion_credit_today->listtotal?></b></p>
					</div>
				</div>
			</div>
			<?php if ($rs_agent_pussy->num_rows() > 0) {?>
			<?php $i = 1;foreach ($rs_agent_pussy->result() as $row) {?>
				<div class="col-sm-6 col-lg-3">
					<div class="panel text-center">
						<div class="panel-heading">
							<h4 class="panel-title text-muted font-weight-light mb-0">เครดิต Pussy <?=$row->username?></h4>
						</div>
						<div class="panel-body p-t-10">
							<h4 class="m-t-0">
							<?php $row_lastcredit_agent = $this->deposit_withdraw_model->get_deposit_withdraw_last('Pussy888',$row->username,$end); ?>
							<?php if ($row_lastcredit_agent) { ?>
								<?php $creditagentlast = ($row_lastcredit_agent->type=='ฝาก')?$row_lastcredit_agent->creditagentbefore-$row_lastcredit_agent->credit:$row_lastcredit_agent->creditagentbefore+$row_lastcredit_agent->credit; ?>
									<i class="fa fa-money text-danger m-r-10"></i><b><?=number_format($creditagentlast, 2)?></b>
								<?php } else { ?>
									<i class="fa fa-money text-danger m-r-10"></i><b>-</b>
								<?php } ?>
							</h4>
						</div>
					</div>
				</div>
			<?php } ?>
			<?php } ?>
            <?php if ($rs_agent_scr->num_rows() > 0) {?>
			<?php $i = 1;foreach ($rs_agent_scr->result() as $row) {?>
				<div class="col-sm-6 col-lg-3">
					<div class="panel text-center">
						<div class="panel-heading">
							<h4 class="panel-title text-muted font-weight-light mb-0">เครดิต 918kiss <?=$row->username?></h4>
						</div>
						<div class="panel-body p-t-10">
							<h4 class="m-t-0">
							<?php $row_lastcredit_agent = $this->deposit_withdraw_model->get_deposit_withdraw_last('918kiss',$row->username,$end); ?>
							<?php if ($row_lastcredit_agent) { ?>
								<?php $creditagentlast = ($row_lastcredit_agent->type=='ฝาก')?$row_lastcredit_agent->creditagentbefore-$row_lastcredit_agent->credit:$row_lastcredit_agent->creditagentbefore+$row_lastcredit_agent->credit; ?>
									<i class="fa fa-money text-danger m-r-10"></i><b><?=number_format($creditagentlast, 2)?></b>
								<?php } else { ?>
									<i class="fa fa-money text-danger m-r-10"></i><b>-</b>
								<?php } ?>
							</h4>
						</div>
					</div>
				</div>
			<?php } ?>
			<?php } ?>
		</div>

		<div class="row">
				<div class="col-sm-12 col-md-12">
						<div class="panel">
								<div class="panel-body" style="padding-top:0px;">
										<form action="" method="post" id="form-search-top" class="form-inline col-md-10 col-xs-11" style="padding-top: 20px;">
											<div class="input-group date date-main col-md-4" data-date="" data-link-field="start" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
												<input class="form-control" size="16" type="text" value="<?php echo $start ?>" readonly required="required">
												<span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
												<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
											</div>
											<input type="hidden" id="start" name="start" value="<?php echo $start ?>" required="required" />
											<label>:</label>
											<div class="input-group date date-main col-md-4" data-date="" data-link-field="end" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
												<input class="form-control" size="16" type="text" value="<?php echo $end ?>" readonly required="required">
												<span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
												<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
											</div>
											<input type="hidden" id="end" name="end" value="<?php echo $end ?>" required="required" />
											<button type="submit" id="search-top" class="btn btn-success"><i class="ti-search"></i> ค้นหา</button>
										</form>
								</div>
						</div>
				</div>
		</div>

		<div class="row">
			<div class="col-md-12 col-lg-7">
			
				<div class="panel">
					<!--Panel heading-->
					<div class="panel-heading">
							<i class="glyphicon glyphicon-credit-card"></i><h3 class="panel-title">15 รายการเติม / ถอน ล่าสุด</h3>
					</div>
					<!--Panel body-->
					<div class="panel-body table-responsive">
						<table class="table table-hover table-striped" style="font-size:12px;">
							<thead>
								<tr>
									<th></th>
									<th>เว็บ</th>
									<th>สินค้า</th>
									<!--<th>เอเย่นต์</th>-->
									<!-- <th>ชื่อ</th> -->
									<th>ชื่อบัญชี</th>
									<th>ยอดก่อน</th>
									<th>ยอด</th>
									<th>โดย</th>
									<th>วันที่</th>
								</tr>
							</thead>
							<tbody style="font-size:11px;">
							<?php if ($latest_de_wi->num_rows() > 0) {?>
							<?php foreach ($latest_de_wi->result() as $row) {?>
								<tr>
									<td style="padding:5px;"><?php echo $row->type ?></td>
									<td style="padding:5px;"><?php echo $row->site_name ?></td>
									<td style="padding:5px;"><?php echo $row->dealer ?></td>
									<!--<td style="padding:5px;"><?php //echo $row->agent ?></td>-->
									<!-- <td style="padding:5px;"><?php //echo $row->name ?></td> -->
									<td style="padding:5px;"><?php echo $row->username ?></td>
									<td style="padding:5px;"><?php echo $row->creditbefore ?></td>
									<td style="padding:5px;"><?php echo $row->credit ?></td>
									<td style="padding:5px;"><?php echo $row->add_by_name ?></td>
									<td style="padding:5px;"><?php echo $row->created ?></td>
								</tr>
							<?php }?>
							<?php }?>
							</tbody>
						</table>
					</div>
				</div>

				<div class="panel" style="background-color:#f8cb7e">
					<!--Panel heading-->
					<div class="panel-heading">
						<i class="fa fa-trophy"></i>
						<h3 class="panel-title">สมาชิกฝาก TOP 5</h3>
						<br>
						<i class="fa fa-calendar"></i>
						<h5 class="panel-title"><span class="small"><?php echo $start ?> - <?php echo $end ?></span></h5>
					</div>
					<!--Panel body-->
					<div class="panel-body table-responsive">
						<table class="table table-hover table-striped" style="font-size:12px;">
							<thead>
								<tr>
									<th>#</th>
									<th>เว็บ</th>
									<th>สินค้า</th>
									<th>ชื่อบัญชี</th>
									<th>รายการ</th>
									<th>ยอดรวม</th>
								</tr>
							</thead>
							<tbody style="font-size:11px;">
							<?php if ($rs_deposit_top && $rs_deposit_top->num_rows() > 0) {?>
							<?php $i = 1;foreach ($rs_deposit_top->result() as $row) {?>
								<tr style="background-color:#f8cb7e">
									<td style="padding:5px;"><?php echo $i ?></td>
									<td style="padding:5px;"><?php echo $row->site_name ?></td>
									<td style="padding:5px;"><?php echo $row->dealer ?></td>
									<td style="padding:5px;"><?php echo $row->username ?></td>
									<td style="padding:5px;"><?php echo $row->listtotal ?></td>
									<td style="padding:5px;"><?php echo number_format($row->credittotal) ?></td>
								</tr>
							<?php $i++;}?>
							<?php }?>
							</tbody>
						</table>
					</div>
				</div>
				
				<div class="panel" style="background-color:#f8cb7e">
					<!--Panel heading-->
					<div class="panel-heading">
						<i class="fa fa-trophy"></i>
						<h3 class="panel-title">สมาชิกถอน TOP 5</h3>
						<br>
						<i class="fa fa-calendar"></i>
						<h5 class="panel-title"><span class="small"><?php echo $start ?> - <?php echo $end ?></span></h5>
					</div>
					<!--Panel body-->
					<div class="panel-body table-responsive">
						<table class="table table-hover table-striped" style="font-size:12px;">
							<thead>
								<tr>
									<th>#</th>
									<th>เว็บ</th>
									<th>สินค้า</th>
									<th>ชื่อบัญชี</th>
									<th>รายการ</th>
									<th>ยอดรวม</th>
								</tr>
							</thead>
							<tbody style="font-size:11px;">
							<?php if ($rs_withdraw_top && $rs_withdraw_top->num_rows() > 0) {?>
							<?php $i = 1;foreach ($rs_withdraw_top->result() as $row) {?>
								<tr style="background-color:#f8cb7e">
									<td style="padding:5px;"><?php echo $i ?></td>
									<td style="padding:5px;"><?php echo $row->site_name ?></td>
									<td style="padding:5px;"><?php echo $row->dealer ?></td>
									<td style="padding:5px;"><?php echo $row->username ?></td>
									<td style="padding:5px;"><?php echo $row->listtotal ?></td>
									<td style="padding:5px;"><?php echo number_format($row->credittotal) ?></td>
								</tr>
							<?php $i++;}?>
							<?php }?>
							</tbody>
						</table>
					</div>
				</div>
				
				<div class="panel" style="background-color:#f8cb7e">
					<!--Panel heading-->
					<div class="panel-heading">
						<i class="fa fa-trophy"></i>
						<h3 class="panel-title">สมาชิกฝากไม่ถอน TOP 5</h3>
						<br>
						<i class="fa fa-calendar"></i>
						<h5 class="panel-title"><span class="small"><?php echo $start ?> - <?php echo $end ?></span></h5>
					</div>
					<!--Panel body-->
					<div class="panel-body table-responsive">
						<table class="table table-hover table-striped" style="font-size:12px;">
							<thead>
								<tr>
									<th>#</th>
									<th>เว็บ</th>
									<th>สินค้า</th>
									<th>ชื่อบัญชี</th>
									<th>รายการ</th>
									<th>ยอดรวม</th>
								</tr>
							</thead>
							<tbody style="font-size:11px;">
								<?php if ($rs_depositnotwithdraw_top && $rs_depositnotwithdraw_top->num_rows() > 0) {?>
								<?php $i = 1;foreach ($rs_depositnotwithdraw_top->result() as $row) {?>
								<tr style="background-color:#f8cb7e">
									<td style="padding:5px;"><?php echo $i ?></td>
									<td style="padding:5px;"><?php echo $row->site_name ?></td>
									<td style="padding:5px;"><?php echo $row->dealer ?></td>
									<td style="padding:5px;"><?php echo $row->username ?></td>
									<td style="padding:5px;"><?php echo $row->delisttotal ?></td>
									<td style="padding:5px;"><?php echo number_format($row->decredittotal) ?></td>
								</tr>
								<?php $i++;}?>
								<?php }?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="col-md-12 col-lg-5">
				<div class="panel">
					<!--Panel heading-->
					<div class="panel-heading">
						<i class="fa fa-university"></i><h3 class="panel-title">บัญชีฝาก</h3>
					</div>
					<!--Panel body-->
					<div class="panel-body">
						<div class="row">
						<?php if ($rs_bank_deposit->num_rows() > 0) {?>
						<?php foreach ($rs_bank_deposit->result() as $row_bank) {?>
							<div class="col-sm-12 col-md-6">
								<div class="panel <?=$row_bank->type?>-bg">
									<div class="panel-body">
										<div class="icon-bg"><i class="thbanks thbanks-<?=$row_bank->type?>"></i></div>
										<div class="text-right">
											<?php $row_detail_bank = $this->statement_model->get_sumin($row_bank->type, $row_bank->username, $start, $end); ?>
											<h5 style="color: white;">
												ฝาก <?php echo $row_detail_bank->listtotal ?> รายการ
												<br>
												จำนวน <?php echo number_format($row_detail_bank->stintotal) ?> บ.
												<br>
												<?php $row_statement_open_worksheet = $this->statement_model->get_sumin($row_bank->type, $row_bank->username, $start, $end, 1); ?>
												เปิดใบงาน <?php echo number_format($row_statement_open_worksheet->stintotal,2) ?> บ.
												<br>
												<?php $row_statement_open_worksheet = $this->statement_model->get_sumin($row_bank->type, $row_bank->username, $start, $end, 0); ?>
												ไม่เปิดใบงาน <?php echo number_format($row_statement_open_worksheet->stintotal,2) ?> บ.
											</h5>
											<h5 style="color: white;">
												คงเหลือ <?php echo $row_bank->balance ? $row_bank->balance : '-' ?> บ.
												<br>
												ใช้ได้ <?php echo $row_bank->available ? $row_bank->available : '-' ?> บ.
											</h5>
										</div>
									</div>
									<div class="panel-footer clearfix panel-footer-link"><?php echo strtoupper($row_bank->type) ?> (<?php echo $row_bank->bankname ?>) </div>
								</div>
							</div>
							<?php }?>
							<div style="clear:both"></div>
							<?php }?>
						</div>
						<!-- END Row BANK -->
					</div>
				</div>

				<div class="panel">
					<!--Panel heading-->
					<div class="panel-heading">
						<i class="fa fa-university"></i><h3 class="panel-title">บัญชีถอน</h3>
					</div>
					<!--Panel body-->
					<div class="panel-body">
						<div class="row">
						<?php if ($rs_bank_withdraw->num_rows() > 0) {?>
						<?php foreach ($rs_bank_withdraw->result() as $row_bank) {?>
							<div class="col-sm-12 col-md-6">
								<div class="panel <?=$row_bank->type?>-bg">
									<div class="panel-body">
										<div class="icon-bg"><i class="thbanks thbanks-<?=$row_bank->type?>"></i></div>
										<div class="text-right">
											<?php $row_detail_bank = $this->statement_model->get_sumin($row_bank->type, $row_bank->username, $start, $end); ?>
											<h5 style="color: white;">
												ฝาก <?php echo $row_detail_bank->listtotal ?> รายการ
												<br>
												จำนวน <?php echo number_format($row_detail_bank->stintotal) ?> บ.
											</h5>
											<h5 style="color: white;">
												คงเหลือ <?php echo $row_bank->balance ? $row_bank->balance : '-' ?> บ.
												<br>
												ใช้ได้ <?php echo $row_bank->available ? $row_bank->available : '-' ?> บ.
											</h5>
										</div>
									</div>
									<div class="panel-footer clearfix panel-footer-link"><?php echo strtoupper($row_bank->type) ?> (<?php echo $row_bank->bankname ?>) </div>
								</div>
							</div>
							<?php }?>
							<div style="clear:both"></div>
							<?php }?>
						</div>
						<!-- END Row BANK -->
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body">
						<form class="form-inline" method="post" id="form-search">
							<label for="date_start">หาจำนวนผู้สมัครจาก วันที่ :</label>
							<!--<input type="text" class="form-control datepicker" id="date_start" placeholder="วันที่" style="width:140px;" name="date_start" onkeydown="return false">-->
							<div class="input-group date date-main col-md-3" data-date="" data-link-field="start-date" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
							<input class="form-control" size="16" type="text" value="" readonly required="required">
							<span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
							<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
							</div>
							<input type="hidden" id="start-date" name="start-date" value="" />

							<label for="date_end">ถึงวันที่ :</label>
							<!--<input type="text" class="form-control datepicker" id="date_end" placeholder="ถึงวันที่" style="width:140px;" name="date_end" onkeydown="return false">-->
							<div class="input-group date date-main col-md-3" data-date="" data-link-field="end-date" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
							<input class="form-control" size="16" type="text" value="" readonly required="required">
							<span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
							<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
							</div>
							<input type="hidden" id="end-date" name="end-date" value="" />
							<button type="button" class="btn btn-success" id="search"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ค้นหา</button>
						</form>
						<br />
						<span id="result-from-search"></span>
					</div>
				</div>
			</div>
		</div>
		<!-- END Row -->


	</div>
  <!-- container -->
</div>
<!-- Page content Wrapper -->