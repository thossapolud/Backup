<div class="">
	<div class="page-header-title">
		<h4 class="page-title">เติม-ถอนเครดิต : <?=$row_website->site_name?> : <?=$dealer?></h4>
	</div>
</div>
<div class="page-content-wrapper ">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body">
						<form id="form-ag" action="<?php echo site_url('credit') ?>" class="col-sm-12 col-md-7 form-inline" method="get">
							<input type="hidden" name="wbid" id="wbid" value="<?=$row_website->site_id?>">
							<input type="hidden" name="dl" value="<?=$dealer?>">
							<?php if ($rs_agent->num_rows() > 0) {?>
								<select name="agid" id="agid" class="form-control" required>
									<option value="">=== เลือกเอเย่นต์ ===</option>
									<?php foreach ($rs_agent->result() as $row_agent) {?>
										<option value="<?php echo $row_agent->userpass_id ?>"
											<?php echo ($agent_id == $row_agent->userpass_id) ? 'selected' : '' ?>>
											<?php echo $row_agent->username ?>
										</option>
									<?php }?>
								</select>
							<?php }?>
							<input class="form-control" size="19" type="text" maxlength="19" name="username" value="<?php echo (isset($username))?$username:''?>" autocomplete="off" placeholder="กรอก Username" required>
							<button class="btn btn-primary" type="submit"><i class="ti-search"></i> ค้นหา User</button>
						</form>
						<?php if (isset($balance)) {?>
							<button class="btn btn-default pull-right" type="button" style="font-size:16px;">Remaining Balance	: <span id="currentbalance"><?=number_format($balance,2)?></span></button>
						<?php }?>
					</div>
				</div>
			</div>
		</div>
		<!-- END Row -->

		<?php if (isset($rs_users)) {?>
			<div class="row">
				<div class="col-md-12 col-xs-12">
					<div class="panel">
						<table class="table table-striped table-bordered table-hover display">
							<thead>
								<tr>
									<th width="5%">&nbsp;</th>
									<th class="text-center">Username</th>
									<th class="text-center">ชื่อสมาชิก</th>
									<th class="text-center" width="30%"></th>
								</tr>
							</thead>
							<tbody>
								<?php if ($rs_users->num_rows() > 0) {
									$i = 1;
									foreach ($rs_users->result() as $row_user) {?>
									<tr align="center">
										<td><?php echo $i++ ?></td>
										<td><?php echo $row_user->username ?></td>
										<td><?php echo $row_user->nickname ?></td>
										<td>
											<a data-toggle="modal" data-target="#deposit-modal" data-username="<?php echo trim($row_user->username) ?>" data-name="<?php echo $row_user->nickname ?>" data-ac="<?php echo trim($row_user->userpass_id) ?>" data-dl="<?php echo trim($row_user->dealer) ?>" data-acusername="<?php echo trim($row_user->ag_username) ?>" data-user_id="<?php echo $row_user->user_id ?>" class="btn btn-success btn-xs <?=!in_array($dealer, unserialize(CONST_DL_CR_DEPOSIT)) ? 'disabled' : ''?>">เติม</a>&nbsp;
											<a data-toggle="modal" data-target="#withdraw-modal" data-username="<?php echo trim($row_user->username) ?>" data-name="<?php echo $row_user->nickname ?>" data-ac="<?php echo trim($row_user->userpass_id) ?>" data-dl="<?php echo trim($row_user->dealer) ?>" data-acusername="<?php echo trim($row_user->ag_username) ?>" data-user_id="<?php echo $row_user->user_id ?>" class="btn btn-danger btn-xs <?=!in_array($dealer, unserialize(CONST_DL_CR_WITHDRAW)) ? 'disabled' : ''?>">ถอน</a>
										</td>
									</tr>
									<?php }?>
								<?php }?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- END Row -->
		<?php }?>
	</div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->

<?php if (isset($rs_users)) {?>
	<!-- Deposit Modals -->
	<div class="modal fade" id="deposit-modal" tabindex="-1" role="dialog" aria-labelledby="addCredit" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content" id="modal-content">
				<form class="form-horizontal" id="form-deposit-credit" action="" method="POST" role="form">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">เติมเครดิต</h4>
					</div>
					<div class="modal-body">
						<div class="form-group ">
							<label for="name" class="col-sm-3 control-label">ชื่อสมาชิก:</label>
							<div class="col-sm-8">
								<input name="name" type="text" class="form-control name" id="name" placeholder="ชื่อสมาชิก" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="username" class="col-sm-3 control-label">ชื่อบัญชีสมาชิก:</label>
							<div class="col-sm-8">
								<input name="username" type="text" class="form-control username" id="username" placeholder="ชื่อบัญชีสมาชิก" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="credit_game" class="col-sm-3 control-label">ค้างในเกม:</label>
							<div class="col-sm-8">
								<input name="credit_game" type="text" class="form-control credit_game" id="credit_game" placeholder="ค้างในเกม" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="credit_balance" class="col-sm-3 control-label">กระเป๋าเกม:</label>
							<div class="col-sm-8">
								<input name="credit_balance" type="text" class="form-control credit_balance" id="credit_balance" placeholder="กระเป๋าเกม" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="credit_total" class="col-sm-3 control-label">ยอดเครดิต:</label>
							<div class="col-sm-8">
								<input name="credit_total" type="text" class="form-control credit_total" id="credit_total" placeholder="ยอดรวมเครดิต" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="Credit" class="col-sm-3 control-label">Credit:</label>
							<div class="col-sm-8">
								<input name="credit" type="text" class="form-control credit" id="credit" placeholder="credit" required>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
						<button type="button" class="btn btn-success" id="deposit-credit" ><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> เติมเครดิต</button>
					</div>
					<input type="hidden" name="dealer" id="dealer" value="<?=$dealer?>" />
					<input name="ac" type="hidden" id="ac" value="<?=$agent_id?>">
					<input name="ac_username" type="hidden" id="ac_username" value="<?=$ac_username?>">
					<input name="user_id" type="hidden" id="user_id">
					<input name="method" type="hidden" id="method" value="deposit">
				</form>
			</div>
		</div>
	</div>
	<!-- END Deposit Modals -->
	<!-- Withdraw Modals -->
	<div class="modal fade" id="withdraw-modal" tabindex="-1" role="dialog" aria-labelledby="withdrawCredit" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content" id="modal-content">
				<form class="form-horizontal" id="form-withdraw-credit" action="" method="POST" role="form">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">ถอนเครดิต</h4>
					</div>
					<div class="modal-body">
						<div class="form-group ">
							<label for="name" class="col-sm-3 control-label">ชื่อสมาชิก:</label>
							<div class="col-sm-8">
								<input name="name" type="text" class="form-control name" id="name" placeholder="ชื่อสมาชิก" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="username" class="col-sm-3 control-label">ชื่อบัญชีสมาชิก:</label>
							<div class="col-sm-8">
								<input name="username" type="text" class="form-control username" id="username" placeholder="ชื่อบัญชีสมาชิก" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="credit_game" class="col-sm-3 control-label">ค้างในเกม:</label>
							<div class="col-sm-8">
								<input name="credit_game" type="text" class="form-control credit_game" id="credit_game" placeholder="ค้างในเกม" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="credit_balance" class="col-sm-3 control-label">กระเป๋าเกม:</label>
							<div class="col-sm-8">
								<input name="credit_balance" type="text" class="form-control credit_balance" id="credit_balance" placeholder="กระเป๋าเกม" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="credit_total" class="col-sm-3 control-label">ยอดเครดิต:</label>
							<div class="col-sm-8">
								<input name="credit_total" type="text" class="form-control credit_total" id="credit_total" placeholder="ยอดรวมเครดิต" required readonly>
							</div>
						</div>
						<div class="form-group ">
							<label for="Credit" class="col-sm-3 control-label">Credit:</label>
							<div class="col-sm-8">
								<input name="credit" type="text" class="form-control credit" id="credit" placeholder="credit" required>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
						<button type="button" class="btn btn-danger" id="withdraw-credit" ><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> ถอนเครดิต</button>
					</div>
					<input type="hidden" name="dealer" id="dealer" value="<?=$dealer?>" />
					<input name="ac" type="hidden" id="ac" value="<?=$agent_id?>">
					<input name="ac_username" type="hidden" id="ac_username" value="<?=$ac_username?>">
					<input name="method" type="hidden" id="method" value="withdraw">
				</form>
			</div>
		</div>
	</div>
	<!-- END Withdraw Modals -->
<?php }?>
<script language="javascript">
	$.LoadingOverlay("show");
	$("#agid").change(function() {
		$('#form-ag').submit();
	});
	$(function(){		
		$(".credit").on("input", function(evt) {
			var self = $(this);
			self.val(self.val().replace(/[^0-9\.]/g, ''));
		});
		<?php if (isset($rs_users)) {?>
		$('#deposit-modal, #withdraw-modal').on('show.bs.modal', function (e) {
			//e.preventDefault();
			$this = $(this);
			$.LoadingOverlay("show");
			$.ajax({
				type: 'POST',
				dataType: 'json',
				cache: false,
				url: '<?php echo site_url('credit/get-player-credit') ?>',
				data: {'user_id':$(e.relatedTarget).attr('data-user_id'),'dealer':$(e.relatedTarget).attr('data-dl')},
				success: function(data){
					console.log(data);
					$.LoadingOverlay("hide");
					$this.find('.credit_game').val(data.creditGame);
					$this.find('.credit_balance').val(data.creditBalance);
					$this.find('.credit_total').val(data.creditTotal);
				}
			});
			$(this).find('.credit').val('');
			$(this).find('.username').val($(e.relatedTarget).attr('data-username'));
			$(this).find('.name').val($(e.relatedTarget).attr('data-name'));
		});
		$('#deposit-credit, #withdraw-credit').click(function(){
			var form,url,$modal,ac;
			if($(this).attr('id')=='deposit-credit'){
				form=$("#form-deposit-credit");
				$modal = '#deposit-modal';
			}else{
				form=$("#form-withdraw-credit");
				$modal = '#withdraw-modal';
			}
			if(form.find('#credit').val()!=''){
				if(confirm('ยืนยันจัดการเครดิต ?')){
					//form.find('span.glyphicon-refresh').show();
					$.LoadingOverlay("show");
					ac = form.find('input#ac').val();
					$.ajax({
						cache: false,
						type: 'POST',
						url: '<?php echo site_url('credit/editcredit') ?>',
						data: form.serialize(),
						success: function(data){
							//form.find('span.glyphicon-refresh').hide();
							$.LoadingOverlay("hide");
							swal({ title: data, confirmButtonText: 'OK' },function(){
								$($modal).modal('hide');
								window.location.reload();
							});
						}
					});
				}
			}else{
				swal({ title:'กรุณากรอก Credit', confirmButtonText: 'OK' });
			}
		});
		<?php }?>
		$.LoadingOverlay("hide");
	});
</script>