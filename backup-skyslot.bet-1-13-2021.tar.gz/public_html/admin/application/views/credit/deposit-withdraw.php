<div class="">
  <div class="page-header-title">
    <h4 class="page-title">รายการเติม-ถอนเครดิต : <?=$row_website->site_name?> : <?=$dealer?></h4>
  </div>
</div>

<div class="page-content-wrapper ">
    <div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body">
						<form id="form-ag" action="<?php echo site_url('credit/deposit-withdraw') ?>" class="col-sm-12 col-md-7 form-inline" method="get">
							<input type="hidden" name="wbid" id="wbid" value="<?=$row_website->site_id?>">
							<input type="hidden" name="dl" value="<?=$dealer?>">
							<?php if ($rs_agent->num_rows() > 0) {?>
							<select name="agid" id="agid" class="form-control" >
									<option value="">=== เลือกเอเย่นต์ ===</option>
									<?php foreach ($rs_agent->result() as $row_agent) {?>
									<option value="<?php echo $row_agent->userpass_id ?>" <?php echo ($agent_id == $row_agent->userpass_id) ? 'selected' : '' ?> ><?php echo $row_agent->username ?></option>
									<?php }?>
							</select>
							<?php }?>
						</form>
					</div>
				</div>
			</div>
		</div>

        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>
                              <th></th>	                              
                              <th>ชื่อสมาชิก</th>
                              <th>ชื่อบัญชีสมาชิก</th>
                              <th>เครดิตเอเย่นต์</th>
                              <th>ยอดก่อนเติม/ถอน</th> 
                              <th>ยอดเติม/ถอน</th>                      
                              <th width="15%">เติม/ถอนโดย</th>
                              <th width="15%">วันที่</th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- END Row -->
     </div>
  <!-- container -->   
</div>
<!-- Page content Wrapper -->

<script type="text/javascript" charset="utf-8">
	// $(function(){
		$("#agid").change(function() {
			// if($(this).val()!=''){
				$('#form-ag').submit();
			// }
		});
	// });
	$(document).ready(function() {
		var t = $('#datatables').DataTable({
			"bPaginate": true, 
			//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
			//"bFilter": false, //+ ช่องค้นหา
			//"bInfo": false, //+ รายละเอียดจำนวนแถว
			"bProcessing": true,
			"bServerSide": true,
			"sServerMethod": "GET",
			"sAjaxSource": '<?php echo base_url('credit/deposit-withdraw-all?wbid='.$row_website->site_id.'&dl='.$dealer.'&agid='.$agent_id); ?>',
			"iDisplayLength": 50,
			"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
				{"searchable": false, "orderable": false, "targets":0,'className':'text-center'},
				{"searchable": false, "orderable": false, "targets":1,'className':'text-center'},	
				{"targets":[2,4,5,6,7,8],'className':'text-center'},
				{"searchable": true, "orderable": true, "targets":3,'className':'text-center text-vertical',
					"render": function(data, type, row) { // Available data available for you within the row	
						return '<a href="<?php echo site_url('user/deposit-withdraw-username') ?>/'+data+'" target="_blank">'+data+'</a>';
					}	
				}
			],
			"language": {
				"infoFiltered": ""
			},
			"order": [8, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
		});
	});
</script>