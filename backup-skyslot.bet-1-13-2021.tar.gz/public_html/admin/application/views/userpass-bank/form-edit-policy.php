<form class="form-horizontal" id="form-edit-userpass-bank" role="form">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h4 class="modal-title" id="myModalLabel">การแสดงบัญชีต่อกลุ่มลูกค้า <?=conv_ws_type($actype)?></h4>
	</div>
	<div class="modal-body">
	<?php if($actype) { ?>
		<div class="form-group">
			<label for="sys_bank" class="col-sm-3 control-label">ธนาคาร<?=conv_ws_type($actype)?>:</label>
			<div class="col-sm-8">
				<select name="sys_bank" id="sys_bank" class="form-control" required="required">
					<option value="">== เลือก ==</option>
				<?php foreach ($rs_bank as $row_bank) { ?>
					<option value="<?=$row_bank->opt_name?>"><?=strtoupper($row_bank->opt_name)?> - <?=$row_bank->opt_value?></option>
				<?php } ?>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="cust_bank" class="col-sm-3 control-label">ธนาคารลูกค้า:</label>
			<div class="col-sm-8">
				<select class="form-control" name="cust_bank" id="cust_bank" require="required">
					<option value="">==เลือกธนาคาร==</option>
					<option value="KBANK">KBANK - ธนาคารกสิกรไทย</option>
					<option value="SCB">SCB - ธนาคารไทยพาณิชย์</option>
					<option value="BBL">BBL - ธนาคารกรุงเทพ</option>
					<option value="KTB">KTB - ธนาคารกรุงไทย</option>
					<option value="TMB">TMB - ธนาคารทหารไทย</option>
					<option value="BAY">BAY - ธนาคารกรุงศรีอยุธยา</option>
					<option value="GSB">GSB - ธนาคารออมสิน</option>
					<option value="ISBT">ISBT - ธนาคารอิสลาม</option>
					<option value="GHB">GHB - ธนาคารอาคารสงเคราะห์</option>
					<option value="CIMBT">CIMBT - ธนาคารซีไอเอ็มบี</option>
					<option value="TBANK">TBANK - ธนาคารธนชาต</option>
					<option value="LHBANK">LHBANK - ธนาคารแลนด์แอนด์เฮ้าส์</option>
					<option value="SCBT">SCBT - ธนาคารสแตนดาร์ดชาร์เตอร์ด</option>
					<option value="TISCO">TISCO - ธนาคารทิสโก้</option>
					<option value="CITI">CITI - ธนาคารซิตี้แบงก์</option>
					<option value="HSBC">HSBC - ธนาคารฮ่องกงและเซี่ยงไฮ้</option>
					<option value="KK">KK - ธนาคารเกียรตินาคิน</option>
					<option value="UOBT">UOBT - ธนาคารยูโอบี</option>
					<option value="ICBC">ICBC - ธนาคารไอซีบีซี</option>
					<option value="TCRB">TCRB - ธนาคารไทยเครดิต</option>
					<option value="BAAC">BAAC - ธนาคารเพื่อการเกษตรฯ</option>
				</select>
			</div>
		</div>
		<hr>
		<div class="form-group">
			<label for="bank_account" class="col-sm-3 control-label">การตั้งค่าปัจจุบัน:</label>
			<div class="col-sm-6">
				<table class="table table-striped table-bordered table-hover" id="table-list-policy" width="100%" style="font-size:11px;">
					<thead>
					<tr role="row">
						<th class="text-center" width="5%"></th>
						<th class="text-center" width="33%">ธนาคาร<?=conv_ws_type($actype)?></th>
						<th class="text-center" width="33%">ธ.ลค.</th>
					</tr>
					</thead>
					<tbody>
					<?php if($rs_current_policy->num_rows()>0){ ?>
					<?php foreach($rs_current_policy->result() as $row_current_policy){ ?>
					<tr>
						<td class="text-center"><input type="radio" name="opt_id" id="opt_id" class="opt_id" value="<?php echo $row_current_policy->opt_id ?>" /></td>
						<td class="text-center"><?php echo strtoupper($row_current_policy->opt_name) ?></td>
						<td class="text-center"><?php echo $row_current_policy->opt_value ?></td>
					</tr>
					<?php } ?>
					<?php } ?>
					</tbody>
				</table>
			</div>
			<div class="col-sm-2">
				<button type="button" class="btn btn-success form-control" id="add-policy">เพิ่ม</button>
			</div>
		</div>
		<div class="form-group">
			<label for="" class="col-sm-3 control-label"></label>
			<div class="col-sm-6">
			</div>
			<div class="col-sm-2">
				<button type="button" class="btn btn-primary form-control" id="delete-policy">ลบ</button>
			</div>
		</div>
	<?php } ?>
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
	</div>
</form>

<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	var base_url = '<?php echo site_url() ?>';
	function setPolicyTable() {
		$.LoadingOverlay("show");
		$('#table-list-policy tbody').empty();
		$.ajax({
			cache: false,
			type: 'POST',
			dataType: 'json',
			url: '<?php echo site_url('userpass-bank/get-policy') ?>',
			data: {'actype':'<?php echo $actype ?>'},
			success: function(data){
				$.LoadingOverlay("hide");
				if(data!=''){
					var tr = '';
					$.each(data,function(index, val){
						tr += '<tr>';
						tr += '<td class=" text-center"><input type="radio" name="opt_id" id="opt_id" class="opt_id" value="'+val.opt_id+'" /></td>';
						tr += '<td class="text-center">'+val.opt_name+'</td>';
						tr += '<td class="text-center">'+val.opt_value+'</td>';
						tr += '</tr>';
					});
					$('#table-list-policy tbody').append(tr);
				}else{
					swal({title:'ไม่มีธนาคารในนี้แล้ว',confirmButtonText: 'OK' })
				}					
			}
		});
	}
	$('#add-policy').click(function(){
		if($('#sys_bank').val()!='' && $('#cust_bank').val()!='') {
			swal({
				title: "ยืนยัน เพิ่มธนาคาร ?",
				type: "warning",
				showCancelButton: true,
				cancelButtonText: "ยกเลิก",
				confirmButtonText: "ยืนยัน",
				closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				var sys_bank = $('#sys_bank').val();
				var cust_bank = $('#cust_bank').val();
				$.ajax({
					type: 'POST',
					//dataType: 'json',
					cache: false,
					url: '<?php echo site_url('userpass-bank/add-policy') ?>',
					data: { 'actype':'<?php echo $actype ?>', 'sys_bank': sys_bank, 'cust_bank': cust_bank },
					success: function(resp){
						$.LoadingOverlay("hide");
						swal({title:resp,confirmButtonText: 'OK'},function(){
							setPolicyTable();
						});
					}
				});
			});
		} else {
			swal({title:'เลือก ธนาคาร ก่อน!',confirmButtonText: 'OK'});
		}
	});
	$('#delete-policy').click(function(){
		var opt_id = '';
		$.each($("input[name='opt_id']:checked"), function(){            
			opt_id = $(this).val();
		});
		if (opt_id.length > 0) {
			swal({
				title: "ยืนยัน ลบธนาคาร ?",
				type: "warning",
				showCancelButton: true,
				cancelButtonText: "ยกเลิก",
				confirmButtonText: "ยืนยัน",
				closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					cache: false,
					url: '<?php echo site_url('userpass-bank/delete-policy') ?>',
					data: { 'opt_id': opt_id },
					success: function(resp){
						$.LoadingOverlay("hide");
						swal({title:resp,confirmButtonText: 'OK'},function(){
							setPolicyTable();
						});
					}
				});
			});
		} else {
			swal({title:'เลือก ธนาคาร ก่อน!',confirmButtonText: 'OK'});
		}
	});
});
</script>