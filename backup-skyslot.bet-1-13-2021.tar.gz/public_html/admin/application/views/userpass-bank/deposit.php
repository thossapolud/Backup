<div class="">
	<div class="page-header-title">
		<h4 class="page-title">จัดการบัญชีธนาคารฝาก</h4>
	</div>
</div>
<div class="page-content-wrapper ">
    <div class="container"> 
    
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <button class="btn btn-success btn-lg" href="#addBankAccount" type="button" data-toggle="modal">เพิ่มบัญชีธนาคารฝาก</button>
						<a data-toggle="modal" data-target="#edit-policy-modal" data-actype="deposit" class="btn btn-info btn-lg"><span class="ti-pencil"> การแสดงผลธนาคารฝาก</span></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>
							  <th>เว็บไซต์</th>
                              <th>ธนาคาร</th>
                              <th>ชื่อบัญชี</th>
                              <th>เลขที่บัญชี</th> 
                              <th>บัญชีฝาก/ถอน</th>
							  <th>ดึงอัตโนมัติ</th>
                              <th>สถานะ</th>
                              <th></th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Row -->
        
     </div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->
<!-- Create Modals -->
<div class="modal fade" id="addBankAccount" tabindex="-1" role="dialog" aria-labelledby="addBankAccount" aria-hidden="true" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<form class="form-horizontal" id="form-add-bank-account" action="#" method="POST" role="form">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">เพิ่มบัญชีธนาคารฝาก</h4>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="site_id" class="col-sm-3 control-label">สำหรับเว็บไซต์:</label>
						<div class="col-sm-8">
							<select name="site_id" id="site_id" class="form-control" required="required">
								<option value="">== เลือก ==</option>
								<?php foreach ($rs_website->result() as $row_website) {?>
								<option value="<?=$row_website->site_id?>"><?=$row_website->site_name?></option>
								<?php }?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="type" class="col-sm-3 control-label">ธนาคาร:</label>
						<div class="col-sm-8">
							<select name="type" id="type" class="form-control" required="required">
								<option value="">== เลือก ==</option>
							<?php foreach ($rs_bank as $row_bank) { ?>
								<option value="<?=$row_bank->opt_name?>"><?=strtoupper($row_bank->opt_name)?> - <?=$row_bank->opt_value?></option>
							<?php } ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="bankname" class="col-sm-3 control-label">ชื่อบัญชี:</label>
						<div class="col-sm-8">
							<input type="text" name="bankname" class="form-control" id="bankname" placeholder="ชื่อบัญชี" required="required">
						</div>
					</div>
					<div class="form-group">
						<label for="banknum" class="col-sm-3 control-label">เลขที่บัญชี:</label>
						<div class="col-sm-8">
							<input type="text" name="banknum" class="form-control" id="banknum" placeholder="เลขที่บัญชี" required="required">
						</div>
					</div>
					<div class="form-group">
						<label for="username" class="col-sm-3 control-label">Username:</label>
						<div class="col-sm-8">
							<input type="text" name="username" class="form-control" id="username" placeholder="Username" required="required">
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-3 control-label">Password:</label>
						<div class="col-sm-8">
							<input type="text" name="password" class="form-control" id="password" placeholder="Password" required="required">
						</div>
					</div>
					<input name="actype" value="deposit" type="hidden">
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
					<button type="button" class="btn btn-success" id="submit-add-bank-account">เพิ่มบัญชีธนาคารฝาก</button>
					<button type="submit" style="display: none;" id="submit-hidden"></button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- END Create Modals -->
<!-- View Worksheet Modals -->
<div class="modal fade" id="edit-bank-modal" tabindex="-1" role="dialog" aria-labelledby="bankView" aria-hidden="false" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<form class="form-horizontal" id="form-edit-bank" action="<?php echo base_url('userpass-bank/edit'); ?>" method="POST" role="form">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">แก้ไขบัญชีธนาคาร</h4>
				</div>
				<div class="modal-body">				 
				</div>
				<div class="modal-footer">
					<input name="actype" value="deposit" type="hidden">
					<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
					<button type="submit" class="btn btn-success" >แก้ไขบัญชีธนาคารฝาก</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- END View Worksheet Modals -->
<!-- View Worksheet Modals -->
<div class="modal fade" id="edit-policy-modal" tabindex="-1" role="dialog" aria-labelledby="BankPolicyView" aria-hidden="false" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<div class="div-for-load-edit-form">
			</div>
		</div>
	</div>
</div>
<!-- END View Worksheet Modals -->

<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$.fn.modal.Constructor.prototype.enforceFocus = function(){};
	var base_url = '<?php echo site_url() ?>';
	var t = $('#datatables').DataTable({
		"bPaginate": true, 
		//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
		//"bFilter": false, //+ ช่องค้นหา
		//"bInfo": false, //+ รายละเอียดจำนวนแถว
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": '<?php echo base_url('userpass-bank/get-userpass-bank?actype=deposit'); ?>',
		"iDisplayLength": 50,
		"columnDefs": [	//+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
			{"searchable": true, "orderable": false, "targets":0,'className':'text-center text-vertical'},
			{"searchable": false, "orderable": true, "targets":[5,6,7],'className':'text-center text-vertical'},		
			{"targets":[1,2,3,4,5],'className':'text-center text-vertical'},
			{"searchable": false, "orderable": false, "targets":8,'className':'text-center text-vertical',
				"render": function(data, type, row) { // Available data available for you within the row	
					var button = '<a data-toggle="modal" data-target="#edit-bank-modal" data-upid="'+data+'" class="btn btn-xs btn-default"><span class="ti-pencil"> แก้ไขข้อมูล</span></a>';					
					return button;
				}	
			}
		],
		// "order": [[6, 'asc'],[ 1, "asc" ],[ 4, "asc" ],[ 5, "asc" ]] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
	});
	$('#addBankAccount').on('hidden.bs.modal', function () {
		document.getElementById('form-add-bank-account').reset();
	});
	$('#submit-add-bank-account').click(function(){
		if ($('#form-add-bank-account')[0].checkValidity()) {
			swal({
				title: "ยืนยัน เพิ่มบัญชีธนาคาร ?",
				type: "warning",
				showCancelButton: true,
				cancelButtonText: "ยกเลิก",
				confirmButtonText: "ยืนยัน",
				closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					cache: false,
					url: '<?php echo site_url('userpass_bank/add') ?>',
					data: $("#form-add-bank-account").serialize(),
					success: function(resp){
						$.LoadingOverlay("hide");
						swal({title:resp,confirmButtonText: 'OK'},function(){window.location.reload();});
					}
				});
			});
		} else {
			$("#form-add-bank-account").find("#submit-hidden").click();
		}
	});
	$('#edit-bank-modal').on('show.bs.modal', function (e){
		$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('userpass-bank/form-edit-bank')?>?upid='+$(e.relatedTarget).attr('data-upid'));
	});
	$('#edit-policy-modal').on('show.bs.modal', function (e){
		$(this).find('.div-for-load-edit-form').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('userpass-bank/form-edit-policy')?>?actype='+$(e.relatedTarget).attr('data-actype'));
	});
});
</script>
<link href="<?php echo base_url('assets/plugins/uploadifive/uploadifive.css') ?>" type="text/css" media="screen" rel="stylesheet"/>
<script src="<?php echo base_url('assets/plugins/uploadifive/jquery.uploadifive.min.js') ?>" type="text/javascript"></script>