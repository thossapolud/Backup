<?php if($row_userpass) { ?>
<div class="form-group">
	<input name="userpasstoedit" value="<?php echo $row_userpass->userpass_id ?>" type="hidden">
	<label for="acnum" class="col-sm-3 control-label">ACNUM:</label>
	<div class="col-sm-8">
		<input type="text" class="form-control" disabled="disabled" value="<?php echo $row_userpass->acnum ?>">
	</div>
</div>
<div class="form-group">
	<label for="site_name" class="col-sm-3 control-label">สำหรับเว็บไซต์:</label>
	<div class="col-sm-8">
		<input type="text" class="form-control" value="<?php echo $row_website->site_name ?>" disabled="disabled">
	</div>
</div>
<div class="form-group">
	<label for="bankname" class="col-sm-3 control-label">ชื่อบัญชี:</label>
	<div class="col-sm-8">
		<input type="text" name="bankname" class="form-control" id="bankname" value="<?php echo $row_userpass->bankname ?>" disabled="disabled">
	</div>
</div>
<div class="form-group">
	<label for="banknum" class="col-sm-3 control-label">เลขที่บัญชี:</label>
	<div class="col-sm-8">
		<input type="text" name="banknum" class="form-control" id="banknum" value="<?php echo $row_userpass->banknum ?>" disabled="disabled">
	</div>
</div>
<div class="form-group">
	<label for="username" class="col-sm-3 control-label">Username:</label>
	<div class="col-sm-8">
		<input type="text" name="username" class="form-control" id="username" value="<?php echo $row_userpass->username ?>" required="required">
	</div>
</div>
<div class="form-group">
	<label for="password" class="col-sm-3 control-label">password:</label>
	<div class="col-sm-8">
		<input type="password" name="password" class="form-control" id="password" placeholder="Password" value="<?php echo $row_userpass->password ?>" data-toggle="password" required="required">
	</div>
</div>
<div class="form-group">
	<label for="password" class="col-sm-3 control-label">เลข 3 ตัวท้าย:</label>
	<div class="col-sm-8">
		<input type="text" name="lastdigitphone" class="form-control" id="lastdigitphone" placeholder="lastdigitphone" value="<?php echo $row_userpass->lastdigitphone ?>" data-toggle="lastdigitphone" maxlength="3">
	</div>
</div>
<div class="form-group">
	<label for="autojob_status" class="col-sm-3 control-label">ดึงรายการอัตโนมัติ:</label>
	<div class="col-sm-8">
		<div class="radio radio-success form-check-inline">
			<input type="radio" id="autojob_status_active" value="1" name="autojob_status" <?php echo ($row_userpass->autojob_status == 1) ? 'checked="checked"':'' ?> required>
			<label for="autojob_status_active">เปิด</label>
		</div>
		<div class="radio form-primary-inline">
			<input type="radio" id="autojob_status_inactive" value="0" name="autojob_status" <?php echo ($row_userpass->autojob_status == 0) ? 'checked="checked"':'' ?> required>
			<label for="autojob_status_inactive">ปิด</label>
		</div>
	</div>
</div>
<div class="form-group">
	<label for="up_status" class="col-sm-3 control-label">สถานะ:</label>
	<div class="col-sm-8">
		<div class="radio radio-success form-check-inline">
			<input type="radio" id="up_status_active" value="1" name="up_status" <?php echo ($row_userpass->up_status == 1) ? 'checked="checked"':'' ?> required>
			<label for="up_status_active">ใช้งาน</label>
		</div>
		<div class="radio form-primary-inline">
			<input type="radio" id="up_status_inactive" value="0" name="up_status" <?php echo ($row_userpass->up_status == 0) ? 'checked="checked"':'' ?> required>
			<label for="up_status_inactive">ปิดใช้งาน</label>
		</div>
	</div>
</div>
<?php } ?>