<div class="">
  <div class="page-header-title">
    <h4 class="page-title">User / Pass Bank</h4>
  </div>
</div>
<div class="page-content-wrapper ">
  <div class="container">

    <div class="row">
        <div class="col-sm-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
            <div class="panel">
              <div class="panel-heading"> 
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                  <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">General Info</a></li>              
                  <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Edit</a></li>
                </ul>
              </div>
              <div class="panel-body"> 
                <!-- Tab panes -->
                <div class="tab-content">
                  <div role="tabpanel" class="tab-pane active" id="home">
                    <form class="form-horizontal" method="POST" role="form">
                    <?php $i=1; foreach($rs_userpass->result() as $row_userpass){ ?>
                      <div class="form-group">
                        <label for="bankname" class="col-sm-4 col-md-4 control-label">ชื่อบัญชี <?php echo $row_userpass->type ?> <?php echo $row_userpass->acnum ?> :</label>                    <div class="col-sm-3 col-md-3">
                          <p class="form-control-static"><?php echo $row_userpass->bankname ?></p>
                        </div>       
                        <label for="banknum" class="col-sm-2 col-md-2 control-label">เลขบัญชี:</label>
                        <div class="col-sm-3 col-md-3">
                          <p class="form-control-static"><?php echo $row_userpass->banknum ?></p>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="username" class="col-sm-4 col-md-4 control-label">Username <?php echo $row_userpass->type ?> :</label>
                        <div class="col-sm-3 col-md-3">
                          <p class="form-control-static"><?php echo $row_userpass->username ?></p>
                        </div>
                        <label for="username" class="col-sm-2 col-md-2 control-label">Password:</label>
                        <div class="col-sm-3 col-md-3">
                          <p class="form-control-static"><?php echo $row_userpass->password ?></p>
                        </div>          
                      </div>
                   <?php if($i%3==0){echo '<hr style="background-color: red; height: 1px; border: 0;">';} ?>
                   <?php $i++; } ?>              
                    </form>
                  </div>              
                  <div role="tabpanel" class="tab-pane" id="profile">
                    <div class="modal-content" id="modal-content">
                      <form class="form-horizontal" id="admin-edit-userscr" action="<?php echo site_url('userpass-bank/edit') ?>" method="POST" role="form">
                        <div class="form-group">
                            <div class="col-sm-4 col-md-3 col-lg-3"> </div>
                        </div>
                        <?php $i=1; foreach($rs_userpass->result() as $row_userpass){ ?>
                        <div class="form-group ">
                            <label for="Bankname" class="col-sm-3 control-label">ชื่อบัญชี <?php echo $row_userpass->type ?> <?php echo $row_userpass->acnum ?> :</label>
                            <div class="col-sm-4">
                               <input type="text" class="form-control" placeholder="Bankname" name="bankname[<?php echo $row_userpass->userpass_id ?>]" id="bankname" value="<?php echo $row_userpass->bankname ?>" required="required">
                            </div>
                            <div class="col-sm-4">
                               <input type="text" class="form-control" placeholder="เลขบัญชี" name="banknum[<?php echo $row_userpass->userpass_id ?>]" id="banknum" value="<?php echo $row_userpass->banknum ?>" required="required">
                            </div>            
                        </div>
                        <div class="form-group ">
                            <label for="inputUsername" class="col-sm-3 control-label">Username <?php echo $row_userpass->type ?>:</label>
                            <div class="col-sm-4">
                               <input type="text" class="form-control" placeholder="Username" name="username[<?php echo $row_userpass->userpass_id ?>]" id="username" value="<?php echo $row_userpass->username ?>" required="required">
                            </div>
                            <div class="col-sm-4">              
                              <input type="password" name="password[<?php echo $row_userpass->userpass_id ?>]" class="form-control" id="password" placeholder="Password" value="<?php echo $row_userpass->password ?>" data-toggle="password" required="required">
                            </div>            
                        </div>
                        <input name="usertoedit[<?php echo $row_userpass->userpass_id ?>]" value="<?php echo $row_userpass->userpass_id ?>" type="hidden">
                        <?php if($i%3==0){echo '<hr style="background-color: red; height: 1px; border: 0;">';} ?>
                        <?php $i++; } ?>
                        <div class="form-group">
                            <div class="col-sm-4 col-md-3"></div>
                            <div class="col-sm-4 col-md-4">                        
                            <button type="submit" id="submit" name="button" value="Edit Account" class="btn btn-default"><i class=" fa fa-refresh "></i> Submit Changes</button>
                            </div>
                        </div>
                      </form>
                    </div><!-- End <div class="modal-content" id="modal-content"> -->
                  </div><!-- End <div role="tabpanel" class="tab-pane" id="profile"> -->
                </div>
              </div>
            </div><!-- End panel -->
        </div>
    </div><!-- End row -->

<!-- container -->   
</div>
<!-- Page content Wrapper -->
<script type="text/javascript">
$(function() {
	// Javascript to enable link to tab
	var hash = document.location.hash;
	if (hash) {
		console.log(hash);
		$('.nav-tabs a[href='+hash+']').tab('show');
	}	
	// Change hash for page-reload
	$('a[data-toggle="tab"]').on('show.bs.tab', function (e) {
		window.location.hash = e.target.hash;
	});
});
</script>