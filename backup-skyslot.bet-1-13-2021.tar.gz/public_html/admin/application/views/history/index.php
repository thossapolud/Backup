<div class="">
  <div class="page-header-title">
    <h4 class="page-title">ประวัติการใช้งาน</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container">
    
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel">
                <div class="panel-heading">
                    <h2 class="panel-title">รายการประวัติการใช้งาน</h2>                
                </div>
                <div class="panel-body table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                      <thead>
                        <tr role="row">
                          <th width="5%"></th>
                          <th>ชื่อ</th>	
                          <th>ไอพี</th>
                          <th>การกระทำ</th>
                          <th>รายละเอียด</th>                      
                          <th>วันที่</th>
                        </tr>
                      </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>                                   
    </div>
    <!-- END Row -->
  </div>
  <!-- container -->   
</div>
<!-- Page content Wrapper -->
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	var t = $('#datatables').DataTable({
		"bPaginate": true, 
		//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
		//"bFilter": false, //+ ช่องค้นหา
		//"bInfo": false, //+ รายละเอียดจำนวนแถว
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": '<?php echo base_url('history/list-table'); ?>',
		"iDisplayLength": 50,
		"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
			{"searchable": false, "orderable": false, "targets":[0],'className':'text-center'},
			{"searchable": false, "orderable": true, "targets":5,'className':'text-center'},
			{"targets":[1,2,3,4],'className':'text-center'}
		],
		"order": [5, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
	});	
});
</script>