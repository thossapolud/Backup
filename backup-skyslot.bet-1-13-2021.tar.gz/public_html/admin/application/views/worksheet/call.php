<div class="">
  <div class="page-header-title">
    <h4 class="page-title">Call</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container"> 
    
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <button class="btn btn-success btn-lg" href="#createWorksheet" type="button" data-toggle="modal" id="create" disabled>เปิดใบงาน</button>
						<button class="btn btn-success btn-lg pull-right" type="button" id="btn-refresh" onclick="window.location.reload();">REFRESH</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th></th>
                              <th>สินค้า</th>
                              <th>ชื่อ</th>
                              <th>ชื่อบัญชีสมาชิก</th> 
                              <th>วันที่ฝาก/ถอน</th>
                              <th>จำนวน</th>
                              <th width="6%">รูปฝาก</th>
                              <th>Call</th>
                              <th>วันเปิด</th>
                              <th>Bank</th>
                              <th>Manage</th>
                              <th></th>
                              <th></th>
                              <th></th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Row -->
        
     </div>
  <!-- container -->
</div>
<!-- Page content Wrapper -->
<!-- Create Modals -->
<div class="modal fade" id="createWorksheet" tabindex="-1" role="dialog" aria-labelledby="createWorksheet" aria-hidden="true" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content" id="modal-content">
      <form class="form-horizontal" id="form-create-worksheet" action="#" method="POST" role="form">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">ใบงาน</h4>
        </div>
        <div class="modal-body">
          <div class="form-group  ">
            <label for="inputType" class="col-sm-3 control-label">รายการ:</label>
            <div class="col-sm-8">
              <input type="radio" name="ws_type" id="ws_type" class="ws_type" value="deposit" />
              <label for="deposit">ฝาก</label>
              &nbsp;&nbsp;
              <input type="radio" name="ws_type" id="ws_type" class="ws_type" value="withdraw" />
              <label for="withdraw">ถอน</label>
              &nbsp;&nbsp;
              <!-- <input type="radio" name="ws_type"  id="ws_type" class="ws_type" value="transfer" />
              <label for="withdraw">โยกเครดิต</label> -->
            </div>
          </div>
          <div class="form-group for-transfer" style="display:none;">
            <div class="col-sm-12 text-center"><h1>จากสินค้า</h1></div>
          </div>
		  <div class="form-group  ">
            <label for="inputWebsite" class="col-sm-3 control-label">เว็บไซต์:</label>
            <div class="col-sm-8">
			  <select name="site_id" id="site_id" class="form-control site_id" >
				<option value="">== เลือก ==</option>
				<option disabled="disabled">-----------------------------------------------------------------------------</option>
				<?php foreach ($rs_website->result() as $row_website) {?>
				<option value="<?=$row_website->site_id?>"><?=$row_website->site_name?></option>
				<option disabled="disabled">-----------------------------------------------------------------------------</option>
				<?php }?>
			  </select>
            </div>
          </div>
          <div class="form-group  ">
            <label for="inputDealer" class="col-sm-3 control-label">ตัวเกมส์สินค้า:</label>
            <div class="col-sm-8">
			  <select name="ws_dealer" id="ws_dealer" class="form-control ws_dealer" >
				<option value="">== เลือก ==</option>
				<option disabled="disabled">-----------------------------------------------------------------------------</option>
				<?php foreach ($rs_dealer->result() as $row_dealer) {?>
				<option value="<?=$row_dealer->dl_code?>"><?=$row_dealer->dl_code?></option>
				<option disabled="disabled">-----------------------------------------------------------------------------</option>
				<?php }?>
			  </select>
            </div>
          </div>
          <!--<div class="form-group ">
          	<label for="inputName" class="col-sm-3 control-label">เลขที่บิล:</label>
          	<div class="col-sm-8">
              <input type="text" name="ws_code" class="form-control" id="ws_code" placeholder="เลขที่บิล" value="<?php //echo strtoupper(uniqid("ws".date('Y').'-',false)) ?>" readonly="readonly">
            </div>   
          </div>  -->  
          <div class="form-group ">
          	<label for="inputName" class="col-sm-3 control-label">Username:</label>
          	<div class="col-sm-8">
              <input type="text" name="username" class="form-control" id="username" placeholder="พิมพ์ Username ที่ต้องการแล้วเลือกตามรายการที่ปรากฏขึ้น" value="" readonly>
              <input type="hidden" name="user_id" class="form-control" id="user_id" placeholder="ไอดีอ้างอิง" value="" readonly>
            </div>   
          </div>
          <div class="form-group">
            <label for="inputPhone" class="col-sm-3 control-label">ชื่อเล่น:</label>
            <div class="col-sm-8">
              <input type="text" name="nickname" class="form-control" id="nickname" placeholder="ชื่อเล่น" readonly>
            </div>
          </div>
          
          <div class="form-group for-transfer" style="display:none;">
            <div class="col-sm-12 text-center"><h1>ไปสินค้า</h1></div>
          </div>
          <div class="form-group for-transfer" style="display:none;">
            <label for="inputDealer" class="col-sm-3 control-label">ตัวเกมส์สินค้า:</label>
            <div class="col-sm-8">
              <input type = "radio" name = "ws_dealer_target"  id = "ws_dealer_target" class="ws_dealer_target" value = "918kiss" />
              <label for="web918kiss">918kiss</label>
              <input type = "radio" name = "ws_dealer_target"  id = "ws_dealer_target" class="ws_dealer_target" value = "Slotxo" />
              <label for="webSlotxo">Slotxo</label>
            </div>
          </div>           
          <div class="form-group for-transfer" style="display:none;">
          	<label for="inputName" class="col-sm-3 control-label">Username:</label>
          	<div class="col-sm-8">
              <input type="text" name="username_target" class="form-control" id="username_target" placeholder="พิมพ์ Username ที่ต้องการแล้วเลือกตามรายการที่ปรากฏขึ้น" value="" readonly>
              <input type="hidden" name="user_id_target" class="form-control" id="user_id_target" value="" readonly>
            </div>   
          </div>
          <div class="form-group for-transfer" style="display:none;">
            <label for="inputPhone" class="col-sm-3 control-label">ชื่อเล่น:</label>
            <div class="col-sm-8">
              <input type="text" name="nickname_target" class="form-control" id="nickname_target" placeholder="ชื่อเล่น" readonly>
            </div>
          </div>
          <hr class="hr-black for-transfer" style="display:none;">
          
          <div class="form-group">
            <label for="inputAccountname" class="col-sm-3 control-label">ชื่อบัญชี:</label>
            <div class="col-sm-8">
              <input type="text" name="accountname" class="form-control" id="accountname" placeholder="ชื่อบัญชี" readonly>
            </div>
          </div>
          <div class="form-group">
            <label for="inputBankno" class="col-sm-3 control-label">เลขบัญชี:</label>
            <div class="col-sm-8">
              <input type="text" name="bankno" class="form-control" id="bankno" placeholder="เลขบัญชี" readonly>
            </div>
          </div>
          <div class="form-group">
            <label for="inputPhone" class="col-sm-3 control-label">ธนาคาร:</label>
            <div class="col-sm-8">
              <input type="text" name="bank" class="form-control" id="bank" placeholder="ธนาคาร" readonly>
            </div>
          </div>
          <div class="form-group">
            <label for="inputWithdrawcode" class="col-sm-3 control-label">รหัสถอน:</label>
            <div class="col-sm-8">
              <input type="text" name="withdrawcode" class="form-control" id="withdrawcode" placeholder="รหัสถอน" readonly>
            </div>
          </div> 
          <div class="form-group">
            <label for="inputC_comment" class="col-sm-3 control-label">Call Comment:</label>
            <div class="col-sm-8">
              <textarea class="form-control" name="c_comment" id="c_comment" rows="2" placeholder="ข้อความ Callcenter" ></textarea>
            </div>
          </div>
                    
          <hr class="hr-black">
          <div class="form-group">
            <label for="Ws_Credit" class="col-sm-3 control-label">ยอด ฝาก / ถอน :</label>
            <div class="col-sm-8">
              <input name="ws_credit" type="text" class="form-control" id="ws_credit" placeholder="จำนวนยอด" required>
            </div>
          </div>
          <!--<div class="form-group form-group-lg for-deposit" style="display:none;">
            <label for="Ws_Pro" class="col-sm-3 control-label">ยอด โปรโมชั่น:</label>
            <div class="col-sm-8">
              <input name="ws_pro" type="text" class="form-control" id="ws_pro" placeholder="จำนวนยอดโปรโมชั่น" required onfocus="this.select();" value="0">
            </div>
          </div>
          <div class="form-group form-group-lg">
            <label for="Ws_Total" class="col-sm-3 control-label">ยอด ทำรายการ:</label>
            <div class="col-sm-8">
              <input name="ws_total" type="text" class="form-control" id="ws_total" placeholder="จำนวนยอดทำรายการ" readonly="readonly">
            </div>
          </div>-->   
          <div class="form-group for-deposit" style="display:none;">
            <label for="inputPhone" class="col-sm-3 control-label">ฝาก เข้าบัญชี:</label>
            <div class="col-sm-8">
                <select name="ws_bankac" id="ws_bankac" class="form-control" >
                    <option value="">== เลือก ==</option>
                    <option disabled="disabled">-----------------------------------------------------------------------------</option>
                    <?php foreach($rs_userpass->result() as $row_userpass){ ?>
                    <option value="<?php echo $row_userpass->type ?>|<?php echo $row_userpass->username ?>|<?php echo $row_userpass->acnum ?>|<?php echo $row_userpass->bankname ?>">[<?php echo strtoupper($row_userpass->type) ?>] <?php echo $row_userpass->bankname ?></option>
                    <option disabled="disabled">-----------------------------------------------------------------------------</option>
                    <?php } ?>
                </select>
            </div>
          </div>
          <div class="form-group">
            <label for="inputPhone" class="col-sm-3 control-label">ฝาก / ถอน วันที่:</label>
            <div class="col-sm-8">
                <div class="input-group date date-ws" data-date="" data-link-field="ws_date" data-date-format="yyyy-mm-dd hh:ii"  data-link-format="yyyy-mm-dd hh:ii">
                <input class="form-control" size="16" type="text" value="" readonly required="required">
                <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                </div>
                <input type="hidden" id="ws_date" name="ws_date" value=""/>
            </div>
          </div>
          <div class="form-group for-deposit" style="display:none;">
            <label for="inputPromotion" class="col-sm-3 control-label">โปรโมชั่น:</label>
            <div class="col-sm-8">
                <select name="promotion_id" id="promotion_id" class="form-control" >
                    <option value="">== ไม่ใช้โปรโมชั่น ==</option>
                    <?php if($rs_promotion->num_rows()>0){ ?>
                    <?php foreach($rs_promotion->result() as $row_promotion){ ?>
                    	<option value="<?php echo $row_promotion->pr_id ?>"><?php echo $row_promotion->title ?></option>
                    <?php } ?>
                    <?php } ?>
                </select>
            </div>
          </div>
          <div class="form-group for-deposit" style="display:none;">
            <label for="image" class="col-sm-3 control-label">ไฟล์รูปประกอบ:</label>
            <div class="col-sm-8 col-md-8">
                <input type="file"  id="image_upload_deposit" name="image_upload_deposit"/>
                <div id="image_queue_deposit" class="queue"></div>
                <!--<img id="example-image" />-->
                <input type="hidden" id="ws_deimg" name="ws_deimg" value="" />
            </div>
          </div>
          <center><small><font color="#FF0000">*** บัญชีที่โอนเงินเข้ามาต้องเป็นบัญชีที่ลงทะเบียนเท่านั้น ถ้าไม่ใช่บัญชีที่ลงทะเบียนทางเราขอยึดยอด นะค่ะ ***</font></small></center>
          <center><small><font color="#FF0000">** ขณะอัพโหลด รอให้ขึ้น สถานะ Completed และห้ามทำการ Refresh หน้าเว็บ **</font></small></center>          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-success" id="submit-create-worksheet" >Create</button>
          <input type="hidden" name = "method"  id = "method" value = "createWorksheet" />
        </div>
      </form>
    </div>
  </div>
</div>
<!-- END Create Modals -->
<!-- Auto Image Modals -->
<div class="modal fade" id="AutoImageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<div class="Autoimagepreview" style="width: 100%;" >
		</div>
      </div>
    </div>
  </div>
</div>
<!-- END Auto Image Modals -->
<!-- View Worksheet Modals -->
<div class="modal fade" id="worksheet-view-modal" tabindex="-1" role="dialog" aria-labelledby="WorksheetView" aria-hidden="false" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content" id="modal-content">
      <form class="form-horizontal" id="form-worksheet-view" action="" method="POST" role="form">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">รายละเอียดใบงาน</h4>
        </div>
        <div class="modal-body">
        </div>
        <!--<div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
        </div>-->
      </form>
    </div>
  </div>
</div>
<!-- END View Worksheet Modals -->
<!-- Image Modals -->
<div class="modal fade" id="ImageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <img src="" class="imagepreview" style="width: 100%;" >
      </div>
    </div>
  </div>
</div>
<!-- END Image Modals -->
<!-- Add Wiimg Modals -->
<div class="modal fade" id="add-wiimg-modal" tabindex="-1" role="dialog" aria-labelledby="AddWiImageModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content"> 
      <form class="form-horizontal" id="form-add-wiimg" action="<?php echo site_url('worksheet/add-wiimg') ?>" method="POST" role="form">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">เพิ่มรูปสลิปโอนเงินให้สมาชิก</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label for="image" class="col-sm-3 control-label">ไฟล์รูป:</label>
                <div class="col-sm-8 col-md-8">
                    <input type="file"  id="image_upload_withdraw" name="image_upload_withdraw"/>
                    <div id="image_queue_withdraw" class="queue"></div>
                    <!--<img id="example-image" />-->
                    <input type="hidden" id="ws_wiimg" name="ws_wiimg" value="" /> 
                    <input type="hidden" id="username" name="username" value="" />    
                    <input type="hidden" id="ws_id" name="ws_id" value="" />        
                </div>
            </div>
        </div>
     </form>
    </div>
  </div>
</div>
<!-- END Add Wiimg Modals -->
<!-- Initialize Form Validation -->
<script src="<?php echo base_url('assets/plugins/formValidation/FormsCreateWorksheetValidation.js') ?>"></script>
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
		$('#create').attr("disabled", false);	
		$.fn.modal.Constructor.prototype.enforceFocus = function(){};
		var app_url = '<?php echo site_url() ?>';
		var t = $('#datatables').DataTable({
			"bPaginate": true, 
			//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
			//"bFilter": false, //+ ช่องค้นหา
			//"bInfo": false, //+ รายละเอียดจำนวนแถว
			"bProcessing": true,
			"bServerSide": true,
			"sServerMethod": "GET",
			"sAjaxSource": app_url+'worksheet/call-all<?php echo ($show_ws_type)?'/'.$show_ws_type:''?>',
			"iDisplayLength": 30,
			"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
				{"searchable": true, "orderable": false, "targets":0,'className':'text-center text-vertical'},
				{"searchable": false, "orderable": true, "targets":1,'className':'text-center text-vertical'},
				{"visible": false,"searchable": false, "orderable": false, "targets":13},			
				{"targets":[2,3,4,5,6,7,8,9,10,11],'className':'text-center text-vertical'},
				{"searchable": false, "orderable": false, "targets":7,'className':'text-center text-vertical',
					"render": function(data, type, row) { // Available data available for you within the row	
						var img = '';
						if(data!=null){
							//img += '<a class="pop" data-img="'+base_url+'images/worksheet/'+data+'"><span class="oi oi-image"></span></a>';
							img += '<a class="pop" data-img="'+data+'"><span class="mdi mdi-image"></span></a>';
						}
						return img;
					}	
				},
				{"searchable": false, "orderable": false, "targets":12,'className':'text-center text-vertical',
					"render": function(data, type, row) { // Available data available for you within the row
						var button = data;
						if(data==0&&data!=''){
							button = '&nbsp;';
							//button = '<a data-wsid="'+row[14]+'" class="btn btn-xs btn-default notify"><span class="mdi mdi-cellphone-iphone"></span></a>';
						}
						if(row[1]=='ถอน'){
							button += '&nbsp;&nbsp;<a data-toggle="modal" data-target="#add-wiimg-modal" data-wsid="'+row[14]+'" data-username="'+row[4]+'" class="btn btn-xs btn-default add-wiimg"><i class="fa fa-plus"></i><i class="fa fa-image"></i></a>';
						}
						return button;
					}	
				},
				{"searchable": false, "orderable": false, "targets":14,'className':'text-center text-vertical',
					"render": function(data, type, row) { // Available data available for you within the row	
						var button = '<a data-toggle="modal" data-target="#worksheet-view-modal" data-wsid="'+data+'" class="btn btn-xs btn-default"><span class="ti-search"></span></a>';					
						return button;
					}	
				}
			],
			"order": [9, 'desc'], //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
			"createdRow": function ( row, data, index ) {		
				var bg;
				switch (data[1]) {
					case 'ฝาก':
						bg = "deposit-bg";
						break;
					case 'ถอน':
						bg = "withdraw-bg";
						break;
					case 'โยก':
						bg = "transfer-bg";
						break;
				}			
				$(row).addClass(bg);
			}
		});
		$('#createWorksheet').on('hidden.bs.modal', function () {
			document.getElementById('form-create-worksheet').reset();
			$('#username').attr('readonly',true);
			$('.for-deposit').hide();
			//window.location.reload();
		});
		$('.date-ws').datetimepicker({
			language:'th',
			weekStart: 1,
			todayBtn:  1,
			autoclose: 1,
			todayHighlight: 1,
			startView: 2,
			forceParse: 0,
			minuteStep:1,
			zIndex:9999,
			pickerPosition:'top-left',
			startDate:"<?php echo date("Y-m-d H:i", strtotime("-2 days")) ?>",
			endDate: "<?php echo date('Y-m-d H:i') ?>"
		});
		$('.ws_type').change(function(){
			$('#ws_credit,#ws_total').val('');
			//$('#ws_pro').val('0');
			if($(this).val()=='deposit'){
				$('.for-'+$(this).val()).show();
				$('.for-transfer').hide();
			}else if($(this).val()=='transfer'){
				$('.for-'+$(this).val()).show();
				$('.for-deposit').hide();
			}else{
				$('.for-transfer').hide();
				$('.for-deposit').hide();
			}
		});
		$('.site_id, .ws_dealer').change(function(){
			if ($('.site_id').val() != '' && $('.ws_dealer').val() != '') {
				//?site_id='+$('.site_id').val()+'&dealer='+$('.ws_dealer').val()
				var $url = app_url+'json/search-user-by-username-json';
				console.log($('#username').val());
				$('#username').val('').attr('readonly',false);
				$("#user_id,#nickname,#accountname,#phone,#bankno,#bank,#withdrawcode").val('');
				var options_user = {
						url: $url,
						getValue: "username",
						template: {
							type: "description",
							fields: {
								description: "detail"
							}
						},
						list: {
							onClickEvent: function(){
								var user_id = $("#username").getSelectedItemData().user_id; 
								var nickname = $("#username").getSelectedItemData().nickname; 
								var accountname = $("#username").getSelectedItemData().accountname; 
								var bankno = $("#username").getSelectedItemData().bankno; 
								var bank = $("#username").getSelectedItemData().bank; 
								var withdrawcode = $("#username").getSelectedItemData().withdrawcode;										
								$.LoadingOverlay("show");
								$.ajax({
									cache: false,
									type: 'POST',
									url: '<?php echo site_url('worksheet/get-worksheet-remain') ?>',
									data: {'user_id':$("#username").getSelectedItemData().user_id},
									success: function(data){
										if(data==1){
											$.LoadingOverlay("hide");
											swal({title:'User นี้มีใบงาน ค้างอยู่ในระบบ',confirmButtonText: 'OK'},function(){
												$("#username,#user_id,#nickname,#accountname,#phone,#bankno,#bank,#withdrawcode").val('');
											});
										}else{
											$("#user_id").val(user_id).trigger("change");
											$("#nickname").val(nickname).trigger("change");
											$("#accountname").val(accountname).trigger("change");
											$("#bankno").val(bankno).trigger("change");
											$("#bank").val(bank).trigger("change");
											$("#withdrawcode").val(withdrawcode).trigger("change");
											$.ajax({
												url: '<?php echo site_url('json/get-deposit-bank-by-site-id-json?site_id=') ?>'+$('.site_id').val(),
												type: 'GET',
												dataType: 'json',
												success:function(response){
													var len = response.length;
													$("#ws_bankac").empty();
													$("#ws_bankac").append('<option value="">== เลือก ==</option>');
													for( var i = 0; i<len; i++){
														var s_b_type = response[i]['type'];
														var s_b_username = response[i]['username'];
														var s_b_acnum = response[i]['acnum'];
														var s_b_bankname = response[i]['bankname'];
														var s_b_balance = response[i]['balance'];
														$("#ws_bankac").append('<option disabled="disabled">-----------------------------------------------------------------------------</option>');
														var s_b_option =  '<option value="'+s_b_type+'|'+s_b_username+'|'+s_b_acnum+'|'+s_b_bankname+'">['+s_b_type.toUpperCase()+'] '+s_b_bankname+'</option>';
														$("#ws_bankac").append(s_b_option);
													}
													$("#ws_bankac").append('<option disabled="disabled">-----------------------------------------------------------------------------</option>');
													$.LoadingOverlay("hide");
												}
											});
										}
									}
								});
							},
							match: {
							enabled: true
							}
						},
						theme: "plate-dark",
						requestDelay: 400,
						ajaxSettings: {
							dataType: "json",
							method: "GET",
							data: {
								dataType: "json",
								site_id: $('.site_id').val(),
								dealer: $('.ws_dealer').val(),
								username: $('#username').val(),
							}
						},
						preparePostData: function(data) {
							data.site_id= $('.site_id').val();
							data.dealer= $('.ws_dealer').val();
							data.username= $('#username').val();
							return data;
						},
						requestDelay: 400
					};	
				$("#username").easyAutocomplete(options_user);
			} else {
				$('#username').val('').attr('readonly',true);
			}
		});
		$('#username').on('change blur', function(e) {
			if($(this).val()==''){
				$("#user_id,#nickname,#accountname,#phone,#bankno,#bank,#withdrawcode").val('');
			}
		});	
		$('.ws_dealer_target').change(function(){
		if($('#user_id').val()!=''){
			var $url = app_url+'json/get-user-target-json?dealer='+$(this).val()+'&user_id='+$('#user_id').val();
			$('#username_target').val('').attr('readonly',false);
			var options_user_target = {
					url: $url,
					getValue: "username",
					template: {
						type: "description",
						fields: {
							description: "detail"
						}
					},
					list: {
						onClickEvent: function(){
							var user_id = $("#username_target").getSelectedItemData().user_id; 
							var nickname = $("#username_target").getSelectedItemData().nickname; 
							//alert($('#accountname').val());	//alert($("#username_target").getSelectedItemData().accountname);	
							if($('#accountname').val()==$("#username_target").getSelectedItemData().accountname&&$('#bankno').val()==$("#username_target").getSelectedItemData().bankno){
								$("#user_id_target").val(user_id).trigger("change");
								$("#nickname_target").val(nickname).trigger("change");
							}else{
								swal({title:'ชื่อและเลขบัญชี ไม่ตรงกัน !',confirmButtonText: 'OK'},function(){$('.ws_dealer_target').prop('checked',false);$("#user_id_target,#nickname_target").val('');$('#username_target').val('').attr('readonly',true);});
							}											
						},
						match: {
						enabled: true
						}
					},
					theme: "plate-dark"
				};	
			$("#username_target").easyAutocomplete(options_user_target);
		}else{
			swal({title:'เลือก User ต้นทางก่อน!',confirmButtonText: 'OK'},function(){$('.ws_dealer_target').prop('checked',false)});
		}
		});
		$('#username_target').on('change blur', function(e) {
			if($(this).val()==''){
				$("#user_id_target,#nickname_target").val('');
			}
		});
		$("#ws_credit").on("input", function(evt) {
		var self = $(this);
		self.val(self.val().replace(/[^0-9\.]/g, ''));
		});
		/*$("#ws_pro").on("input", function(evt) {
		var self = $(this);
		self.val(self.val().replace(/[^0-9\.]/g, ''));
		});
		$("#ws_credit").on("keyup keypress keydown", function(evt) {
			$('#ws_pro').val('0');
			if($(this).val()!=''){
				$('#ws_total').val($(this).val());
			}
		});
		$("#ws_pro").on("keyup keypress keydown", function(evt) {		
			var credit = parseFloat($("#ws_credit").val());
			var total;
			if(isNaN(credit)){
				swal({title:'กรอก ยอด ฝาก / ถอน / โอน ก่อน!',confirmButtonText: 'OK'});			
			}else{
				if($(this).val()!=''){
					var pro = parseFloat($(this).val());
					total = credit+pro;
					$('#ws_total').val(total.toFixed(2));
				}else{
					$('#ws_total').val($("#ws_credit").val());
				}
			}
		});*/
		$('#submit-create-worksheet').click(function(){
			FormsValidation.init();
			var validator = $("#form-create-worksheet").validate();
			if(validator.form()){
				swal({
						title: "ยืนยัน สร้างใบงาน ?",
						type: "warning",
						showCancelButton: true,
						cancelButtonText: "ยกเลิก",
						confirmButtonText: "ยืนยัน",
						closeOnConfirm: false
				},function(){
					//if($('.ws_type').filter(':checked').val()==='deposit'&&$('#ws_deimg').val()===''){
						//swal({title:'เลือกไฟล์รูปประกอบ',confirmButtonText: 'OK' })
					//}else{
						$.LoadingOverlay("show");
						$.ajax({
							type: 'POST',
							//dataType: 'json',
							cache: false,
							url: '<?php echo site_url('worksheet/create') ?>',
							data: $("#form-create-worksheet").serialize(),
							success: function(resp){
								$.LoadingOverlay("hide");
								swal({title:resp,confirmButtonText: 'OK'},function(){window.location.reload();});
							}
						});
					//}				
				});
			}
		});
		$('#worksheet-view-modal').on('show.bs.modal', function (e){
			$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('worksheet/view')?>?wsid='+$(e.relatedTarget).attr('data-wsid'));
		});		
		$('#add-wiimg-modal').on('show.bs.modal', function (e){
			$(this).find('#ws_id').val($(e.relatedTarget).attr('data-wsid'));
			$(this).find('#username').val($(e.relatedTarget).attr('data-username'));
		});
		setInterval(function(){ $('#datatables').DataTable().ajax.reload(null, false);}, 45000);
		$('#datatables tbody').on('click', 'td > a.pop', function (e) {
		$('.imagepreview').attr('src', $(this).attr('data-img'));
		$('#ImageModal').modal('show'); 
		return false;
		});
		$("#ImageModal").easydrag();	
		$('#datatables tbody').on('click', 'td > a.notify', function (e) {
			var ws_id = $(this).attr('data-wsid');
			swal({
			title: "ยืนยัน ว่าได้ทำการแจ้งลูกค้า ?",
			type: "warning",
			showCancelButton: true,
			cancelButtonText: "ยกเลิก",
			confirmButtonText: "ยืนยัน",
			closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					dataType: 'json',
					cache: false,
					url: '<?php echo site_url('worksheet/call-notify-confirm') ?>',
					//data: $form.serialize(),
					data: {'ws_id':ws_id},
					success: function(resp){
						$.LoadingOverlay("hide");							
						if(resp.error==1){
							swal({title:'ไม่สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){window.location.reload();});
						}else{
							swal({title:'สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){window.location.reload();});
						}							
					}
				});				
			});		
			return false;
		});
	});
</script>
<link href="<?php echo base_url('assets/plugins/uploadifive/uploadifive.css') ?>" type="text/css" media="screen" rel="stylesheet"/>
<script src="<?php echo base_url('assets/plugins/uploadifive/jquery.uploadifive.min.js') ?>" type="text/javascript"></script>
<script type="text/javascript">
	$(function(){
		var app_url = '<?php echo site_url(); ?>';
		$('#image_upload_deposit').uploadifive({
			'auto' : true,
			'buttonText':'เลือกไฟล์ (JPG | PNG) และ ขนาดไม่เกิน 2 Mb.',
			'fileType' : new Array("image"),
			'removeCompleted' : false,
			'multi' : false,
			//'formData':{'image_old':''},
			'fileObjName':'depositfile',
			'fileSizeLimit' : 2048,
			'width' :300,
			'queueID' : 'image_queue_deposit',
			'uploadScript' : '<?php echo base_url('worksheet/upload-deposit-img') ?>',
			'onUploadComplete' : function(file, data){
				var d = new Date();
				var obj = $.parseJSON(data);
				//alert('The file ' + obj.name + ' Success ');
				//$('#example-image').attr('src', base_url+'images/'+obj.name+'?d='+d.getTime());
				$('#ws_deimg').val(obj.name);
			}
		});
		$('#image_upload_withdraw').uploadifive({
			'auto' : true,
			'buttonText':'เลือกไฟล์ (JPG | PNG) และ ขนาดไม่เกิน 2 Mb.',
			'fileType' : new Array("image"),
			'removeCompleted' : false,
			'multi' : false,
			//'formData':{'image_old':''},
			'fileObjName':'withdrawfile',
			'fileSizeLimit' : 2048,
			'width' :300,
			'queueID' : 'image_queue_withdraw',
			'uploadScript' : '<?php echo base_url('worksheet/upload-withdraw-img') ?>',
			'onUploadComplete' : function(file, data){
				var d = new Date();
				var obj = $.parseJSON(data);
				//alert('The file ' + obj.name + ' Success ');
				//$('#example-image').attr('src', base_url+'images/'+obj.name+'?d='+d.getTime());
				$('#ws_wiimg').val(obj.name); //return false;
				$('#form-add-wiimg').submit();
			}
		});
	});
</script>