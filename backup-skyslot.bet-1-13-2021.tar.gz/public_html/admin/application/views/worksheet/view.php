<?php $row_worksheet = $rs_worksheet->row(); ?>
<div class="form-group ">
  <label for="inputCode" class="col-sm-3 control-label">เลขที่บิล:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_code" class="form-control" id="ws_code" placeholder="เลขที่บิล" value="<?php echo $row_worksheet->ws_code ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputDealer" class="col-sm-3 control-label">เว็บไซต์:</label>
  <div class="col-sm-8">
  	<input type="hidden" name="site_id" class="form-control" id="site_id" value="<?php echo $row_worksheet->site_id ?>" readonly>
    <input type="text" name="site_name" class="form-control" id="site_name" value="<?php echo $row_worksheet->site_name ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputDealer" class="col-sm-3 control-label">ตัวเกมส์สินค้า:</label>
  <div class="col-sm-4">
    <input type="text" name="dealer" class="form-control" id="dealer" value="<?php echo $row_worksheet->ws_dealer ?>" readonly>
  </div>
  <div class="col-sm-4">
    <input type="text" name="type" class="form-control" id="type" value="<?php echo conv_ws_type($row_worksheet->ws_type) ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputName" class="col-sm-3 control-label">Username:</label>
  <div class="col-sm-8">
    <input type="text" name="username" class="form-control" id="username" value="<?php echo $row_worksheet->u1username ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อเล่น:</label>
  <div class="col-sm-8">
    <input type="text" name="nickname" class="form-control" id="nickname" value="<?php echo $row_worksheet->u1nickname ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อบัญชี:</label>
  <div class="col-sm-8">
    <input type="text" name="accountname" class="form-control" id="accountname" value="<?php echo $row_worksheet->accountname ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputBankno" class="col-sm-3 control-label">เลขบัญชี:</label>
  <div class="col-sm-8">
    <input type="text" name="bankno" class="form-control" id="bankno" value="<?php echo $row_worksheet->bankno ?>" readonly>
  </div>
</div>
<?php if($row_worksheet->ws_type=='transfer'){ ?>
<div class="form-group">
  <label for="inputDealer" class="col-sm-3 control-label"><span style="font-size:12px;">ตัวเกมส์สินค้าที่โยกให้:</span></label>
  <div class="col-sm-8">
    <input type="text" name="ws_dealer_target" class="form-control" id="ws_dealer_target" value="<?php echo $row_worksheet->ws_dealer_target ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputName" class="col-sm-3 control-label"><span style="font-size:12px;">Username ที่โยกให้:</span></label>
  <div class="col-sm-8">
    <input type="text" name="username_target" class="form-control" id="username_target" value="<?php echo $row_worksheet->u2username ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label"><span style="font-size:12px;">ชื่อเล่น ที่โยกให้:</span></label>
  <div class="col-sm-8">
    <input type="text" name="nickname_target" class="form-control" id="nickname_target" value="<?php echo $row_worksheet->u2nickname ?>" readonly>
  </div>
</div>
<?php } ?>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">แจ้ง วันที่:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_date" class="form-control" id="ws_date" value="<?php echo date('d / m / Y H:i:s',strtotime($row_worksheet->ws_date)) ?>" readonly>
  </div>
</div>
<?php if($row_worksheet->ws_type=='deposit'){ ?>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">เข้าธนาคาร:</label>
  <div class="col-sm-4">
    <input type="text" name="ws_debank" class="form-control" id="ws_debank" value="<?php echo strtoupper($row_worksheet->ws_debank) ?>" readonly>
  </div>
  <div class="col-sm-4">
    <input type="text" name="ws_debankac" class="form-control" id="ws_debankac" value="<?php echo $row_worksheet->ws_debankname ?>" readonly>
  </div>
</div>
<?php } ?>
<div class="form-group">
  <label for="Ws_Credit" class="col-sm-3 control-label">จำนวน:</label>
  <div class="col-sm-8">
    <input name="credit" type="text" class="form-control" id="credit" value="<?php echo number_format($row_worksheet->ws_credit,2); ?>" readonly>
  </div>
</div>
<?php if($row_worksheet->ws_type=='deposit'){ ?>
<div class="form-group">
  <label for="Ws_Pro" class="col-sm-3 control-label">ยอด โปร:</label>
  <div class="col-sm-8">
    <input name="ws_pro" type="text" class="form-control" id="ws_pro" value="<?php echo number_format($row_worksheet->ws_pro,2); ?>" readonly>
  </div>
</div>
<?php } ?>
<div class="form-group">
  <label for="Ws_Total" class="col-sm-3 control-label">ยอด ทำรายการ:</label>
  <div class="col-sm-8">
    <input name="ws_total" type="text" class="form-control" id="ws_total" value="<?php echo number_format($row_worksheet->ws_total,2); ?>" readonly>
  </div>
</div>
<?php if($row_worksheet->ws_type=='deposit'){ ?>
<div class="form-group">
  <label for="Promotion" class="col-sm-3 control-label">โปรโมชั่น:</label>
  <div class="col-sm-8">
    <input name="promotion" type="text" class="form-control" id="promotion" value="<?php echo $row_worksheet->title ?>" readonly>
  </div>
</div>
<?php } ?>
<?php if($row_worksheet->ws_type=='deposit'){ ?>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">ไฟล์สลิปฝากเงิน:</label>
  <div class="col-sm-8 col-md-8">
  	<a class="pop" data-img="<?php echo $row_worksheet->ws_deimg ?>">
  		<span class="mdi mdi-file-image" style="padding-top:10px;"></span>
  	</a> 
  </div>
</div>
<?php } ?>
<?php if($row_worksheet->free=='y'){ ?>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">ไฟล์แชร์ 1:</label>
  <div class="col-sm-8 col-md-8">
  	<a class="pop" data-img="<?php echo $row_worksheet->free_img ?>">
  		<span class="mdi mdi-file-image" style="padding-top:10px;"></span>
  	</a> 
  </div>
</div>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">ไฟล์แชร์ 2:</label>
  <div class="col-sm-8 col-md-8">
  	<a class="pop" data-img="<?php echo $row_worksheet->free_img1 ?>">
  		<span class="mdi mdi-file-image" style="padding-top:10px;"></span>
  	</a> 
  </div>
</div>
<?php } ?>
<div class="form-group">
  <label for="created" class="col-sm-3 control-label">Call เปิดใบงาน:</label>
  <div class="col-sm-8">
    <input name="created" type="text" class="form-control" id="created" value="<?php echo date('d / m / Y H:i:s',strtotime($row_worksheet->created)) ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputC_comment" class="col-sm-3 control-label">Call Comment:</label>
  <div class="col-sm-8">
  <textarea class="form-control" name="c_comment" rows="2" readonly><?php echo $row_worksheet->c_comment ?></textarea>
  </div>
</div>
<?php 
//$b_status = ($row_worksheet->m_status==2)?conv_ws_status($row_worksheet->m_status):conv_ws_status($row_worksheet->b_status);
//$m_status = ($row_worksheet->b_status==2)?conv_ws_status($row_worksheet->b_status):conv_ws_status($row_worksheet->m_status);
$b_status = conv_ws_status($row_worksheet->b_status);
$m_status = conv_ws_status($row_worksheet->m_status);
?>
<?php if($row_worksheet->ws_type=='deposit'){ ?>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">รายการดึงจาก แบงค์:</label>
  <div class="col-sm-8 col-md-8">
    <table class="table table-striped table-bordered table-hover" id="table-list-statement" width="100%" style="font-size:11px;">
      <thead>
        <tr role="row">	
          <th class="text-center" width="25%">วันที่</th>
          <th class="text-center" width="10%">ฝาก</th>                      
          <th class="text-center">หมายเหตุ</th>
        </tr>
      </thead>
        <tbody>
        	<tr>
            	<td class="text-center"><?php echo $row_worksheet->st_datein ?></td>
                <td class=" text-center"><?php echo $row_worksheet->st_in ?></td>
                <td class=" text-center"><?php echo $row_worksheet->st_comment ?></td>
            </tr>
        </tbody>
    </table>
  </div>
</div>
<?php } ?>
<?php if($row_worksheet->ws_type!='transfer'){ ?>
<div class="form-group">
  <label for="b_date" class="col-sm-3 control-label">Bank status:</label>
  <div class="col-sm-8"><?php echo $b_status; ?>
  <?php if($row_worksheet->ws_type=='withdraw' && ($row_worksheet->b_status==3||$row_worksheet->b_status==5||$row_worksheet->b_status==4)){ 
			$present_time = strtotime(date('Y-m-d H:i:s'));
			$can_revert_time = strtotime("+5 minute",strtotime($row_worksheet->modified));  
			if($row_worksheet->b_status!=4||($row_worksheet->b_status==4 && $present_time>$can_revert_time)) {
	  ?>
	<button class="btn btn-xs btn-warning" type="button" id="worksheet-withdraw-revert">ย้อนสถานะกลับไปรอตรวจ</button>
	<?php //echo $row_worksheet->modified. ':'. date("Y-m-d H:i:s", strtotime("+5 minute",strtotime($row_worksheet->modified))); ?>	
  <?php 	}
  		} ?>
</div>
</div>
<?php if($row_worksheet->ws_type=='withdraw' && $row_worksheet->b_status==1){ ?>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">โอนโดยธนาคาร:</label>
  <div class="col-sm-8 col-md-8">
  	<input name="b_name" type="text" class="form-control" id="b_name" value="<?php echo conv_bankname($row_worksheet->ws_wibank).' [ '.$row_worksheet->ws_wibankname.' ] ' ?>" readonly>
  </div>
</div>
<?php } ?>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">Bank:</label>
  <div class="col-sm-8 col-md-8">
  	<input name="b_name" type="text" class="form-control" id="b_name" value="<?php echo $row_worksheet->a2name ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="b_date" class="col-sm-3 control-label">Bank ยืนยัน:</label>
  <div class="col-sm-8">
    <input name="b_date" type="text" class="form-control" id="b_date" value="<?php echo ($row_worksheet->b_date!='')?date('d / m / Y H:i:s',strtotime($row_worksheet->b_date)):'' ?>" readonly>
  </div>
</div>
<?php } ?>
<?php if($row_worksheet->ws_type=='withdraw'&&$row_worksheet->b_status==1){ ?>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">ไฟล์สลิปถอนเงิน:</label>
  <div class="col-sm-8 col-md-8">
  	<a class="pop" data-img="<?php echo base_url('images/worksheet/'.$row_worksheet->ws_wiimg) ?>">
  		<span class="mdi mdi-file-image" style="padding-top:10px;"></span>
	</a> 
	<?php if ($row_ws_log) { ?>
	<a class="pop2" data-img="<?php echo base_url('images/worksheet/'.$row_worksheet->ws_wiimg) ?>">
  		<span class="mdi mdi-file-image" style="padding-top:10px;">AT</span>
	</a>
	<div id="htmlSlipHidden" style="display:none;"> 
	<style>
		.transaction_result_green{color:#00a651}.transaction_result_headline{font-family:KrungsriSimpleMedium,Sans-Serif;font-size:25px;text-align:center;margin-bottom:10px;margin-top:10px;clear:both}.transaction_summary_header{width:100%;margin-left:auto;margin-right:auto;background:#ffda00;overflow:hidden;font-size:16px;word-wrap:break-word;padding-top:8px}.transaction_summary_row{clear:both;overflow:auto;padding:5px 0}.transaction_summary_column_accrole{float:left;width:120px;height:17px}.transaction_summary_column_icon{float:left;width:40px;height:30px}.transaction_summary_column_accnickname,.transaction_summary_column_accnickname_accname{float:left;width:220px}.transaction_summary_body{width:100%;margin-left:auto;margin-right:auto;background:#f1f1f2;overflow:auto;font-size:13px;padding-top:5px;padding-bottom:5px;word-wrap:break-word}.transaction_summary_column_acccurrency,.transaction_summary_column_accinfo,.transaction_summary_column_accname,.transaction_summary_column_accnickname,.transaction_summary_column_accnickname_accname{text-align:center}.transaction_detail_header{width:100%;margin-left:auto;margin-right:auto;background:#d1d2d4;overflow:hidden;font-size:15px}.transaction_detail_column_icon{float:left;width:40px;height:30px;text-align:center}.transaction_detail_column_title{min-height:25px;padding:5px 0}.transaction_detail_body{width:100%;margin-left:auto;margin-right:auto;background:#f1f1f2;overflow:hidden;font-size:13px;padding-top:5px;padding-bottom:5px}.transaction_detail_row{clear:both;overflow:hidden}.transaction_detail_row_title,.transaction_detail_row_value{width:40%}.transaction_detail_row_full,.transaction_detail_row_title,.transaction_detail_row_title_long,.transaction_detail_row_title_short{float:left;margin-left:40px;padding:6px 0}.transaction_detail_row_full,.transaction_detail_row_value,.transaction_detail_row_value_long,.transaction_detail_row_value_short{float:right;margin-right:40px;padding:6px 0}.alignright{text-align:right!important}.mobile_only{display:none}
	</style>	
	<?php echo $row_ws_log->wc_html; ?>	
		
	</div>
	<?php } ?>
  </div>
</div>
<?php } ?>
<?php //if($row_worksheet->ws_type!='transfer'&&$row_worksheet->b_status==1){ ?>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">Bank Comment:</label>
  <div class="col-sm-8 col-md-8">
  	<textarea rows="2" class="form-control" readonly><?php echo $row_worksheet->b_comment ?></textarea>
  </div>
</div>
<?php //} ?>
<div class="form-group">
  <label for="b_date" class="col-sm-3 control-label">Manage status:</label>
  <div class="col-sm-8"><?php echo $m_status ?></div>
</div>
<div class="form-group">
  <label for="b_date" class="col-sm-3 control-label">Manage ยืนยัน:</label>
  <div class="col-sm-8">
    <input name="b_date" type="text" class="form-control" id="b_date" value="<?php echo ($row_worksheet->m_date!='')?date('d / m / Y H:i:s',strtotime($row_worksheet->m_date)):'' ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">Manage:</label>
  <div class="col-sm-8 col-md-8">
  	<input name="b_name" type="text" class="form-control" id="b_name" value="<?php echo $row_worksheet->a3name ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label"><span style="font-size:12px;">Manage Comment:</span></label>
  <div class="col-sm-8 col-md-8">
  	<textarea rows="2" class="form-control" readonly><?php echo $row_worksheet->m_comment ?></textarea>
  </div>
</div>
<?php if($row_worksheet->n_status==1){ ?>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">แจ้งลูกค้าแล้ว วันที่:</label>
  <div class="col-sm-8 col-md-8">
  	<input name="n_date" type="text" class="form-control" id="n_date" value="<?php echo date('d / m / Y H:i:s',strtotime($row_worksheet->n_date)) ?>" readonly />
  </div>
</div>
<?php } ?>
<script type="text/javascript">
$(function(){
	/*$(".fancybox-deposit,.fancybox-withdraw").fancybox({
        openEffect : "none",
        closeEffect : "none",
		helpers : { overlay : null },
		autoCenter: true,
    	margin: [0, 0, 0, 850], // [top, right, bottom, left]
    });*/
	$('.pop').on('click', function() {
		$('.imagepreview').attr('src', $(this).attr('data-img'));
		$('#ImageModal').modal('show');
	});
	$("#ImageModal").easydrag();
	$('#worksheet-withdraw-revert').click(function(){
		swal({
			title: "ยืนยัน ย้อนสถานะใบงาน ?",
			type: "warning",
			showCancelButton: true,
			cancelButtonText: "ยกเลิก",
			confirmButtonText: "ยืนยัน",
			closeOnConfirm: false
		},function(){
			$.LoadingOverlay("show");
			$.ajax({
				type: 'POST',
				dataType: 'json',
				cache: false,
				url: '<?php echo site_url('worksheet/revert-queue') ?>',
				data: {'wsid':<?= $row_worksheet->ws_id ?>},
				success: function(resp){
					$.LoadingOverlay("hide");							
					if(resp.error==1){
						swal({title:'ไม่สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
					}else{
						swal({title:'สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
							$('#worksheet-view-modal').modal('hide');
							window.location.reload();
						});
					}							
				}
			});	
		});
	});
});
</script>
<!--<script src="https://files.codepedia.info/files/uploads/iScripts/html2canvas.js"></script>-->
<script>
$(document).ready(function(){
	$('.pop2').on('click', function() {
		$('#AutoImageModal').modal('show');
		var htmlSlip = $("#htmlSlipHidden").html();
		$(".Autoimagepreview").html(htmlSlip);		
		// takeScreenShot();
	});
	window.takeScreenShot = function() {
		var w = 1366;
		var h = 768;
		var testcanvas = document.createElement('canvas');
		testcanvas.width = w * 2;
		testcanvas.height = h * 2;
		testcanvas.style.width = w + 'px';
		testcanvas.style.height = h + 'px';
		var context = testcanvas.getContext('2d');
		context.scale(2, 2);
		$aaa = $("#htmlSlipHidden").html();
		console.log($aaa);
		// Trying new way
		// html2canvas(document.getElementById("html-content-holder"), {
		html2canvas($("#htmlSlipHidden").html(), {
			canvas: testcanvas,
			onrendered: function(canvas) {
				console.log(canvas);
			$('#htmlSlip').appendChild(canvas);
			var img = canvas.toDataURL("image/png");
			//   download(img, "notimproved", "image/png");
			},
			// width: 320,
			// height: 220
		});
	}
});
</script>