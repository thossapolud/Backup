<?php if($rs_worksheet->num_rows()>0){ $row_worksheet = $rs_worksheet->row(); ?>
<div class="form-group text-center">
  <h4><font color="#FF0000">** ระยะเวลาในการทำรายการ 5 นาที และห้ามรีเฟรช **</font></h4>
</div>
<div class="form-group ">
  <label for="inputCode" class="col-sm-3 control-label">เลขที่บิล:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_code" class="form-control" id="ws_code" placeholder="เลขที่บิล" value="<?php echo $row_worksheet->ws_code ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputWebsite" class="col-sm-3 control-label">เว็บไซต์:</label>
  <div class="col-sm-8">
  	<input type="hidden" name="site_id" class="form-control" id="site_id" value="<?php echo $row_worksheet->site_id ?>" readonly>
    <input type="text" name="site_name" class="form-control" id="site_name" value="<?php echo $row_worksheet->site_name ?>" readonly>
  </div>
</div>
<div class="form-group">
	<div class="col-sm-12 text-center"><h1>จากสินค้า</h1></div>
</div>
<div class="form-group">
  <label for="inputDealer" class="col-sm-3 control-label">ตัวเกมส์สินค้า:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_dealer" class="form-control" id="ws_dealer" value="<?php echo $row_worksheet->ws_dealer ?>" readonly>
  </div>
  <!--<div class="col-sm-4">
    <input type="text" name="type" class="form-control" id="type" value="<?php //echo conv_ws_type($row_worksheet->ws_type) ?>" readonly="readonly">
  </div>-->
</div>
<div class="form-group">
  <label for="inputName" class="col-sm-3 control-label">Username:</label>
  <div class="col-sm-8">
    <input type="text" name="u1username" class="form-control" id="u1username" value="<?php echo $row_worksheet->u1username ?>" readonly>
    <input type="hidden" name="ws_id" class="form-control" id="ws_id" value="<?php echo $row_worksheet->ws_id ?>">
    <input type="hidden" name = "u1user_id"  id = "u1user_id" value = "<?php echo $row_worksheet->u1user_id ?>" />
    <input type="hidden" name = "u1userpass_id"  id = "u1userpass_id" value = "<?php echo $row_worksheet->u1userpass_id ?>" />
    <input type="hidden" name="ws_type" class="form-control" value="<?php echo $row_worksheet->ws_type ?>">
    <input type="hidden" name = "m_comment"  id = "m_comment" value = "" />
    <input type="hidden" name = "method"  id = "method" value = "ManageTransferConfirm" />
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อเล่น:</label>
  <div class="col-sm-8">
    <input type="text" name="u1nickname" class="form-control" id="u1nickname" value="<?php echo $row_worksheet->u1nickname ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อบัญชี:</label>
  <div class="col-sm-8">
    <input type="text" name="accountname" class="form-control" id="accountname" value="<?php echo $row_worksheet->accountname ?>" readonly>
  </div>
</div>
<!--<div class="form-group">
  <label for="inputBankno" class="col-sm-3 control-label">เลขบัญชี:</label>
  <div class="col-sm-8">
    <input type="text" name="bankno" class="form-control" id="bankno" value="<?php //echo $row_worksheet->bankno ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ธนาคาร:</label>
  <div class="col-sm-8">
    <input type="text" name="bank" class="form-control" id="bank" value="<?php //echo $row_worksheet->bank ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">รหัสถอน:</label>
  <div class="col-sm-8">
    <input type="text" name="withdrawcode" class="form-control" id="withdrawcode" value="<?php //echo $row_worksheet->withdrawcode ?>" readonly="readonly">
  </div>
</div>-->
<div class="form-group">
	<div class="col-sm-12 text-center"><h1>ไปสินค้า</h1></div>
</div>
<div class="form-group">
  <label for="inputDealer" class="col-sm-3 control-label">ตัวเกมส์สินค้า:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_dealer_target" class="form-control" id="ws_dealer_target" value="<?php echo $row_worksheet->ws_dealer_target ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputName" class="col-sm-3 control-label">Username:</label>
  <div class="col-sm-8">
    <input type="text" name="u2username" class="form-control" id="u2username" value="<?php echo $row_worksheet->u2username ?>" readonly>
    <input type="hidden" name = "u2user_id"  id = "u2user_id" value = "<?php echo $row_worksheet->u2user_id ?>" />
    <input type="hidden" name = "u2userpass_id"  id = "u2userpass_id" value = "<?php echo $row_worksheet->u2userpass_id ?>" />
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อเล่น:</label>
  <div class="col-sm-8">
    <input type="text" name="u2nickname" class="form-control" id="u2nickname" value="<?php echo $row_worksheet->u2nickname ?>" readonly>
  </div>
</div>
<hr class="hr-black" />
<div class="form-group text-center">
  <h4><font color="#FF0000">** ต้องเช็คดูรายการก่อนกดทำรายการทุกครั้ง **</font></h4>
</div>
<!--<div class="form-group form-group-lg  text-red">
<label for="Ws_Credit" class="col-sm-4 control-label"><h4>ยอดที่โยก:</h4></label>
<div class="col-sm-7">
  <input name="ws_credit" type="text" class="form-control text-red" id="ws_credit" value="<?php //echo number_format($row_worksheet->ws_credit,2) ?>" readonly="readonly">
</div>
</div>-->
<div class="form-group form-group-lg text-red">
<label for="Ws_Total" class="col-sm-4 control-label"><h4>ยอดที่ต้องทำรายการ:</h4></label>
<div class="col-sm-7">
  <input name="ws_total" type="text" class="form-control text-red" id="ws_total" value="<?php echo number_format($row_worksheet->ws_total,2) ?>" readonly>
</div>
</div>
<!--<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">แจ้งโยก วันที่:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_date" class="form-control" id="ws_date" value="<?php echo date('d / m / Y H:i:s',strtotime($row_worksheet->ws_date)) ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="Ws_Credit" class="col-sm-3 control-label">จำนวนโยก:</label>
  <div class="col-sm-8">
    <input name="credit" type="text" class="form-control" id="credit" value="<?php echo $row_worksheet->ws_credit ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="created" class="col-sm-3 control-label">Call เปิดใบงาน:</label>
  <div class="col-sm-8">
    <input name="created" type="text" class="form-control" id="created" value="<?php echo date('d / m / Y H:i:s',strtotime($row_worksheet->created)) ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="inputC_comment" class="col-sm-3 control-label">Call Comment:</label>
  <div class="col-sm-8">
  <textarea class="form-control" name="c_comment" rows="2" readonly="readonly"><?php echo $row_worksheet->c_comment ?></textarea>
  </div>
</div>-->
<div class="modal-footer">
  <!--<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
  <button type="button" class="btn btn-danger" id="worksheet-transfer-cancel" >ยกเลิกใบงาน</button>-->
  <button type="button" class="btn btn-default" id="worksheet-leave">ปล่อยใบงาน</button>
  <button type="button" class="btn btn-success" id="worksheet-transfer-confirm" >ยืนยันการตรวจสอบ</button>
</div>
<script type="text/javascript">
$(function(){
	$('#worksheet-leave').click(function(){
		var $form = $('#form-worksheet-transfer');
		if($form.find('#ws_id').length>0){
			swal({
			  title: "ยืนยัน ปล่อยใบงาน ?",
			  type: "warning",
			  showCancelButton: true,
			  cancelButtonText: "ยกเลิก",
			  confirmButtonText: "ยืนยัน",
			  closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					dataType: 'json',
					cache: false,
					url: '<?php echo site_url('worksheet/manage-leave') ?>',
					data: $form.serialize(),
					success: function(resp){
						$.LoadingOverlay("hide");							
						if(resp.error==1){
							swal({title:'ไม่สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
						}else{
							swal({title:'สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
								$('#worksheet-deposit-modal,#worksheet-withdraw-modal,#worksheet-transfer-modal').modal('hide');
								window.location.reload();
							});
						}							
					}
				});				
			});
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
	$('#worksheet-transfer-confirm').click(function(){
		var $form = $('#form-worksheet-transfer');
		if($form.find('#ws_id').length>0){
			swal({
			  title: "ยืนยัน ตรวจสอบใบงาน โยก ?",
			  type: "warning",
			  showCancelButton: true,
			  cancelButtonText: "ยกเลิก",
			  confirmButtonText: "ยืนยัน",
			  closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					dataType: 'json',
					cache: false,
					url: '<?php echo site_url('worksheet/manage-transfer-confirm') ?>',
					data: $form.serialize(),
					success: function(resp){
						$.LoadingOverlay("hide");							
						if(resp.error==1){
							swal({title:'ไม่สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
						}else{
							swal({title:'สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
								$('#worksheet-deposit-modal,#worksheet-withdraw-modal,#worksheet-transfer-modal').modal('hide');
								window.location.reload();
							});
						}							
					}
				});				
			});
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
});
</script>
<?php }else{ ?>
<center>
  <small><font color="#FF0000">** ใบงานอาจถูกปรับสถานะไปแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบอีกรอบ **</font></small>
</center>
<?php } ?>
