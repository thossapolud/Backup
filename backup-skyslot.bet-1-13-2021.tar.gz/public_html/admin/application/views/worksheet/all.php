<div class="">
  <div class="page-header-title">
    <h4 class="page-title">รายการใบงานทั้งหมด</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container"> 

        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th></th>
                              <th>สินค้า</th>                                           
                              <th>ชื่อ</th>
                              <th>ชื่อบัญชีสมาชิก</th> 
                              <th>วันที่ฝาก/ถอน</th>
                              <th>จำนวน</th>                    
                              <th>Call</th>
                              <th>วันเปิด</th>
                              <th>B_name</th>
                              <th>Bank</th>
                              <th>B_date</th>
                              <th>M_name</th>
                              <th>Manage</th>
                              <th>M_date</th>
                              <th>รวม</th>
                              <th></th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- END Row -->
        
     </div>
  <!-- container -->   
</div>
<!-- Page content Wrapper -->
<!-- View Worksheet Modals -->
<div class="modal fade" id="worksheet-view-modal" tabindex="-1" role="dialog" aria-labelledby="WorksheetWithdraw" aria-hidden="false">
  <div class="modal-dialog">
    <div class="modal-content" id="modal-content">
      <form class="form-horizontal" id="form-worksheet-view" action="" method="POST" role="form">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">รายละเอียดใบงาน</h4>
        </div>
        <div class="modal-body">         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- END View Worksheet Modals -->
<!-- Image Modals -->
<div class="modal fade" id="ImageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <img src="" class="imagepreview" style="width: 100%;" >
      </div>
    </div>
  </div>
</div>
<!-- END Image Modals -->
<!-- Initialize Form Validation -->
<script src="<?php echo base_url('assets/plugins/formValidation/FormsCreateWorksheetValidation.js') ?>"></script>
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$.fn.modal.Constructor.prototype.enforceFocus = function(){};
	var base_url = '<?php echo site_url() ?>';
	var t = $('#datatables').DataTable({
		"bPaginate": true, 
		//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
		//"bFilter": false, //+ ช่องค้นหา
		//"bInfo": false, //+ รายละเอียดจำนวนแถว
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": '<?php echo base_url('worksheet/worksheet-all'); ?>',
		"iDisplayLength": 50,
		"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
			{"searchable": false, "orderable": false, "targets":0,'className':'text-center text-vertical'},
			{"searchable": false, "orderable": true, "targets":[1,13],'className':'text-center text-vertical'},
			{"searchable": false, "orderable": false, "targets":15,'className':'text-center text-vertical'},
			{"targets":[2,3,4,5,6,7,8,9,10],'className':'text-center text-vertical'},
			{"searchable": false, "orderable": true,"visible":false, "targets":[9,11,12,14]},
			{"searchable": false, "orderable": false, "targets":16,'className':'text-center text-vertical',
				"render": function(data, type, row) { // Available data available for you within the row	
					var button = '<a data-toggle="modal" data-target="#worksheet-view-modal" data-wsid="'+data+'" class="btn btn-xs btn-default"><span class="ti-search"></span></a>';					
					return button;
				}	
			}
		],
		"order": [8, 'desc'], //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
		"createdRow": function ( row, data, index ) {			
			var bg;
			switch (data[1]) {
				case 'ฝาก':
					bg = "deposit-bg";
					break;
				case 'ถอน':
					bg = "withdraw-bg";
					break;
				case 'โยก':
					bg = "transfer-bg";
					break;
			}			
			$(row).addClass(bg);
        }
	});
	$('#worksheet-view-modal').on('show.bs.modal', function (e){
		$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('worksheet/view')?>?wsid='+$(e.relatedTarget).attr('data-wsid'));
	});

	setInterval(function(){ $('#datatables').DataTable().ajax.reload(null, false);}, 45000);
});
</script>