<div class="">
  <div class="page-header-title">
    <h4 class="page-title">Bank</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container">

        <div class="row">                                     
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <button class="btn btn-success btn-lg pull-right" type="button" id="btn-refresh" onclick="window.location.reload();">REFRESH</button>
                    </div>
                </div>
            </div>                                     
        </div>
        
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th></th>
                              <th>สินค้า</th>                                           
                              <th>ชื่อ</th>
                              <th>ชื่อบัญชีสมาชิก</th> 
                              <th>วันที่ฝาก/ถอน</th>
                              <th>จำนวน</th>                    
                              <th width="8%">รูปฝาก</th>
                              <th>Call</th>
                              <th>วันเปิด</th>
                              <th></th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- END Row -->
        
    </div>
  <!-- container -->   
</div>
<!-- Page content Wrapper -->
<!-- Worksheet Deposit Modals -->
<div class="modal fade" id="worksheet-deposit-modal" tabindex="-1" role="dialog" aria-labelledby="WorkSheetDeposit" aria-hidden="true" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content" id="modal-content">
      <form class="form-horizontal" id="form-worksheet-deposit" action="" method="POST" role="form">
        <div class="modal-header">
          <!--<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
          <h4 class="modal-title" id="myModalLabel">รายการเติมเครดิต</h4>
        </div>
        <div class="modal-body">        	      
        </div>        
      </form>
    </div>
  </div>
</div>
<!-- END Worksheet Deposit Modals -->
<!-- Withdraw Modals -->
<div class="modal fade" id="worksheet-withdraw-modal" tabindex="-1" role="dialog" aria-labelledby="WorksheetWithdraw" aria-hidden="false" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content" id="modal-content">
      <form class="form-horizontal" id="form-worksheet-withdraw" action="" method="POST" role="form">
        <div class="modal-header">
          <!--<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
          <h4 class="modal-title" id="myModalLabel">รายการถอนเครดิต</h4>
        </div>
        <div class="modal-body">         
        </div>        
      </form>
    </div>
  </div>
</div>
<!-- END Withdraw Modals -->
<!-- Image Modals -->
<div class="modal fade" id="ImageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <img src="" class="imagepreview" style="width: 100%;" >
      </div>
    </div>
  </div>
</div>
<!-- END Image Modals -->
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$.fn.modal.Constructor.prototype.enforceFocus = function(){};
	var base_url = '<?php echo site_url() ?>';
	var t = $('#datatables').DataTable({
		"bPaginate": true, 
		//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
		//"bFilter": false, //+ ช่องค้นหา
		//"bInfo": false, //+ รายละเอียดจำนวนแถว
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": '<?php echo base_url('worksheet/bank-all'); ?>',
		"iDisplayLength": 50,
		"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
			{"searchable": true, "orderable": false, "targets":0,'className':'text-center'},
			{"searchable": false, "orderable": true, "targets":1,'className':'text-center'},
			{"targets":[2,3,4,5,6,8,9],'className':'text-center'},
			{"searchable": false, "orderable": false, "targets":7,'className':'text-center',
				"render": function(data, type, row) { // Available data available for you within the row	
					var img = '';
					if(data!=null){
						//img += '<a class="pop" data-img="'+base_url+'images/worksheet/'+data+'"><span class="oi oi-image"></span></a>';
						img += '<a class="pop" data-img="'+data+'"><span class="oi oi-image"></span></a>';
					}
					return img;
				}	
			},
			{"searchable": false, "orderable": false, "targets":10,'className':'text-center',
				"render": function(data, type, row) { // Available data available for you within the row	
					var button = '';
					if(row[1].trim()=='ฝาก'){
						button += '<a data-toggle="modal" data-target="#worksheet-deposit-modal" data-wsid="'+data+'" class="btn btn-xs btn-success">จัดการ</a>';
					}else{
						button += '<a data-toggle="modal" data-target="#worksheet-withdraw-modal" data-wsid="'+data+'" class="btn btn-xs btn-success">จัดการ</a>';
					}					
					return button;
				}	
			}
		],
		"order": [9, 'desc'], //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
		"createdRow": function ( row, data, index ) {			
			var bg;
			switch (data[1]) {
				case 'ฝาก':
					bg = "deposit-bg";
					break;
				case 'ถอน':
					bg = "withdraw-bg";
					break;
				case 'โยก':
					bg = "transfer-bg";
					break;
			}			
			$(row).addClass(bg);
        }
	});
	$('#worksheet-deposit-modal,#worksheet-withdraw-modal').on('hidden.bs.modal', function () {
		//window.location.reload();
	});	
	$('#worksheet-withdraw-modal').on('show.bs.modal', function (e){
		$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('worksheet/bank-withdraw')?>?wsid='+$(e.relatedTarget).attr('data-wsid'));
	});
	$('#worksheet-deposit-modal').on('show.bs.modal', function (e) {
		$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('worksheet/bank-deposit')?>?wsid='+$(e.relatedTarget).attr('data-wsid'));
		$("#worksheet-deposit-cancel,#worksheet-deposit-confirm").prop("disabled",true);
	});

	setInterval(function(){ $('#datatables').DataTable().ajax.reload(null, false);}, 45000);

	/*$(".fancybox").fancybox({
        openEffect : "none",
        closeEffect : "none"
    });*/
	$('#datatables tbody').on('click', 'td > a.pop', function (e) {
       $('.imagepreview').attr('src', $(this).attr('data-img'));
	   $('#ImageModal').modal('show'); 
       return false;
    });
	$("#ImageModal").easydrag();
});
</script>
<link href="<?php echo base_url('assets/plugins/uploadifive/uploadifive.css') ?>" type="text/css" media="screen" rel="stylesheet"/>
<script src="<?php echo base_url('assets/plugins/uploadifive/jquery.uploadifive.min.js') ?>" type="text/javascript"></script>