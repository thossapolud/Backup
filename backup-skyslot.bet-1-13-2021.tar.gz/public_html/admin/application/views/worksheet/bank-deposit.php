<?php if($rs_worksheet->num_rows()>0){ $row_worksheet = $rs_worksheet->row(); ?>
<div class="form-group text-center">
  <h4><font color="#FF0000">** ระยะเวลาในการทำรายการ 5 นาที และห้ามรีเฟรช **</font></h4>
</div>
<div class="form-group ">
  <label for="inputCode" class="col-sm-3 control-label">เลขที่บิล:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_code" class="form-control" id="ws_code" placeholder="เลขที่บิล" value="<?php echo $row_worksheet->ws_code ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputWebsite" class="col-sm-3 control-label">เว็บไซต์:</label>
  <div class="col-sm-8">
  	<input type="hidden" name="site_id" class="form-control" id="site_id" value="<?php echo $row_worksheet->site_id ?>" readonly="readonly">
    <input type="text" name="site_name" class="form-control" id="site_name" value="<?php echo $row_worksheet->site_name ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="inputDealer" class="col-sm-3 control-label">ตัวเกมส์สินค้า:</label>
  <div class="col-sm-4">
    <input type="text" name="ws_dealer" class="form-control" id="ws_dealer" value="<?php echo $row_worksheet->ws_dealer ?>" readonly>
  </div>
  <div class="col-sm-4">
    <input type="text" name="type" class="form-control" id="type" value="<?php echo conv_ws_type($row_worksheet->ws_type) ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputName" class="col-sm-3 control-label">Username:</label>
  <div class="col-sm-8">
    <input type="text" name="username" class="form-control" id="username" value="<?php echo $row_worksheet->username ?>" readonly>
    <input type="hidden" name="ws_id" class="form-control" id="ws_id" value="<?php echo $row_worksheet->ws_id ?>">
    <input type="hidden" name = "method"  id = "method" value = "BankDepositConfirm" />
    <input type="hidden" name = "b_comment"  id = "b_comment" value = "" />
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อเล่น:</label>
  <div class="col-sm-8">
    <input type="text" name="nickname" class="form-control" id="nickname" value="<?php echo $row_worksheet->nickname ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="Ws_Credit" class="col-sm-3 control-label">จำนวนฝาก:</label>
  <div class="col-sm-4">
    <input name="ws_credit" type="text" class="form-control text-red" id="ws_credit" value="<?php echo number_format($row_worksheet->ws_credit,2) ?>" readonly>
  </div>
  <label for="image" class="col-sm-3 control-label">ไฟล์สลิปฝากเงิน:</label>
  <div class="col-sm-2">
  <a class="pop pop-deposit" data-img="<?php echo $row_worksheet->ws_deimg ?>"> <span class="mdi mdi-file-image" style="padding-top:10px;"></span> </a>
  </div>
</div>

<div class="form-group text-right">
  <div class="col-sm-7"></div>
  <div class="col-sm-4"><h5><font color="#FF0000">** คลิ๊กเพื่อดูสลิปฝากเงิน <span class="mdi mdi-arrow-up"></span></font></h5></div>
</div>

<!--<div class="form-group form-group-lg">
  <label for="Ws_Pro" class="col-sm-3 control-label">ยอดโปร:</label>
  <div class="col-sm-4">
    <input name="ws_pro" type="text" class="form-control text-red" id="ws_pro" value="<?php //echo number_format($row_worksheet->ws_pro,2) ?>" readonly="readonly">
  </div>
</div>
<div class="form-group form-group-lg">
  <label for="Ws_Total" class="col-sm-3 control-label">ยอดทำรายการ:</label>
  <div class="col-sm-4">
    <input name="ws_total" type="text" class="form-control text-red" id="ws_total" value="<?php //echo number_format($row_worksheet->ws_total,2) ?>" readonly="readonly">
  </div>
</div>-->
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">เข้าธนาคาร:</label>
  <div class="col-sm-4">
    <input type="text" name="ws_debank" class="form-control" id="ws_debank" value="<?php echo strtoupper($row_worksheet->ws_debank) ?>" readonly>
  </div>
  <div class="col-sm-4">
    <input type="text" name="ws_debankac" class="form-control" id="ws_debankac" value="<?php echo $row_worksheet->ws_debankname ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ฝาก วันที่:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_date" class="form-control" id="ws_date" value="<?php echo date('d / m / Y H:i:s',strtotime($row_worksheet->ws_date)) ?>" readonly>
  </div>
</div>
<div class="form-group text-center">
  <h4><font color="#FF0000">** เลขบัญชีที่โอนเงินเข้ามาต้องเป็นของลูกค้าที่ได้แจ้งลงทะเบียนเท่านั้น **</font></h4>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อบัญชี:</label>
  <div class="col-sm-6">
    <input type="text" name="accountname" class="form-control" id="accountname" value="<?php echo $row_worksheet->accountname ?>" readonly>
  </div>
  <div class="col-sm-2">
    <input type="text" name="bank" class="form-control" id="bank" value="<?php echo $row_worksheet->bank ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputBankno" class="col-sm-3 control-label">เลขบัญชี:</label>
  <div class="col-sm-8">
    <input type="text" name="bankno" class="form-control" id="bankno" value="<?php echo $row_worksheet->bankno ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">รายการจากแบงค์:</label>
  <div class="col-sm-8 col-md-8">
    <table class="table table-striped table-bordered table-hover" id="table-list-statement" width="100%" style="font-size:11px;">
      <thead>
        <tr role="row">
          <th class="text-center" width="5%"></th>
          <th class="text-center" width="20%">วันที่</th>
          <th class="text-center" width="10%">ฝาก</th>
          <th class="text-center">หมายเหตุ</th>
        </tr>
      </thead>
      <tbody>
        <?php if($rs_statement->num_rows()>0){ ?>
        <?php foreach($rs_statement->result() as $row){ ?>
        <tr>
          <td class=" text-center"><input type = "radio" name = "st_id"  id = "st_id" class="st_id" value = "<?php echo $row->st_id ?>" /></td>
          <td class="text-center"><?php echo $row->st_datein ?></td>
          <td class=" text-center"><?php echo $row->st_in ?></td>
          <td class=" text-center"><?php echo $row->st_acc.' '.$row->st_comment ?></td>
        </tr>
        <?php } ?>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>
<hr class="hr-black" />
<div class="form-group">
  <label for="Promotion" class="col-sm-3 control-label">โปรโมชั่น:</label>
  <div class="col-sm-8">
    <input name="promotion" type="text" class="form-control" id="promotion" value="<?php echo $row_worksheet->title ?>" readonly>
  </div>
</div>
<div class="modal-footer">
  <!--<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>-->
  <button type="button" class="btn btn-default" id="worksheet-leave" disabled="disabled">ปล่อยใบงาน</button>
  <button type="button" class="btn btn-danger" id="worksheet-deposit-cancel" disabled="disabled">ยกเลิกใบงาน</button>
  <button type="button" class="btn btn-success" id="worksheet-deposit-confirm" disabled="disabled">ยืนยันการตรวจสอบ</button>
</div>
<!--<div class="form-group">
  <label for="created" class="col-sm-3 control-label">Call เปิดใบงาน:</label>
  <div class="col-sm-8">
    <input name="created" type="text" class="form-control" id="created" value="<?php //echo date('d / m / Y H:i:s',strtotime($row_worksheet->created)) ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="inputC_comment" class="col-sm-3 control-label">Call Comment:</label>
  <div class="col-sm-8">
  <textarea class="form-control" name="c_comment" rows="2" readonly="readonly"><?php //echo $row_worksheet->c_comment ?></textarea>
  </div>
</div>-->
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {	
	$('#get-statement').click(function(){
		$('.glyphicon-refresh').show();
		$.ajax({
			type: 'POST',
			//dataType: 'json',
			cache: false,
			// url: '<?php echo site_url('get-'.$row_worksheet->ws_debank.'statement/'.$row_worksheet->ws_debankacnum) ?>',
			url: '<?php echo site_url('get-'.$row_worksheet->ws_debank.'statement/get/'.$row_worksheet->ws_debank.'/'.$row_worksheet->ws_debankacnum) ?>',
			// data: {bank:'<?php echo $row_worksheet->ws_debank ?>'},
			success: function(resp){
				swal({title:resp,confirmButtonText:'OK'},function(){
					$('.glyphicon-refresh').hide();
					$.LoadingOverlay("show");
					$('#table-list-statement tbody').empty();
					$.ajax({
						cache: false,
						type: 'POST',
						dataType: 'json',
						url: '<?php echo site_url('json/get-bank-statement') ?>',
						data: {'st_bank':'<?php echo $row_worksheet->ws_debank ?>','st_ac':'<?php echo $row_worksheet->ws_debankac ?>','st_datein':'<?php echo date('Y-m-d H:i',strtotime($row_worksheet->ws_date)) ?>'},
						success: function(data){
							$.LoadingOverlay("hide");
							if(data!=''){
								var tr = '';
								$.each(data,function(index, val){
									tr += '<tr>';
									tr += '<td class=" text-center"><input type = "radio" name = "st_id"  id = "st_id" class="st_id" value = "'+val.st_id+'" /></td>';
									tr += '<td class="text-center">'+val.st_datein+'</td><td class=" text-center">'+val.st_in+'</td>';
									tr += '<td class=" text-center">'+val.st_acc+' '+val.st_comment+'</td>';
									tr += '</tr>';
								});
								$('#table-list-statement tbody').append(tr);
							}else{
								swal({title:'ไม่มีรายการฝากจากลูกค้าท่านนี้',confirmButtonText: 'OK' })
							}					
						}
					});
				});
			}
		});
	});
	$(".pop-deposit").click(function(){
		$("#worksheet-leave,#worksheet-deposit-cancel,#worksheet-deposit-confirm").prop("disabled",false);
	});
	/*$(".fancybox-deposit").fancybox({
        openEffect : "none",
        closeEffect : "none",
		helpers : { overlay : null },
		//autoCenter: true,
    	margin: [0, 0, 0, 850], // [top, right, bottom, left]
    });*/
	$('.pop').on('click', function() {
		$('.imagepreview').attr('src', $(this).attr('data-img'));
		$('#ImageModal').modal('show');
	});
	$("#ImageModal").easydrag();
	$('#worksheet-leave').click(function(){
		var $form = $('#form-worksheet-deposit');
		if($form.find('#ws_id').length>0){
			swal({
			  title: "ยืนยัน ปล่อยใบงาน ?",
			  type: "warning",
			  showCancelButton: true,
			  cancelButtonText: "ยกเลิก",
			  confirmButtonText: "ยืนยัน",
			  closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					dataType: 'json',
					cache: false,
					url: '<?php echo site_url('worksheet/bank-leave') ?>',
					data: $form.serialize(),
					success: function(resp){
						$.LoadingOverlay("hide");							
						if(resp.error==1){
							swal({title:'ไม่สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
						}else{
							swal({title:'สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
								$('#worksheet-deposit-modal,#worksheet-withdraw-modal').modal('hide');
								window.location.reload();
							});
						}							
					}
				});	
			});
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
	$('#worksheet-deposit-confirm').click(function(){
		var $form = $('#form-worksheet-deposit');
		if($form.find('#ws_id').length>0){
			swal({
			  title: "ยืนยัน ตรวจสอบใบงาน ฝาก ?",
			  type: "warning",
			  showCancelButton: true,
			  cancelButtonText: "ยกเลิก",
			  confirmButtonText: "ยืนยัน",
			  closeOnConfirm: false
			},function(){
				//if($form.find('.st_id').length>0&&$form.find('.st_id').filter(':checked').length>0){
					$.LoadingOverlay("show");
					$.ajax({
						type: 'POST',
						dataType: 'json',
						cache: false,
						url: '<?php echo site_url('worksheet/bank-deposit-confirm') ?>',
						data: $form.serialize(),
						success: function(resp){
							$.LoadingOverlay("hide");							
							if(resp.error==1){
								swal({title:'ไม่สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
							}else{
								swal({title:'สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
									$('#worksheet-deposit-modal,#worksheet-withdraw-modal').modal('hide');
									window.location.reload();
								});
							}							
						}
					});
				//}else{
					//swal({title:'เลือกรายการฝากจากธนาคาร',confirmButtonText: 'OK' });					
				//}				
			});
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
	$('#worksheet-deposit-cancel').click(function(){
		var $form = $('#form-worksheet-deposit');
		if($form.find('#ws_id').length>0){

			swal({
			  title: "ยืนยัน ยกเลิก ใบงาน ฝาก ?",
			  text: "ระบุเหตุผลในการยกเลิก:",
			  type: "input",
			  cancelButtonText: "ยกเลิก",
			  confirmButtonText: "ยืนยัน",
			  showCancelButton: true,
			  closeOnConfirm: false,
			  /*animation: "slide-from-top",*/
			  inputPlaceholder: "เหตุผล"
			},
			function(inputValue){
			  if (inputValue === false) return false;			 
			  if (inputValue === "") {
				swal.showInputError("กรุณาระบุเหตุผลในการยกเลิก!");
				return false
			  }else{
				$form.find('#b_comment').val(inputValue);
				//swal("Nice!", "You wrote: " + inputValue, "success");  
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					dataType: 'json',
					cache: false,
					url: '<?php echo site_url('worksheet/bank-deposit-cancel') ?>',
					data: $form.serialize(),
					success: function(resp){						
						$.LoadingOverlay("hide");				
						if(resp.error==1){
							swal({title:'ไม่สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
						}else{
							swal({title:'สำเร็จ!',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
								$('#worksheet-deposit-modal,#worksheet-withdraw-modal').modal('hide');
								window.location.reload();
							});
						}							
					}
				});
			  }		  
			});
									
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
});
</script>
<?php }else{ ?>
<center>
  <small><font color="#FF0000">** ใบงานอาจถูกปรับสถานะไปแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบอีกรอบ **</font></small>
</center>
<?php } ?>
