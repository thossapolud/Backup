<?php if($rs_worksheet->num_rows()>0){ $row_worksheet = $rs_worksheet->row(); ?>
<div class="form-group text-center">
  <h4><font color="#FF0000">** ระยะเวลาในการทำรายการ 5 นาที และห้ามรีเฟรช **</font></h4>
</div>
<div class="form-group ">
  <label for="inputCode" class="col-sm-3 control-label">เลขที่บิล:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_code" class="form-control" id="ws_code" placeholder="เลขที่บิล" value="<?php echo $row_worksheet->ws_code ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputWebsite" class="col-sm-3 control-label">เว็บไซต์:</label>
  <div class="col-sm-8">
  	<input type="hidden" name="site_id" class="form-control" id="site_id" value="<?php echo $row_worksheet->site_id ?>" readonly>
    <input type="text" name="site_name" class="form-control" id="site_name" value="<?php echo $row_worksheet->site_name ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputDealer" class="col-sm-3 control-label">ตัวเกมส์สินค้า:</label>
  <div class="col-sm-4">
    <input type="text" name="ws_dealer" class="form-control" id="ws_dealer" value="<?php echo $row_worksheet->ws_dealer ?>" readonly>
  </div>
  <div class="col-sm-4">
    <input type="text" name="type" class="form-control" id="type" value="<?php echo conv_ws_type($row_worksheet->ws_type) ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputName" class="col-sm-3 control-label">Username:</label>
  <div class="col-sm-8">
    <input type="text" name="username" class="form-control" id="username" value="<?php echo $row_worksheet->username ?>" readonly>
    <input type="hidden" name="ws_id" class="form-control" id="ws_id" value="<?php echo $row_worksheet->ws_id ?>">
    <input type="hidden" name = "user_id"  id = "user_id" value = "<?php echo $row_worksheet->user_id ?>" />
    <input type="hidden" name = "userpass_id"  id = "userpass_id" value = "<?php echo $row_worksheet->userpass_id ?>" />
    <input type="hidden" name="ws_type" class="form-control" value="<?php echo $row_worksheet->ws_type ?>">
    <input type="hidden" name = "method"  id = "method" value = "BankWithdrawConfirm" />
    <input type="hidden" name = "b_comment"  id = "b_comment" value = "" />
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อเล่น:</label>
  <div class="col-sm-8">
    <input type="text" name="nickname" class="form-control" id="nickname" value="<?php echo $row_worksheet->nickname ?>" readonly>
  </div>
</div>
<div class="form-group form-group-lg">
  <label for="Ws_Credit" class="col-sm-3 control-label">จำนวนถอน:</label>
  <div class="col-sm-8">
    <input name="ws_credit" type="text" class="form-control text-red" id="ws_credit" value="<?php echo number_format($row_worksheet->ws_credit,2) ?>" readonly>
    <input name="ws_total" type="hidden" id="ws_total" value="<?php echo number_format($row_worksheet->ws_credit,2) ?>">

  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ชื่อบัญชี:</label>
  <div class="col-sm-6">
    <input type="text" name="accountname" class="form-control" id="accountname" value="<?php echo $row_worksheet->accountname ?>" readonly>
  </div>
  <div class="col-sm-2">
    <input type="text" name="bank" class="form-control" id="bank" value="<?php echo $row_worksheet->bank ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputBankno" class="col-sm-3 control-label">เลขบัญชี:</label>
  <div class="col-sm-8">
    <input type="text" name="bankno" class="form-control" id="bankno" value="<?php echo $row_worksheet->bankno ?>" readonly>
  </div>
</div>
<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">รหัสถอน:</label>
  <div class="col-sm-8">
    <input type="text" name="withdrawcode" class="form-control" id="withdrawcode" value="<?php echo $row_worksheet->withdrawcode ?>" readonly>
  </div>
</div>
<!--<div class="form-group">
  <label for="inputPhone" class="col-sm-3 control-label">ถอน วันที่:</label>
  <div class="col-sm-8">
    <input type="text" name="ws_date" class="form-control" id="ws_date" value="<?php //echo date('d / m / Y H:i:s',strtotime($row_worksheet->ws_date)) ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="created" class="col-sm-3 control-label">Call เปิดใบงาน:</label>
  <div class="col-sm-8">
    <input name="created" type="text" class="form-control" id="created" value="<?php //echo date('d / m / Y H:i:s',strtotime($row_worksheet->created)) ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="inputC_comment" class="col-sm-3 control-label">Call Comment:</label>
  <div class="col-sm-8">
  <textarea class="form-control" name="c_comment" rows="2" readonly="readonly"><?php //echo $row_worksheet->c_comment ?></textarea>
  </div>
</div>
<div class="form-group">
  <label for="b_date" class="col-sm-3 control-label">Manage status:</label>
  <div class="col-sm-8">
    <?php //echo conv_ws_status($row_worksheet->m_status) ?>
  </div>
</div>
<div class="form-group">
  <label for="b_date" class="col-sm-3 control-label">Manage ยืนยัน:</label>
  <div class="col-sm-8">
    <input name="b_date" type="text" class="form-control" id="b_date" value="<?php //echo ($row_worksheet->m_date!='')?date('d / m / Y H:i:s',strtotime($row_worksheet->m_date)):'' ?>" readonly="readonly">
  </div>
</div>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">Manage:</label>
  <div class="col-sm-8 col-md-8">
  	<input name="b_name" type="text" class="form-control" id="b_name" value="<?php //echo $row_worksheet->a3name ?>" readonly="readonly">
  </div>
</div>-->
<div class="form-group">
    <label for="input" class="col-sm-3 control-label">ถอนจากบัญชี:</label>
    <div class="col-sm-8">
        <select name="ws_bankac" id="ws_bankac" class="form-control" >
            <option value="">== เลือก ==</option>
            <option disabled="disabled">-----------------------------------------------------------------------------</option>
            <?php foreach($rs_bankwithdraw->result() as $row){ ?>
            <option value="<?php echo $row->type ?>|<?php echo $row->username ?>|<?php echo $row->acnum ?>|<?php echo $row->bankname ?>">[<?php echo strtoupper($row->type) ?>] <?php echo $row->bankname ?> (ยอดเงินใช้ได้:<?php echo $row->available ?>)</option>
            <option disabled="disabled">-----------------------------------------------------------------------------</option>
            <?php } ?>
        </select>
    </div>
</div>
<div class="form-group">
  <label for="image" class="col-sm-3 control-label">ไฟล์สลิปถอนเงิน:</label>
  <div class="col-sm-8 col-md-8">
    <input type="file"  id="image_upload_withdraw" name="image_upload_withdraw"/>
    <div id="image_queue_withdraw" class="queue"></div>
    <!--<img id="example-image" />-->
    <input type="hidden" id="ws_wiimg" name="ws_wiimg" value="" />
  </div>
</div>
<center>
  <small><font color="#FF0000">** ขณะอัพโหลด รอให้ขึ้น สถานะ Completed และห้ามทำการ Refresh หน้าเว็บ **</font></small>
</center>
<div class="modal-footer">
  <!--<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>-->
  <button type="button" class="btn btn-danger" id="worksheet-withdraw-cancel" >ยกเลิกใบงาน</button>
  <button type="button" class="btn btn-default" id="worksheet-leave">ปล่อยใบงาน</button>
  <button type="button" class="btn btn-success" id="worksheet-withdraw-confirm" >ถอนปกติ</button>
  <button type="button" class="btn bay-bg" id="worksheet-withdraw-add-queue"><i class="thbanks thbanks-bay"></i> ถอนออโต้</button>
</div>
<script type="text/javascript">
$(function(){
	var base_url = '<?php echo base_url(); ?>';
	$('#image_upload_withdraw').uploadifive({
		'auto' : true,
		'buttonText':'เลือกไฟล์ (JPG | PNG) และ ขนาดไม่เกิน 2 Mb.',
		'fileType' : new Array("image"),
		'removeCompleted' : false,
		'multi' : false,
		//'formData':{'image_old':''},
		'fileObjName':'withdrawfile',
		'fileSizeLimit' : 2048,
		'width' :300,
		'queueID' : 'image_queue_withdraw',
		'uploadScript' : '<?php echo base_url('worksheet/upload-withdraw-img') ?>',
		'onUploadComplete' : function(file, data){
			var d = new Date();
			var obj = $.parseJSON(data);
			//alert('The file ' + obj.name + ' Success ');
			//$('#example-image').attr('src', base_url+'images/'+obj.name+'?d='+d.getTime());
			$('#ws_wiimg').val(obj.name);
		}
	});	
	$('#worksheet-withdraw-confirm').click(function(){
		var $form = $('#form-worksheet-withdraw');
		if($form.find('#ws_id').length>0){
			swal({
					  title: "ยืนยัน ตรวจสอบใบงาน ถอน ?",
					  type: "warning",
					  showCancelButton: true,
					  cancelButtonText: "ยกเลิก",
					  confirmButtonText: "ยืนยัน",
					  closeOnConfirm: false
			},function(){
				/*if($('#ws_dealer').val()!=='918kiss'&&$('#ws_dealer').val()!=='Gclub'&&$('#ws_dealer').val()!=='Slotxo'){
					swal({title:$('#ws_dealer').val()+' ยังไม่สามารถทำการได้',confirmButtonText: 'OK' })
				}else */
				if($('#userpass_id').val()===''){
					swal({title:'ลูกค้าท่านนี้ ยังไม่ได้ผูกกับ เอเย่นต์',confirmButtonText: 'OK' })
				}else if($('#ws_bankac').val()===''){
					swal({title:'กรุณาเลือกบัญชีถอน',confirmButtonText: 'OK' })			
				}else if($('#ws_wiimg').val()===''){
					swal({title:'กรุณาใส่สลิปถอนเงิน',confirmButtonText: 'OK' })			
				}else{
					$.LoadingOverlay("show");
					$.ajax({
						type: 'POST',
						dataType: 'json',
						cache: false,
						url: '<?php echo site_url('worksheet/bank-withdraw-confirm') ?>',
						data: $form.serialize(),
						success: function(resp){
							$.LoadingOverlay("hide");							
							if(resp.error==1){
								swal({title:'<span style="color:#C9302C">ไม่สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
							}else{
								swal({title:'<span style="color:#449D44">สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
									$('#worksheet-deposit-modal,#worksheet-withdraw-modal').modal('hide');
									window.location.reload();
								});
							}							
						}
					});
				}				
			});
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
	$('#worksheet-withdraw-add-queue').click(function(e){
		e.preventDefault();
		e.stopImmediatePropagation();
		var $form = $('#form-worksheet-withdraw');
		if($form.find('#ws_id').length>0){
			swal({
			  title: "ยืนยัน รอจัดการใบงาน ถอน ?",
			  type: "warning",
			  showCancelButton: true,
			  cancelButtonText: "ยกเลิก",
			  confirmButtonText: "ยืนยัน",
			  closeOnConfirm: false
			},function(){
				/*if($('#ws_dealer').val()!=='Pussy888'&&$('#ws_dealer').val()!=='Gclub'&&$('#ws_dealer').val()!=='Slotxo'){
					swal({title:$('#ws_dealer').val()+' ยังไม่สามารถทำการได้',confirmButtonText: 'OK' })
				}else */
				if($('#userpass_id').val()===''){
					swal({title:'ลูกค้าท่านนี้ ยังไม่ได้ผูกกับ เอเย่นต์',confirmButtonText: 'OK' })
				}else if($('#ws_bankac').val()===''){
					swal({title:'กรุณาเลือกบัญชีถอน',confirmButtonText: 'OK' })			
				//}else if($('#ws_wiimg').val()===''){
					//swal({title:'กรุณาใส่สลิปถอนเงิน',confirmButtonText: 'OK' })			
				}else{
					var string1 = $('#ws_bankac').val();
					var $match = string1.match(/bay/i);
					if($match){
						$.LoadingOverlay("show");
						$("#worksheet-withdraw-confirm").attr("disabled", true);
						$.ajax({
							type: 'POST',
							dataType: 'json',
							cache: false,
							url: '<?php echo site_url('worksheet/add-queue') ?>',
							data: {'wsid':$('#ws_id').val(),'wsbankac':$('#ws_bankac').val()},
							success: function(resp){
								$.LoadingOverlay("hide");							
								if(resp.error==1){
									swal({title:'<span style="color:#C9302C">ไม่สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
										$('#worksheet-withdraw-modal').modal('hide');
										window.location.reload();
									});
								}else{
									swal({title:'<span style="color:#449D44">สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
										$('#worksheet-withdraw-modal').modal('hide');
										window.location.reload();				
									});
								}							
							}
						});
					}else{
						swal({title:'<span style="color:#C9302C">ไม่สำเร็จ!</span>',text:'รองรับเฉพาะ BAY เท่านั้น',confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
						/*
						$.LoadingOverlay("show");
						$.ajax({
							type: 'POST',
							dataType: 'json',
							cache: false,
							url: '<?php echo site_url('worksheet/bank-withdraw-confirm') ?>',
							data: $form.serialize(),
							success: function(resp){
								$.LoadingOverlay("hide");							
								if(resp.error==1){
									swal({title:'<span style="color:#C9302C">ไม่สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
								}else{
									swal({title:'<span style="color:#449D44">สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
										$('#worksheet-withdraw-modal').modal('hide');
										window.location.reload();
									});
								}							
							}
						});
						*/
					}
				}				
			});
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
	$('#worksheet-leave').click(function(){
		var $form = $('#form-worksheet-withdraw');
		if($form.find('#ws_id').length>0){
			swal({
			  title: "ยืนยัน ปล่อยใบงาน ?",
			  type: "warning",
			  showCancelButton: true,
			  cancelButtonText: "ยกเลิก",
			  confirmButtonText: "ยืนยัน",
			  closeOnConfirm: false
			},function(){
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					dataType: 'json',
					cache: false,
					url: '<?php echo site_url('worksheet/bank-leave') ?>',
					data: $form.serialize(),
					success: function(resp){
						$.LoadingOverlay("hide");							
						if(resp.error==1){
							swal({title:'<span style="color:#C9302C">ไม่สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
						}else{
							swal({title:'<span style="color:#449D44">สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
								$('#worksheet-deposit-modal,#worksheet-withdraw-modal').modal('hide');
								window.location.reload();
							});
						}							
					}
				});		
			});
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
	$('#worksheet-withdraw-cancel').click(function(){
		var $form = $('#form-worksheet-withdraw');
		if($form.find('#ws_id').length>0){

			swal({
			  title: "ยืนยัน ยกเลิก ใบงาน ถอน ?",
			  text: "ระบุเหตุผลในการยกเลิก:",
			  type: "input",
			  cancelButtonText: "ยกเลิก",
			  confirmButtonText: "ยืนยัน",
			  showCancelButton: true,
			  closeOnConfirm: false,
			  /*animation: "slide-from-top",*/
			  inputPlaceholder: "เหตุผล"
			},
			function(inputValue){
			  if (inputValue === false) return false;			 
			  if (inputValue === "") {
				swal.showInputError("กรุณาระบุเหตุผลในการยกเลิก!");
				return false
			  }else{
				$form.find('#b_comment').val(inputValue);
				//swal("Nice!", "You wrote: " + inputValue, "success");  
				$.LoadingOverlay("show");
				$.ajax({
					type: 'POST',
					dataType: 'json',
					cache: false,
					url: '<?php echo site_url('worksheet/bank-withdraw-cancel') ?>',
					data: $form.serialize(),
					success: function(resp){						
						$.LoadingOverlay("hide");				
						if(resp.error==1){
							swal({title:'<span style="color:#C9302C">ไม่สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true});
						}else{
							swal({title:'<span style="color:#449D44">สำเร็จ!</span>',text:resp.text,confirmButtonText: 'OK',closeOnClickOutside: false,html:true},function(){
								$('#worksheet-deposit-modal,#worksheet-withdraw-modal').modal('hide');
								window.location.reload();
							});
						}							
					}
				});
			  }		  
			});
									
		}else{
			swal({title:'โปรดตรวจสอบข้อมูล',confirmButtonText: 'OK'});
		}
	});
});
</script>
<?php }else{ ?>
<center>
  <small><font color="#FF0000">** ใบงานอาจถูกปรับสถานะไปแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบอีกรอบ **</font></small>
</center>
<?php } ?>
