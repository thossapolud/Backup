<?php
	//define('SITE_KEY', '6Lcu3dYUAAAAAMTVgFXDDvKVX8uSQabpPMWlZTAp');
	//define('SECRET_KEY', '6Lcu3dYUAAAAAJeNAL_ijlWJnDy1A3QGwn4JdX8L');
?>
<!DOCTYPE html>
<html>
    <head>
        <title>SKYSLOT.BET - Credit Management Center</title>
		<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">        
		<meta http-equiv="pragma" content="no-cache" >
		<meta http-equiv="cache-control" content="max-age=0" >
		<meta http-equiv="cache-control" content="no-cache" >
		<meta http-equiv="expires" content="0" >
        <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url('assets/css/icons.css') ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet" type="text/css">          
        <!-- Sweetalert CSS -->
        <link href="<?php echo base_url('assets/plugins/bootstrap-sweetalert/sweet-alert.css') ?>" rel="stylesheet">        
         <!-- JavaScript Resources -->
         <!-- jQuery  -->
        <script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/modernizr.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/detect.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/fastclick.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.slimscroll.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.blockUI.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/waves.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/wow.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.nicescroll.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.scrollTo.min.js') ?>"></script>
        <!-- Sweetalert JS -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-sweetalert/sweet-alert.min.js') ?>"></script>
        <script type="text/javascript">
		$(function(){
			sweetAlertInitialize();
			<?php if($this->session->flashdata('msg_error')){ ?>
			swal("Sorry!", "<?php echo $this->session->flashdata('msg_error') ?>", "error");	
			<?php } ?>
			<?php if($this->session->flashdata('msg_success')){ ?>
			swal({
			  title: "Good job!",
			  text: "<?php echo $this->session->flashdata('msg_success') ?>",
			  imageUrl: '<?php echo base_url('assets/plugins/bootstrap-sweetalert/thumbs-up.jpg') ?>'
			});
			<?php } ?>
		});
		</script>
		<!--<script src="https://www.google.com/recaptcha/api.js?render=<?= SITE_KEY; ?>"></script>-->
		<style>
			body, html {
				height: 100%;
 				margin: 0;
			}
		</style>
    </head>
    <body>
		<!-- Begin page -->
		<div class="login-bg">
			<!-- <div class="accountbg"></div> -->
			<div class="wrapper-page text-center" style="margin:auto auto; padding-top: 7.5%;">
			<div class="panel panel-color panel-primary panel-pages">
				<div class="panel-body">
				<h3 class="text-center m-t-0 m-b-15"> <a href="<?php echo site_url() ?>" class="logo logo-admin"><span>SKYBET{CMS}</span></a></h3>
				<h4 class="text-muted text-center m-t-0"><b>เข้าระบบ</b></h4>
				<form class="form-horizontal m-t-20" action="<?php echo site_url('login/check') ?>" method="post">
					<div class="form-group">
					<div class="col-xs-12">
						<input class="form-control" type="text" required="" placeholder="Username" name="username">
					</div>
					</div>
					<div class="form-group">
					<div class="col-xs-12">
						<input class="form-control" type="password" required="" placeholder="Password" name="password">
					</div>
					</div>         
					<div class="form-group text-center m-t-40">
					<div class="col-xs-12">
						<input type="hidden" id="gtoken" name="gtoken" />
						<button class="btn btn-primary btn-block btn-lg waves-effect waves-light" type="submit">Log In</button>
					</div>
					</div>                
				</form>
				</div>
			</div>
			</div>
		</div>
		<script>
			//grecaptcha.ready(function() {
				//grecaptcha.execute('<?= SITE_KEY; ?>', {action: 'admin/login'}).then(function(token) {
					//document.getElementById('gtoken').value=token;
				//});
			//});
		</script>
    </body>
</html>