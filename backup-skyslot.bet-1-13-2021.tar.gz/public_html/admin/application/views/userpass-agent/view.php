<div class="">
	<div class="page-header-title">
		<h4 class="page-title">User Pass <?php echo $row_userpass->type ?> : <?php echo $row_userpass->username ?></h4>
	</div>
</div>
<div class="page-content-wrapper ">
	<div class="container">

		<div class="row">
			<div class="col-sm-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
				<div class="panel">
					<div class="panel-heading">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">General Info</a></li>
							<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Edit</a></li>
							<!--<li role="presentation"><a href="#other-admin" aria-controls="other-admin" role="tab" data-toggle="tab">Other Admin Features</a></li>-->
						</ul>
					</div>
					<div class="panel-body">
						<!-- Tab panes -->
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="home">
								<form class="form-horizontal" method="POST" role="form">
									<div class="form-group">
										<label for="username" class="col-sm-4 col-md-4 control-label">สำหรับเว็บไซต์:</label>
										<div class="col-sm-4 col-md-4">
											<p class="form-control-static"><?php echo $row_website->site_name ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="username" class="col-sm-4 col-md-4 control-label">Username:</label>
										<div class="col-sm-4 col-md-4">
											<p class="form-control-static"><?php echo $row_userpass->username ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="password" class="col-sm-4 col-md-4 control-label">Password:</label>
										<div class="col-sm-4 col-md-4">
											<p class="form-control-static"><?php echo $row_userpass->password ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="password" class="col-sm-4 col-md-4 control-label">ใช้สมัคร AUTO:</label>
										<div class="col-sm-4 col-md-4">
											<p class="form-control-static"><?php echo ($row_userpass->default_agent == 1) ? 'Y' : 'N' ?></p>
										</div>
									</div>
								</form>
							</div>
							<div role="tabpanel" class="tab-pane" id="profile">
								<div class="modal-content" id="modal-content">
									<form class="form-horizontal" id="admin-edit-account" action="<?php echo site_url('userpass-agent/edit') ?>" method="POST" role="form">
										<div class="form-group">
											<div class="col-sm-4 col-md-3 col-lg-3"> </div>
										</div>
										<div class="form-group ">
											<label for="inputUsername" class="col-sm-3 control-label">Username:</label>
											<div class="col-sm-4">
												<input type="text" class="form-control" placeholder="Username" name="username" id="username" value="<?php echo $row_userpass->username ?>">
											</div>
											<div class="col-sm-4">
												<input type="password" name="password" class="form-control" id="password" required="required" data-toggle="password" value="<?php echo $row_userpass->password ?>">
											</div>
										</div>
										<div class="form-group ">
											<label for="default_agent" class="col-sm-3 control-label">ใช้สมัคร AUTO:</label>
											<div class="col-sm-8">
												<div class="checkbox checkbox-default">
													<input type="checkbox" value="1" name="default_agent" id="default_agent" 
														<?php echo ($row_userpass->default_agent == 1) ? 'checked="checked"' : ''; ?>>
													<label for="default_agent">ใช้ Agent นี้ Gen ยูสสมัครออโต้สำหรับเว็บไซต์นี้</label>
												</div>
											</div>
										</div>
										<div class="form-group ">
											<label for="inputBindUser" class="col-sm-3 control-label">Bind User:</label>
											<div class="col-sm-8">
												<?php if ($bind_data['status']) { ?>
												<button class="btn btn-primary" onclick="function newWindow(){window.open('<?php echo site_url('userpass-agent/bind/'.$row_userpass->userpass_id); ?>', '_blank', 'toolbar=yes,scrollbars=yes,resizable=yes,top=10,left=10,width=600,height=400'); return false;}return newWindow();">เชื่อมบัญชี</button>
												<?php } else { ?>
												<p class="form-control-static"><?=$bind_data['status_message']?></p>
												<?php } ?>
											</div>
										</div>
										<div class="form-group">
											<div class="col-sm-4 col-md-3"></div>
											<div class="col-sm-4 col-md-4">
												<input name="site_id" value="<?php echo $row_userpass->site_id ?>" type="hidden">
												<input name="dealer" value="<?php echo $row_userpass->type ?>" type="hidden">
												<input name="userpasstoedit" value="<?php echo $row_userpass->userpass_id ?>" type="hidden">
												<button type="submit" id="submit" name="button" value="Edit Account" class="btn btn-default"><i class=" fa fa-refresh "></i> Submit Changes</button>
											</div>
										</div>
									</form>
								</div><!-- End <div class="modal-content" id="modal-content"> -->
							</div><!-- End <div role="tabpanel" class="tab-pane" id="profile"> -->
							<div role="tabpanel" class="tab-pane" id="other-admin">
								<form id="form-delete" class="form-horizontal" method="POST" role="form" action="<?php echo site_url('userpass-agent/delete') ?>">
									<div class="form-group">
										<div class="col-sm-4 col-md-3 col-lg-2"> </div>
										<div class="col-sm-4 col-md-4">
											<p class="form-control-static">Other Admin Features</p>
										</div>
									</div>
									<div class="form-group">
										<div class="col-sm-offset-2 col-sm-10">
											<input name="userpasstodelete" value="<?php echo $row_userpass->userpass_id ?>" type="hidden">
											<input name="dealer" value="<?php echo $row_userpass->type ?>" type="hidden">
											<button type="submit" id="submit" name="button" value="Delete" class="btn btn-danger" onclick="return confirm ('Are you sure you want to delete, this cannot be undone?\n\n' + 'Click OK to continue or Cancel to Abort!')"><i class=" fa fa-times "></i> Delete</button>
										</div>
									</div>
								</form>
							</div><!-- End	<div role="tabpanel" class="tab-pane" id="other-admin"> -->
						</div>
					</div>
				</div><!-- End panel -->
			</div>
		</div><!-- End row -->
	</div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->

<script type="text/javascript">
$(function() {
	// Javascript to enable link to tab
	var hash = document.location.hash;
	if (hash) {
		console.log(hash);
		$('.nav-tabs a[href='+hash+']').tab('show');
	}
	// Change hash for page-reload
	$('a[data-toggle="tab"]').on('show.bs.tab', function (e) {
		window.location.hash = e.target.hash;
	});
});
</script>