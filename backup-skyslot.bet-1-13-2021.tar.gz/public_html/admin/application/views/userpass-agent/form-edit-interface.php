<?php if($row_agent) { ?>
<div class="form-group">
	<input name="itf_agent_id" value="<?php echo ($row_itf)?$row_itf->itf_agent_id:$row_agent->userpass_id ?>" type="hidden">
	<input name="itf_id" value="<?php echo ($row_itf)?$row_itf->itf_id:'' ?>" type="hidden">
	<label for="username" class="col-sm-3 control-label">สินค้า:</label>
	<div class="col-sm-8">
		<input type="text" name="dealer" class="form-control" value="<?php echo $dealer ?>" readonly="readonly">
	</div>
</div>
<div class="form-group">
	<label for="username" class="col-sm-3 control-label">เอเย่นต์:</label>
	<div class="col-sm-8">
		<input type="text" class="form-control" value="<?php echo $row_agent->username ?>" readonly="readonly">
	</div>
</div>
<div class="form-group">
	<label for="itf_auth" class="col-sm-3 control-label">รหัสในการเชื่อมต่อ:</label>
	<div class="col-sm-8">
		<input type="text" name="itf_auth" class="form-control" id="itf_auth" value="<?php echo ($row_itf)?$row_itf->itf_auth:'' ?>" required="required">
	</div>
</div>
<div class="form-group">
	<label for="itf_chat_url" class="col-sm-3 control-label">Line Chat URL:</label>
	<div class="col-sm-8">
		<input type="url" name="itf_chat_url" class="form-control" id="itf_chat_url" value="<?php echo ($row_itf)?$row_itf->itf_chat_url:'' ?>" placeholder="https://xxx.com/lineadmin2">
	</div>
</div>
<div class="form-group">
	<label for="itf_callback_url" class="col-sm-3 control-label">Line Callback URL:</label>
	<div class="col-sm-8">
		<input type="url" name="itf_callback_url" class="form-control" id="itf_callback_url" value="<?php echo ($row_itf)?$row_itf->itf_callback_url:'' ?>" placeholder="https://xxx.com/line/callback.php">
	</div>
</div>
<?php } ?>