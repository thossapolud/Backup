<div class="">
	<div class="page-header-title">
		<h4 class="page-title">สินค้า <?=$dealer?></h4>
	</div>
</div>

<div class="page-content-wrapper ">
  <div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <button class="btn btn-primary" href="#createAccount" type="button" data-toggle="modal">สร้างบัญชีเอเย่นต์</button>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel">
                <div class="panel-body table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                        <thead>
                            <tr role="row">
								<th width="5%"></th>
								<th width="17%">Website</th>
                                <th width="15%">Username</th>
                                <th width="15%">Password</th>
								<th width="15%">ใช้สมัคร AUTO</th>
                                <th class="text-center" width="30%"></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- END Row -->
 </div>
  <!-- container -->
</div>

<!-- Page content Wrapper -->
<!-- Modals -->
<div class="modal fade" id="createAccount" tabindex="-1" role="dialog" aria-labelledby="createAccount" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" id="modal-content">
      <form class="form-horizontal" id="admin-create-account" action="<?php echo site_url('userpass-agent/add') ?>" method="POST" role="form">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">สร้างบัญชีเอเย่นต์</h4>
        </div>
        <div class="modal-body">
			<div class="form-group">
				<label for="inputDealer" class="col-sm-3 control-label">สินค้า</label>
				<div class="col-sm-8">
					<div class="radio">
						<input type="radio" name="dealer" id="dealer" value="<?=$dealer?>" checked="checked">
						<label for="web<?=$dealer?>"><?=$dealer?></label>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label for="site_id" class="col-sm-3 control-label">สำหรับเว็บไซต์:</label>
				<div class="col-sm-8">
					<select name="site_id" id="site_id" class="form-control" required="required">
						<option value="">== เลือก ==</option>
						<?php foreach ($rs_website->result() as $row_website) {?>
						<option value="<?=$row_website->site_id?>"><?=$row_website->site_name?></option>
						<?php }?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label for="inputUsername" class="col-sm-3 control-label">Username:</label>
				<div class="col-sm-8">
					<input type="text" class="form-control" placeholder="Username" name="username" id="username" required="required">
				</div>
			</div>
			<div class="form-group">
				<label for="inputPassword" class="col-sm-3 control-label">Password:</label>
				<div class="col-sm-8">
					<input type="password" name="password" class="form-control" id="password" placeholder="Password" data-toggle="password" required="required">
				</div>
			</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="submit" >Create New Username</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- END Modals -->
<!-- View Worksheet Modals -->
<div class="modal fade" id="edit-interface-modal" tabindex="-1" role="dialog" aria-labelledby="interfaceView" aria-hidden="false" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<form class="form-horizontal" id="form-edit-interface" action="<?php echo base_url('userpass-agent/edit-interface'); ?>" method="POST" role="form">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">ข้อมูลเชื่อมต่อ</h4>
				</div>
				<div class="modal-body">				 
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
					<button type="submit" class="btn btn-success" >บันทึก</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- END View Worksheet Modals -->

<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        var t = $('#datatables').DataTable({
			"bPaginate": true,
			//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
			//"bFilter": false, //+ ช่องค้นหา
			//"bInfo": false, //+ รายละเอียดจำนวนแถว
            "bProcessing": true,
            "bServerSide": true,
            "sServerMethod": "GET",
            "sAjaxSource": '<?php echo base_url('userpass-agent/all?dl=' . $dealer); ?>',
            "iDisplayLength": 50,
			"columnDefs": [ //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
				{"searchable": true, "orderable": false, "targets":0,'className':'text-center'},
				{
					//"visible":<?php echo ($this->session->userdata('level') != 'admin') ? 'false' : 'true' ?>,
					"searchable": false,
					"orderable": false,
					'className':'text-center',
					"targets":5,
					"render": function(data, type, row) { // Available data available for you within the row
						var x = '<div class="btn-group btn-group-xs" align="center"><a href="<?php echo site_url('userpass-agent/view') ?>/'+data+'" class="open_modal btn btn-default"><i class="ti-search"></i> ดูข้อมูล</a><a data-toggle="modal" data-target="#edit-interface-modal" data-agid="'+data+'" class="btn btn-xs btn-default disabled"><span class="ti-pencil"> แก้ไขข้อมูลเชื่อมต่อ</span></a></div>';
						return x;
					}
				}
			],
			"order": [1, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
        });
	$('#edit-interface-modal').on('show.bs.modal', function (e){
		$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('userpass-agent/form-edit-interface?dl='.$dealer)?>&agid='+$(e.relatedTarget).attr('data-agid'));
	});
    });
</script>