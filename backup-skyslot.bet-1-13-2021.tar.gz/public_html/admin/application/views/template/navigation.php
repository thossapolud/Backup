<?php
$ci =&get_instance();
$ci->load->model('dealer_model');
$ci->load->model('userpass_model');
$ci->load->model('website_model');
$ci->load->model('option_model');
$rs_dealer = $ci->dealer_model->get_by_dealer_status(1)->result();
$rs_website = $ci->website_model->get_by_status(1)->result();
$rs_bank = $ci->option_model->get_by_opt_code('SYS_BANK')->result();
?>

<div class="left side-menu">
	<div class="sidebar-inner slimscrollleft">
		<div class="user-details">
			<div class="user-info">
				<div class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo $this->session->userdata('name') ?></a>
					<ul class="dropdown-menu">
						<li><a href="<?php echo site_url('logout') ?>"> Logout</a></li>
					</ul>
				</div>
				<p class="text-muted m-0"><i class="fa fa-dot-circle-o text-success"></i> Online</p>
			</div>
		</div>
		<!--- Divider -->

		<div id="sidebar-menu">
			<ul>
				<li><a href="<?php echo site_url('home') ?>" class="waves-effect"><i class="mdi mdi-home"></i><span> แผงควบคุม</span></a></li>
				<?php if ($this->session->userdata('level') == 'admin') {?>
				<li class="has_sub"> <a href="javascript:void(0);" class="waves-effect"><i class="ion-gear-b"></i><span> ตั้งค่าข้อมูล </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
					<ul class="list-unstyled">
						<li><a href="<?php echo site_url('account') ?>">ผู้ใช้งาน</a></li>
						<li><a href="<?php echo site_url('promotion') ?>">โปรโมชั่น</a></li>
						<li><a href="<?php echo site_url('website') ?>">เว็บไซต์</a></li>
						<li><a href="<?php echo site_url('transfer-channel') ?>">กลุ่มลูกค้า</a></li>
						<li><a href="<?php echo site_url('userpass-bank/deposit') ?>">บัญชีธนาคารฝาก</a></li>
						<li><a href="<?php echo site_url('userpass-bank/withdraw') ?>">บัญชีธนาคารถอน</a></li>
						<?php foreach ($rs_dealer as $row_dealer) { ?>
							<li><a href="<?php echo site_url('userpass-agent?dl='.$row_dealer->dl_code) ?>">สินค้า <?=$row_dealer->dl_name?></a></li>
						<?php } ?>
					</ul>
				</li>
				<li class="has_sub"> <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-google-pages"></i> <span>ประวัติการใช้งาน</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
					<ul class="list-unstyled">
						<li><a href="<?php echo site_url('history') ?>">ประวัติการใช้งาน</a></li>
						<li><a href="<?php echo site_url('report/account-summary') ?>">การทำงาน</a></li>
					</ul>
				</li>
				<?php }?>
				
				<li class="has_sub"> <a href="javascript:void(0);" class="waves-effect"><i class="ion-android-social-user"></i> <span>สมาชิก</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
					<ul class="list-unstyled">
					<?php foreach ($rs_website as $row_website) { 
						$rs_site_dealer = $ci->userpass_model->get_dealer_by_site_id($row_website->site_id)->result(); ?>
						<li>
							<a href="<?php echo site_url('user?wbid='.$row_website->site_id) ?>">
								<small style="display: block;"><?=$row_website->site_name?></small>
								<span style="display: inline-block; vertical-align: middle;"><i class="ti-arrow-right"></i> ทั้งหมด</span>
							</a>
						</li>
						<?php foreach ($rs_site_dealer as $row_site_dealer) { ?>
							<li>
								<a href="<?php echo site_url('user?wbid='.$row_website->site_id.'&dl='.$row_site_dealer->dl_code) ?>">
									<small style="display: block;"><?=$row_website->site_name?></small>
									<span style="display: inline-block; vertical-align: middle;"><i class="ti-arrow-right"></i> สินค้า <?=$row_site_dealer->dl_name?></span>
								</a>
							</li>
						<?php } ?>
						<li class="dropdown-divider" style="height: 0; margin: .5rem 0; overflow: hidden; border-top: 1px solid #e9ecef;"></li>
					<?php } ?>
					</ul>
				</li>
				<li class="has_sub"> <a href="javascript:void(0);" class="waves-effect"><i class="ion-ios7-paper-outline"></i> <span>ใบงาน</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
					<ul class="list-unstyled">
						<li><a href="<?php echo site_url('worksheet/call') ?>"><i class="ti-arrow-right"></i> CALL ทั้งหมด</a></li>
						<li><a href="<?php echo site_url('worksheet/call/deposit') ?>"><i class="ti-arrow-right"></i> CALL ฝาก</a></li>
						<li><a href="<?php echo site_url('worksheet/call/withdraw') ?>"><i class="ti-arrow-right"></i> CALL ถอน</a></li>
						<li><a href="<?php echo site_url('worksheet/call/transfer') ?>"><i class="ti-arrow-right"></i> CALL โยก</a></li>
						<li><a href="<?php echo site_url('worksheet/bank') ?>"><i class="ti-arrow-right"></i> BANK</a></li>
						<li><a href="<?php echo site_url('worksheet/manage') ?>"><i class="ti-arrow-right"></i> MANAGE</a></li>
						<li><a href="<?php echo site_url('worksheet/all') ?>"><i class="ti-arrow-right"></i> ทั้งหมด</a></li>
					</ul>
				</li>
				<li class="has_sub"> <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-university"></i> <span>ธนาคารฝาก</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
					<ul class="list-unstyled">
					<?php foreach ($rs_website as $row_website) { 
						$rs_bank_ac = $ci->userpass_model->get_active_deposit_withdraw_bank($row_website->site_id,NULL,'deposit')->result(); ?>
						<?php foreach ($rs_bank_ac as $row_bank_ac) { ?>
							<li>
								<a href="<?php echo site_url($row_bank_ac->type.'-statement/ac?acnum='.$row_bank_ac->acnum) ?>">
									<small style="display: block;"><?=$row_website->site_name?></small>
									<span style="display: inline-block; vertical-align: middle;"><i class="thbanks thbanks-<?=$row_bank_ac->type?>" style="background-color: transparent;"></i> <?php echo $row_bank_ac->bankname ?></span>
								</a>
							</li>
						<?php } ?>
						<li class="dropdown-divider" style="height: 0; margin: .5rem 0; overflow: hidden; border-top: 1px solid #e9ecef;"></li>
					<?php } ?>
					</ul>
				</li>
				<li class="has_sub"> <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-university"></i> <span>ธนาคารถอน</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
					<ul class="list-unstyled">
					<?php foreach ($rs_website as $row_website) { 
						$rs_bank_ac = $ci->userpass_model->get_active_deposit_withdraw_bank($row_website->site_id,NULL,'withdraw')->result(); ?>
						<?php foreach ($rs_bank_ac as $row_bank_ac) { ?>
							<li>
								<a href="<?php echo site_url($row_bank_ac->type.'-statement/ac?acnum='.$row_bank_ac->acnum) ?>">
									<small style="display: block;"><?=$row_website->site_name?></small>
									<span style="display: inline-block; vertical-align: middle;"><i class="thbanks thbanks-<?=$row_bank_ac->type?>" style="background-color: transparent;"></i> <?php echo $row_bank_ac->bankname ?></span>
								</a>
							</li>
						<?php } ?>
						<li class="dropdown-divider" style="height: 0; margin: .5rem 0; overflow: hidden; border-top: 1px solid #e9ecef;"></li>
					<?php } ?>
					</ul>
				</li>
				<li class="has_sub"> <a href="javascript:void(0);" class="waves-effect"><i class="glyphicon glyphicon-credit-card"></i> <span>เครดิต</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
					<ul class="list-unstyled">
						<?php foreach ($rs_website as $row_website) { ?>
							<?php foreach ($rs_dealer as $row_dealer) { ?>
								<li>
									<a href="<?php echo site_url('credit?wbid='.$row_website->site_id.'&dl='.$row_dealer->dl_code) ?>">
										<small style="display: block;"><?=$row_website->site_name?> : <?=$row_dealer->dl_code?></small>
										<span style="display: inline-block; vertical-align: middle;"><i class="ti-arrow-right"></i> เติม/ถอน</a></span>
									</a>
								</li>
								<li>
									<a href="<?php echo site_url('credit/deposit-withdraw?wbid='.$row_website->site_id.'&dl='.$row_dealer->dl_code) ?>">
										<small style="display: block;"><?=$row_website->site_name?> : <?=$row_dealer->dl_code?></small>
										<span style="display: inline-block; vertical-align: middle;"><i class="ti-arrow-right"></i> รายการทั้งหมด</a></span>
									</a>
								</li>
							<?php } ?>
						<?php } ?>
					</ul>
				</li>
				<li class="has_sub"> <a href="javascript:void(0);" class="waves-effect"><i class="ti-files"></i> <span>รายงาน</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
					<ul class="list-unstyled">
						<li><a href="<?php echo site_url('report/bank-deposit') ?>"><i class="ti-arrow-right"></i> ธนาคารฝาก</a></li>
						<li><a href="<?php echo site_url('report/bank-withdraw') ?>"><i class="ti-arrow-right"></i> ธนาคารถอน</a></li>
						<!--<li><a href="<?php echo site_url('report/promotion/Pussy888') ?>"><i class="ti-arrow-right"></i> รับโปรโมชั่น Pussy</a></li>
                        <li><a href="<?php echo site_url('report/promotion/918kiss') ?>"><i class="ti-arrow-right"></i> รับโปรโมชั่น 918kiss</a></li>-->
                        <?php foreach ($rs_site_dealer as $row_site_dealer) { ?>
                        <li><a href="<?php echo site_url('report/promotion/'.$row_site_dealer->dl_code) ?>" target="_blank"><i class="ti-arrow-right"></i> รับโปรโมชั่น <?php echo $row_site_dealer->dl_code ?></a></li>
                        <?php } ?>
                        <li><a href="<?php echo site_url('report/summary') ?>"><i class="ti-arrow-right"></i> สรุปยอด </a></li>
					</ul>
				</li>
			</ul>
		</div>
		<div class="clearfix"></div>
	</div>
	<!-- end sidebarinner -->
</div>