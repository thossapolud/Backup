<div class="topbar"> 
  <!-- LOGO -->
  <div class="topbar-left">
    <div class="text-center"> <a href="<?php echo site_url() ?>" class="logo"><span>Sky</span>bet</a> <a href="<?php echo site_url() ?>" class="logo-sm"><span>S</span></a> 
      <!--<a href="index.html" class="logo"><img src="assets/images/logo_white_2.png" height="28"></a>--> 
      <!--<a href="index.html" class="logo-sm"><img src="assets/images/logo_sm.png" height="36"></a>--> 
    </div>
  </div>
  <!-- Button mobile view to collapse sidebar menu -->
  <div class="navbar navbar-default" role="navigation">
    <div class="container">
      <div class="">
        <div class="pull-left">
         <button type="button" class="button-menu-mobile open-left waves-effect waves-light"> <i class="ion-navicon"></i> </button>
          <span class="clearfix"></span> </div>
        <!--<form class="navbar-form pull-left" role="search">
          <div class="form-group">
            <input type="text" class="form-control search-bar" placeholder="Search...">
          </div>
          <button type="submit" class="btn btn-search"><i class="fa fa-search"></i></button>
        </form>-->
        <ul class="nav navbar-nav navbar-right pull-right">
          <li class="hidden-xs"> <a href="#" id="btn-fullscreen" class="waves-effect waves-light notification-icon-box"><i class="mdi mdi-fullscreen"></i></a> </li>
          <li class="dropdown"> <a href="" class="dropdown-toggle profile waves-effect waves-light" data-toggle="dropdown" aria-expanded="true"> <img src="<?php echo base_url('assets/images/users/avatar-1.jpg') ?>" alt="user-img" class="img-circle"> <span class="profile-username"> <?php echo $this->session->userdata('name') ?> <br/>
            <small><?php echo $this->session->userdata('level') ?></small> </span> </a>
            <ul class="dropdown-menu">
              <!--<li><a href="javascript:void(0)"> Profile</a></li>
              <li><a href="javascript:void(0)"><span class="badge badge-success pull-right">5</span> Settings </a></li>
              <li><a href="javascript:void(0)"> Lock screen</a></li>
              <li class="divider"></li>-->
              <li><a href="<?php echo site_url('logout') ?>"> Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
      <!--/.nav-collapse --> 
    </div>
  </div>
</div>