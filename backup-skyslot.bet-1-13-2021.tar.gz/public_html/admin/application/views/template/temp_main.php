<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title><?php echo $this->titlecomponent->output(); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="Admin Dashboard" name="description" />
        <meta content="ThemeDesign" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- CSS -->
        <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url('assets/css/icons.css') ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet" type="text/css">     
        <!-- DataTables -->
        <link href="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.css') ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/plugins/datatables/buttons.bootstrap.min.css') ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/plugins/datatables/fixedHeader.bootstrap.min.css') ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/plugins/datatables/responsive.bootstrap.min.css') ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.css') ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url('assets/plugins/datatables/scroller.bootstrap.min.css') ?>" rel="stylesheet" type="text/css" />
        <!-- Sweet Alert -->
        <link href="<?php echo base_url('assets/plugins/bootstrap-sweetalert/sweetalert.css') ?>" rel="stylesheet" type="text/css">
        <!-- Datepicker CSS -->
		<link href="<?php echo base_url('assets/plugins/datepicker-master/bootstrap-datepicker3.css') ?>" rel="stylesheet">   
        <link href="<?php echo base_url('assets/plugins/datepicker-master/bootstrap-datetimepicker.min.css ') ?>" rel="stylesheet">   
        <!-- ThBank CSS -->
        <link href="<?php echo base_url('assets/plugins/thbank/thbanklogos.min.css') ?>" rel="stylesheet"> 
        <!-- Easy-autocomplete CSS -->
		<link href="<?php echo base_url('assets/plugins/easy-autocomplete/easy-autocomplete.min.css') ?>" rel="stylesheet">    
        <!-- jQuery  -->
        <script src="<?php echo base_url('assets/js/jquery.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/modernizr.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/detect.js')?>"></script>
        <script src="<?php echo base_url('assets/js/fastclick.js')?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.slimscroll.js')?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.blockUI.js')?>"></script>
        <script src="<?php echo base_url('assets/js/waves.js')?>"></script>
        <script src="<?php echo base_url('assets/js/wow.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.nicescroll.js')?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.scrollTo.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap-show-password.min.js') ?>"></script>
        <!-- Datatables-->
        <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.buttons.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/buttons.bootstrap.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/jszip.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/pdfmake.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/vfs_fonts.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/buttons.html5.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/buttons.print.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.fixedHeader.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.keyTable.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.responsive.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/responsive.bootstrap.min.js')?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.scroller.min.js')?>"></script>
        <!-- Initialize Form Validation -->		
        <script src="<?php echo base_url('assets/plugins/formValidation/jquery.validate.js') ?>"></script>
        <!-- Sweet-Alert  -->
        <script src="<?php echo base_url('assets/plugins/bootstrap-sweetalert/sweetalert.min.js') ?>"></script>
        <!-- Datepicker -->
        <script src="<?php echo base_url('assets/plugins/datepicker-master/bootstrap-datepicker.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/plugins/datepicker-master/locales/bootstrap-datepicker.th.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/plugins/datepicker-master/bootstrap-datetimepicker.js') ?>"></script> 
        <script src="<?php echo base_url('assets/plugins/datepicker-master/locales/bootstrap-datetimepicker.th.js') ?>"></script>
        <!-- Copy2clipboard -->
    	<script src="<?php echo base_url('assets/plugins/copy2clipboard/copy2clipboard.js') ?>"></script>
    	<script src="<?php echo base_url('assets/plugins/copy2clipboard/copy2clipboard-extra.js') ?>"></script>
        <!-- Easy-autocomplete JS -->
        <script src="<?php echo base_url('assets/plugins/easy-autocomplete/jquery.easy-autocomplete.min.js') ?>"></script> 
        <!-- Loadingoverlay JS -->
        <script src="<?php echo base_url('assets/plugins/loadingoverlay/loadingoverlay.js') ?>"></script>
        <script type="text/javascript">
		$(function(){
			//sweetAlertInitialize();
		<?php if($this->session->flashdata('msg_error')){ ?>
            swal("Sorry!", "<?php echo $this->session->flashdata('msg_error') ?>", "error");	
        <?php } ?>
        <?php if($this->session->flashdata('msg_success')){ ?>
            swal({
              title: "Good job!",
              text: "<?php echo $this->session->flashdata('msg_success') ?>",
              imageUrl: '<?php echo base_url('assets/plugins/bootstrap-sweetalert/thumbs-up.jpg') ?>'
            });
        <?php } ?>
			$(".datepicker").datepicker({
				 language:'th',
				 format: "yyyy-mm-dd",
				 /*startDate: '-3d',*/
				 endDate: '0d',
				 todayHighlight: true,
				 autoclose: true
			});
			$('.date-main').datetimepicker({
				language:'th',
				weekStart: 1,
				todayBtn:  1,
				autoclose: 1,
				todayHighlight: 1,
				startView: 2,
				forceParse: 0,
				minuteStep:1
			});
			$('.modal').on("hidden.bs.modal", function (e) {
				if($('.modal:visible').length){
					$('.modal-backdrop').first().css('z-index', parseInt($('.modal:visible').last().css('z-index')) - 10);
					$('body').addClass('modal-open');
				}
			}).on("show.bs.modal", function (e) {
				if($('.modal:visible').length){
					$('.modal-backdrop.in').first().css('z-index', parseInt($('.modal:visible').last().css('z-index')) + 10);
					$(this).css('z-index', parseInt($('.modal-backdrop.in').first().css('z-index')) + 10);
				}
			});
		});
		</script>
    </head>
    <body class="fixed-left">
        <!-- Begin page -->
        <div id="wrapper">
            <!-- Top Bar Start -->
             <?php $this->load->view('template/top-navbar'); ?>
            <!-- Top Bar End -->
            <!-- ========== Left Sidebar Start ========== -->
            <?php $this->load->view('template/navigation'); ?>
            <!-- Left Sidebar End -->
            <!-- Start right Content here -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                <?php echo $Content ?>
                </div> <!-- content -->
                <footer class="footer">
                     © 2020 skyslot.bet - All Rights Reserved. {elapsed_time}
                </footer>
            </div>
            <!-- End Right content here -->
        </div>
        <!-- END wrapper -->
        <!-- Modals Setdata -->
        <div class="modal fade" id="Setdata" tabindex="-1" role="dialog" aria-labelledby="Setdata" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content" id="modal-content">
              <form class="form-horizontal" id="form-setdata" method="POST" role="form">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h4 class="modal-title" id="myModalLabel">ใส่ข้อมูลด้านล่าง</h4>
                </div>
                <div class="modal-body">
                  <div class="form-group  ">
                    <div class="col-sm-12">
                      <textarea id="data-forset" rows="10" class="form-control"></textarea>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary" id="submit-setdata" >เซ็ตข้อมูล</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- END Modals Setdata -->
        <script>
		$(document).ready(function (){			
			$('#submit-setdata').click(function(){
				var data = $('#data-forset').val();
				if(data!=''){					
					var res = data.split("\n");
					if(res.length==8){
						for (i=0;i<res.length;i++){
							var res_2 = res[i].split(":");
							if($.trim(res_2[0])=='ชื่อเล่น')$('#nickname').val($.trim(res_2[1]));
							if($.trim(res_2[0])=='เบอร์โทร')$('#phone').val($.trim(res_2[1]));
							if($.trim(res_2[0])=='ธนาคารที่สะดวก')$('#bank').val($.trim(res_2[1]));
							if($.trim(res_2[0])=='เลขบัญชี')$('#bankno').val($.trim(res_2[1]));
							if($.trim(res_2[0])=='ชื่อบัญชี')$('#accountname').val($.trim(res_2[1]));
							if($.trim(res_2[0])=='สาขา')$('#bankbranch').val($.trim(res_2[1]));
							if($.trim(res_2[0])=='รหัสแจ้งถอน')$('#withdrawcode').val($.trim(res_2[1]));
							if($.trim(res_2[0])=='ไลน์ไอดี')$('#lineid').val($.trim(res_2[1]));					
						}
						alert('เซ็ตเรียบร้อย');
					}			
				}
			});
			$('#data').val('');
			$('#copy-data').click(function(){
				var phone = ($('#phone').val()===undefined)?'':$('#phone').val();
				var lineid = ($('#lineid').val()===undefined)?'':$('#lineid').val();				
				var data = '';
				data += 'ชื่อเล่น : '+$('#nickname').val()+'\n';
				data += 'เบอร์โทร : '+phone+'\n';
				data += 'ธนาคารที่สะดวก : '+$('#bank').val()+'\n';			
				data += 'เลขบัญชี : '+$('#bankno').val()+'\n';
				data += 'ชื่อบัญชี : '+$('#accountname').val()+'\n';
				data += 'สาขา : '+$('#bankbranch').val()+'\n';
				data += 'รหัสแจ้งถอน : '+$('#withdrawcode').val()+'\n';
				data += 'ไลน์ไอดี : '+lineid;
				$('#data').val(data);	
				var copyText = document.getElementById('data');
				copyText.select();
				document.execCommand("Copy");
				$('#copy-to-clipboard').trigger('click');
				swal("บันทึกลง Clipbaord สำเร็จ", "", "success");
			});
		});
		</script>                 
        <!--Morris Chart-->
        <!--<script src="assets/plugins/morris/morris.min.js"></script>
        <script src="assets/plugins/raphael/raphael-min.js"></script>
        <script src="assets/pages/dashborad.js"></script>-->
        <script src="<?php echo base_url('assets/plugins/parsleyjs/parsley.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/app.js' )?>"></script>
        <script src="<?php echo base_url('assets/plugins/fancybox/easydrag.js') ?>"></script>
        <script type="text/javascript">
			$(function(){$(".fancybox-close").easydrag();});
		</script>   
    </body>
</html>