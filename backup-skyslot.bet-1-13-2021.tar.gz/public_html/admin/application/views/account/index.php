<div class="">
  <div class="page-header-title">
    <h4 class="page-title">ผู้ใช้งาน</h4>
  </div>
</div>
<div class="page-content-wrapper ">
    <div class="container"> 
        <div class="row">                                     
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
						<div class="col-sm-12 col-md-5">
                        	<button class="btn btn-primary" href="#createAccount" type="button" data-toggle="modal">สร้างผู้ใช้ใหม่</button>
						</div>
						<div class="col-sm-12 col-md-7 right">
							<form id="form-line-notify" action="<?php echo site_url('account/udpate-line-notify') ?>" class="form-inline pull-right" method="post">
								<div class="input-group">
									<input class="form-control" type="text" name="line_notify_token" value="<?php echo $row_line_notify_token->opt_value ?>" autocomplete="off" placeholder="Lint Notify Token" required>
									<span class="input-group-btn">
										<button class="btn btn-primary" type="submit">บันทึก</button>
									</span>
								</div>
							</form>
						</div>
                    </div>
                </div>
            </div>                                     
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th width="30%">ชื่อ</th>
                              <th>&nbsp;</th>
                              <th width="15%">username</th>
                              <th width="15%">อีเมล์</th>
                              <th width="15%">เบอร์โทร</th>
                              <th class="text-center" width="5%"></th>
                            </tr>
                          </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- row -->        
    </div>
  <!-- container -->   
</div>
<!-- Page content Wrapper -->
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
		var t = $('#datatables').DataTable({
			"bPaginate": true, 
			//"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
			//"bFilter": false, //+ ช่องค้นหา
			//"bInfo": false, //+ รายละเอียดจำนวนแถว
			"bProcessing": true,
			"bServerSide": true,
			"sServerMethod": "GET",
			"sAjaxSource": '<?php echo base_url('account/all'); ?>',
			"iDisplayLength": 50,
			"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
				{"searchable": true, "orderable": false, "targets":0},
				{"visible": false, "targets":2},
				{
					//"visible":<?php echo ($this->session->userdata('level')!='admin')?'false':'true' ?>,
					"searchable": false, 
					"orderable": false, 
					'className':'text-center',
					"targets":6,
					"render": function(data, type, row) { // Available data available for you within the row
						var x = '<div class="btn-group btn-group-xs" align="center"><a href="<?php echo site_url('account/view') ?>/'+data+'" class="open_modal btn btn-default"><i class="ti-search"></i> ดูข้อมูล</a></div>';
						return x;
					}
				}
			],
			"order": [1, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
		});
	});
</script>
<!-- Modals -->
<div class="modal fade" id="createAccount" tabindex="-1" role="dialog" aria-labelledby="createAccount" aria-hidden="true">
  <div class="modal-dialog">
	<div class="modal-content" id="modal-content">
	  <form class="form-horizontal" id="admin-create-account" action="<?php echo site_url('account/add') ?>" method="POST" role="form">
		<div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		  <h4 class="modal-title" id="myModalLabel">สร้างผู้ใช้ใหม่</h4>
		</div>
		<div class="modal-body">
		  <div class="form-group  ">
			<label for="inputAame" class="col-sm-3 control-label">ชื่อ:</label>
			<div class="col-sm-8">
			  <input type="text" name="name" class="form-control" id="name" placeholder="ชื่อ" value="">
			</div>           
		  </div>
		  <div class="form-group ">
			<label for="inputUsername" class="col-sm-3 control-label">ยูสเซอร์:</label>
			<div class="col-sm-4">
			   <input type="text" class="form-control" placeholder="Username" name="username" id="username">
			</div>
			<div class="col-sm-4">              
			  <input type="password" name="password" class="form-control" id="password" placeholder="Password" value="">
			</div>            
		  </div>
		  <div class="form-group  ">
			<label for="inputPhone" class="col-sm-3 control-label">เบอร์ติดต่อ:</label>
			<div class="col-sm-4">
			  <input type="tel" name="phone" class="form-control" id="phone" placeholder="0891234567" value="">
			</div>
			<div class="col-sm-4">
			  <input name="email" type="text" class="form-control" id="email" placeholder="E-mail@gmail.com" value="">
			</div>
			<div class="col-sm-4"> <small></small> </div>
		  </div>
          <div class="form-group  ">
			<label for="inputPhone" class="col-sm-3 control-label">Level:</label>
			<div class="col-sm-4">
			  <select  class="form-control" name="level" id="Level">
                <option value="staff" selected>staff</option>
                <option value="manager">manager</option>
              </select>
			</div>
			<div class="col-sm-4"> <small></small> </div>
			<div class="col-sm-4"> <small></small> </div>
		  </div>
		</div>
		<div class="modal-footer">
		  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  <button type="submit" class="btn btn-primary" id="submit" >Create New Account</button>
		</div>
	  </form>
	</div>
  </div>
</div>
<!-- END Modals -->
<!-- Initialize Form Validation -->
<script src="<?php echo base_url('assets/plugins/formValidation/accountadminFormsValidation.js') ?>"></script>
<script>
$(document).ready(function (){
	FormsValidation.init();	
	$('#username').blur(function(){
		if($(this).val()!=''){
			$.LoadingOverlay("show");
			$.ajax({
				type: 'POST',
				dataType: 'json',
				cache: false,
				url: '<?php echo site_url('account/check-username') ?>',
				data: {username:$(this).val()},
				success: function(resp){
					$.LoadingOverlay("hide");
					if(resp.result=='Y'){
						swal("username นี้มีในระบบแล้ว", 'ชื่อ : '+resp.name, "error");
						$('#username').val('');
					}
				}
			});
		}
	});
});
</script>