<div class="">
  <div class="page-header-title">
    <h4 class="page-title">Account : <?php echo $row_account->username ?></h4>
  </div>
</div>
<div class="page-content-wrapper ">
  <div class="container"> 
	<div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel">
              <div class="panel-heading"> 
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                  <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">General Info</a></li>              
                  <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Edit Account</a></li>
                  <li role="presentation"><a href="#loginout-log" aria-controls="loginout-log" role="tab" data-toggle="tab">Login / Logout</a></li>
                  <li role="presentation"><a href="#history-log" aria-controls="history-log" role="tab" data-toggle="tab">History</a></li>
                </ul>
              </div>
              <div class="panel-body"> 
                <!-- Tab panes -->
                <div class="tab-content">
                  <div role="tabpanel" class="tab-pane active" id="home">
                    <form class="form-horizontal" method="POST" role="form">
                      <div class="form-group">
                        <label for="registered" class="col-sm-2 col-md-2 control-label">ชื่อ:</label>
                        <div class="col-sm-4 col-md-4">
                          <p class="form-control-static"><?php echo $row_account->name ?></p>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="username" class="col-sm-2 col-md-2 control-label">Username:</label>
                        <div class="col-sm-4 col-md-4">
                          <p class="form-control-static"><?php echo $row_account->username ?></p>
                        </div>                   
                      </div>
                      <div class="form-group">
                        <label for="username" class="col-sm-2 col-md-2 control-label">เบอร์โทร:</label>
                        <div class="col-sm-4 col-md-4">
                          <p class="form-control-static"><?php echo $row_account->phone ?></p>
                        </div>                   
                      </div>
                      <div class="form-group">
                        <label for="username" class="col-sm-2 col-md-2 control-label">Email:</label>
                        <div class="col-sm-4 col-md-4">
                          <p class="form-control-static"><?php echo $row_account->email ?></p>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="registeredfromip" class="col-sm-2 col-md-2 control-label">Level:</label>
                        <div class="col-sm-4 col-md-4">
                          <p class="form-control-static"><?php echo $row_account->level ?></p>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="registeredfromip" class="col-sm-2 col-md-2 control-label">สถานะ:</label>
                        <div class="col-sm-4 col-md-4">
                          <p class="form-control-static"><?php echo $row_account->status ?></p>
                        </div>
                      </div>                  
                    </form>
                  </div>              
                  <div role="tabpanel" class="tab-pane" id="profile">
                    <div class="modal-content" id="modal-content">
                      <form class="form-horizontal" id="admin-edit-account" action="<?php echo site_url('account/edit') ?>" method="POST" role="form">
                        <div class="form-group">
                            <div class="col-sm-4 col-md-3 col-lg-3"> </div>
                        </div>
                        <div class="form-group  ">
                            <label for="inputAame" class="col-sm-3 control-label">ชื่อ:</label>
                            <div class="col-sm-8">
                              <input type="text" name="name" class="form-control" id="name" placeholder="ชื่อ" value="<?php echo $row_account->name ?>">
                            </div>           
                        </div>
                        <div class="form-group ">
                            <label for="inputUsername" class="col-sm-3 control-label">Username:</label>
                            <div class="col-sm-4">
                               <input type="text" class="form-control" placeholder="Username" name="username" id="username" value="<?php echo $row_account->username ?>" readonly>
                            </div>
                            <div class="col-sm-4">              
                              <input type="password" name="password" class="form-control" id="password" placeholder="หากไม่เปลี่ยนให้ว่างไว้">
                            </div>            
                        </div>
                        <div class="form-group  ">
                            <label for="inputPhone" class="col-sm-3 control-label">เบอร์ติดต่อ:</label>
                            <div class="col-sm-4">
                              <input type="tel" name="phone" class="form-control" id="phone" placeholder="0891234567" value="<?php echo $row_account->phone ?>">
                            </div>
                            <div class="col-sm-4">
                              <input name="email" type="text" class="form-control" id="email" placeholder="E-mail@gmail.com" value="<?php echo $row_account->email ?>">
                            </div>
                            <div class="col-sm-4"> <small></small> </div>
                        </div>                    
                        <div class="form-group  ">
                        	<label for="inputPhone" class="col-sm-3 control-label">Level:</label>
                            <div class="col-sm-3">
                              <select  class="form-control" name="level" id="Level">
                                <option value="staff" <?php echo ($row_account->level=='staff')?'selected':'' ?>>staff</option>
                                <option value="manager" <?php echo ($row_account->level=='manager')?'selected':'' ?>>manager</option>
                              </select>
                            </div>
                            <label for="inputType" class="col-sm-2 control-label">สถาน:</label>
                            <div class="col-sm-3 col-md-3">
                                <select  class="form-control" name="status" id="inputStatus">
                                    <option value="ใช้" <?php echo ($row_account->status=='ใช้')?'selected':'' ?>>ใช้</option>
                                    <option value="เลิกใช้" <?php echo ($row_account->status=='เลิกใช้')?'selected':'' ?>>เลิกใช้</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-4 col-md-3"></div>
                            <div class="col-sm-4 col-md-4">
                            <input name="accounttoedit" value="<?php echo $row_account->ac_id ?>" type="hidden">
                            <button type="submit" id="submit" name="button" value="Edit Account" class="btn btn-default"><i class=" fa fa-refresh "></i> Submit Changes</button>
                            </div>
                        </div>
                      </form>
                    </div><!-- End <div class="modal-content" id="modal-content"> -->
                  </div><!-- End <div role="tabpanel" class="tab-pane" id="profile"> -->
                  <div role="tabpanel" class="tab-pane" id="loginout-log">
                    <div class="form-group">
                     <?php if($rs_loginout->num_rows()>0){ ?>
                        <label for="registered" class="col-sm-2 col-md-2 control-label"></label>
                        <div class="col-sm-10 col-md-10">
                        <?php foreach($rs_loginout->result() as $row_loginout){ ?>
                          <p class="form-control-static"><?php echo $row_loginout->action ?> วันที่ : <?php echo $row_loginout->created ?> / IP : <?php  echo $row_loginout->ip_address ?></p>
                        <?php } ?>
                        </div>
                      <?php } ?>
                    </div>
                  </div><!-- End <div role="tabpanel" class="tab-pane" id="loginout-log"> -->
                  <div role="tabpanel" class="tab-pane" id="history-log">
                    <div class="form-group">
                     <?php if($rs_history->num_rows()>0){ ?>
                        <label for="registered" class="col-sm-2 col-md-2 control-label"></label>
                        <div class="col-sm-10 col-md-10">
                        <?php foreach($rs_history->result() as $row_history){ ?>
                          <?php $detail = json_decode($row_history->detail,true); ?>
                          <p class="form-control-static"><?php echo $row_history->action ?> Username : <strong><?php echo $detail['username'] ?></strong> / วันที่ : <?php echo $row_history->created ?> / IP : <?php  echo $row_history->ip_address ?></p>
                        <?php } ?>
                        </div>
                      <?php } ?>
                    </div>
                  </div><!-- End <div role="tabpanel" class="tab-pane" id="history-log"> -->
                </div>
              </div>
            </div><!-- End panel -->
        </div>
    </div><!-- End row -->    
  </div>
  <!-- container -->   
</div>
<!-- Page content Wrapper -->
<!-- Initialize Form Validation -->
<script src="<?php echo base_url('assets/plugins/formValidation/adminEditaccountFormsValidation.js') ?>"></script>
<script>$(function() { FormsValidation.init(); });</script>  

<script type="text/javascript">
$(function() {
	// Javascript to enable link to tab
	var hash = document.location.hash;
	if (hash) {
		console.log(hash);
		$('.nav-tabs a[href='+hash+']').tab('show');
	}	
	// Change hash for page-reload
	$('a[data-toggle="tab"]').on('show.bs.tab', function (e) {
		window.location.hash = e.target.hash;
	});
	/*$('#username').blur(function(){
		if($(this).val()!=''){
			$.LoadingOverlay("show");
			$.ajax({
				type: 'POST',
				dataType: 'json',
				cache: false,
				url: '<?php //echo site_url('account/check-username') ?>',
				data: {username:$(this).val(),accountid:$('#accounttoedit').val()},
				success: function(resp){
					$.LoadingOverlay("hide");
					if(resp.result=='Y'){
						swal("username นี้มีในระบบแล้ว", 'ชื่อ : '+resp.name, "error");
						$('#username').val($('#usernameold').val());
					}
				}
			});
		}
	});*/
});
</script>