<div class="">
	<div class="page-header-title">
		<h4 class="page-title">สมาชิก : <?=$row_website->site_name?> : <?=$dealer?$dealer:'ทุกสินค้า'?></h4>
	</div>
</div>

<div class="page-content-wrapper ">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body">
						<!-- <button class="btn btn-primary" href="#createUser" type="button"
							data-toggle="modal">สร้างสมาชิกใหม่</button> -->
						<!--<a href="javascript:void(0);" class="btn btn-success pull-right" id="set-agid"><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> จัดการ AG ID</a>-->
						<form id="form-ag" action="<?php echo site_url('user') ?>" class="form-inline" method="get">
							<input type="hidden" name="wbid" id="wbid" value="<?=$row_website->site_id?>">
							<?php if ($dealer) { ?>
							<input type="hidden" name="dl" id="dl" value="<?=$dealer?>">
							<select name="agid" id="agid" class="form-control">
								<option value="">=== แสดงทุกเอเย่นต์ ===</option>
								<?php foreach ($rs_agent->result() as $row_agent) {?>
								<option value="<?php echo $row_agent->userpass_id ?>"
									<?php echo ($agent_id == $row_agent->userpass_id) ? 'selected' : '' ?>>
									<?php echo $row_agent->username ?></option>
								<?php }?>
							</select>
							<?php } else { ?>
							<select name="dl" id="dl" class="form-control">
								<option value="">=== แสดงทุกสินค้า ===</option>
								<?php foreach ($rs_dealer->result() as $row_dealer) {?>
								<option value="<?php echo $row_dealer->dl_code ?>">
									<?php echo $row_dealer->dl_code ?></option>
								<?php }?>
							</select>
							<?php } ?>					
							<button class="btn btn-primary" href="#createUser" type="button" data-toggle="modal" <?php echo ($row_website->site_id && $dealer) ? '':'disabled="disabled"' ?>>สร้างสมาชิกใหม่</button>
						</form>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="panel">
					<div class="panel-body table-responsive">
						<table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
							<thead>
								<tr role="row">
									<th></th>
									<th>ยูสเซอร์</th>
									<th></th>
									<th></th>
									<th>วันที่สมัคร</th>
									<th>เบอร์โทร.</th>
									<th>ธนาคาร</th>
									<th>ชื่อบัญชี</th>
									<th>เลขบัญชี</th>
									<th>มาจาก</th>
									<th class="text-center"></th>
									<th></th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<!-- END Row -->
	</div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->

<script type="text/javascript" charset="utf-8">
	$("#agid, #dl").change(function () {
		$('#form-ag').submit();
	});
	$(document).ready(function () {
		var t = $('#datatables').DataTable({
			"bPaginate": true,
			"bLengthChange": true, //+ แสดงจำนวนต่อหน้า
			//"bFilter": false, //+ ช่องค้นหา
			//"bInfo": false, //+ รายละเอียดจำนวนแถว
			"bProcessing": true,
			"bServerSide": true,
			"sServerMethod": "GET",
			"sAjaxSource": '<?php echo base_url('user/all?&wbid='.$row_website->site_id.'&dl='.$dealer.'&agid='.$agent_id); ?>',
			"iDisplayLength": 50,
			"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
				{ "searchable": true, "orderable": false, "targets": 0 },
				{ "visible": false, "targets": [9,11] },
				{
					//"visible":<?php echo ($this->session->userdata('level')!='admin')?'false':'true' ?>,
					"searchable": false,
					"orderable": false,
					'className': 'text-center',
					"targets": 10,
					"render": function (data, type, row) { // Available data available for you within the row
						var x = '<div class="btn-group btn-group-xs" align="center"><a href="<?php echo site_url('user/view') ?>/' + data + '/'+row[9]+'" class="open_modal btn btn-default"><i class="ti-search"></i> ดูข้อมูล</a><a href="<?php echo site_url('user/deposit-withdraw') ?>/' + data + '/'+row[9]+'" target="_blank" class="open_modal btn btn-default"><i class="mdi mdi-history"></i> ประวัติ</a></div>';
						return x;
					}
				},
				{
					'className': 'text-center',
					"targets": 2,
					"render": function (data, type, row) { // Available data available for you within the row
						if (data == 'มิจฉาชีพ') {
							var x = '<span class="badge badge-error">'+data+'</span>'
						} else if (data == 'คนที่ต้องระวัง') {
							var x = '<span class="badge badge-error">'+data+'</span>'
						} else {
							var x = '<span class="badge">'+data+'</span>'
						}
						return x;
					}
				}
			],
			"order": [11, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
        });
	$('#check-bankno').click(function () {
		if ($('#bankno').val() != '') {
			$('.glyphicon-refresh').show();
			$.ajax({
				type: 'POST',
				dataType: 'json',
				cache: false,
				url: '<?php echo site_url('user/check-bankno') ?>',
				data: { bankno: $('#bankno').val(), site_id: $('#site_id').val(), dealer: $('#dealer').val(), userpass_id: $('#userpass_id').val() },
				success: function (resp) {
					$('.glyphicon-refresh').hide();
					if (resp.result == 'Y') {
						swal("เลขบัญชีนี้มีในระบบแล้ว", 'เกม: ' + resp.dealer + ' / เอเยนต์ไอดี: ' + resp.userpass_id + ' / ชื่อ : ' + resp.accountname + ' / Username : ' + resp.username, "error");
					} else {
						swal({
							title: "Good job!",
							text: "เลขบัญชีนี้ยังไม่มีในระบบ",
							imageUrl: '<?php echo base_url('images/ thumbs - up.jpg') ?>'
						});
					}
				}
			});
		}
	});
	$('#get-userid-slotxo').click(function () {
		if ($('#userpass_id').val() != '' && $('#username').val() != '') {
			$.LoadingOverlay("show");
			$.ajax({
				type: 'POST',
				dataType: 'json',
				cache: false,
				url: '<?php echo site_url('website-slotxo/get-userid-slotxo') ?>',
				data: { userpass_id: $('#userpass_id').val(), 'username': $('#username').val() },
				success: function (resp) {
					$.LoadingOverlay("hide");
					if (resp.error == 1) {
						$('#userid').val(resp.userid);
						swal({ title: resp.text, confirmButtonText: 'OK' });
					} else {
						$('#userid').val(resp.userid);
						swal({ title: resp.text, confirmButtonText: 'OK' });
					}
				}
			});
		}else {
			swal("เลือก เอเย่นต์ และ กรอก Username");
		}
	});
	$('#waitopen').change(function () {
		$("#username").val('').prop("disabled", $(this).is(':checked'));
	});
	$('#gen_user').change(function () {
		$("#waitopen").val('').prop("disabled", $(this).is(':checked'));
		$("#username").val('').prop("disabled", $(this).is(':checked'));
		$("#withdrawcode").val('').prop("disabled", $(this).is(':checked'));
	});
	$('#set-agid').click(function () {
		$('#set-agid span.glyphicon-refresh').show();
		$.ajax({
			type: 'POST',
			//dataType: 'json',
			cache: false,
			url: '<?php echo site_url('website-slotxo/set-agid') ?>',
			data: { method: 'setagid' },
			success: function (resp) {
				swal({ title: resp, confirmButtonText: 'OK' }, function () { $('#set-agid span.glyphicon-refresh').hide('slow'); });
			}
			});
		});
    });
</script>

<!-- Modals -->
<div class="modal fade" id="createUser" tabindex="-1" role="dialog" aria-labelledby="createUser" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<form class="form-horizontal" id="admin-create-user" action="<?php echo site_url('user/add') ?>"
				method="POST" role="form">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">สร้างสมาชิกใหม่ <button class="btn btn-success"
							href="#Setdata" type="button" data-toggle="modal">เซ็ตข้อมูล</button></h4>
				</div>
				<div class="modal-body">
					<div class="form-group  ">
						<label for="inputWebsite" class="col-sm-3 control-label">เว็บไซต์:</label>
						<div class="col-sm-7">
							<div class="radio">
								<input type="radio" name="site_id" id="site_id" value="<?=$row_website->site_id?>" checked="checked" />
								<label for="website"><?=$row_website->site_name?></label>
							</div>
						</div>
					</div>
					<div class="form-group  ">
						<label for="inputDealer" class="col-sm-3 control-label">ตัวเกมส์สินค้า:</label>
						<div class="col-sm-7">
							<div class="radio">
								<input type="radio" name="dealer" id="dealer" value="<?=$dealer?>" checked="checked" />
								<label for="dealer"><?=$dealer?></label>
							</div>
						</div>
					</div>
					<div class="form-group  ">
						<label for="inputAgent" class="col-sm-3 control-label">เอเย่นต์:</label>
						<div class="col-sm-4">
							<select class="form-control" name="userpass_id" id="userpass_id">
								<option value="">==เลือก==</option>
								<?php foreach ($rs_agent->result() as $row_username) { ?>
								<!-- <option value="<?php echo $row_username->userpass_id ?>"><?php echo $row_username->username ?></option> -->
								<option value="<?php echo $row_username->userpass_id ?>"
									<?php echo ($agent_id == $row_username->userpass_id) ? 'selected' : '' ?>>
									<?php echo $row_username->username ?></option>
								<?php }?>
								<?php echo $agent_id . $row_username->userpass_id ?>
							</select>
						</div>
						<div class="col-sm-4">
							<div class="checkbox checkbox-default">
								<input type="checkbox" value="Y" name="gen_user" id="gen_user" <?php echo (in_array($dealer,unserialize(CONST_DL_C_G_USER))) ? 'checked="checked"' : 'disabled' ?>>
								<label for="gen_user">Gen ยูส/รหัสอัตโนมัติ</label>
							</div>
						</div>
					</div>
					<div class="form-group ">
						<label for="inputUsername" class="col-sm-3 control-label">ยูสเซอร์:</label>
						<div class="col-sm-4">
							<div class="input-group">
								<span class="input-group-addon">
									<input type="checkbox" title="รอเปิด" value="Y" name="waitopen" id="waitopen" <?php echo (in_array($dealer,unserialize(CONST_DL_C_G_USER))) ? 'disabled' : '' ?>>
								</span>
								<input type="text" class="form-control" placeholder="Username" name="username"
									id="username" <?php echo (in_array($dealer,unserialize(CONST_DL_C_G_USER))) ? 'disabled' : '' ?>>
							</div>
						</div>
						<div class="col-sm-4">
							<input type="text" name="withdrawcode" class="form-control" id="withdrawcode"
								placeholder="รหัสผ่านในการเข้าเกมส์" value="" <?php echo (in_array($dealer,unserialize(CONST_DL_C_G_USER))) ? 'disabled' : '' ?>>
						</div>
					</div>
					<div class="form-group ">
						<label for="inputUserid" class="col-sm-3 control-label">UserID <?=$dealer?>:</label>
						<div class="col-sm-4">
							<input type="text" name="userid" class="form-control" id="userid"
								placeholder="UserID <?=$dealer?>" value="" readonly>
						</div>
						<div class="col-sm-4">
							<button class="btn btn-success" id="get-userid-slotxo" type="button" 
									disabled>ดึง UserID <?=$dealer?> <span
									class="glyphicon glyphicon-refresh glyphicon-refresh-animate"
									style="display:none;"></span></button>
						</div>
					</div>
					<div class="form-group">
						<label for="inputAccountname" class="col-sm-3 control-label">ชื่อบัญชี:</label>
						<div class="col-sm-4">
							<input type="text" name="accountname" class="form-control" id="accountname"
								placeholder="ชื่อบัญชีธนาคาร" value="">
						</div>
					</div>
					<div class="form-group  ">
						<label for="bank" class="col-sm-3 control-label">ธนาคาร:</label>
						<div class="col-sm-8">
							<select class="form-control" name="bank" id="bank">
								<option value="">==เลือกธนาคาร==</option>
								<option value="KBANK">KBANK - ธนาคารกสิกรไทย</option>
								<option value="SCB">SCB - ธนาคารไทยพาณิชย์</option>
								<option value="BBL">BBL - ธนาคารกรุงเทพ</option>
								<option value="KTB">KTB - ธนาคารกรุงไทย</option>
								<option value="TMB">TMB - ธนาคารทหารไทย</option>
								<option value="BAY">BAY - ธนาคารกรุงศรีอยุธยา</option>
								<option value="GSB">GSB - ธนาคารออมสิน</option>
								<option value="ISBT">ISBT - ธนาคารอิสลาม</option>
								<option value="GHB">GHB - ธนาคารอาคารสงเคราะห์</option>
								<option value="CIMBT">CIMBT - ธนาคารซีไอเอ็มบี</option>
								<option value="TBANK">TBANK - ธนาคารธนชาต</option>
								<option value="LHBANK">LHBANK - ธนาคารแลนด์แอนด์เฮ้าส์</option>
								<option value="SCBT">SCBT - ธนาคารสแตนดาร์ดชาร์เตอร์ด</option>
								<option value="TISCO">TISCO - ธนาคารทิสโก้</option>
								<option value="CITI">CITI - ธนาคารซิตี้แบงก์</option>
								<option value="HSBC">HSBC - ธนาคารฮ่องกงและเซี่ยงไฮ้</option>
								<option value="KK">KK - ธนาคารเกียรตินาคิน</option>
								<option value="UOBT">UOBT - ธนาคารยูโอบี</option>
								<option value="ICBC">ICBC - ธนาคารไอซีบีซี</option>
								<option value="TCRB">TCRB - ธนาคารไทยเครดิต</option>
								<option value="BAAC">BAAC - ธนาคารเพื่อการเกษตรฯ</option>
							</select>
						</div>
					</div>
					<div class="form-group  ">
						<label for="bankno" class="col-sm-3 control-label">เลขที่บัญชี:</label>
						<div class="col-sm-4">
							<input type="text" name="bankno" class="form-control" id="bankno" placeholder="00000000"
								value="">
						</div>
						<div class="col-sm-4">
							<button class="btn btn-success" id="check-bankno" type="button">เช็คเลขบัญชี <span
									class="glyphicon glyphicon-refresh glyphicon-refresh-animate"
									style="display:none;"></span></button>
						</div>
					</div>
					<div class="form-group  ">
						<label for="inputPhone" class="col-sm-3 control-label">เบอร์ติดต่อ:</label>
						<div class="col-sm-4">
							<input type="tel" name="phone" class="form-control" id="phone" placeholder="0891234567"
								value="">
						</div>
						<div class="col-sm-4">
							<input type="text" name="lineid" class="form-control" id="lineid" placeholder="ไลน์ไอดี"
								value="">
						</div>
					</div>
					<div class="form-group  ">
						<label for="refer" class="col-sm-3 control-label">ลูกค้ามาจาก:</label>
						<div class="col-sm-4">
							<select class="form-control" name="refer" id="refer">
								<option value="">=เลือก=</option>
								<option value="Google">Google</option>
								<option value="Facebook">Facebook</option>
								<option value="PR">PR</option>
								<option value="Friend">เพื่อนแนะนำ</option>
								<option value="Existed">ลูกค้าเก่าเปิดอีกยูส</option>
								<option value="Youtube">Youtube</option>
								<option value="Website">Website</option>
								<option value="Marketing">Marketing</option>
							</select>
						</div>
						<div class="col-sm-4">
							<input name="email" type="text" class="form-control" id="email"
								placeholder="E-mail@gmail.com" value="">
						</div>
					</div>

					<div class="form-group  ">
						<label for="type" class="col-sm-3 control-label">ลูกค้าประเภท:</label>
						<div class="col-sm-4">
							<select class="form-control" name="type" id="type">
								<option value="ทั่วไป" selected="selected">ทั่วไป</option>
								<option value="มิจฉาชีพ">มิจฉาชีพ</option>
								<option value="คนที่ต้องระวัง">คนที่ต้องระวัง</option>
							</select>
						</div>
						<div class="col-sm-4">
							<input type="text" name="nickname" class="form-control" id="nickname" placeholder="ชื่อเล่น"
								value="">
						</div>
					</div>
					<div class="form-group">
						<label for="xfer_h_id_deposit" class="col-sm-3 control-label">กลุ่มลูกค้าฝาก:</label>
						<div class="col-sm-8">
							<select name="xfer_h_id_deposit" id="xfer_h_id_deposit" class="form-control" required>
								<option value="">== เลือก ==</option>
								<?php foreach ($rs_xfer_deposit->result() as $row_xfer) {?>
								<option value="<?=$row_xfer->xfer_h_id?>"><?=$row_xfer->xfer_h_name?>: <?=$row_xfer->xfer_h_desc?></option>
								<?php }?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="xfer_h_id_withdraw" class="col-sm-3 control-label">กลุ่มลูกค้าถอน:</label>
						<div class="col-sm-8">
							<select class="form-control" name="xfer_h_id_withdraw" id="xfer_h_id_withdraw" required>
								<option value="">== เลือก ==</option>
								<?php foreach ($rs_xfer_withdraw->result() as $row_xfer) {?>
								<option value="<?=$row_xfer->xfer_h_id?>"><?=$row_xfer->xfer_h_name?>: <?=$row_xfer->xfer_h_desc?></option>
								<?php }?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="other" class="col-sm-3 control-label">อื่นๆ:</label>
						<div class="col-sm-8">
							<textarea name="other" id="other" class="form-control" rows="5"
								placeholder="อื่น ๆ"></textarea>
						</div>
					</div>

					ช่องอื่นๆ ใช้ให้เป็นประโยชน์ เช่น ลูกค้าค้าเก่า เปิดอีกยูส ก็ให้ใส่ข้อมูลอ้างอิง ต่างๆ หรือชื่อ PR
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary create-user-submit-button" id="submit">
						Create New User
						<span class="glyphicon glyphicon-refresh glyphicon-refresh-animate"
							style="display:none;"></span>
					</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- END Modals -->

<!-- Initialize Form Validation -->
<script src="<?php echo base_url('assets/plugins/formValidation/useradminFormsValidation.js?v=3') ?>"></script>
<script>
	$(document).ready(function () {
		FormsValidation.init();
	});
</script>