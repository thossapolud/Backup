<div class="">
	<div class="page-header-title">
		<h4 class="page-title">สมาชิก : <?=$row_website->site_name?> : <?=$row_user->dealer?> : <?php echo $row_user->username ?></h4>
	</div>
</div>
<div class="page-content-wrapper ">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-offset-1 col-md-10 col-lg-offset-1 col-lg-9">
				<div class="panel">
					<div class="panel-heading">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab"
									data-toggle="tab">General Info</a></li>
							<li role="presentation"><a href="#profile" aria-controls="profile" role="tab"
									data-toggle="tab">Edit Account</a></li>
							<?php if($this->session->userdata('level')=='admin') { ?>
							<li role="presentation"><a href="#other-admin" aria-controls="other-admin" role="tab"
									data-toggle="tab">Other Admin Features</a></li>
							<?php } ?>
						</ul>
					</div>
					<div class="panel-body">
						<!-- Tab panes -->
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="home">
								<form class="form-horizontal" method="POST" role="form">
									<div class="form-group">
										<label for="created"
											class="col-sm-3 control-label">ยอดเข้าเกมส์ <?php echo $row_user->dealer ?>:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->default_deposit ?></p>
										</div>
									</div>
                                    <div class="form-group">
										<label for="created"
											class="col-sm-3 control-label">วันที่สมัคร:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->created ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="dealer" class="col-sm-3 control-label">Dealer:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->dealer ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="agent" class="col-sm-3 control-label">Agent:</label>
										<div class="col-sm-3">
											<p class="form-control-static">
											<?php foreach ($rs_agent->result() as $row_agent) { 
												echo ($row_agent->userpass_id == $row_user->userpass_id) ? $row_agent->username : '';
											} ?>
											</p>
										</div>
									</div>
									<div class="form-group">
										<label for="username" class="col-sm-3 control-label">Username:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->username ?></p>
										</div>
										<label for="withdrawcode"
											class="col-sm-2 control-label">รหัสผ่าน:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->withdrawcode ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="accountname"
											class="col-sm-3 control-label">ชื่อบัญชี:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->accountname ?></p>
										</div>
										<label for="accountname_en" class="col-sm-2 control-label">ชื่อบัญชี
											EN:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->accountname_en ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="bank"
											class="col-sm-3 control-label">ธนาคาร:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->bank ?></p>
										</div>
										<label for="bankno"
											class="col-sm-2 control-label">เลขที่บัญชี:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->bankno ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="phone" class="col-sm-3 col-md-3 control-label">เบอร์โทร:</label>
										<div class="col-sm-3 col-md-3">
											<p class="form-control-static"><?php echo $this->auth->hide_pl($row_user->phone) ?></p>
										</div>
										<label for="lineid"
											class="col-sm-2 control-label">Line:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php //echo $this->auth->hide_pl($row_user->lineid);
												echo $row_user->lineid; ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="registeredfromip"
											class="col-sm-3 control-label">ลูกค้ามาจาก:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->refer ?></p>
										</div>
										<label for="email" class="col-sm-2 control-label">อีเมล:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->email ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="registeredfromip"
											class="col-sm-3 control-label">ลูกค้าประเภท:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->type ?></p>
										</div>
										<label for="nickname" class="col-sm-2 control-label">ชื่อเล่น:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->nickname ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="registeredfromip"
											class="col-sm-3 control-label">กลุ่มลูกค้าฝาก:</label>
										<div class="col-sm-8">
											<p class="form-control-static">
											<?php foreach ($rs_xfer_deposit->result() as $row_xfer) { 
												echo ($row_xfer->xfer_h_id == $row_user->xfer_h_id_deposit) ? $row_xfer->xfer_h_name.': '.$row_xfer->xfer_h_desc : '';
											} ?>
											</p>
										</div>
									</div>
									<div class="form-group">
										<label for="registeredfromip"
											class="col-sm-3 control-label">กลุ่มลูกค้าถอน:</label>
										<div class="col-sm-8">
											<p class="form-control-static">
											<?php foreach ($rs_xfer_withdraw->result() as $row_xfer) { 
												echo ($row_xfer->xfer_h_id == $row_user->xfer_h_id_withdraw) ? $row_xfer->xfer_h_name.': '.$row_xfer->xfer_h_desc : '';
											} ?>
											</p>
										</div>
									</div>
									<div class="form-group">
										<label for="registeredfromip"
											class="col-sm-3 control-label">สถานะ:</label>
										<div class="col-sm-3">
											<p class="form-control-static"><?php echo $row_user->status ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="registeredfromip" class="col-sm-3 control-label">อื่น
											ๆ:</label>
										<div class="col-sm-9 col-md-9">
											<p class="form-control-static"><?php echo $row_user->other ?></p>
										</div>
									</div>
								</form>
							</div>
							<div role="tabpanel" class="tab-pane" id="profile">
								<form class="form-horizontal" id="admin-edit-user" method="POST" role="form"
									action="<?php echo site_url('user/edit') ?>">
									<div class="form-group">
										<div class="col-sm-4 col-md-3 col-lg-3"> </div>
									</div>
									<div class="form-group">
										<label for="default_deposit" class="col-sm-3 control-label">สถานะ:</label>
										<div class="col-sm-3">
											<select class="form-control" name="default_deposit" id="default_deposit">
												<option value="Y" <?php echo ($row_user->default_deposit=='Y')?'selected':'' ?>>Y</option>
												<option value="N" <?php echo ($row_user->default_deposit=='N')?'selected':'' ?>>N</option>
											</select>
										</div>
									</div>
                                    <div class="form-group">
										<label for="registered"
											class="col-sm-3 control-label">วันที่สมัคร:</label>
										<div class="col-sm-4">
											<p class="form-control-static"><?php echo $row_user->created ?></p>
										</div>
									</div>
									<div class="form-group">
										<label for="site_name"
											class="col-sm-3 control-label">เว็บไซต์:</label>
										<div class="col-sm-4">
											<p class="form-control-static"><?php echo $row_website->site_name ?></p>
										</div>
									</div>
									<div class="form-group  ">
										<label for="inputGroup" class="col-sm-3 control-label">Dealer:</label>
										<div class="col-sm-3">
											<select class="form-control" name="dealer" id="inputDealer">
												<option value="<?=$row_user->dealer?>"
													<?php echo ($row_user->dealer==$row_user->dealer)?'selected':'' ?>><?=$row_user->dealer?>
												</option>
											</select>
										</div>
										<div class="col-sm-5 text-right">
											<button class="btn btn-success" href="#Setdata" type="button"
												data-toggle="modal">เซ็ตข้อมูล</button>
											<button class="btn btn-primary" href="javascript:void(0)" type="button"
												id="copy-data">Copy ข้อมูล</button>
										</div>
									</div>
									<div class="form-group  ">
										<label for="inputAgent" class="col-sm-3 control-label">เอเย่นต์:</label>
										<div class="col-sm-3">
											<select class="form-control" name="userpass_id" id="userpass_id">
												<option value="" disabled>==เลือก==</option>
												<?php foreach ($rs_agent->result() as $row_agent) { ?>
													<option value="<?php echo $row_agent->userpass_id ?>"
														<?php echo ($row_agent->userpass_id == $row_user->userpass_id) ? 'selected' : 'disabled' ?>>
														<?php echo $row_agent->username ?>
													</option>
												<?php } ?>
											</select>
										</div>
										<div class="col-sm-5">
											<a data-toggle="modal" data-target="#change-password-modal" 
												data-user-id="<?php echo $row_user->user_id ?>" 
                                                data-user-dl="<?php echo $row_user->dealer ?>" 
												class="btn btn-info pull-right <?=!in_array($row_user->dealer, unserialize(CONST_DL_CR_CHNG_PWD)) ? 'disabled' : ''?>">
												เปลี่ยนรหัสผ่านเกมส์
											</a>
										</div>
									</div>
									<div class="form-group ">
										<label for="inputUsername"
											class="col-sm-3 control-label">Username:</label>
										<div class="col-sm-3">
											<div class="input-group">
												<span class="input-group-addon">
													<input type="checkbox" title="รอเปิด" value="Y" name="waitopen"
														id="waitopen"
														<?php echo ($row_user->waitopen=='Y')?'checked="checked"':'' ?>
														disabled>
												</span>
												<input type="text" class="form-control" placeholder="Username"
													name="username" id="username"
													value="<?php echo $row_user->username ?>">
											</div>
										</div>
										<label for="inputwithdrawcode"
											class="col-sm-2 control-label">รหัสผ่าน:</label>
										<div class="col-sm-3">
											<input type="text" name="withdrawcode" class="form-control"
												id="withdrawcode" placeholder="รหัสผ่านในการเข้าเกมส์"
												value="<?php echo $row_user->withdrawcode ?>">
										</div>
									</div>
									<div class="form-group  ">
										<label for="accountname"
											class="col-sm-3 control-label">ชื่อบัญชี:</label>
										<div class="col-sm-3 col-md-3">
											<input name="accountname" class="form-control" id="accountname"
												placeholder="ชื่อบัญชีธนาคาร"
												value="<?php echo $row_user->accountname ?>" type="text">
										</div>
										<label for="accountname_en"
											class="col-sm-2 control-label">ชื่อบัญชี En:</label>
										<div class="col-sm-3 col-md-3">
											<input name="accountname_en" class="form-control" id="accountname_en"
												placeholder="ชื่อบัญชี EN"
												value="<?php echo $row_user->accountname_en ?>" type="text">
										</div>
										<div class="col-sm-4"> <small></small> </div>
									</div>
									<div class="form-group  ">
										<label for="bank" class="col-sm-3 control-label">ธนาคาร:</label>
										<div class="col-sm-3">
											<select class="form-control" name="bank" id="bank">
												<option value="">==เลือกธนาคาร==</option>
												<option value="KBANK"
													<?php echo ($row_user->bank=='KBANK')?'selected':'' ?>>KBANK -
													ธนาคารกสิกรไทย</option>
												<option value="SCB"
													<?php echo ($row_user->bank=='SCB')?'selected':'' ?>>SCB -
													ธนาคารไทยพาณิชย์</option>
												<option value="BBL"
													<?php echo ($row_user->bank=='BBL')?'selected':'' ?>>BBL -
													ธนาคารกรุงเทพ</option>
												<option value="KTB"
													<?php echo ($row_user->bank=='KTB')?'selected':'' ?>>KTB -
													ธนาคารกรุงไทย</option>
												<option value="TMB"
													<?php echo ($row_user->bank=='TMB')?'selected':'' ?>>TMB -
													ธนาคารทหารไทย</option>
												<option value="BAY"
													<?php echo ($row_user->bank=='BAY')?'selected':'' ?>>BAY -
													ธนาคารกรุงศรีอยุธยา</option>
												<option value="GSB"
													<?php echo ($row_user->bank=='GSB')?'selected':'' ?>>GSB -
													ธนาคารออมสิน</option>
												<option value="ISBT"
													<?php echo ($row_user->bank=='ISBT')?'selected':'' ?>>ISBT -
													ธนาคารอิสลาม</option>
												<option value="GHB"
													<?php echo ($row_user->bank=='GHB')?'selected':'' ?>>GHB -
													ธนาคารอาคารสงเคราะห์</option>
												<option value="CIMBT"
													<?php echo ($row_user->bank=='CIMBT')?'selected':'' ?>>CIMBT -
													ธนาคารซีไอเอ็มบี</option>
												<option value="TBANK"
													<?php echo ($row_user->bank=='TBANK')?'selected':'' ?>>TBANK -
													ธนาคารธนชาต</option>
												<option value="LHBANK"
													<?php echo ($row_user->bank=='LHBANK')?'selected':'' ?>>LHBANK -
													ธนาคารแลนด์แอนด์เฮ้าส์</option>
												<option value="SCBT"
													<?php echo ($row_user->bank=='SCBT')?'selected':'' ?>>SCBT -
													ธนาคารสแตนดาร์ดชาร์เตอร์ด</option>
												<option value="TISCO"
													<?php echo ($row_user->bank=='TISCO')?'selected':'' ?>>TISCO -
													ธนาคารทิสโก้</option>
												<option value="CITI"
													<?php echo ($row_user->bank=='CITI')?'selected':'' ?>>CITI -
													ธนาคารซิตี้แบงก์</option>
												<option value="HSBC"
													<?php echo ($row_user->bank=='HSBC')?'selected':'' ?>>HSBC -
													ธนาคารฮ่องกงและเซี่ยงไฮ้</option>
												<option value="KK" <?php echo ($row_user->bank=='KK')?'selected':'' ?>>
													KK - ธนาคารเกียรตินาคิน</option>
												<option value="UOBT"
													<?php echo ($row_user->bank=='UOBT')?'selected':'' ?>>UOBT -
													ธนาคารยูโอบี</option>
												<option value="ICBC"
													<?php echo ($row_user->bank=='ICBC')?'selected':'' ?>>ICBC -
													ธนาคารไอซีบีซี</option>
												<option value="TCRB"
													<?php echo ($row_user->bank=='TCRB')?'selected':'' ?>>TCRB -
													ธนาคารไทยเครดิต</option>
												<option value="BAAC"
													<?php echo ($row_user->bank=='BAAC')?'selected':'' ?>>BAAC -
													ธนาคารเพื่อการเกษตรฯ</option>
											</select>
										</div>
										<label for="bankno" class="col-sm-2 control-label">เลขบัญชี:</label>
										<div class="col-sm-3">
											<input name="bankno" class="form-control" id="bankno" placeholder="00000000"
												value="<?php echo $row_user->bankno ?>" type="text"
												<?php echo ($this->session->userdata('level')=='staff')?'readonly':'' ?>>
										</div>
									</div>
									<?php if($this->session->userdata('level')=='admin'||$this->session->userdata('level')=='manager') { ?>
									<div class="form-group  ">
										<label for="phone" class="col-sm-3 control-label">เบอร์โทร:</label>
										<div class="col-sm-3">
											<input name="phone" class="form-control" id="phone" placeholder="เบอร์โทร"
												value="<?php echo $row_user->phone ?>" type="text">
										</div>
										<label for="lineid" class="col-sm-2 control-label">Line:</label>
										<div class="col-sm-3">
											<input name="lineid" class="form-control" id="lineid" placeholder="ไลน์ไอดี"
												value="<?php echo $row_user->lineid ?>" type="text">
										</div>
									</div>
									<?php }else{ ?>
									<input name="phone" id="phone" value="<?php echo $row_user->phone ?>" type="hidden">
									<input name="lineid" id="lineid" value="<?php echo $row_user->lineid ?>"
										type="hidden">
									<?php } ?>
									<div class="form-group  ">
										<label for="refer" class="col-sm-3 control-label">ลูกค้ามาจาก:</label>
										<div class="col-sm-3">
											<select class="form-control" name="refer" id="refer">
												<option value="">=เลือก=</option>
												<option value="Google"
													<?php echo ($row_user->refer=='Google')?'selected':'' ?>>Google
												</option>
												<option value="Facebook"
													<?php echo ($row_user->refer=='Facebook')?'selected':'' ?>>Facebook
												</option>
												<option value="PR" <?php echo ($row_user->refer=='PR')?'selected':'' ?>>
													PR</option>
												<option value="Friend"
													<?php echo ($row_user->refer=='Friend')?'selected':'' ?>>เพื่อนแนะนำ
												</option>
												<option value="Existed"
													<?php echo ($row_user->refer=='Existed')?'selected':'' ?>>
													ลูกค้าเก่าเปิดอีกยูส</option>
												<option value="Youtube"
													<?php echo ($row_user->refer=='Youtube')?'selected':'' ?>>Youtube
												</option>
												<option value="Website"
													<?php echo ($row_user->refer=='Website')?'selected':'' ?>>Website
												</option>
												<option value="Marketing"
													<?php echo ($row_user->refer=='Marketing')?'selected':'' ?>>
													Marketing</option>
												<option value="สมัครผ่านหน้าเว็บ"
													<?php echo ($row_user->refer=='สมัครผ่านหน้าเว็บ')?'selected':'' ?>>
													สมัครผ่านหน้าเว็บ</option>
												<option value="เครดิตฟรีหน้าเว็บ"
													<?php echo ($row_user->refer=='เครดิตฟรีหน้าเว็บ')?'selected':'' ?>>
													เครดิตฟรีหน้าเว็บ</option>
												<option value="สมัครผ่านหน้าไลน์"
													<?php echo ($row_user->refer=='สมัครผ่านหน้าไลน์')?'selected':'' ?>>
													สมัครผ่านหน้าไลน์</option>
											</select>
										</div>
										<label for="email" class="col-sm-2 control-label">อีเมล:</label>
										<div class="col-sm-3">
											<input name="email" class="form-control" id="email" placeholder="email"
												value="<?php echo $row_user->email ?>" type="text">
										</div>

									</div>
									<div class="form-group  ">
										<label for="type" class="col-sm-3 control-label">ลูกค้าประเภท:</label>
										<div class="col-sm-3">
											<select class="form-control" name="type" id="type">
												<option value="ทั่วไป"
													<?php echo ($row_user->type=='ทั่วไป')?'selected':'' ?>>ทั่วไป
												</option>
												<option value="มิจฉาชีพ"
													<?php echo ($row_user->type=='มิจฉาชีพ')?'selected':'' ?>>มิจฉาชีพ
												</option>
												<option value="คนที่ต้องระวัง"
													<?php echo ($row_user->type=='คนที่ต้องระวัง')?'selected':'' ?>>
													คนที่ต้องระวัง</option>
											</select>
										</div>
										<label for="nickname" class="col-sm-2 control-label">ชื่อเล่น:</label>
										<div class="col-sm-3">
											<input type="text" name="nickname" class="form-control"
												id="nickname" placeholder="ชื่อเล่น"
												value="<?php echo $row_user->nickname ?>">
										</div>
									</div>
									<div class="form-group  ">
										<label for="xfer_h_id_deposit" class="col-sm-3 control-label">กลุ่มลูกค้าฝาก:</label>
										<div class="col-sm-8">
											<select class="form-control" name="xfer_h_id_deposit" id="xfer_h_id_deposit" required>
												<option value="">==เลือก==</option>
												<?php foreach ($rs_xfer_deposit->result() as $row_xfer) { ?>
												<option value="<?php echo $row_xfer->xfer_h_id ?>"
													<?php echo ($row_xfer->xfer_h_id == $row_user->xfer_h_id_deposit) ? 'selected' : '' ?>>
													<?php echo $row_xfer->xfer_h_name ?>: <?php echo $row_xfer->xfer_h_desc ?></option>
												<?php } ?>
											</select>
										</div>
									</div>
									<div class="form-group  ">
										<label for="xfer_h_id_withdraw" class="col-sm-3 control-label">กลุ่มลูกค้าถอน:</label>
										<div class="col-sm-8">
											<select class="form-control" name="xfer_h_id_withdraw" id="xfer_h_id_withdraw" required>
												<option value="">==เลือก==</option>
												<?php foreach ($rs_xfer_withdraw->result() as $row_xfer) { ?>
												<option value="<?php echo $row_xfer->xfer_h_id ?>"
													<?php echo ($row_xfer->xfer_h_id == $row_user->xfer_h_id_withdraw) ? 'selected' : '' ?>>
													<?php echo $row_xfer->xfer_h_name ?>: <?php echo $row_xfer->xfer_h_desc ?></option>
												<?php } ?>
											</select>
										</div>
									</div>
									<div class="form-group  ">
										<label for="status" class="col-sm-3 control-label">สถานะ:</label>
										<div class="col-sm-3">
											<select class="form-control" name="status" id="status">
												<option value="ใช้"
													<?php echo ($row_user->status=='ใช้')?'selected':'' ?>>ใช้</option>
												<option value="เลิกใช้"
													<?php echo ($row_user->status=='เลิกใช้')?'selected':'' ?>>เลิกใช้
												</option>
											</select>
										</div>
									</div>
									<div class="form-group  ">
										<label for="other" class="col-sm-3 control-label">อื่นๆ:</label>
										<div class="col-sm-8">
											<textarea name="other" id="other" class="form-control" rows="5"
												placeholder="อื่น ๆ"><?php echo $row_user->other ?></textarea>
										</div>
									</div>
									<p></p>
									<div class="form-group">
										<div class="col-sm-4 col-md-3"></div>
										<div class="col-sm-4 col-md-4">
											<button type="submit" id="submit" name="button" value="Edit Account"
												class="btn btn-default"><i class=" fa fa-refresh "></i> Submit
												Changes</button>
											<button type="button"
												onclick="select_all_and_copy(document.getElementById('data'))"
												id="copy-to-clipboard" style="opacity:0;">Copy to Clipboard</button>
										</div>
									</div>
									<input name="site_id" value="<?php echo $row_user->site_id ?>" type="hidden">
									<input name="usertoedit" value="<?php echo $row_user->user_id ?>" type="hidden">
                                    <input name="useragenttoedit" value="<?php echo $row_user->user_agid ?>" type="hidden">
									<textarea id="data" style="opacity:0;"></textarea>
								</form>
							</div>
							<?php if($this->session->userdata('level')=='admin') { ?>
							<div role="tabpanel" class="tab-pane" id="other-admin">
								<form id="form-delete" class="form-horizontal" method="POST" role="form"
									action="<?php echo site_url('user/delete') ?>">
									<div class="form-group">
										<div class="col-sm-4 col-md-3 col-lg-2"> </div>
										<div class="col-sm-4 col-md-4">
											<p class="form-control-static">Other Admin Features</p>
										</div>
									</div>
									<div class="form-group">
										<div class="col-sm-offset-2 col-sm-10">
                                        	<input name="site_id" value="<?php echo $row_user->site_id ?>" type="hidden">
                                            <input name="userpass_id" value="<?php echo $row_user->userpass_id ?>" type="hidden">
                                        	<input name="dealer" value="<?php echo $row_user->dealer ?>" type="hidden">
                                            <input name="username" value="<?php echo $row_user->username ?>" type="hidden">
                                            <input name="user_id" value="<?php echo $row_user->user_id ?>" type="hidden">
											<input name="usertodelete" value="<?php echo $row_user->user_agid ?>" type="hidden">
											<button type="submit" id="submit" name="button" value="Delete"
												class="btn btn-danger"
												onclick="return confirm ('Are you sure you want to delete this user, this cannot be undone?\n\n' + 'Click OK to continue or Cancel to Abort!')"><i
													class=" fa fa-times "></i> Delete User</button>
										</div>
									</div>
								</form>
							</div>
						</div>
						<?php } ?>
					</div>
				</div><!-- End panel -->
			</div>
		</div><!-- End row -->
	</div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->

<!-- Edit Change Password Modals -->
<div class="modal fade" id="change-password-modal" tabindex="-1" role="dialog" aria-labelledby="Edit" aria-hidden="true" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content" id="modal-content">
			<form class="form-horizontal" id="form-change-password" action="#" method="POST" role="form">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">เปลี่ยนรหัสผ่านเกมส์</h4>
				</div>
				<div class="modal-body">
					<div class="form-group	">
						<label for="inputNewPassword" class="col-sm-3 control-label">รหัสผ่านใหม่:</label>
						<div class="col-sm-7">
							<input type="password" name="cpm_new_password" class="form-control" id="cpm_new_password" placeholder="Password" data-toggle="password" required>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-info" id="change-password" ><span class="glyphicon glyphicon-refresh glyphicon-refresh-animate" style="display:none;"></span> เปลี่ยนรหัสผ่าน</button>
				</div>
				<input name="cpm_user_id" type="hidden" id="cpm_user_id">
                <input name="cpm_user_dl" type="hidden" id="cpm_user_dl">
				<input name="method" type="hidden" id="method" value="ChangePassword">
			</form>
		</div>
	</div>
</div>
<!-- END Change Password Modals -->

<!-- Initialize Form Validation -->
<script src="<?php echo base_url('assets/plugins/formValidation/adminEditFormsValidation.js?v=2') ?>"></script>
<script>$(function () { FormsValidation.init(); });</script>
<script type="text/javascript">
	$.LoadingOverlay("show");
	$(function () {
		// Javascript to enable link to tab
		var hash = document.location.hash;
		if (hash) {
			console.log(hash);
			$('.nav-tabs a[href=' + hash + ']').tab('show');
		}
		// Change hash for page-reload
		$('a[data-toggle="tab"]').on('show.bs.tab', function (e) {
			window.location.hash = e.target.hash;
		});
		$("#username").prop("disabled", $('#waitopen').prop('checked'));
		$('#waitopen').change(function () {
			$("#username").val('').prop("disabled", $(this).is(':checked'));
		});
		$('#change-password-modal').on('show.bs.modal', function (e) {
			$(this).find('#cpm_new_password').val('');
			$(this).find('#cpm_user_id').val($(e.relatedTarget).attr('data-user-id'));
			$(this).find('#cpm_user_dl').val($(e.relatedTarget).attr('data-user-dl'));
		});
		$('#change-password').click(function(){
			var form=$("#form-change-password"), $modal = '#change-password-modal';;
			if(form.find('#cpm_new_password').val()!=''){
				if (!checkNewPassword(form.find('#cpm_new_password').val().trim())) {
					swal({ title:'กรอกเป็นตัวภาษาอังกฤษที่มีอย่างน้อย ตัวใหญ่ 1 ต้ว ตัวเล็ก 1 ตัว และตัวเลข 1 ตัว และทั้งหมดต้องยาว 8 ตัวอักษร เช่น Aa112233', confirmButtonText: 'OK' });
				} else {
					if(confirm('ยืนยันเปลี่ยนรหัสผ่าน ?')){
						//form.find('span.glyphicon-refresh').show();
						$.LoadingOverlay("show");
						$.ajax({
							cache: false,
							type: 'POST',
							url: '<?php echo site_url('user/change-game-password') ?>',
							data: form.serialize(),
							success: function(data){
								$.LoadingOverlay("hide");
								swal({title:data,confirmButtonText:'OK'},function(){
									$($modal).modal('hide');
									window.location.reload();
								});
							}
						});
					}
				}
			}else{
				swal({ title:'กรุณากรอกรหัสผ่านใหม่', confirmButtonText: 'OK' });
			}
		});
		function checkNewPassword(value) {
			if (!/[A-Z]/.test(value)) {
				return false;
			} else if (!/[a-z]/.test(value)) {
				return false;
			} else if (!/[0-9]/.test(value)) {
				return false;
			} else if (value.length < 8) {
				return false;
			}
			return true;
		}
		$.LoadingOverlay("hide");
	});
</script>