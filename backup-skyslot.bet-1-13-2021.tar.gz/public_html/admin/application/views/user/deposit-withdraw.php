<div class="">
	<div class="page-header-title">
		<h4 class="page-title">ประวัติ ฝาก-ถอน : <?=$row_website->site_name?> : <?=$row_user->dealer?> : <?=$row_user->username?></h4>
	</div>
</div>

<div class="page-content-wrapper ">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
				<div class="panel">
					<div class="panel-body">
						<form action="" method="post" id="form-search-top" class="form-inline col-md-12">
							<input type="text" class="form-control datepicker" id="start" placeholder="วันที่"
								name="start" onkeydown="return false" value="<?php echo $start ?>" autocomplete="off">
							<input type="text" class="form-control datepicker" id="end" placeholder="ถึงวันที่"
								name="end" onkeydown="return false" value="<?php echo $end ?>" autocomplete="off">
							<button type="submit" id="search-top" class="btn btn-success">ค้นหา</button>
						</form>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
				<div class="panel">
					<div class="panel-heading">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab"
									data-toggle="tab">สรุป</a></li>
							<li role="presentation"><a href="#deposit" aria-controls="deposit" role="tab"
									data-toggle="tab">รายการฝาก</a></li>
							<li role="presentation"><a href="#withdraw" aria-controls="withdraw" role="tab"
									data-toggle="tab">รายการถอน</a></li>
						</ul>
					</div>
					<div class="panel-body">
						<!-- Tab panes -->
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="home">
								<h1>ฝาก</h1>
								<h2>จำนวน : <?php echo $deposit_credit->listtotal ?> รายการ</h2>
								<h2>ยอด : <?php echo number_format($deposit_credit->credittotal,2) ?> บาท</h2>
								<hr />
								<h1>ถอน</h1>
								<h2>จำนวน : <?php echo $withdraw_credit->listtotal ?> รายการ</h2>
								<h2>ยอด : <?php echo number_format($withdraw_credit->credittotal,2) ?> บาท</h2>
								<hr />
								<h1>=</h1>
								<?php $total = $deposit_credit->credittotal-$withdraw_credit->credittotal; ?>
								<h1 <?php echo ($total<0)?'class="text-danger"':'' ?>>
									<?php echo number_format($total,2) ?></h1>
							</div>
							<div role="tabpanel" class="tab-pane" id="deposit">
								<table class="table table-striped table-bordered table-hover" width="100%">
									<thead>
										<tr role="row">
											<th width="5%" class="text-center"></th>
											<th class="text-center">ยอดก่อนเติม</th>
											<th class="text-center">ยอดเติม</th>
											<th width="25%" class="text-center">วันที่</th>
											<th class="text-center">หมายเหตุ</th>
										</tr>
									</thead>
									<tbody class="text-center">
										<?php if($deposit_list->num_rows()>0){ $i=1;?>
										<?php foreach($deposit_list->result() as $row){ ?>
										<tr>
											<td><?php echo $i++ ?></td>
											<td><?php echo $row->creditbefore ?></td>
											<td><?php echo $row->credit ?></td>
											<td><?php echo $row->created ?></td>
											<td><?php echo ($row->ws_id!='')?'ฝากเงินเข้าบัญชี':'รับโปร '.$row->title ?>
											</td>
										</tr>
										<?php }?>
										<?php } ?>
									</tbody>
								</table>
							</div>
							<div role="tabpanel" class="tab-pane" id="withdraw">
								<table class="table table-striped table-bordered table-hover" width="100%">
									<thead>
										<tr role="row">
											<th width="5%" class="text-center"></th>
											<th class="text-center">ยอดก่อนถอน</th>
											<th class="text-center">ยอดถอน</th>
											<th width="25%" class="text-center">วันที่</th>
										</tr>
									</thead>
									<tbody class="text-center">
										<?php if($withdraw_list->num_rows()>0){ $i=1;?>
										<?php foreach($withdraw_list->result() as $row){ ?>
										<tr>
											<td><?php echo $i++ ?></td>
											<td><?php echo $row->creditbefore ?></td>
											<td><?php echo $row->credit ?></td>
											<td><?php echo $row->created ?></td>
										</tr>
										<?php }?>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div><!-- End panel-body -->
				</div><!-- End panel -->
			</div>
		</div><!-- End row -->

	</div>
	<!-- container -->
</div>
<!-- Page content Wrapper -->