<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Promotion extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth'));
		$auth = new auth();
		$auth->isnot_login();
		$auth->isnot_admin();
		$this->load->model('promotion_model');
	}

	public function index(){
		$data['Content'] = $this->load->view('promotion/index', NULL, true);
		$this->load->view('template/temp_main', $data);
	}

	public function all(){
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array('status','pr_type','title','percent','maximum_receive','minimum','rate','turn','withdraw_limit','pr_id');

		// DB table to use
		$sTable = 'tb_promotion';
		
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);

		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}

		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);

				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}

		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=0; $i<=count($aColumns); $i++)
			{
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);

				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					//if($aColumns[$i]=='created'){
						//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';
					//}else{
						$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					//}
				}
			}
		}
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}

		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$rResult = $this->db->get($sTable);

		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;

		// Total data set length
		$iTotal = $this->db->count_all_results($sTable);

		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$row[0] = $iDisplayStart;
			$row[1] = ($aRow->status=='ใช้')?'<i class="ion-checkmark" title="ใช้"></i>':'<i class="ion-close-round" title="เลิกใช้"></i>';
			$row[2] = $aRow->pr_type;
			$row[3] = $aRow->title;
			$row[4] = $aRow->percent;
			$row[5] = $aRow->maximum_receive;
			$row[6] = $aRow->minimum;
			$row[7] = $aRow->rate;
			$row[8] = $aRow->turn;
			$row[9] = $aRow->withdraw_limit;
			$row[10] = $aRow->pr_id;			
			$output['aaData'][] = $row;			
		}		 
		echo json_encode($output);
	}

	//+ สร้างภาพเล็ก
	public function make_thumb_img($tempimage, $width=NULL, $height=NULL, $newpath=NULL){
		if(!file_exists($newpath) and $newpath!='') {
			mkdir($newpath, DIR_WRITE_MODE, true);
		}		
		$this->load->library('image_lib');
        $config['image_library'] = 'gd2';
        $config['source_image']    = $tempimage;
        if($newpath)$config['new_image'] = $newpath;
        $config['maintain_ratio'] = TRUE;
        $config['width']     = $width;
        $config['height']    = $height;
        $this->image_lib->initialize($config); 
		@$this->image_lib->resize();
    } 
	
	//+ อัพโหลด img promotion
	public function upload_img(){			
		$this->load->library('upload');
		$post = $this->input->post();
		extract($post);
		
        $image_upload_folder = FCPATH.'/images/promotion';
		
        if(!file_exists($image_upload_folder)) {
            mkdir($image_upload_folder, DIR_WRITE_MODE, true);
        }
				
        $this->upload_config = array(
            'upload_path'   => $image_upload_folder,
            'allowed_types' => 'png|jpg|jpeg',
            'max_size'      => 2048,
            'remove_space'  => TRUE,
            'encrypt_name'  => TRUE,
        );
				
		$this->upload->initialize($this->upload_config);
		
		if (!$this->upload->do_upload('promotionimg')) {
            $upload_error = $this->upload->display_errors();
          	echo json_encode($upload_error);
        } else {
            $file_info = $this->upload->data();								
			$new_name = uniqid().$file_info['file_ext'];			
			rename($file_info['full_path'], $file_info['file_path'].$new_name);
			$this->make_thumb_img($file_info['file_path'].$new_name, 450, 450); //+ ทำให้เป็นภาพเล็ก 450x450				
			$file_info['name'] = $new_name;
            echo json_encode($file_info);
        }
	}

	public function add(){
		$post = $this->input->post();
		if($post){
			extract($post);
			$data = array(
				'pr_type'=>$pr_type,
				'pr_img'=>($fixedrate=='y')?base_url('images/promotion/'.$pr_img_fixed):base_url('images/promotion/'.$pr_img_percent),
				'fixedrate'=>$fixedrate,
				'title'=>$title,
				'percent'=>($fixedrate=='n')?$percent:null,
				'maximum_receive'=>($fixedrate=='n')?$maximum_receive:null,
				'minimum'=>$minimum,
				'rate'=>($fixedrate=='y')?$rate:null,
				'turn'=>$turn,
				'withdraw_limit'=>$withdraw_limit,
				'created'=>date('Y-m-d H:i:s')
			);
			$this->db->insert('tb_promotion', $data);
			$this->session->set_flashdata('msg_success', 'เพิ่มเรียบร้อย');
			redirect('promotion');
		}
	}

	public function edit(){
		$post = $this->input->post();
		if($post){
			extract($post);
			$data = array(
				'pr_type'=>$pr_type,
				'title'=>$title,
				'percent'=>($fixedrate=='n')?$percent:null,
				'maximum_receive'=>($fixedrate=='n')?$maximum_receive:null,
				'minimum'=>$minimum,
				'rate'=>($fixedrate=='y')?$rate:null,
				'turn'=>$turn,
				'withdraw_limit'=>$withdraw_limit,
				'status'=>$status,
				'modified'=>date('Y-m-d H:i:s')
			);
			if($pr_img!=''){
				$data['pr_img'] = base_url('images/promotion/'.$pr_img);
			}
			if ($pr_type == 'ฟรีเครดิต') {
				$data_free = array(
					'promotion_url' => $this->input->post('promotion_url'),
					'promotion_status' => ($this->input->post('promotion_status')=='Y')?true:false
				);
				$json_data = json_encode($data_free,JSON_UNESCAPED_SLASHES);
				file_put_contents(__DIR__ . '/../../../admin/promotion_config_free.json',$json_data);
			}
			$result = $this->db->update('tb_promotion', $data, array('pr_id'=>$promotiontoedit));
			if($result){
				$this->session->set_flashdata('msg_success', 'แก้ไขเรียบร้อย');
			}else{
				$this->session->set_flashdata('msg_error', 'ไม่สำเร็จ โปรดตรวจสอบ');
			}
			redirect('promotion');
			//redirect('promotion/view/'.$promotiontoedit);
		}
	}

	public function view(){
		$id = $this->uri->segment(3,0);
		$row_promotion = $this->promotion_model->get_to_edit($this->uri->segment(3));
		if($row_promotion){
			$Content['row_promotion'] = $row_promotion;
			$data['Content'] = $this->load->view('promotion/view', $Content, true);
			$this->load->view('template/temp_main', $data);
		}else{
			redirect('promotion');
		}
	}

	// free credit
	function get_promotion_settings() {
		$id = $this->uri->segment(3,0);
		$file_content = file_get_contents(__DIR__ . '/../../../admin/promotion_config_free.json');
		echo json_encode(json_decode($file_content));
	}
		
}
