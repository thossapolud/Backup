<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Linenotify extends CI_Controller {

	public function notifytoline($msg = NULL) {
		$this->load->model('option_model');
		$row_line_notify_token = $this->option_model->get_by_opt_name('SYS_LINE_NOTIFY_TOKEN', 'default')->row();
		$notify_token = $row_line_notify_token->opt_value;
		$line_api = 'https://notify-api.line.me/api/notify';
		$msg = urldecode($msg);
		
		$message_data = array(
			'message' => $msg,
		);

		$result = $this->send_notify_message($line_api, $notify_token, $message_data);
		return ($result);
	}

	private function send_notify_message($line_api, $access_token, $message_data) {
		$headers = array('Method: POST', 'Content-type: multipart/form-data', 'Authorization: Bearer ' . $access_token);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $line_api);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $message_data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$result = curl_exec($ch);
		// Check Error
		if (curl_error($ch)) {
			$return_array = array('status' => '000: send fail', 'message' => curl_error($ch));
		} else {
			$return_array = json_decode($result, true);
		}
		curl_close($ch);
		return $return_array;
	}
}
