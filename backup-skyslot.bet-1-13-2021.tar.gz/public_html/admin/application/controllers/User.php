<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	
	var $auth;
	var $history;
	
	public function __construct() {
		parent::__construct();
		$this->load->library(array('auth', 'history_log'));
		$this->auth = new auth();
		$this->history = new history_log();
		$this->auth->isnot_login();
		$this->load->model('agent_model');
		$this->load->model('dealer_model');
		$this->load->model('transfer_channel_model');
		$this->load->model('user_model');
		$this->load->model('website_model');
	}
	
	public function index() {
		$site_id = $this->input->get('wbid');
		$dealer = $this->input->get('dl');
		$agent_id = $this->input->get('agid');
		$row_website = $this->website_model->get_by_site_id($site_id);
		if ($row_website) {
			// start need to clean this part
			if ($dealer) {
				$row_dealer = $this->dealer_model->get_by_code($dealer);
				if ($row_dealer) {
					$dealer = $row_dealer->dl_code;
				} else {
					echo 'กรุณาตรวจสอบข้อมูล Ref.User.index.1';
					die();
				}	
			}
			// end need to clean this part
			// set html title tag
			$this->titlecomponent->add('สมาชิก');
			$this->titlecomponent->add($row_website->site_name);
			$this->titlecomponent->add($dealer?$dealer:'ทุกสินค้า');
			$Content['rs_dealer'] = $this->dealer_model->get_by_dealer_status(1);
			$Content['rs_agent'] = $this->agent_model->get_by_site_id_and_dealer($row_website->site_id, $dealer);
			$Content['rs_xfer_deposit'] = $this->transfer_channel_model->get_deposit_by_site_id($row_website->site_id);
			$Content['rs_xfer_withdraw'] = $this->transfer_channel_model->get_withdraw_by_site_id($row_website->site_id);
			$Content['row_website'] = $row_website;
			$Content['dealer'] = $dealer;
			$Content['agent_id'] = $agent_id;
			$data['Content'] = $this->load->view('user/index', $Content, true);
			$this->load->view('template/temp_main', $data);
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.User.index.2';
			die();
		}
	}
	
	/**
	 * Get users data to display in datatable. For ajax use.
	 */
	public function all() {
		$site_id = $this->input->get('wbid');
		$dealer = $this->input->get('dl');
		$agent_id = $this->input->get('agid');
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
			* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1 => 'username', 2 => 'type', 3 => 'status', 4 => 'created', 5 => 'phone', 6 => 'bank', 7 => 'accountname', 8 => 'bankno', 9 => 'dealer', 10 => 'tb_users.user_id', 11 => 'tb_users.user_id' /*SORT*/);
		// DB table to use
		$sTable = 'tb_users';
		//
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);
		// Paging
		if (isset($iDisplayStart) && $iDisplayLength != '-1') {
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}
		// Ordering
		if (isset($iSortCol_0)) {
			for ($i = 0; $i < intval($iSortingCols); $i++) {
				$iSortCol = $this->input->get_post('iSortCol_' . $i, true);
				$bSortable = $this->input->get_post('bSortable_' . intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_' . $i, true);
				if ($bSortable == 'true') {
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}
		/*
			 * Filtering
			 * NOTE this does not match the built-in DataTables filtering which does it
			 * word by word on any field. It's possible to do here, but concerned about efficiency
			 * on very large tables, and MySQL's regex functionality is very limited
		*/
		if (isset($sSearch) && !empty($sSearch)) {
			for ($i = 1; $i <= count($aColumns); $i++) {
				$bSearchable = $this->input->get_post('bSearchable_' . $i, true);
				// Individual column filtering
				if (isset($bSearchable) && $bSearchable == 'true') {
					if($aColumns[$i]=='created'){
						(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'" : '';
					}else{
						$like[] = $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($sSearch) . "%'";
					}
				}
			}
		}
		if (isset($like) && !empty($like)) {
			$where = "(" . implode(" OR ", $like) . ")";
			$this->db->where($where, NULL, FALSE);
		}
		$this->db->where('tb_users_agent.site_id', $site_id);
		if ($dealer) {
			$this->db->where('tb_users_agent.dealer', $dealer);
		}
		if ($agent_id) {
			$this->db->where('tb_users_agent.userpass_id', $agent_id);
		}
		// $this->db->where('status', 'ใช้');
		$this->db->where('tb_users_agent.uag_status', 'ใช้');
		$this->db->where('nickname !=', 'Username ซ้ำ');
		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_users_agent', 'tb_users_agent.user_id=tb_users.user_id', 'LEFT');
		$rResult = $this->db->get($sTable);
		//$x = $this->db->last_query();
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;
		// Total data set length
		//$iTotal = $this->db->count_all($sTable);
		$this->db->where('tb_users_agent.site_id', $site_id);
		if ($dealer) {
			$this->db->where('tb_users_agent.dealer', $dealer);
		}
		if ($agent_id) {
			$this->db->where('tb_users_agent.userpass_id', $agent_id);
		}
		// $this->db->where('status', 'ใช้');
		$this->db->where('tb_users_agent.uag_status', 'ใช้');
		$this->db->where('nickname !=', 'Username ซ้ำ');
		$this->db->join('tb_users_agent', 'tb_users_agent.user_id=tb_users.user_id', 'LEFT');
		$iTotal = $this->db->count_all_results($sTable);
		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array(),
		);
		foreach ($rResult->result() as $aRow) {
			$iDisplayStart = $iDisplayStart + 1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$row[0] = $iDisplayStart;
			$username = ($aRow->type == 'มิจฉาชีพ') ? $aRow->username . ' <i class="oi oi-person text-warning" title="มิจฉาชีพ"></i>' : $aRow->username;
			$username .= ($aRow->type == 'คนที่ต้องระวัง') ? ' <i class="oi oi-person text-danger" title="คนที่ต้องระวัง"></i>' : '';
			$username .= ($aRow->status == 'เลิกใช้') ? ' <i class="oi oi-x text-danger" title="เลิกใช้"></i>' : '';
			$row[1] = $username;
			$row[2] = $aRow->type;
			$row[3] = $aRow->status;
			$row[4] = $aRow->created;
			$row[5] = ($this->session->userdata('level') == 'staff') ? hide_phone($aRow->phone) : $aRow->phone;
			//$row[5] = $aRow->phone;
			$row[6] = $aRow->bank;
			$row[7] = $aRow->accountname;
			$row[8] = $aRow->bankno;
			$row[9] = $aRow->dealer;
			$row[10] = $aRow->user_id;
			$row[11] = $aRow->user_id;
			$output['aaData'][] = $row;
		}
		echo json_encode($output);
	}
	
	public function add() {
		$post = $this->input->post();
		if ($post) {
			extract($post);
			
			$accountname = trim(str_replace(' ','',$accountname));
			$sql = "SELECT tb_users.user_id,username FROM tb_users LEFT JOIN tb_users_agent ON tb_users_agent.user_id=tb_users.user_id WHERE (phone = '$phone' OR bankno = '$bankno' OR REPLACE(accountname , ' ','') = '$accountname') AND dealer = '$dealer' AND site_id = '$site_id'";
			$result = $this->db->query($sql);
			$count = $result->num_rows();
			if($count){ // Already Register
				$this->session->set_flashdata('msg_error', 'Already Register '.$result->row()->username);
				redirect('user?wbid=' . $site_id . '&dl=' . $dealer . '&agid=' . $userpass_id);				
			}else{
				if ($gen_user) {
					$data_return = $this->gen_game_user($dealer, $userpass_id, 0, $bankno);
					if ($data_return['status'] === true) {
						$username = $data_return['username'];
						$withdrawcode = $data_return['password'];
					} else {
						$this->session->set_flashdata('msg_error', 'สร้างยูเซอร์ที่เว็บเกมไม่สำเร็จ ('.@$data_return['status_message'].')');
						redirect('user?wbid=' . $site_id . '&dl=' . $dealer . '&agid=' . $userpass_id);
					}
				}
			
				$sql="SELECT user_id FROM tb_users WHERE (phone = '$phone' OR bankno = '$bankno' OR REPLACE(accountname , ' ','') = '$accountname')";
				$result = $this->db->query($sql);
				$count = $result->num_rows();
				if($count==1){ // Already Have User
					$user_id = $result->row()->user_id;
					
					// Update username agent เก่าให้มีสถานะเติม ออโตตอนฝาก เป็น N
					$this->db->update('tb_users_agent', array('default_deposit'=>'N'), array('user_id'=>$user_id));
													
					$data = array(
						'user_id' => $user_id,
						'site_id' => $site_id,
						'dealer' => $dealer,
						'userpass_id' => $userpass_id,
						'username' =>(isset($waitopen)) ? NULL : trim($username),
						'password' => $withdrawcode,
						'default_deposit'=>'Y',									
						'open_date' =>date('Y-m-d H:i:s'),
						'uag_created' => date('Y-m-d H:i:s'),
					);
					$result = $this->db->insert('tb_users_agent', $data);
				}else{
					$data = array(
						'waitopen' => (isset($waitopen)) ? $waitopen : 'N',
						'nickname' => $nickname,
						'email' => $email,
						'phone' => $phone,
						'lineid' => $lineid,
						'accountname' => $accountname,
						'bank' => $bank,
						'bankno' => $bankno,
						'xfer_h_id_deposit' => $xfer_h_id_deposit,
						'xfer_h_id_withdraw' => $xfer_h_id_withdraw,
						'province' => $this->session->userdata('name'),
						'refer' => $refer,
						'other' => $other,
						'withdrawcode' => $withdrawcode,
						'type' => $type,
						'register_date' => date('Y-m-d'),
						'add_by' => $this->session->userdata('level'),
						'add_by_id' => $this->session->userdata('ac_id'),
						'created' => date('Y-m-d H:i:s'),
					);
					$result = $this->db->insert('tb_users', $data);
					if($result){
						$user_id = $this->db->insert_id();							
						$data = array(
							'user_id' => $user_id,
							'site_id' => $site_id,
							'dealer' => $dealer,
							'userpass_id' => $userpass_id,
							'username' =>$username,
							'password' => $withdrawcode,	
							'default_deposit'=>'Y',								
							'open_date' =>date('Y-m-d'),
							'uag_created' => date('Y-m-d H:i:s'),
						);
						$result = $this->db->insert('tb_users_agent', $data);
						$user_agid = $this->db->insert_id();
					}			
				}			
				
				// Add History Log
				$data = array(
					'dealer' => $dealer,
					'username' => (isset($waitopen)) ? NULL : trim($username),
				);
				$this->history->save(array('action' => 'เพิ่ม', 'user_id' => $user_id, 'detail' => json_encode($data)));
	
				$this->session->set_flashdata('msg_success', 'เพิ่มเรียบร้อย');
				redirect('user?wbid=' . $site_id . '&dl=' . $dealer . '&agid=' . $userpass_id);
			}
		}
	}
	
	public function edit() {
		//$this->auth->isnot_admin();
		$post = $this->input->post();
		if ($post) {
			extract($post);
			$data = array(				
				'waitopen' => (isset($waitopen)) ? $waitopen : 'N',
				'nickname' => $nickname,
				//'email'=>$email,
				//'phone'=>$phone,
				'lineid' => $lineid,
				'accountname' => $accountname,
				'bank' => $bank,
				'accountname_en' => $accountname_en,
				'bankno' => $bankno,
				'xfer_h_id_deposit' => $xfer_h_id_deposit,
				'xfer_h_id_withdraw' => $xfer_h_id_withdraw,
				//'province'=>$this->session->userdata('name'),
				'refer' => $refer,
				'other' => $other,
				'withdrawcode' => $withdrawcode,
				'type' => $type,
				//'status' => $status,				
				'modified' => date('Y-m-d H:i:s'),
			);
			if($this->session->userdata('level')=='admin'||$this->session->userdata('level')=='manager'){
				$data['phone'] = $phone;
				$data['lineid'] = $lineid;
			}
			$this->db->update('tb_users', $data, array('user_id' => $usertoedit)); // Update user data
			
			if($default_deposit=='Y'){
				$this->db->update('tb_users_agent', array('default_deposit'=>'N'), array('user_id' => $usertoedit)); // Update default_deposit เป็น N ก่อน
			}
			
			$data = array(
				'site_id' => $site_id,
				'dealer' => $dealer,
				'userpass_id' => $userpass_id,				
				'username' => (isset($waitopen)) ? NULL : trim($username),
				// 'password' => $withdrawcode,
				'open_date' => (isset($waitopen)) ? NULL : date('Y-m-d H:i:s'),
				'default_deposit'=>$default_deposit,
				'uag_status' =>$status,
				'uag_modified' => date('Y-m-d H:i:s'),
			);
			$this->db->update('tb_users_agent', $data, array('user_agid' => $useragenttoedit,'dealer'=>$dealer)); // Update user agent data
			
			if($status=='เลิกใช้'){
				$sql = 'SELECT user_agid FROM tb_users_agent WHERE uag_status="ใช้" AND user_id = '.$usertoedit.'';
				$query = $this->db->query($sql);
				if($query->num_rows()==0){
					$this->db->update('tb_users', array('status'=>$status),array('user_id' => $usertoedit));
				}
			}
			
			// Add History Log
			$data = array(
				'dealer' => $dealer,
				'username' => (isset($waitopen)) ? NULL : trim($username),
			);
			$this->history->save(array('action' => 'แก้ไข', 'user_id' => $usertoedit, 'detail' => json_encode($data)));
			$this->session->set_flashdata('msg_success', 'แก้ไขเรียบร้อย');
			redirect('user/view/'.$usertoedit.'/'.$dealer);
		}
	}
	
	/**
	 * View user data profile page.
	 */
	public function view() {
		$id = $this->uri->segment(3, 0);
		$dealer = $this->uri->segment(4, 0);
		$row_user = $this->user_model->get_by_id($this->uri->segment(3),$this->uri->segment(4));
		//echo $this->db->last_query(); die();
		if ($row_user) {
			$row_website = $this->website_model->get_by_site_id($row_user->site_id);
			if (!$this->session->flashdata('msg_success')) {
				// Add History Log
				$data = array(
					'dealer' => $row_user->dealer,
					'username' => $row_user->username,
				);
				$this->history->save(array('action' => 'เข้าดู', 'user_id' => $row_user->user_id, 'detail' => json_encode($data)));
			}
			
			// Set html title tag
			$this->titlecomponent->add('สมาชิก');
			$this->titlecomponent->add($row_website->site_name);
			$this->titlecomponent->add($row_user->dealer);
			$this->titlecomponent->add($row_user->username);
			// Get agent username list by site_id and dealer
			$Content['rs_agent'] = $this->agent_model->get_by_site_id_and_dealer($row_user->site_id, $row_user->dealer);
			$Content['rs_xfer_deposit'] = $this->transfer_channel_model->get_deposit_by_site_id($row_website->site_id);
			$Content['rs_xfer_withdraw'] = $this->transfer_channel_model->get_withdraw_by_site_id($row_website->site_id);
			$Content['row_user'] = $row_user;
			$Content['row_website'] = $row_website;
			$data['Content'] = $this->load->view('user/view', $Content, true);
			$this->load->view('template/temp_main', $data);
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.User.view.1';
			die();
		}
	}
	
	// WAIT COMMENT
	public function deposit_withdraw() {
		$id = $this->uri->segment(3, 0);
		$dealer = $this->uri->segment(4, 0);
		$row_user = $this->user_model->get_by_id($this->uri->segment(3),$this->uri->segment(4));
		if ($row_user && $row_user->username != '') {
			$row_website = $this->website_model->get_by_site_id($row_user->site_id);
			$this->load->model('deposit_model');
			$this->load->model('withdraw_model');
			if ($this->input->post('start') && $this->input->post('start') != '' && $this->input->post('end') && $this->input->post('end') != '') {
				$start = $this->input->post('start');
				$end = $this->input->post('end');
			} else {
				$G = date('G', strtotime(date('Y-m-d H:i:s')));
				if ($G > 11) {
					$start = date('Y-m-d');
					$end = date('Y-m-d', (strtotime('+1 day', strtotime(date('Y-m-d')))));
				} else {
					$start = date('Y-m-d', (strtotime('-1 day', strtotime(date('Y-m-d')))));
					$end = date('Y-m-d');
				}
			}
			if (!$this->session->flashdata('msg_success')) { // Add History Log
				$data = array(
					'dealer' => $row_user->dealer,
					'username' => $row_user->username,
				);
				//$this->history->save(array('action'=>'เข้าดู ประวัติ ฝาก-ถอน','user_id'=>$row_user->user_id,'detail'=>json_encode($data)));
			}
			$this->titlecomponent->add('ประวัติ ฝาก-ถอน');
			$this->titlecomponent->add($row_website->site_name);
			$this->titlecomponent->add($row_user->dealer);
			$this->titlecomponent->add($row_user->username);
			$Content['row_user'] = $row_user;
			$Content['row_website'] = $row_website;
			$Content['start'] = $start;
			$Content['end'] = $end;
			$Content['deposit_credit'] = $this->deposit_model->get_sumcountcredit_user($row_user->dealer, $row_user->username, $start, $end);
			$Content['deposit_list'] = $this->deposit_model->get_listdeposit_user($row_user->dealer, $row_user->username, $start, $end);
			$Content['withdraw_credit'] = $this->withdraw_model->get_sumcountcredit_user($row_user->dealer, $row_user->username, $start, $end);
			$Content['withdraw_list'] = $this->withdraw_model->get_listwithdraw_user($row_user->dealer, $row_user->username, $start, $end);
			$data['Content'] = $this->load->view('user/deposit-withdraw', $Content, true);
			$this->load->view('template/temp_main', $data);
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.User.deposit_withdraw.1';
			die();
		}
	}
	
	public function deposit_withdraw_username() {
		$username = $this->uri->segment(3, 0);
		$row_user = $this->user_model->get_by_username(NULL, $username);
		if ($row_user) {
			$row_website = $this->website_model->get_by_site_id($row_user->site_id);
			$this->load->model('deposit_model');
			$this->load->model('withdraw_model');
			if ($this->input->post('start') && $this->input->post('start') != '' && $this->input->post('end') && $this->input->post('end') != '') {
				$start = $this->input->post('start');
				$end = $this->input->post('end');
			} else {
				$G = date('G', strtotime(date('Y-m-d H:i:s')));
				if ($G > 11) {
					$start = date('Y-m-d');
					$end = date('Y-m-d', (strtotime('+1 day', strtotime(date('Y-m-d')))));
				} else {
					$start = date('Y-m-d', (strtotime('-1 day', strtotime(date('Y-m-d')))));
					$end = date('Y-m-d');
				}
			}
			if (!$this->session->flashdata('msg_success')) { // Add History Log
				$data = array(
					'dealer' => $row_user->dealer,
					'username' => $row_user->username,
				);
				//$this->history->save(array('action'=>'เข้าดู ประวัติ ฝาก-ถอน','user_id'=>$row_user->user_id,'detail'=>json_encode($data)));
			}
			$this->titlecomponent->add('ประวัติ ฝาก-ถอน');
			$this->titlecomponent->add($row_website->site_name);
			$this->titlecomponent->add($row_user->dealer);
			$this->titlecomponent->add($row_user->username);
			$Content['row_user'] = $row_user;
			$Content['row_website'] = $row_website;
			$Content['start'] = $start;
			$Content['end'] = $end;
			$Content['deposit_credit'] = $this->deposit_model->get_sumcountcredit_user($row_user->dealer, $row_user->username, $start, $end);
			$Content['deposit_list'] = $this->deposit_model->get_listdeposit_user($row_user->dealer, $row_user->username, $start, $end);
			$Content['withdraw_credit'] = $this->withdraw_model->get_sumcountcredit_user($row_user->dealer, $row_user->username, $start, $end);
			$Content['withdraw_list'] = $this->withdraw_model->get_listwithdraw_user($row_user->dealer, $row_user->username, $start, $end);
			$data['Content'] = $this->load->view('user/deposit-withdraw', $Content, true);
			$this->load->view('template/temp_main', $data);
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.User.deposit_withdraw_username.1';
			die();
		}
	}
	
	public function delete() {
		$this->auth->isnot_admin();
		$post = $this->input->post();
		if ($post) {
			extract($post);
			//$row_user = $this->user_model->get_by_id($usertodelete);
			//if($row_user) {
				
				$this->db->update('tb_users_agent', array('user_status'=>'เลิกใช้'),array('user_agid' => $usertodelete));			
				//$this->db->delete('tb_users_agent', array('user_agid' => $usertodelete));
				
				$sql = 'SELECT user_agid FROM tb_users_agent WHERE user_id = '.$user_id.'';
				$query = $this->db->query($sql);
				if($query->num_rows()==0){
					$this->db->update('tb_users', array('status'=>'เลิกใช้'),array('user_id' => $user_id));
					//$this->db->delete('tb_users', array('user_id' => $user_id));
				}
				
				// Add History Log
				$data = array(
					'dealer' => $dealer,
					'user_agid' => $usertodelete,
					'username' => $username,
				);
				$this->history->save(array('action' => 'ลบ', 'user_id' => $user_id, 'detail' => json_encode($data)));	
				
				$this->session->set_flashdata('msg_success', 'ลบเรียบร้อย');
				redirect('user?wbid=' . $site_id . '&dl=' . $dealer . '&agid=' . $userpass_id);
			//} else {
				//echo 'ลบไม่สำเร็จ โปรดตรวจสอบข้อมูล Ref.User.delete.1';
				//die();
			//}
		} else {
			echo 'ลบไม่สำเร็จ โปรดตรวจสอบข้อมูล Ref.User.delete.2';
			die();
		}
	}
	
	public function check_bankno() {
		$bankno = $this->input->post('bankno');
		$site_id = $this->input->post('site_id');
		$dealer = $this->input->post('dealer');
		$userpass_id = $this->input->post('userpass_id');
		$row_user = $this->user_model->get_user_by_bankno($bankno, NULL, NULL, NULL)->row();
		if($row_user){
			$data = array(
				'result' => 'Y',
				'dealer' => $row_user->dealer,
				'userpass_id' => $row_user->userpass_id,
				'username' => $row_user->username,
				'accountname' => $row_user->accountname,
				'bankno' => $row_user->bankno,
			);
		} else {
			$data = array(
				'result' => 'N',
			);
		}
		$data = json_encode($data);
		echo $data;
	}
	
	private function gen_game_user($dealer, $agent_id, $start_credit=0, $user_contact=NULL) {
		$row_agent = $this->agent_model->get_by_agent_id($agent_id);
		$agent_username = $row_agent->username;
		$agent_password = $row_agent->password;
		$authcode = $row_agent->authcode;
		$secretkey = $row_agent->secretkey;
		if ($dealer == 'Ufa') {			
			$sql = 'SELECT username FROM tb_users LEFT JOIN tb_users_agent ON tb_users_agent.user_id=tb_users.user_id	WHERE userpass_id = '.$agent_id.' AND dealer = "'.$dealer.'" ORDER BY username DESC LIMIT 0,1';
			$query = $this->db->query($sql);
			$row_last_user = $query->row();
			if ($row_last_user) {
				$last_username = $row_last_user->username;
				$last_number = str_replace($agent_username,"",$last_username);
				$new_number = str_pad($last_number + 1, strlen($last_number), "0", STR_PAD_LEFT);
			} else {
				$new_number = '00001';
			}
			$this->load->library('interface_gateway');
			$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password,$authcode,$secretkey);
			$start_credit = 0;
			$data_return = $this->interface_gateway->create_user_auto($start_credit, $user_contact, $new_number);
			return $data_return;
		} else {
			$this->load->library('interface_gateway');
			$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password,$authcode,$secretkey);
			$start_credit = 0;
			$data_return = $this->interface_gateway->create_user_auto($start_credit, $user_contact);
			return $data_return;
		}
	}
	
	public function change_game_password() {
		$return = 'กรุณาตรวจสอบข้อมูล Ref.User.change_game_password.0';
		$user_id = $this->input->post('cpm_user_id');
		$dealer = $this->input->post('cpm_user_dl');
		$new_password = trim($this->input->post('cpm_new_password'));
		if ($user_id && $new_password) {
			$row_user = $this->user_model->get_by_id($user_id,$dealer);
			if ($row_user) {
				$row_agent = $this->agent_model->get_by_agent_id($row_user->userpass_id);
				$dealer = $row_agent->type;
				$agent_username = $row_agent->username;
				$agent_password = $row_agent->password;
				$authcode = $row_agent->authcode;
				$secretkey = $row_agent->secretkey;
		
				$this->load->library('interface_gateway');
				$this->interface_gateway->set_agent_login($dealer ,$agent_username, $agent_password,$authcode,$secretkey);
				$data_return = $this->interface_gateway->change_password($row_user->username, $new_password, $row_user->bankno);
				if ($data_return['status'] === true) {
					$new_password = $data_return['new_password'];
					$return = 'เปลี่ยนรหัสผ่านใหม่สำเร็จ';
				} else {
					$return = $data_return['status_message'];
				}
			} else {
				$return = 'กรุณาตรวจสอบข้อมูล Ref.User.change_game_password.1';
			}
		} else {
			$return = 'กรุณาตรวจสอบข้อมูล Ref.User.change_game_password.2';
		}
		echo $return;
	}
	
}