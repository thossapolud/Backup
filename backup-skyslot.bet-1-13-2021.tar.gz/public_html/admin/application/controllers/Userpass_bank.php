<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Userpass_bank extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth'));
		$auth = new auth();
		$auth->isnot_login();
		$auth->isnot_admin();
		$this->load->model('option_model');
		$this->load->model('userpass_model');
		$this->load->model('website_model');
	}

	public function index(){
		$Content['rs_userpass'] = $this->userpass_model->get_userpass_bank_edit();
		$data['Content'] = $this->load->view('userpass-bank/index', $Content, true);
		$this->load->view('template/temp_main', $data);
	}

	public function get_userpass_bank() {
		$actype = $this->input->get('actype'); // bank account for deposit or withdraw

		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'site.site_name',2=>'up.type',3=>'up.bankname',4=>'up.banknum',5=>'up.actype',6=>'up.autojob_status',7=>'up.up_status',8=>'up.userpass_id');
		// $aColumns = array(1=>'type',2=>'bankname',3=>'banknum',4=>'actype',5=>'up_status',6=>'userpass_id');
		// DB table to use
		$sTable = 'tb_userpass up';
		//

		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);

		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}

		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);

				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}

		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++){
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);

				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
				}
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
		if ($actype) {
			$this->db->where('actype', $actype);
		}
		$this->db->where('acnum !=', 'dealer');

		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_website site', 'site.site_id=up.site_id');
		$rResult = $this->db->get($sTable);		
		
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;

		// Total data set length
		if ($actype) {
			$this->db->where('actype', $actype);
		}
		$this->db->where('acnum !=', 'dealer');
		$this->db->join('tb_website site', 'site.site_id=up.site_id');
		$iTotal = $this->db->count_all_results($sTable);

		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$aColumns = array(1=>'site.site_name',2=>'up.type',3=>'up.bankname',4=>'up.banknum',5=>'up.actype',6=>'up.autojob_status',7=>'up.up_status',8=>'up.userpass_id');
			$row[0] = $iDisplayStart;
			$row[1] = $aRow->site_name;
			$row[2] = $aRow->type;
			$row[3] = $aRow->bankname;
			$row[4] = $aRow->banknum;			
			$row[5] = conv_ws_type($aRow->actype);
			$row[6] = ($aRow->autojob_status == 1) ? '<span class="badge badge-success">เปิด</span>':'<span class="badge badge-primary">ปิด</span>';
			$row[7] = ($aRow->up_status == 1) ? '<span class="badge badge-success">ใช้งาน</span>':'<span class="badge badge-primary">ปิดใช้งาน</span>';
			$row[8] = $aRow->userpass_id;
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}

	public function deposit() {
		$Content['rs_website'] = $this->website_model->get_by_status(1);
		$Content['rs_bank'] = $this->option_model->get_by_opt_code('SYS_BANK')->result();
		$data['Content'] = $this->load->view('userpass-bank/deposit', $Content, true);
		$this->load->view('template/temp_main', $data);
	}

	public function withdraw() {
		$Content['rs_website'] = $this->website_model->get_by_status(1);
		$Content['rs_bank'] = $this->option_model->get_by_opt_code('SYS_BANK')->result();
		$data['Content'] = $this->load->view('userpass-bank/withdraw', $Content, true);
		$this->load->view('template/temp_main', $data);
	}

	public function form_edit_bank() {
		$userpass_id = $this->input->get('upid');
		if ($userpass_id) {
			$row_userpass = $this->userpass_model->get_by_bankid($userpass_id);
			$Content['row_website'] = $this->website_model->get_by_site_id($row_userpass->site_id);
			$Content['row_userpass'] = $row_userpass;
			$this->load->view('userpass-bank/form-edit-bank', $Content);
		}
	}


	public function add() {
		$msg = "กรุณาตรวจสอบข้อมูล";
		$post = $this->input->post();
		if($post) {
			extract($post);
			$row = $this->db->get_where('tb_userpass', 'banknum = "'.$banknum.'"')->row();
			if ($row) {
				$msg = "เพิ่มบัญชีไม่สำเร็จ (มีบัญชีนี้แล้ว)";
			} else {
				$data = array(
					'site_id' => $site_id,
					'type' => $type,
					'bankname' => $bankname,
					'banknum' => $banknum,
					'username' => $username,
					'password' => $password,
					'actype' => $actype,
					'created' => date('Y-m-d H:i:s'),
					'modified' => date('Y-m-d H:i:s')
				);
				$result = $this->db->insert('tb_userpass', $data);
				if ($result === TRUE) {
					$userpass_id =  $this->db->insert_id();
					$this->db->update('tb_userpass', array('acnum' => 'ac'.$userpass_id), array('userpass_id' => $userpass_id));
					$msg = "เพิ่มบัญชีสำเร็จ";
				} else {
					$msg = "เพิ่มบัญชีไม่สำเร็จ";
				}
			}
		}
		echo $msg;
	}

	public function edit() {
		$post = $this->input->post();
		if($post) {
			extract($post);
			// $row = $this->db->get_where('tb_userpass', 'userpass_id != '.$userpasstoedit.' AND username = "'.$username.'"')->row();
			// if ($row) {
			// 	$this->session->set_flashdata('msg_error', 'แก้ไขบัญชีไม่สำเร็จ (Username ซ้ำ)');
			// 	redirect('userpass-bank/'.$actype);
			// } else {
				$data = array(
					'username' => $username,
					'password' => $password,
					'lastdigitphone' => $lastdigitphone,
					'autojob_status' => $autojob_status,
					'up_status' => $up_status,
					'modified' => date('Y-m-d H:i:s')
				);
				$result = $this->db->update('tb_userpass', $data, array('userpass_id'=>$userpasstoedit));
				if ($result === TRUE) {
					$this->session->set_flashdata('msg_success', 'แก้ไขบัญชีสำเร็จ');
					redirect('userpass-bank/'.$actype);
				} else {
					$this->session->set_flashdata('msg_error', 'แก้ไขบัญชีไม่สำเร็จ');
					redirect('userpass-bank/'.$actype);
				}
			// }
		}
		$this->session->set_flashdata('msg_error', 'กรุณาตรวจสอบข้อมูล');
		redirect('userpass-bank/'.$actype);
	}

	public function form_edit_policy() {
		$actype = $this->input->get('actype'); // bank account for deposit or withdraw
		if ($actype == 'deposit') {
			$opt_code = 'BANK_DEPOSIT_POLICY';
		} elseif ($actype == 'withdraw') {
			$opt_code = 'BANK_WITHDRAW_POLICY';
		} else {
			echo ("กรุณาตรวจสอบข้อมูล");
			die();
		}
		if ($actype) {
			$Content['rs_current_policy'] = $this->option_model->get_by_opt_code($opt_code);
			$Content['rs_bank'] = $this->option_model->get_by_opt_code('SYS_BANK')->result();
			$Content['actype'] = $actype;
			$this->load->view('userpass-bank/form-edit-policy', $Content);
		}
	}

	public function get_policy() {
		$actype = $this->input->post('actype');
		if ($actype == 'deposit') {
			$opt_code = 'BANK_DEPOSIT_POLICY';
		} elseif ($actype == 'withdraw') {
			$opt_code = 'BANK_WITHDRAW_POLICY';
		} else {
			echo ("กรุณาตรวจสอบข้อมูล");
			die();
		}
		$rs_current_policy = $this->option_model->get_by_opt_code($opt_code);
		$output = array();
		if($rs_current_policy->num_rows()>0){				
			foreach($rs_current_policy->result() as $row){
				$data['opt_id'] = $row->opt_id;
				$data['opt_code'] = $row->opt_code;
				$data['opt_name'] = strtoupper($row->opt_name);
				$data['opt_value'] = $row->opt_value;
				$output[] = $data;
			}
		}
		echo json_encode($output);
	}

	public function add_policy() {
		$msg = "กรุณาตรวจสอบข้อมูล";
		$post = $this->input->post();
		if($post) {
			extract($post);
			if ($actype == 'deposit' || $actype == 'withdraw') {
				if ($actype == 'deposit') {
					$opt_code = 'BANK_DEPOSIT_POLICY';
				} elseif ($actype == 'withdraw') {
					$opt_code = 'BANK_WITHDRAW_POLICY';
				}
				$check = $this->option_model->get_by_opt_name_value($opt_code,$sys_bank,$cust_bank);
				if ($check) {
					$msg = "เพิ่มไม่สำเร็จ (ซ้ำ)";
				} else {
					$data = array(
						'opt_code' => $opt_code,
						'opt_name' => $sys_bank,
						'opt_value' => $cust_bank,
					);
					$result = $this->option_model->add_option($data);
					if ($result === TRUE) {
						$msg = "เพิ่มสำเร็จ";
					} else {
						$msg = "เพิ่มไม่สำเร็จ";
					}
				}
			}
		}
		echo $msg;
	}

	public function delete_policy() {
		$msg = "กรุณาตรวจสอบข้อมูล";
		$opt_id = $this->input->post('opt_id');
		if ($opt_id) {
			$cond = array(
				'opt_id' => $opt_id
			);
			$result = $this->option_model->delete_option($cond);
			if ($result) {
				$msg = "ลบสำเร็จ";
			} else {
				$msg = "ลบไม่สำเร็จ";
			}
		}
		echo $msg;
	}

}
