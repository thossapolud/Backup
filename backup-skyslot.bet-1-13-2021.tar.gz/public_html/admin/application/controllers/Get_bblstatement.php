<?php
defined('BASEPATH') OR exit('No direct script access allowed');
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Get_bblstatement extends CI_Controller {

	var $auth;
	//var $history;
	var $ch;
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth'));
		$this->auth = new auth();
		//$this->history = new history_log();
		$this->auth->isnot_login();	
		$this->load->model('userpass_model');	
	}
	
	public function set_bbldate($date) {
		$date_array=explode(" ",$date);
		$d=$date_array[0];
		$m=$date_array[1];	
		$y=$date_array[2];
		$h=$date_array[3];
		$m_number = array('ม.ค.'=>'01','ก.พ.'=>'02','มี.ค.'=>'03','เม.ย.'=>'04','พ.ค.'=>'05','มิ.ย.'=>'06','ก.ค.'=>'07','ส.ค.'=>'08','ก.ย.'=>'09','ต.ค.'=>'10','พ.ย.'=>'11','ธ.ค.'=>'12');
		$y_ad = $y-543;		
		$newformat="$y_ad-$m_number[$m]-$d $h";
		return $newformat;
	}
		
	public function ac1(){
		$bank = $this->input->post('bank');
		//$bank = 'bbl';
		if($bank && $bank!=''){
			$row_userpass = $this->userpass_model->get_by_bankac($bank,'ac1');
			$username = $row_userpass->username;
			$password = $row_userpass->password;
			if($username!=''&&$password!=''){				
				$cookie = PUBPATH."cookie/cookie-".$bank."-ac1.txt";				
				//+ Login		
				$this->ch = curl_init(); 
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/SignOn.aspx'); 
				curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
				curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
				curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
				curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
				curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
				curl_setopt($this->ch, CURLOPT_COOKIEJAR, $cookie); 
				curl_setopt($this->ch, CURLOPT_COOKIEFILE, $cookie);  // <-- add this line
				curl_setopt($this->ch, CURLOPT_REFERER, 'https://ibanking.bangkokbank.com/SignOn.aspx');	
				$html = curl_exec($this->ch);		
				
				$dom = new DOMDocument(); // create DOM object
				@$dom->loadHTML($html);// load it's all html contents	
				$inputs = $dom->getElementsByTagName('input');
			
				$postdata='';
				foreach ($inputs as $input) {		
					 $inputname = $input->getAttribute('name');
					 $inputval = $input->getAttribute('value'); 
					 switch($inputname){
						case '__VIEWSTATE':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case 'txtID':
							$postdata .= $inputname.'='.$username.'&';
						break;
						case 'txtPwd':
							$postdata .= $inputname.'='.$password.'&';
						break;
						 default:
							$postdata .= $inputname.'='.$inputval.'&';
					 }
				}
				$postdata = substr($postdata,0,-1);	
				
				curl_setopt($this->ch, CURLOPT_POST, 1);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);	
				curl_exec($this->ch);
				
				//+ AccountSummary	
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/workspace/16AccountActivity/wsp_AccountSummary_AccountSummaryPage.aspx');
				$html = curl_exec($this->ch);
				
				$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
				@$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents	
				//$dom->loadHTML($html);// load it's all html contents	
				$AcctID = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lnkDepositAccts')->nodeValue;
				$AcctID = str_replace('-','', $AcctID);
				$Balance = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lblAcctBal')->nodeValue;
				$Available = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lblAcctAvailBal')->nodeValue;		
				//+ Update Balance
				$sql = "UPDATE tb_userpass SET balance='$Balance', available='$Available' WHERE userpass_id=".$row_userpass->userpass_id;
				$this->db->query($sql); 				
				//+ Update Balance
							
				//$table6 = $dom->getElementsByTagName('table')->item(6); // get table contents.
				//$balance = $dom->saveHTML($table6);  // save html table 6
				//$balance = str_replace(array('class="GridTableNoBorder"'),array('class="table-bordered"'), $balance);
				
				$inputs = $dom->getElementsByTagName('input');
							
				$postdata='';
				foreach ($inputs as $input) {		
					 $inputname = $input->getAttribute('name');
					 $inputval = $input->getAttribute('value'); 
					 switch($inputname){
						case '__VIEWSTATE':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case '__RequestVerificationToken':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case 'AcctID':
							$postdata .= $inputname.'='.$AcctID.'&';
						break;
						case 'AcctIndex':
							$postdata .= $inputname.'=1&';
						break;
						default:
							$postdata .= $inputname.'='.$inputval.'&';
					 }
				}
				$postdata = substr($postdata,0,-1);
				
				//+ AccountActivity	
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/workspace/16AccountActivity/wsp_AccountActivity_Saving_Current.aspx');
				curl_setopt($this->ch, CURLOPT_POST, 1);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
				$html = curl_exec($this->ch);
	
				$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
				@$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents	
				//$dom->loadHTML($html);// load it's all html contents	
				$table8 = $dom->getElementsByTagName('table')->item(8);
				$trs = $table8->getElementsByTagName('tr'); // get this row table8
				$trs_row = $trs->length;
				$i=1;
				
				if($trs_row>1){
					foreach($trs as $tr){
						if($i!=1&&$i!=$trs_row){
							$tds = $tr->getElementsByTagName('td'); // get the columns in this row
							
							//+ สร้าง Where เพื่อเช็คข้อมูลในตาราง	
							$where_select = 'st_out= "'.trim($tds->item(3)->nodeValue).'" AND ';
							$where_select .= 'st_in= "'.trim($tds->item(4)->nodeValue).'" AND ';	
							$where_select .= 'st_datein= "'.$this->set_bbldate(trim($tds->item(1)->nodeValue)).'" AND ';
							$where_select .= 'st_bank="'.$bank.'" AND ';
							//$where_select .= 'st_datein>="'.date("Y-m-d", strtotime("-10 days")).' 00:00:00" AND ';
							$where_select .= 'st_ac="'.$username.'"';
							
							//+ ค่าสำหรับนำไปบันทึก	
							$row_value = array(
								'st_out'=>trim($tds->item(3)->nodeValue),
								'st_in'=>trim($tds->item(4)->nodeValue),
								'st_datein'=>$this->set_bbldate(trim($tds->item(1)->nodeValue)),
								'st_datein_original'=>trim($tds->item(1)->nodeValue),							
								'st_balance'=>trim($tds->item(5)->nodeValue),
								'st_comment'=>trim($tds->item(2)->nodeValue).' / '.trim($tds->item(6)->nodeValue),
								'st_bank'=>$bank,
								'st_ac'=>$username,
								'created'=>date('Y-m-d H:i:s'),
							);
							
							$sql = "SELECT * FROM tb_statement WHERE 1 AND ".$where_select."";
							$query = $this->db->query($sql);
							$count = $query->num_rows();
							if(!$count){
								$sql = "INSERT INTO tb_statement (".implode(", ", array_keys($row_value)).") VALUES ('".implode("', '", $row_value)."') ";
								$query = $this->db->query($sql);
							}
						} // end if($i!=1){
						$i++;	
					} // end foreach($trs as $tr){
				} // end if($trs_row>1){				
									
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/LogOut.aspx');
				curl_exec($this->ch);
				curl_close($this->ch);				
					
				if($query){
					echo 'ดึงข้อมูลสำเร็จ';
				}else{
					echo 'ดึงไม่สำเร็จ';
				}
				
			}else{
				echo 'เช็ค Username / Password Bank';
			} // End if($username!=''&&$password!=''){
		} // End if($bank && $bank!=''){
	}
	
	public function ac2(){
		$bank = $this->input->post('bank');
		//$bank = 'bbl';
		if($bank && $bank!=''){
			$row_userpass = $this->userpass_model->get_by_bankac($bank,'ac2');
			$username = $row_userpass->username;
			$password = $row_userpass->password;
			if($username!=''&&$password!=''){				
				$cookie = PUBPATH."cookie/cookie-".$bank."-ac2.txt";				
				//+ Login		
				$this->ch = curl_init(); 
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/SignOn.aspx'); 
				curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
				curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
				curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
				curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
				curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
				curl_setopt($this->ch, CURLOPT_COOKIEJAR, $cookie); 
				curl_setopt($this->ch, CURLOPT_COOKIEFILE, $cookie);  // <-- add this line
				curl_setopt($this->ch, CURLOPT_REFERER, 'https://ibanking.bangkokbank.com/SignOn.aspx');	
				$html = curl_exec($this->ch);		
				
				$dom = new DOMDocument(); // create DOM object
				@$dom->loadHTML($html);// load it's all html contents	
				$inputs = $dom->getElementsByTagName('input');
			
				$postdata='';
				foreach ($inputs as $input) {		
					 $inputname = $input->getAttribute('name');
					 $inputval = $input->getAttribute('value'); 
					 switch($inputname){
						case '__VIEWSTATE':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case 'txtID':
							$postdata .= $inputname.'='.$username.'&';
						break;
						case 'txtPwd':
							$postdata .= $inputname.'='.$password.'&';
						break;
						 default:
							$postdata .= $inputname.'='.$inputval.'&';
					 }
				}
				$postdata = substr($postdata,0,-1);	
				
				curl_setopt($this->ch, CURLOPT_POST, 1);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);	
				curl_exec($this->ch);
				
				//+ AccountSummary	
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/workspace/16AccountActivity/wsp_AccountSummary_AccountSummaryPage.aspx');
				$html = curl_exec($this->ch);
				
				$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
				@$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents	
				//$dom->loadHTML($html);// load it's all html contents	
				$AcctID = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lnkDepositAccts')->nodeValue;
				$AcctID = str_replace('-','', $AcctID);
				$Balance = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lblAcctBal')->nodeValue;		
				$Available = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lblAcctAvailBal')->nodeValue;		
				//+ Update Balance
				$sql = "UPDATE tb_userpass SET balance='$Balance', available='$Available' WHERE userpass_id=".$row_userpass->userpass_id;
				$this->db->query($sql); 				
				//+ Update Balance
				
				$inputs = $dom->getElementsByTagName('input');							
				$postdata='';
				foreach ($inputs as $input) {		
					 $inputname = $input->getAttribute('name');
					 $inputval = $input->getAttribute('value'); 
					 switch($inputname){
						case '__VIEWSTATE':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case '__RequestVerificationToken':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case 'AcctID':
							$postdata .= $inputname.'='.$AcctID.'&';
						break;
						case 'AcctIndex':
							$postdata .= $inputname.'=1&';
						break;
						default:
							$postdata .= $inputname.'='.$inputval.'&';
					 }
				}
				$postdata = substr($postdata,0,-1);
				
				//+ AccountActivity	
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/workspace/16AccountActivity/wsp_AccountActivity_Saving_Current.aspx');
				curl_setopt($this->ch, CURLOPT_POST, 1);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
				$html = curl_exec($this->ch);
							
				$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
				@$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents	
				//$dom->loadHTML($html);// load it's all html contents	
				$table8 = $dom->getElementsByTagName('table')->item(8);
				$trs = $table8->getElementsByTagName('tr'); // get this row table8
				$trs_row = $trs->length;
				$i=1;
				
				if($trs_row>1){
					foreach($trs as $tr){
						if($i!=1&&$i!=$trs_row){
							$tds = $tr->getElementsByTagName('td'); // get the columns in this row
							
							//+ สร้าง Where เพื่อเช็คข้อมูลในตาราง	
							$where_select = 'st_out= "'.trim($tds->item(3)->nodeValue).'" AND ';
							$where_select .= 'st_in= "'.trim($tds->item(4)->nodeValue).'" AND ';	
							$where_select .= 'st_datein= "'.$this->set_bbldate(trim($tds->item(1)->nodeValue)).'" AND ';
							$where_select .= 'st_bank="'.$bank.'" AND ';
							//$where_select .= 'st_datein>="'.date("Y-m-d", strtotime("-10 days")).' 00:00:00" AND ';
							$where_select .= 'st_ac="'.$username.'"';
							
							//+ ค่าสำหรับนำไปบันทึก	
							$row_value = array(
								'st_out'=>trim($tds->item(3)->nodeValue),
								'st_in'=>trim($tds->item(4)->nodeValue),
								'st_datein'=>$this->set_bbldate(trim($tds->item(1)->nodeValue)),
								'st_datein_original'=>trim($tds->item(1)->nodeValue),							
								'st_balance'=>trim($tds->item(5)->nodeValue),
								'st_comment'=>trim($tds->item(2)->nodeValue).' / '.trim($tds->item(6)->nodeValue),
								'st_bank'=>$bank,
								'st_ac'=>$username,
								'created'=>date('Y-m-d H:i:s'),
							);
							
							$sql = "SELECT * FROM tb_statement WHERE 1 AND ".$where_select."";
							$query = $this->db->query($sql);
							$count = $query->num_rows();
							if(!$count){
								$sql = "INSERT INTO tb_statement (".implode(", ", array_keys($row_value)).") VALUES ('".implode("', '", $row_value)."') ";
								$query = $this->db->query($sql);
							}
						} // end if($i!=1){
						$i++;	
					} // end foreach($trs as $tr){
				} // end if($trs_row>1){				
									
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/LogOut.aspx');
				curl_exec($this->ch);
				curl_close($this->ch);				
					
				if($query){
					echo 'ดึงข้อมูลสำเร็จ';
				}else{
					echo 'ดึงไม่สำเร็จ';
				}
				
			}else{
				echo 'เช็ค Username / Password Bank';
			} // End if($username!=''&&$password!=''){
		} // End if($bank && $bank!=''){
	}
	
	public function ac3(){
		$bank = $this->input->post('bank');
		//$bank = 'bbl';
		if($bank && $bank!=''){
			$row_userpass = $this->userpass_model->get_by_bankac($bank,'ac3');
			$username = $row_userpass->username;
			$password = $row_userpass->password;
			if($username!=''&&$password!=''){				
				$cookie = PUBPATH."cookie/cookie-".$bank."-ac3.txt";				
				//+ Login		
				$this->ch = curl_init(); 
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/SignOn.aspx'); 
				curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
				curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
				curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
				curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
				curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
				curl_setopt($this->ch, CURLOPT_COOKIEJAR, $cookie); 
				curl_setopt($this->ch, CURLOPT_COOKIEFILE, $cookie);  // <-- add this line
				curl_setopt($this->ch, CURLOPT_REFERER, 'https://ibanking.bangkokbank.com/SignOn.aspx');	
				$html = curl_exec($this->ch);		
				
				$dom = new DOMDocument(); // create DOM object
				@$dom->loadHTML($html);// load it's all html contents	
				$inputs = $dom->getElementsByTagName('input');
			
				$postdata='';
				foreach ($inputs as $input) {		
					 $inputname = $input->getAttribute('name');
					 $inputval = $input->getAttribute('value'); 
					 switch($inputname){
						case '__VIEWSTATE':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case 'txtID':
							$postdata .= $inputname.'='.$username.'&';
						break;
						case 'txtPwd':
							$postdata .= $inputname.'='.$password.'&';
						break;
						 default:
							$postdata .= $inputname.'='.$inputval.'&';
					 }
				}
				$postdata = substr($postdata,0,-1);	
				
				curl_setopt($this->ch, CURLOPT_POST, 1);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);	
				curl_exec($this->ch);
				
				//+ AccountSummary	
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/workspace/16AccountActivity/wsp_AccountSummary_AccountSummaryPage.aspx');
				$html = curl_exec($this->ch);
				
				$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
				@$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents	
				//$dom->loadHTML($html);// load it's all html contents	
				$AcctID = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lnkDepositAccts')->nodeValue;
				$AcctID = str_replace('-','', $AcctID);
				$Balance = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lblAcctBal')->nodeValue;		
				$Available = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lblAcctAvailBal')->nodeValue;		
				//+ Update Balance
				$sql = "UPDATE tb_userpass SET balance='$Balance', available='$Available' WHERE userpass_id=".$row_userpass->userpass_id;
				$this->db->query($sql); 				
				//+ Update Balance
				
				$inputs = $dom->getElementsByTagName('input');							
				$postdata='';
				foreach ($inputs as $input) {		
					 $inputname = $input->getAttribute('name');
					 $inputval = $input->getAttribute('value'); 
					 switch($inputname){
						case '__VIEWSTATE':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case '__RequestVerificationToken':
							$postdata .= $inputname.'='.rawurlencode($inputval).'&';
						break;
						case 'AcctID':
							$postdata .= $inputname.'='.$AcctID.'&';
						break;
						case 'AcctIndex':
							$postdata .= $inputname.'=1&';
							//$postdata .= $inputname.'=2&';
						break;
						default:
							$postdata .= $inputname.'='.$inputval.'&';
					 }
				}
				$postdata = substr($postdata,0,-1);
				
				//+ AccountActivity	
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/workspace/16AccountActivity/wsp_AccountActivity_Saving_Current.aspx');
				curl_setopt($this->ch, CURLOPT_POST, 1);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
				$html = curl_exec($this->ch);

				$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
				@$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents	
				//$dom->loadHTML($html);// load it's all html contents	
				$table8 = $dom->getElementsByTagName('table')->item(8);
				$trs = $table8->getElementsByTagName('tr'); // get this row table8
				$trs_row = $trs->length;
				$i=1;
				
				if($trs_row>1){
					foreach($trs as $tr){
						if($i!=1&&$i!=$trs_row){
							$tds = $tr->getElementsByTagName('td'); // get the columns in this row
							
							//+ สร้าง Where เพื่อเช็คข้อมูลในตาราง	
							$where_select = 'st_out= "'.trim($tds->item(3)->nodeValue).'" AND ';
							$where_select .= 'st_in= "'.trim($tds->item(4)->nodeValue).'" AND ';	
							$where_select .= 'st_datein= "'.$this->set_bbldate(trim($tds->item(1)->nodeValue)).'" AND ';
							$where_select .= 'st_bank="'.$bank.'" AND ';
							$where_select .= 'st_balance="'.trim($tds->item(5)->nodeValue).'" AND ';
							//$where_select .= 'st_datein>="'.date("Y-m-d", strtotime("-10 days")).' 00:00:00" AND ';
							$where_select .= 'st_ac="'.$username.'"';
							
							//+ ค่าสำหรับนำไปบันทึก	
							$row_value = array(
								'st_out'=>trim($tds->item(3)->nodeValue),
								'st_in'=>trim($tds->item(4)->nodeValue),
								'st_datein'=>$this->set_bbldate(trim($tds->item(1)->nodeValue)),
								'st_datein_original'=>trim($tds->item(1)->nodeValue),							
								'st_balance'=>trim($tds->item(5)->nodeValue),
								'st_comment'=>trim($tds->item(2)->nodeValue).' / '.trim($tds->item(6)->nodeValue),
								'st_bank'=>$bank,
								'st_ac'=>$username,
								'created'=>date('Y-m-d H:i:s'),
							);
							
							$sql = "SELECT * FROM tb_statement WHERE 1 AND ".$where_select."";
							$query = $this->db->query($sql);
							$count = $query->num_rows();
							if(!$count){
								$sql = "INSERT INTO tb_statement (".implode(", ", array_keys($row_value)).") VALUES ('".implode("', '", $row_value)."') ";
								$query = $this->db->query($sql);
							}
						} // end if($i!=1){
						$i++;	
					} // end foreach($trs as $tr){
				} // end if($trs_row>1){				
									
				curl_setopt($this->ch, CURLOPT_URL, 'https://ibanking.bangkokbank.com/LogOut.aspx');
				curl_exec($this->ch);
				curl_close($this->ch);				
					
				if($query){
					echo 'ดึงข้อมูลสำเร็จ';
				}else{
					echo 'ดึงไม่สำเร็จ';
				}
				
			}else{
				echo 'เช็ค Username / Password Bank';
			} // End if($username!=''&&$password!=''){
		} // End if($bank && $bank!=''){
	}
	
	function __destruct(){
		
	}
		
}
