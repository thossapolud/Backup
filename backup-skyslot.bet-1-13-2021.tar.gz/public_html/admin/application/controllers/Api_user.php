<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Api_user extends CI_Controller {
   
    private $_row_itf = NULL;
    
	public function __construct() {
        parent::__construct();
        $this->load->library(array('history_log'));
        $this->history = new history_log();
        
		$this->load->model('agent_model');
		$this->load->model('user_model');
        $this->load->model('website_model');
        $this->_is_authorize();
    }
	
    private function _is_authorize() {
        $auth_key = $this->input->post('auth_key');
        if ($auth_key) {
            $row_itf = $this->agent_model->get_interface_by_itf_auth($auth_key);
            if ($row_itf) {
                $this->_row_itf = $row_itf;
            } else {
				header("Content-type:application/json");
				echo json_encode(array('status' => false, 'status_message' => 'Invalid authorize key.'));
                die();
            }
        } else {
			header("Content-type:application/json");
			echo json_encode(array('status' => false, 'status_message' => 'Authorize key required.'));
			die();
        }
    }
    public function index() {
        echo 'I am OK';
    }
   
    /**
     * Get deposit bank list for this user
     */
    public function get_bank_deposit() {
        $username = $this->input->post('username');
        $row_agent = $this->agent_model->get_by_agent_id($this->_row_itf->itf_agent_id);
        if ($row_agent) {
            $row_user = $this->user_model->get_by_username($row_agent->type, $username);
            if ($row_user) {
                $this->load->model('userpass_model');
				$rs_bank = $this->userpass_model->get_deposit_bank_by_username($username)->result();
				header("Content-type:application/json");
				echo json_encode(array('status' => true, 'bank' => $rs_bank));
				die();
            } else {
				header("Content-type:application/json");
				echo json_encode(array('status' => false, 'status_message' => 'Invalid user.'));
				die();
            }
        } else {
			header("Content-type:application/json");
			echo json_encode(array('status' => false, 'status_message' => 'Invalid agent.'));
			die();
		}
	}
	
	/**
     * Get user profile
     */
    public function get_user_profile() {
        $username = $this->input->post('username');
        $row_agent = $this->agent_model->get_by_agent_id($this->_row_itf->itf_agent_id);
        if ($row_agent) {
            $row_user = $this->user_model->get_by_username($row_agent->type, $username);
            if ($row_user) {
				$this->load->model('userpass_model');
				$this->load->model('deposit_model');
				$this->load->model('withdraw_model');
				$Content['dealer'] = $row_agent->type;
				$Content['agent'] = $row_agent->username;
				$Content['username'] = $username;
				$Content['deposit_credit'] = $this->deposit_model->get_sumcountcredit_user($row_user->dealer, $row_user->username);
				$Content['withdraw_credit'] = $this->withdraw_model->get_sumcountcredit_user($row_user->dealer, $row_user->username);
				header("Content-type:application/json");
				echo json_encode(array('status' => true, 'profile' => $Content));
				die();
            } else {
				header("Content-type:application/json");
				echo json_encode(array('status' => false, 'status_message' => 'Invalid user.'));
				die();
            }
        } else {
			header("Content-type:application/json");
			echo json_encode(array('status' => false, 'status_message' => 'Invalid agent.'));
			die();
		}
    }
    /**
     * Create new user and Gen user
     */
    public function create() {
        $post = $this->input->post();
        if ($post) {
            extract($post);
            $row_agent = $this->agent_model->get_by_agent_id($this->_row_itf->itf_agent_id);
			// Check is already register or not
			$this->check_already_register_before($row_agent->site_id, $row_agent->type, $row_agent->userpass_id, $phone, $bankno, $accountname);
			$row_website = $this->website_model->get_by_site_id($row_agent->site_id);
			$data_return = $this->gen_game_user($row_agent->type, $row_agent->userpass_id);
			if ($data_return['status'] === true) {
				$username = $data_return['username'];
				$withdrawcode = $data_return['password'];
			} else {
				echo '<h1 class="header">ไม่สำเร็จ</h1><br>เกิดข้อผิดพลาด กรุณาติดต่อทีมงาน Ref.ap.user.create.1';
				die();
			}
            $data = array(
                'site_id' => $row_agent->site_id,
                'dealer' => $row_agent->type,
                'userpass_id' => $row_agent->userpass_id,
                'waitopen' => (isset($waitopen)) ? $waitopen : 'N',
                'username' => (isset($waitopen)) ? NULL : trim($username),
                'password' => $withdrawcode,
                'nickname' => (isset($nickname)) ? trim($nickname) : '',
                'email' => (isset($email)) ? trim($email) : NULL,
                'phone' => $phone,
                'lineid' => $lineid,
                'accountname' => $accountname,
                'bank' => $bank,
                'bankno' => $bankno,
                'xfer_h_id_deposit' => $row_website->site_def_xfer_h_id_deposit,
                'xfer_h_id_withdraw' => $row_website->site_def_xfer_h_id_withdraw,
                'province' => 'AUTO AP',
                'refer' => ($lineuserid && $groupline_id) ? 'สมัครผ่านหน้าไลน์' : 'สมัครผ่านหน้าเว็บ',
                'other' => (isset($other)) ? trim($other) : '',
                'withdrawcode' => $withdrawcode,
                'register_date' => date('Y-m-d'),
                'open_date' => (isset($waitopen)) ? NULL : date('Y-m-d H:i:s'),
                'add_by' => 'AUTO AP ' . $this->_row_itf->itf_id,
                'created' => date('Y-m-d H:i:s'),
            );
            $result = $this->db->insert('tb_users', $data);
            if ($result) {
                $user_id = $this->db->insert_id();
                $data = array(
                    'dealer' => $row_agent->type,
                    'username' => (isset($waitopen)) ? NULL : trim($username),
                );
                $this->history->save(array('action' => 'เพิ่ม', 'user_id' => $user_id, 'detail' => json_encode($data)));
                if ($lineuserid && $groupline_id) {
                    //update username line
                    $chline = curl_init();
                    curl_setopt($chline, CURLOPT_URL, $this->_row_itf->itf_chat_url . '/member/updateusername/' . $lineuserid . '/' . $username . '/' . $groupline_id . '');
                    curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
                    $linedata = curl_exec($chline);
                    curl_close($chline);
                    //send to line
                    $chline = curl_init();
                    curl_setopt($chline, CURLOPT_URL, $this->_row_itf->itf_callback_url . '?linepush=1&act=register&lineuserid=' . $lineuserid . '&password=' . urlencode($withdrawcode) . '&username=' . $username . '&gid=' . $groupline_id . '');
                    curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
                    $linedata = curl_exec($chline);
                    curl_close($chline);
                }
                echo '<h1 class="header">สำเร็จ</h1><br>ยูสในการเข้าเกมส์ ' . $username . '<br>รหัสผ่านในการเข้าเกมส์ ' . $withdrawcode . '';
                die();
            } else {
                echo '<h1 class="header">ไม่สำเร็จ</h1><br>เกิดข้อผิดพลาด กรุณาติดต่อทีมงาน Ref.ap.user.create.2';
                die();
            }
        } else {
            echo '<h1 class="header">ไม่สำเร็จ</h1><br>เกิดข้อผิดพลาด กรุณาติดต่อทีมงาน Ref.ap.user.create.3';
            die();
        }
	}
	
	/**
     * Create new user and Gen user
     */
    public function create_pro() {
		$this->load->model('promotion_model');
        $post = $this->input->post();
        if ($post) {
            extract($post);
            $row_agent = $this->agent_model->get_by_agent_id($this->_row_itf->itf_agent_id);
			// Check is already register or not
            $this->check_already_register_before($row_agent->site_id, $row_agent->type, $row_agent->userpass_id, $phone, $bankno, $accountname);
		
			$row_website = $this->website_model->get_by_site_id($row_agent->site_id);
			$row_promotion = $this->promotion_model->get_by_id($promotion_id);
			$data_return = $this->gen_game_user($row_agent->type, $row_agent->userpass_id,$row_promotion->rate);
			if ($data_return['status'] === true) {
				$username = $data_return['username'];
				$withdrawcode = $data_return['password'];
			} else {
				echo '<h1 class="header">ไม่สำเร็จ</h1><br>เกิดข้อผิดพลาด กรุณาติดต่อทีมงาน Ref.ap.user.create_pro.1';
				die();
			}
            $data = array(
                'site_id' => $row_agent->site_id,
                'dealer' => $row_agent->type,
                'userpass_id' => $row_agent->userpass_id,
                'waitopen' => (isset($waitopen)) ? $waitopen : 'N',
                'username' => (isset($waitopen)) ? NULL : trim($username),
                'password' => $withdrawcode,
                'nickname' => (isset($nickname)) ? trim($nickname) : '',
                'email' => (isset($email)) ? trim($email) : NULL,
                'phone' => $phone,
                'lineid' => $lineid,
                'accountname' => $accountname,
                'bank' => $bank,
                'bankno' => $bankno,
                'xfer_h_id_deposit' => $row_website->site_def_xfer_h_id_deposit,
                'xfer_h_id_withdraw' => $row_website->site_def_xfer_h_id_withdraw,
                'province' => 'AUTO AP',
                'refer' => ($lineuserid && $groupline_id) ? 'สมัครผ่านหน้าไลน์' : 'สมัครผ่านหน้าเว็บ',
                'other' => (isset($other)) ? trim($other) : '',
                'withdrawcode' => $withdrawcode,
                'register_date' => date('Y-m-d'),
                'open_date' => (isset($waitopen)) ? NULL : date('Y-m-d H:i:s'),
                'add_by' => 'AUTO AP ' . $this->_row_itf->itf_id,
                'created' => date('Y-m-d H:i:s'),
            );
            $result = $this->db->insert('tb_users', $data);
            if ($result) {
				$user_id = $this->db->insert_id();
				
				// Add Promotion
				$this->add_promotion($row_agent->site_id, $row_agent->type, $row_agent->userpass_id, $user_id, 0, $row_promotion->rate, $promotion_id);
				
				$data = array(
                    'dealer' => $row_agent->type,
                    'username' => (isset($waitopen)) ? NULL : trim($username),
                );
                $this->history->save(array('action' => 'เพิ่ม', 'user_id' => $user_id, 'detail' => json_encode($data)));
                if ($lineuserid && $groupline_id) {
                    //update username line
                    $chline = curl_init();
                    curl_setopt($chline, CURLOPT_URL, $this->_row_itf->itf_chat_url . '/member/updateusername/' . $lineuserid . '/' . $username . '/' . $groupline_id . '');
                    curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
                    $linedata = curl_exec($chline);
                    curl_close($chline);
                    //send to line
                    $chline = curl_init();
                    curl_setopt($chline, CURLOPT_URL, $this->_row_itf->itf_callback_url . '?linepush=1&act=register&lineuserid=' . $lineuserid . '&password=' . urlencode($withdrawcode) . '&username=' . $username . '&gid=' . $groupline_id . '');
                    curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
                    $linedata = curl_exec($chline);
                    curl_close($chline);
                }
                echo '<h1 class="header">สำเร็จ</h1><br>ยูสในการเข้าเกมส์ ' . $username . '<br>รหัสผ่านในการเข้าเกมส์ ' . $withdrawcode . '';
                die();
            } else {
                echo '<h1 class="header">ไม่สำเร็จ</h1><br>เกิดข้อผิดพลาด กรุณาติดต่อทีมงาน Ref.ap.user.create_pro.2';
                die();
            }
        } else {
            echo '<h1 class="header">ไม่สำเร็จ</h1><br>เกิดข้อผิดพลาด กรุณาติดต่อทีมงาน Ref.ap.user.create_pro.3';
            die();
        }
    }
	/**
	 * Add user deposit data / worksheet data / promotion data to database
	 */
	private function add_promotion($site_id, $dealer, $agent_id, $user_id, $credit_before, $credit, $promotion_id) {
		$this->load->model('promotion_model');
		$row_user = $this->user_model->get_by_id($user_id,$dealer);
		$row_agent = $this->agent_model->get_by_agent_id($agent_id);
		$row_promotion = $this->promotion_model->get_by_id($promotion_id);
		$nickname = $row_user->nickname;
		$username = $row_user->username;
		$promotion_percent = $row_promotion->percent;
		$promotion_minimum = $row_promotion->minimum;
		$promotion_rate = $row_promotion->rate;
		$promotion_turn = $row_promotion->turn;
		$withdraw_pro = $promotion_rate * $promotion_turn;
		// add data to tb_deposit
		$data = array(
			'site_id' => $site_id,
			'dealer' => $dealer,
			'user_id' => $user_id,
			'name' => $row_user->nickname,
			'username' => $row_user->username,
			'agent' => $row_agent->username,
			'creditagentbefore' => isset($creditagentbefore)?$creditagentbefore:0,
			'creditbefore' => $credit_before,
			'credit' => $credit,
			'add_by_name' => 'เพิ่มผ่านการเลือกโปรโมชั่น',
			'created' => date('Y-m-d H:i:s'),
		);
		$this->db->insert('tb_deposit', $data);
		$de_id = $this->db->insert_id();
		// creat new worksheet
		$data = array(
			'ws_code'=>'-',
			'ws_dealer'=>$dealer,
			'free'=>'Y',
			'ws_type'=>'deposit',
			'ws_date'=>date('Y-m-d H:i:s'),
			'site_id'=>$site_id,
			'user_id'=>$user_id,
			'ws_debank'=>'free',
			'ws_debankac'=>'free',
			'ws_debankacnum'=>'free',
			'ws_debankname'=>'free',
			'ws_credit'=>0,
			'ws_pro'=>$credit,
			'ws_total'=>$credit,
			'promotion_id'=>$promotion_id,
			'c_status'=>1,
			'c_comment'=>'เปิดอัตโนมัติ ขณะลูกค้ารับ'.$row_promotion->title,
			'b_status'=>1,
			'b_comment'=>'ตรวจอัตโนมัติ ขณะลูกค้ารับ'.$row_promotion->title,
			'b_date'=>date('Y-m-d H:i:s'),
			'm_status'=>1,
			'm_comment'=>'ตรวจอัตโนมัติ ขณะลูกค้ารับ'.$row_promotion->title,
			'm_date'=>date('Y-m-d H:i:s'),
			'created'=>date('Y-m-d H:i:s'),
			'modified'=>date("Y-m-d H:i:s")
		);
		//$this->db->set('ws_code', 'CONCAT(DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y   \'),IFNULL((SELECT SUBSTR(`ws_code`, 14) FROM tb_worksheet AS `alias` WHERE SUBSTR(`ws_code`, 1, 10) = DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y\') ORDER BY created DESC LIMIT 1)+ 1,1) )', FALSE); //CAST(`ws_code` as SIGNED integer)
		$this->db->insert('tb_worksheet', $data);
		$ws_id = $this->db->insert_id();
		// add promotion user
		$data = array(
			'pr_id'=>$promotion_id,
			'user_id'=>$user_id,
			'ws_id'=>$ws_id,
			'de_id'=>$de_id,
			'percent_pro'=>$promotion_percent,
			'minimum_pro'=>$promotion_minimum,
			'rate_pro'=>$promotion_rate,
			'turn_pro'=>$promotion_turn,
			'credit_pro'=>$withdraw_pro,
			'withdraw_pro'=>'n',
			'created'=>date('Y-m-d H:i:s')
		);
		$this->db->insert('tb_promotion_user', $data);
		// $pr_user_id = $this->db->insert_id();
		// if (!$pr_user_id) {
		// 	echo '<h1 class="header">ไม่สำเร็จ</h1><br>รับโปรโมชั่นไม่สำเร็จ';
		// 	die();
		// }
	}
    /**
     * Check is this visitor already register before
     */
    private function check_already_register_before($site_id, $dealer, $userpass_id, $phone, $bankno, $accountname) {
        $sql = "SELECT *
				FROM tb_users
				WHERE (
					phone = '$phone' OR
					bankno = '$bankno' OR
					accountname = '$accountname') AND
					userpass_id = $userpass_id AND
					dealer = '$dealer' AND
					site_id = '$site_id'
				";
        $result = $this->db->query($sql);
        $count = $result->num_rows();
        if ($count) { // Already Register
			echo '<h1 class="header">ไม่สำเร็จ</h1><br>ท่านเคยสมัครสมาชิกไปแล้ว ยูส: ' . $result->row()->username;
			die();
        }
    }
    /**
     * Create new user on dealer system
     */
    private function gen_game_user($dealer, $agent_id, $start_credit=0) {
        $row_agent = $this->agent_model->get_by_agent_id($agent_id);
        $agent_username = $row_agent->username;
        $agent_password = $row_agent->password;
        $this->load->library('interface_gateway');
        $this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password);
        $data_return = $this->interface_gateway->create_user_auto($start_credit);
        return $data_return;
	}
}
