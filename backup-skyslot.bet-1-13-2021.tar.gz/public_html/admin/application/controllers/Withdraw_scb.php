<?php defined('BASEPATH') OR exit('No direct script access allowed');

error_reporting(0);
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Withdraw_scb extends CI_Controller {

	var $auth;
	var $history;
	var $ch;	
	var $cookie;
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth','history_log'));

		// if ($_SERVER['REMOTE_ADDR'] === $_SERVER['SERVER_ADDR']) {
		if ($this->uri->segment(2)==='process_queue' || $this->uri->segment(2)==='process-queue') {

		} else {
			$this->auth = new auth();
			$this->auth->isnot_login();
		}
		$this->history = new history_log();	
		$this->load->model('userpass_model');
		$this->load->model('worksheet_model');
	}

	private function login_scb($usernamebank,$passwordbank){
		@unlink(PUBPATH."cookie/cookie-m-withdraw-".$bank."-".$acnum."-".$usernamebank.".txt");
		//+ Login	
		curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/login.aspx'); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
		curl_setopt($this->ch, CURLOPT_REFERER, 'https://m.scbeasy.com/online/easynet/mobile/login.aspx');
		$html = curl_exec($this->ch);

		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
		
		$postdata='';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 switch($inputname){
				case '__VIEWSTATE':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__VIEWSTATEGENERATOR':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
			 }
		}
		$postdata .= 'tbUsername='.$usernamebank.'&tbPassword='.rawurlencode($passwordbank).'&Login_Button=Login'; 
		
		curl_setopt($this->ch, CURLOPT_POST, 1);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		$html = curl_exec($this->ch);	
		// print_r($html); die();
	}

	private function to_anotherbank($tobank,$toacc,$amt,$lastdigitphone=NULL){
		//+ Transfers Another Bank
		curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/transfers/another-bank.aspx');
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
		curl_setopt($this->ch, CURLOPT_REFERER, 'https://m.scbeasy.com/online/easynet/mobile/transfers/home.aspx');
		$html = curl_exec($this->ch);
		//print_r($html); die();
		
		//+ Transfers Another Bank noProfile
		curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/transfers/another-bank-noProfile.aspx');
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
		curl_setopt($this->ch, CURLOPT_REFERER, 'https://m.scbeasy.com/online/easynet/mobile/transfers/another-bank.aspx');
		$html = curl_exec($this->ch);

		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
		
		$postdata='';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 switch($inputname){
				case '__EVENTTARGET':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__EVENTARGUMENT':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;						
				case '__LASTFOCUS':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__VIEWSTATE':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__VIEWSTATEGENERATOR':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;						
			 }
		}				
		
		// FromAcc	
		$ddlMobile = 0;
		$selects = $dom->getElementsByTagName('select');
		foreach ($selects as $select) {
			$selectname = $select->getAttribute('name');
			if($selectname=='ctl00$DataProcess$ddlFromAcc'){
				$optionTags = $select->getElementsByTagName('option');
				foreach ($optionTags as $tag){
					if($tag->hasAttribute("selected")){
						$postdata .= rawurlencode($selectname).'='.rawurlencode($tag->nodeValue).'&';
					}
				}
			}
			
			if($lastdigitphone!=NULL||$lastdigitphone!=''){
			//ctl00$DataProcess$ddlMobile
				if($selectname=='ctl00$DataProcess$ddlMobile'){
					$optionTags = $select->getElementsByTagName('option');
					foreach ($optionTags as $tag){
						$digitphone = preg_replace("/[^0-9]/", '', $tag->nodeValue); // ตัวเลขบัตรปชช ที่โอนเข้ามา
						if($digitphone==$lastdigitphone){
							$ddlMobile = $tag->getAttribute('value');
						}
					}
				}
			} // if($lastdigitphone!=NULL){
		}
		
		// ddlBank
		//$tobank = 'xxx';
		$postdata .= rawurlencode('ctl00$DataProcess$ddlBank').'='.$tobank.'&';
		
		// tbToAcc
		//$toacc = '1234567890';
		$postdata .= rawurlencode('ctl00$DataProcess$tbToAcc').'='.$toacc.'&';
		
		// ddlMobile
		$postdata .= rawurlencode('ctl00$DataProcess$ddlMobile').'='.$ddlMobile.'&';
		
		// tbAmt จำนวนเงิน
		$postdata .= rawurlencode('ctl00$DataProcess$tbAmt').'='.$amt.'&';
		
		// tbAmt btNext
		$postdata .= rawurlencode('ctl00$DataProcess$btNext').'=%B6%D1%B4%E4%BB';				
		//print_r($postdata); die();			
		//echo '<hr>';
		
		curl_setopt($this->ch, CURLOPT_POST, 1);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		$html = curl_exec($this->ch);
		return $html;	
		//print_r($html); //die();
	}
	
	private function to_anotheraccount($toacc,$amt,$lastdigitphone=NULL){
		//+ Transfers Another Account
		curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/transfers/another-account.aspx');
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
		curl_setopt($this->ch, CURLOPT_REFERER, 'https://m.scbeasy.com/online/easynet/mobile/transfers/home.aspx');
		$html = curl_exec($this->ch);
		
		//+ Transfers Another Account noProfile
		curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/transfers/another-account-noProfile.aspx');
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
		curl_setopt($this->ch, CURLOPT_REFERER, 'https://m.scbeasy.com/online/easynet/mobile/transfers/another-account.aspx');
		$html = curl_exec($this->ch);
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
		
		$postdata='';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 switch($inputname){
				case '__EVENTTARGET':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__EVENTARGUMENT':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;						
				case '__LASTFOCUS':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__VIEWSTATE':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__VIEWSTATEGENERATOR':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;						
			 }
		}				
		
		// FromAcc	
		$ddlMobile = 0;
		$selects = $dom->getElementsByTagName('select');
		foreach ($selects as $select) {
			$selectname = $select->getAttribute('name');
			if($selectname=='ctl00$DataProcess$ddlFromAcc'){
				$optionTags = $select->getElementsByTagName('option');
				foreach ($optionTags as $tag){
					if($tag->hasAttribute("selected")){
						$postdata .= rawurlencode($selectname).'='.rawurlencode($tag->nodeValue).'&';
					}
				}
			}
			
			if($lastdigitphone!=NULL||$lastdigitphone!=''){
			//ctl00$DataProcess$ddlMobile
				if($selectname=='ctl00$DataProcess$ddlMobile'){
					$optionTags = $select->getElementsByTagName('option');
					foreach ($optionTags as $tag){
						$digitphone = preg_replace("/[^0-9]/", '', $tag->nodeValue); // ตัวเลขบัตรปชช ที่โอนเข้ามา
						if($digitphone==$lastdigitphone){
							$ddlMobile = $tag->getAttribute('value');
						}
					}
				}
			} // if($lastdigitphone!=NULL){
		}
		
		// tbToAcc
		//$toacc = '1234567890';
		$postdata .= rawurlencode('ctl00$DataProcess$tbToAcc').'='.$toacc.'&';
		
		// ddlMobile
		$postdata .= rawurlencode('ctl00$DataProcess$ddlMobile').'='.$ddlMobile.'&';
		
		// tbAmount จำนวนเงิน
		$postdata .= rawurlencode('ctl00$DataProcess$tbAmount').'='.$amt.'&';
		
		// btNext
		$postdata .= rawurlencode('ctl00$DataProcess$btNext').'=%B6%D1%B4%E4%BB';				
		//print_r($postdata); die();			
		//echo '<hr>';
		
		curl_setopt($this->ch, CURLOPT_POST, 1);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		$html = curl_exec($this->ch);
		return $html;	
		//print_r($html); //die();
	}

	public function process_queue() {
		// $msg = array('error'=>'1','text'=>'ปิดการใช้งาน process_queue ชั่วคราว');
		// echo json_encode($msg);
		// die();

		$start_process_time = date('Y-m-d H:i:s');
		$start_process_time_5 = date('Y-m-d H:i:s',strtotime('-5 minutes'));

		// เช็คว่ามีใบงานกำลังประมวลผลอยู่ไหม
		$sql = 'SELECT * FROM tb_worksheet 
				WHERE ws_type = "withdraw" AND b_status = 4 AND ws_wibank = "scb" 
				ORDER BY ws_id LIMIT 1';
		$query_curr_process = $this->db->query($sql);
		if($query_curr_process->num_rows()==1){ // ถ้ามีใบงานกำลังประมวลผล
			$row_curr_process = $query_curr_process->row();
			$present_time = strtotime(date('Y-m-d H:i:s'));
			$can_revert_time = strtotime("+10 minute",strtotime($row_curr_process->modified));  
			if(($present_time>$can_revert_time)) {
				echo 'withdraw_scb.process_queue: มีใบงานกำลังประมวลผลอยู่ ws_id:' .$row_curr_process->ws_id;
				// ปล่อยใบงาน
				$data = array(
					'ws_wibank'=>NULL,
					'ws_wibankac'=>NULL,
					'ws_wibankname'=>NULL,
					'ws_wibankacnum'=>NULL,
					'b_id'=>NULL,
					'b_status'=>0,
					'b_comment'=>'ไม่สำเร็จ: '.date('Y-m-d H:i:s') . ' (ยกเลิกการประมวลผลเนื่องจากทำงานเกิน 10 นาที)',
					'b_date'=>date('Y-m-d H:i:s'),
					'b_flag'=>0,
					'b_flag_id'=>NULL,
					'b_flag_expire'=>NULL,
					'modified'=>date('Y-m-d H:i:s')
				);
				$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_curr_process->ws_id,'c_status'=>1,'b_status'=>4,'m_status'=>1));
				if($this->db->affected_rows() > 0){
					echo 'withdraw_scb.process_queue: ยกเลิกการประมวลผลเนื่องจากทำงานเกิน 10 นาที ws_id:' .$row_curr_process->ws_id;
					$data = array(
						'dealer'=>$row_curr_process->ws_dealer,
						'username'=>$row_curr_process->username,
						'ws_id'=>$row_curr_process->ws_id
					);
					$this->history->save(array('action'=>'AT ย้อน ใบงานถอน '.$row_curr_process->b_status.'=>0'. ' ('.@$row_curr_process->b_comment.')','user_id'=>NULL,'detail'=>json_encode($data)));
				}
			} else {
				echo 'withdraw_scb.process_queue: มีใบงานกำลังประมวลผลอยู่ ws_id:' .$row_curr_process->ws_id;
			}
			die();
		} else { // End if($query_curr_process->num_rows()==1){ ถ้าไม่มีใบงานกำลังประมวลผลแล้ว
			// เช็คว่ามีใบงานรอจัดการไหม
			$sql = 'SELECT ws_id,b_id FROM tb_worksheet 
					WHERE ws_type = "withdraw" AND b_status = 3 AND ws_wibank = "scb" 
					ORDER BY ws_id LIMIT 1';
			$query_new_process = $this->db->query($sql);
			if($query_new_process->num_rows()>0){ // ถ้ามีใบงานรอจัดการ
				$msg = array('error'=>'1','text'=>'เกิดข้อผิดพลาดในการประมวลผลใบงานถอน');

				$row_new_process = $query_new_process->row();
				$ws_id = $row_new_process->ws_id;
				$add_queue_by = $row_new_process->b_id;

				// อัพเดตให้เป็นกำลังประมวลผล
				$data = array(
					// 'b_id'=>NULL,
					'b_status'=>4,
					'b_comment'=>'กำลังประมวลผล: '.date('Y-m-d H:i:s'),
					'b_date'=>date('Y-m-d H:i:s'),
					'modified'=>date('Y-m-d H:i:s')
				);
				$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'c_status'=>1,'b_status'=>3,'m_status'=>1));
				if($this->db->affected_rows()==0){
					echo 'withdraw_scb.process_queue: เปลี่ยนสถานะใบงานเป็นสถานะประมวลผลไม่สำเร็จ';
					die();
				}
				$rs_worksheet = $this->worksheet_model->get_worksheet_withdraw_auto_bank_by_id($ws_id);
				if($rs_worksheet->num_rows()==1){
					$row_worksheet = $rs_worksheet->row();				
					if($row_worksheet->b_status==4){
						$wibank = $row_worksheet->ws_wibank;
						$wibankac = $row_worksheet->ws_wibankac;
						$wibankname = $row_worksheet->ws_wibankname;
						$sql = 'SELECT * FROM tb_userpass WHERE type="'.$wibank.'" AND username="'.$wibankac.'" AND bankname="'.$wibankname.'" AND acnum="'.$wibankacnum.'" AND status = "ใช้"';
						$query_bankwithdraw = $this->db->query($sql);
						if($query_bankwithdraw->num_rows()==1){
							$row_bankwithdraw = $query_bankwithdraw->row();
							$usernamebank = $row_bankwithdraw->username;
							$passwordbank = $row_bankwithdraw->password;
							$lastdigitphone = $row_bankwithdraw->lastdigitphone;
							if($usernamebank!=''&&$passwordbank!=''&&$lastdigitphone!=''){
								$this->ch = curl_init();
								$this->cookie = PUBPATH."cookie/cookie-m-withdraw-".$bank."-".$acnum."-".$usernamebank.".txt";
												
								// Check Session SCB
								curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/welcome.aspx'); 
								curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
								curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
								curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
								curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
								curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
								curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
								curl_setopt($this->ch, CURLOPT_REFERER, 'https://m.scbeasy.com/online/easynet/mobile/welcome.aspx');
								$html = curl_exec($this->ch);
								$html = iconv("windows-874", "utf-8", $html);
								if(!preg_match('/ยินดีต้อนรับสู่บริการ/', $html)){
									$this->login_scb($usernamebank,$passwordbank);
								}
								
								//+ Before Summary
								curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/summary.aspx');
								curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
								curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
								curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
								curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
								curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
								curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
								$html = curl_exec($this->ch);
								
								$dom = new DOMDocument(); // create DOM object
								@$dom->loadHTML($html);// load it's all html contents	
								$tables = $dom->getElementsByTagName('table');
								$table0tr1nodeValue = $tables->item(0)->getElementsByTagName('tr')->item(1)->nodeValue;
								$beforebalance = substr(preg_replace("/[^0-9\.]/", '', $table0tr1nodeValue),1); // ออมทรัพย์ :  ยอดในบ.ช (฿)
								//print_r($beforebalance); die();
																							
								//+ Transfers Home
								curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/transfers/home.aspx');
								curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
								curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
								curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
								curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
								curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
								curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
								$html = curl_exec($this->ch);
								//print_r($html); die();
								
								if($row_worksheet->bank=='SCB'){
									$toacc = $row_worksheet->bankno;
									$amt = $row_worksheet->ws_credit;
									$html = $this->to_anotheraccount($toacc,$amt,$lastdigitphone);			
									$to = 'anotheraccount';
								}else{
									$tobank = conv_bankwithdrawnum($row_worksheet->bank);
									$toacc = $row_worksheet->bankno;
									$amt = $row_worksheet->ws_credit;
									$html = $this->to_anotherbank($tobank,$toacc,$amt,$lastdigitphone);				
									$to = 'anotherbank';
								}
									
								$dom = new DOMDocument(); // create DOM object
								@$dom->loadHTML($html);// load it's all html contents	
								$divcontent = $dom->getElementById('content');
								$spanref = $dom->getElementById('DataProcess_lbOTPRefNo')->nodeValue;
								$p = $divcontent->getElementsByTagName("p");
								
								if($p->length<=2){
									$htmliconv = iconv("windows-874", "utf-8", $html);
									$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
									@$dom->loadHTML(mb_convert_encoding($htmliconv, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents
									$divcontent = $dom->getElementById('content');			
									$stringdiv = $dom->saveHTML($divcontent);  // save html table								
									$msg = array('error'=>'1','text'=>$stringdiv);	
									
									// ปล่อยใบงาน
									$data = array(
										'b_status'=>5,
										'b_comment'=>'ไม่สำเร็จ: '.date('Y-m-d H:i:s') . ' มีปัญหาเกี่ยวกับการโอนเงินชั่วคราว อีกสักครู่กรุณาลองทำรายการอีกครั้ง',
										'b_date'=>date('Y-m-d H:i:s'),
										'b_flag'=>0,
										'b_flag_id'=>NULL,
										'b_flag_expire'=>NULL,
										'modified'=>date('Y-m-d H:i:s')
									);
									$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'c_status'=>1,'b_status'=>4,'m_status'=>1));
									echo json_encode($msg); die();	
								}
								
								//$p = $p->item(5);
								//$p->parentNode->removeChild($p);				
								//$inputotp = $dom->getElementById('DataProcess_tbOTP');
								//$inputotp->parentNode->removeChild($inputotp);
								//$table = $divcontent->getElementsByTagName("table");
								//$table = $table->item(0);
								//$table->parentNode->removeChild($table);				
								//$stringdiv = $dom->saveHTML($divcontent);  // save html table
								
								$inputs = $dom->getElementsByTagName('input');				
								$postdata='';
								foreach ($inputs as $input) {		
										$inputname = $input->getAttribute('name');
										$inputval = $input->getAttribute('value');		
										switch($inputname){
										case '__EVENTTARGET':
											$postdata .= $inputname.'=ctl00%24DataProcess%24btConfirm&';
										break;
										case '__EVENTARGUMENT':
											$postdata .= $inputname.'='.rawurlencode($inputval).'&';
										break;						
										case '__VIEWSTATE':
											$postdata .= $inputname.'='.rawurlencode($inputval).'&';
										break;
										case '__VIEWSTATEGENERATOR':
											$postdata .= $inputname.'='.rawurlencode($inputval).'&';
										break;						
										}
								}
								
								// OTP
								$postdata .= rawurlencode('ctl00$DataProcess$tbOTP').'=';
								
								if(isset($spanref)&&$spanref!=''){
									//$Content['to'] = $to;
									//$Content['ref'] = $spanref;
									//$Content['content'] = $stringdiv;
									//$Content['postdata'] = $postdata;	

									$otp = '000000';
									for ($i=0; $i <=35; $i++) {
										sleep(3); // this should halt for 5 seconds for every loop
										$this->db->select('smsotp_id,sms_otp');
										$this->db->where('sms_ref', $spanref);
										// $this->db->where("sms_created >= date_add('$start_process_time', interval -10 minute)");
										$this->db->where('sms_created >=',$start_process_time_5);
										$rs_sms = $this->db->get('tb_smsotp');
										if($rs_sms->num_rows()==1){
											$otp = $rs_sms->row()->sms_otp;
											// $i=1;
										}
										if($otp!='000000') {
											break;
										}
									}
									/*									
									for ($i=0; $i <=15; $i++) {
										sleep(5); // this should halt for 5 seconds for every loop
										$this->db->select('smsotp_id,sms_otp');
										$this->db->where('sms_ref', $spanref);
										$rs_sms = $this->db->get('tb_smsotp');
										if($rs_sms->num_rows()==1){
											$otp = $rs_sms->row()->sms_otp;
											$i=1;
										}
										if($otp!='000000') {
											break;
										}
									}
									*/				

									if($otp=='000000'){
										$msg = array('error'=>'1','text'=>'OTP ไม่เข้าระบบ โปรดตรวจสอบโทรศัพท์');	
										
										// ปล่อยใบงาน
										$data = array(
											'b_status'=>5,
											'b_comment'=>'ไม่สำเร็จ: '.date('Y-m-d H:i:s') . '(OTP ไม่เข้าระบบ โปรดตรวจสอบโทรศัพท์)',
											'b_date'=>date('Y-m-d H:i:s'),
											'b_flag'=>0,
											'b_flag_id'=>NULL,
											'b_flag_expire'=>NULL,
											'modified'=>date('Y-m-d H:i:s')
										);
										$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'c_status'=>1,'b_status'=>4,'m_status'=>1));						
										echo json_encode($msg); die();
									}
									
									if($to=='anotherbank'){
										$url = 'https://m.scbeasy.com/online/easynet/mobile/transfers/another-bank-noProfile-confirm.aspx';
									}else{
										$url = 'https://m.scbeasy.com/online/easynet/mobile/transfers/another-account-confirm-noProfile.aspx';				
									}

									curl_setopt($this->ch, CURLOPT_URL, $url);			
									curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
									curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
									curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
									curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
									curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
									curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
									curl_setopt($this->ch, CURLOPT_REFERER, $url);
									curl_setopt($this->ch, CURLOPT_POST, 1);
									curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata.$otp);
									$html = @curl_exec($this->ch);
									$htmliconv = @iconv("windows-874", "utf-8", $html);
							
									//+ After Summary
									curl_setopt($this->ch, CURLOPT_URL, 'https://m.scbeasy.com/online/easynet/mobile/summary.aspx');
									curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
									curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
									curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
									curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
									curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
									curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
									$htmlsummary = curl_exec($this->ch);

									$dom = new DOMDocument(); // create DOM object
									@$dom->loadHTML($htmlsummary);// load it's all html contents	
									$tables = $dom->getElementsByTagName('table');
									$table0tr1nodeValue = $tables->item(0)->getElementsByTagName('tr')->item(1)->nodeValue;
									$afterbalance = substr(preg_replace("/[^0-9\.]/", '', $table0tr1nodeValue),1); // ออมทรัพย์ :  ยอดในบ.ช (฿)
									//print_r($afterbalance); die();
									
									$result = 'unsuccess';			
									$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
									@$dom->loadHTML(mb_convert_encoding($htmliconv, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents
									$divcontent = @$dom->getElementById('content');			
									$stringdiv = @$dom->saveHTML($divcontent);  // save html table
									//echo $stringdiv;
									if(preg_match('/ทำรายการสำเร็จ/',$htmliconv)||preg_match('/ทำรายการสำเร็จ/',$html)||(/*empty($html)&&*/$beforebalance>$afterbalance)){
									//if($beforebalance>$afterbalance){
										$data = array(
											'ws_wibank'=>$row_bankwithdraw->type,
											'ws_wibankac'=>$row_bankwithdraw->username,
											'ws_wibankname'=>$row_bankwithdraw->bankname,
											'ws_wibankacnum'=>$row_bankwithdraw->acnum,
											'beforebalance'=>$beforebalance,
											'afterbalance'=>$afterbalance,
											'b_status'=>1,
											'b_comment'=>'ตรวจอัตโนมัติ ผ่านการถอน SCB EASY NET',
											'b_date'=>date('Y-m-d H:i:s'),
											'modified'=>date('Y-m-d H:i:s')
										);					
										// $this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'ws_type'=>'withdraw','c_status'=>1,'b_status'=>4,'m_status'=>1));
										$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
										if($this->db->affected_rows() > 0){
											$result = 'success';
											//+ History Log 
											$data = array(
												'dealer'=>$row_worksheet->ws_dealer,
												'username'=>$row_worksheet->username,
												'ws_id'=>$row_worksheet->ws_id
											);		
											$this->history->save(array('action'=>'AT Bank ตรวจ ใบงานถอน (รอจัดการโดย '.@$add_queue_by.')','user_id'=>NULL,'detail'=>json_encode($data)));
											
											// ตัดหมายเหตุ SCB
											$listp = @$divcontent->getElementsByTagName("p");
											$p6 = @$listp->item(6);
											@$p6->parentNode->removeChild($p6);
											$stringdiv = @$dom->saveHTML($divcontent);  // save html table
											
											$msg = 'AT Bank ตรวจ ใบงานถอน (รอจัดการโดย '.$add_queue_by.')';
											$msg = array('error'=>'0','text'=>$msg,'username'=>$row_worksheet->username);								
											echo json_encode($msg);
											
											$totext = ($to=='anotheraccount')?'บัญชีบุคคลอื่นใน SCB':'บัญชีธนาคารอื่น';
											$msg = '<div style="border:1px #F8090D solid; padding:15px;text-align:left !important;font-size:14px !important;"><div><img id="imgHeader" src="'.base_url('images/img_scb_top.jpg').'"></div><div style="background: #56027E;padding: 3px;color: #FFF;font-size: 15px;font-weight: bold;padding-left: 15px;margin-top: 8px;margin-bottom: 8px;">'.$totext.'</div>'.$stringdiv.'</div>';
											
											$data_ws_autolog = array(
												'wc_ws_id'=>$row_worksheet->ws_id,
												'wc_beforebalance'=>$beforebalance,
												'wc_afterbalance'=>$afterbalance,
												'wc_html'=>$msg,
												'wc_created'=>date('Y-m-d H:i:s')
											);					
											$this->db->insert('tb_ws_autolog', $data_ws_autolog);

											// $this->load->model('website_model');
											// $row_website = $this->website_model->get_by_site_id($row_worksheet->site_id);

											die();	
										}
										//echo $stringdiv;	
									}else{				
										if(preg_match('/OTP/', $htmliconv)||preg_match('/OTP/', $html)){
											$listp = $divcontent->getElementsByTagName("p");
											for ($i = $listp->length; --$i >= 0; ) {
												$p = $listp->item($i);
												$p->parentNode->removeChild($p);
											}
											$table = $divcontent->getElementsByTagName("table");
											$table = $table->item(0);
											$table->parentNode->removeChild($table);
											$stringdiv = $dom->saveHTML($divcontent);  // save html table
										}
									} // End if(preg_match('/ทำรายการสำเร็จ/', $htmliconv)||preg_match('/ทำรายการสำเร็จ/', $html))
									$msg = array('error'=>'1','text'=>$stringdiv);
									$msg_text_for_b_comment = 'ทำรายการไม่สำเร็จ';
								}else{								
									$msg = array('error'=>'1','text'=>'เข้าหน้า Bank ไม่ได้ โปรลองใหม่ในภายหลัง');
									$msg_text_for_b_comment = 'เข้าหน้า Bank ไม่ได้ โปรลองใหม่ในภายหลัง';
								}
							}else{							
								$msg = array('error'=>'1','text'=>'เช็ค Username / Password / Last digit phone Bank');
								$msg_text_for_b_comment = 'เช็ค Username / Password / Last digit phone Bank';
							} // End if($usernamebank!=''&&$passwordbank!=''&&$lastdigitphone!=''){	
						} else {
							$msg = array('error'=>'1','text'=>'เช็ค ธนาคาร / ชื่อบัญชี / Username Bank');
							$msg_text_for_b_comment = 'เช็ค ธนาคาร / ชื่อบัญชี / Username Bank';
						} // End if($query_bankwithdraw->num_rows()==1){
						// ปล่อยใบงาน
						$data = array(
							'b_status'=>5,
							'b_comment'=>'ไม่สำเร็จ: '.date('Y-m-d H:i:s') . @$msg_text_for_b_comment,
							'b_date'=>date('Y-m-d H:i:s'),
							'b_flag'=>0,
							'b_flag_id'=>NULL,
							'b_flag_expire'=>NULL,
							'modified'=>date('Y-m-d H:i:s')
						);
						$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'c_status'=>1,'b_status'=>4,'m_status'=>1));
						echo json_encode($msg);
						die();
					} // End if($rs_worksheet->num_rows()==1&&count($ws_bankac)==3){
				} // End if(rs_worksheet->num_rows()==1){
			} else { // End if($query_new_process->num_rows()>0){ ถ้าไม่มีใบงานรอจัดการแล้ว
				echo 'withdraw_scb.process_queue: ไม่มีใบงานรอจัดการแล้ว';
				die();
			}
		}
	}

	function __destruct(){
		if($this->ch) {
			curl_close($this->ch);
		}
		// var_dump($this->ch);
		$this->db->close();
	}
		
}