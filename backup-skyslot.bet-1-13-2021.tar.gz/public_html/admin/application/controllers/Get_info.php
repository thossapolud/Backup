<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Get_info extends CI_Controller {

	public function __construct(){
		parent::__construct();	
		$this->load->model('user_model');
	}

	public function deposit_withdraw(){
		$username = $this->uri->segment(3,0);
		$row_user = $this->user_model->get_by_username('Slotxo', $username);
		if(count($row_user)>0&&$row_user->username!=''){
			
			#Deposit
			$this->db->select("SUM(credit) AS credittotal");
			$this->db->where('dealer','Slotxo');
			$this->db->where('username',$username);
			$this->db->where('add_by_name !=', 'เพิ่มผ่านการเลือกโปรโมชั่น');
			$this->db->where('add_by_name !=', 'เพิ่มผ่านการเลือกโปรโมชั่นฟรี');
			$depositcredittotal = $this->db->get('tb_deposit')->row()->credittotal;
			
			#Withdraw
			$this->db->select("SUM(credit) AS credittotal");
			$this->db->where('dealer','Slotxo');
			$this->db->where('username',$username);
			$withdrawcredittotal = $this->db->get('tb_withdraw')->row()->credittotal;
			
			$data = array('deposit'=>number_format($depositcredittotal,2,'.',''),'withdraw'=>number_format($withdrawcredittotal,2,'.',''));
			echo json_encode($data);

		}else{
			echo 'No data';
		}
	}
	
	public function deposit_withdraw_presentmonth(){
		$username = $this->uri->segment(3,0);
		$row_user = $this->user_model->get_by_username('Slotxo', $username);
		if(count($row_user)>0&&$row_user->username!=''){
			
			$a_date = date('Y-m-d');

			#Deposit
			$this->db->select("SUM(credit) AS credittotal");
			$this->db->where('dealer','Slotxo');
			$this->db->where('username',$username);
			$this->db->where('add_by_name !=', 'เพิ่มผ่านการเลือกโปรโมชั่น');
			$this->db->where('add_by_name !=', 'เพิ่มผ่านการเลือกโปรโมชั่นฟรี');
			$this->db->where('created BETWEEN "'.date('Y-m-').'01 00:00:00" AND "'.date("Y-m-t", strtotime($a_date)).' 23:59:59"');
			$depositcredittotal = $this->db->get('tb_deposit')->row()->credittotal;

			#Withdraw
			$this->db->select("SUM(credit) AS credittotal");
			$this->db->where('dealer','Slotxo');
			$this->db->where('username',$username);
			$this->db->where('created BETWEEN "'.date('Y-m-').'01 00:00:00" AND "'.date("Y-m-t", strtotime($a_date)).' 23:59:59"');
			$withdrawcredittotal = $this->db->get('tb_withdraw')->row()->credittotal;

			$data = array('deposit'=>number_format($depositcredittotal,2,'.',''),'withdraw'=>number_format($withdrawcredittotal,2,'.',''));
			echo json_encode($data);

		}else{
			echo 'No data';
		}
		
	}

}