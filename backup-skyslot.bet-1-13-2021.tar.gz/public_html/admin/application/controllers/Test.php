<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Test extends CI_Controller {
    public function __construct(){
		parent::__construct();
// 		$this->load->library(array('auth','bypasscaptcha'));
// 		$this->auth = new auth();
// 		$this->load->model('transfer_channel_model');
// 		$this->load->model('website_model');
// 		$this->load->model('bankformat_model');
		$this->load->model('user_model');
	}
	public function apitest(){
		$data_return = array('error_status'=>true, 'error_message'=>'เกิดข้อผิดพลาด กรุณาติดต่อพนักงานค่ะ');
		if($image_url && $amount){
		    $image_url = $this->input->get('path');
    		$amount = (double)$this->input->get('amount');
            $credit = str_replace(',','',$amount);
    		$u_id = $this->input->get('u_id');
    		
    		$this->db->select('*');
			$this->db->from('tb_users a');
			$this->db->join('tb_users_agent b', 'b.user_id=a.user_id', 'left');
    		$this->db->join('tb_userpass c', 'c.userpass_id=b.userpass_id', 'left');
    		$this->db->where('b.user_id', '6');
    		$this->db->where('b.default_deposit', 'Y');
    		$query_uag = $this->db->get();
    		
    		$row_uag = $query_uag->row();
    		
    		$dealer = $row_uag->dealer;
    		$site_id = $row_uag->site_id;
    		$newmember = $row_uag->newmember;
    		$user_id = $row_uag->user_id;
        	$username = $row_uag->username;
    		
    	    $row_user = $this->user_model->get_by_id($u_id, $dealer); 
    		$bank_user = $row_user->bank; // kbank
    		$bankno_user = $row_user->bankno;
    		
    		$bank_acc = substr($bankno_user, -6); // 123-4-5678-90 -> 567890
    		
    		    $this->db->select('*');
    		    $this->db->where('st_in', '+'.number_format($credit,2));
    		    $this->db->where('st_acc', $bank_acc);
    		    $this->db->where('st_from_bank', $bank_user);
    		    $this->db->where('st_status', '0');
    		    $query_st = $this->db->get('tb_statement');
    		    if($query_st->num_rows() > 0){
    		        $data_return = array('error_status'=>false, 'error_message'=>'ระบบกำลังดำเนินการค่ะ');
    		        $row_st = $query_st->row();
    		        $st_id = $row_st->st_id;
    		        $st_datein = $row_st->st_datein;
    		        $st_ac = $row_st->st_ac;
    		        $st_comment = $row_st->st_comment;
        		    $st_bank = $row_st->st_bank;
        		    $msg_comment = explode('เข้าx', $st_comment);
        		    $st_toacc = substr($msg_comment[1], 0, 6);
    		        
    		      //  $this->db->select('*');
        		  //  $this->db->where('username', $st_ac);
        		  //  $this->db->where('actype', 'deposit');
        		  //  $this->db->where('up_status', '1');
        		  //  $query_us = $this->db->get('tb_userpass');
        		  //  $row_userpass = $query_us->row();
        		  //  $ac = $row_userpass->acnum;
        		  //  $bankname = $row_userpass->bankname;
        		    
        		    $sql_userpass = 'SELECT * FROM tb_userpass WHERE type = "scb" AND REPLACE(banknum, "-", "") LIKE "%'.$st_toacc.'"';
        		    $query_userpass = $this->db->query($sql_userpass);
        		    if($query_userpass->num_rows()==1){
            			$row_userpass = $query_userpass->row();
            			$bank = 'scb';
            			$userpass_id = $row_userpass->userpass_id;
            			$ac = $row_userpass->acnum;
            			$usernamebank = $row_userpass->username;
            			$passwordbank = $row_userpass->password;
            			$bankname = $row_userpass->bankname;
            			$userpass_status = $row_userpass->up_status;
            			$row_xfer = $this->transfer_channel_model->get_by_userpass_id($userpass_id);
            			if ($row_xfer && $row_xfer->site_id) {
            				$row_website = $this->website_model->get_by_site_id($row_xfer->site_id);
            			} else {
            				echo 'กรุณาตรวจสอบกลุ่มลูกค้า (transfer-channel)';
            				die();	
            			}
            		}
    		        $data = array(
                        'ws_code'=>'-',
                        'site_id'=>$site_id,
                        'ws_dealer'=>$dealer,
                        'ws_type'=>'deposit',
                        'ws_date'=>$datein,
                        'user_id'=>$u_id,
                        'ws_debank'=>$bank_user,
                        'ws_debankac'=>$st_ac,
                        'ws_debankacnum'=>$ac,
                        'ws_debankname'=>$bankname,
                        'ws_credit'=>$credit,
                        'ws_total'=>$credit,
                        'st_id'=>$st_id,
                        'c_status'=>1,
                        'c_comment'=>'เปิดอัตโนมัติ จาก SMS',
                        'b_status'=>1,
                        'b_comment'=>'ตรวจจากการอัพ SLIP',
                        'b_date'=>date('Y-m-d H:i:s'),
                        'created'=>date('Y-m-d H:i:s')
                    );	
                    $this->db->insert('tb_worksheet', $data);
    				$ws_id = $this->db->insert_id();	
    				if($this->db->affected_rows() > 0){
    				/*อัพเดทสถานะ รายการเงินฝาก*/
    					$data = array(						
    						'st_status'=>1,
    						'modified'=>date("Y-m-d H:i:s")
    					);  
    					$this->db->update('tb_statement', $data, array('st_id'=>$st_id));
    					
    					if($newmember=='Y'){
        				/*อัพเดทใบงาน*/
        				$data = array(
        					'b_comment'=>'ตรวจอัตโนมัติ จาก SLIP สมาชิกใหม่ ฝากครั้งแรก',
        					'modified'=>date("Y-m-d H:i:s")
        				);
        				$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
        				$noti_msg = "มีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
        				$noti_msg = rawurlencode($noti_msg);
        				// เรียก Line เมื่อมีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก
        				$chline = curl_init();
        				curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
        				curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
        				curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
        				$data = curl_exec($chline);	
        				curl_close($chline);
        				// เรียก Line เมื่อมีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก
        				}else{
        							
        				// เช็คยอดฝากเท่ากันในเวลา 5 นาที
        				$sqlwsfiveminute = 'SELECT ws_id FROM tb_worksheet WHERE user_id='.$user_id.' AND ws_id!='.$ws_id.' AND ws_type = "deposit" AND ws_date BETWEEN "'.date('Y-m-d H:i:s',strtotime( '-2 minute' , strtotime($datein))).'" AND "'.date('Y-m-d H:i:s',strtotime( '+3 minute' , strtotime($datein))).'" AND (ws_credit="'.$credit.'"OR ws_credit="'.number_format($credit,2,'.','').'")';
        				$query_wsfiveminute = $this->db->query($sqlwsfiveminute);
        				if($query_wsfiveminute->num_rows()==0){
        									
        					if ($userpass_status == 1) {
        						// ทำการฝากเงินเข้าเกมส์
        					$dataeditcredit = $this->edit_credit($agusername,$agpassword,$name,$username,$credit,$dealer,$site_id,$user_id,$authcode,$secretkey);
        					} else {
        					$dataeditcredit = array();
        					$dataeditcredit['success']=false;
        					}
        					// หากทำการฝากสำเร็จ
        					if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
        					/*อัพเดทใบงาน*/
        					$data = array(						
        					    'de_id'=>$dataeditcredit['de_id'],
        				    	'm_status'=>1,
        						'm_comment'=>'ตรวจอัตโนมัติ จาก SLIP',
        						'm_date'=>date('Y-m-d H:i:s'),
        						'modified'=>date("Y-m-d H:i:s")
        					);
        					$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
        					/*หาก creditbefore มากกว่า 10 ดึงโปรโมชั่นที่ลูกค้ารับ มาเช็ค ว่าทำการถอนไปหรือยัง*/
        					
        					$sql = 'SELECT pr_user_id,withdraw_pro,turn_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$dealer.'" ORDER BY created DESC limit 1';
        					$query_promotion_user = $this->db->query($sql);
        					if($query_promotion_user->num_rows()>0){
        						$row_promotion_user = $query_promotion_user->row();
        						if($row_promotion_user->withdraw_pro=='n'){
        							if($dataeditcredit['creditbefore']>10){	
        								$newcredit_pro = $credit*$row_promotion_user->turn_pro;
        								//+ เพิ่มจำนวนเครดิตทำเทริน
        								$sql = "UPDATE tb_promotion_user SET credit_pro = credit_pro+".$newcredit_pro." WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
        								$this->db->query($sql);
        								//+ สิ้นสุดเพิ่มจำนวนเครดิตทำเทริน
        							}else{
        								//+ ทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
        								$sql = "UPDATE tb_promotion_user SET withdraw_pro = 'y', note='ปรับ withdraw_pro = y เนื่องจากมียอดก่อนฝาก น้อยกว่า 10',modified='".date("Y-m-d H:i:s")."' WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
        								$this->db->query($sql);
        								//+ สิ้นสุดทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
        							} // End if($dataeditcredit['creditbefore']>10){
        						} // End if($row_promotion_user->withdraw_pro=='n'){
        					} // End if($query_promotion_user->num_rows()>0){
        												
                					if ($row_website->site_line_callback_url) {
                					// เช็ค gid จาก username
                					$chgid = curl_init();
                					curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
                					curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
                					curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
                					$gid = curl_exec($chgid);
                					curl_close($chgid);
                				
                					// เรียก Line
                					$chline = curl_init();
                					curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=deposit&username='.$username.'&credit='.$credit.'&phone='.$phone);
                					curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
                					curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
                					$data = curl_exec($chline);	
                					curl_close($chline);
                					// เรียก Line
                					}
        					    }else{
            						$noti_msg = "มีใบงานที่รอตรวจสอบ:: เว็บ:".$row_website->site_name.". เกม:$dealer. เอเยนต์:$agusername. ยูส:$username. ยอด:$credit บาท.";
            						$noti_msg = rawurlencode($noti_msg);
            						// // เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
            						$chline = curl_init();
            						curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg));
            						curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
            						curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
            						$data = curl_exec($chline);	
            						curl_close($chline);
            						// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
        					    } // End if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
        					}else{
        					/*อัพเดทใบงาน*/
        						$data = array(
        							'b_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์ ฝากยอดเดียวกันในเวลา 5 นาที',
        							'modified'=>date("Y-m-d H:i:s")
        						);
        						$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
            						$noti_msg = "มีใบงานยอดเงินเดียวกันในเวลา 5 นาที:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
            						$noti_msg = rawurlencode($noti_msg);
            						// เรียก Line เมื่อมีใบงานยอดเงินเดียวกันในเวลา 5 นาที
            						$chline = curl_init();
            						curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
            						curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
            						curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
            						$data = curl_exec($chline);	
            						curl_close($chline);
        						// เรียก Line เมื่อมีใบงานยอดเงินเดียวกันในเวลา 5 นาที
        					}// End if($query_wsfiveminute->num_rows()==0){
        				} // End if($newmember=='Y'){
    				}
    				
    		    }else{
    		        $this->ch = curl_init();
        			curl_setopt($this->ch, CURLOPT_URL, 'https://www.monkeycave.net/projects/my_ocr/main/api_vision?path='.$image_url);
        			curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
        			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
        			$data = curl_exec($this->ch);
        			$data_json = json_decode($data);
        			if ($data_json->error_status === false) { // ดึงข้อมูลสลิปจาก SCB ได้
        				if (strpos($data_json->status, "Found")) { // เจอสลิป strstr >> strpos
        					$chk_slip_amount = str_replace(",", "", $data_json->amount); // 69,6969.00 -> 696969.00
        					$rec_banknum = preg_replace('/[^0-9]/', '', $data_json->toacnumber); // xxxx-xx868-6 -> 8686 && xxxx-xx056-9 -> 0569 && xxxx-xx736-8 -> 7368
        					if ($rec_banknum != '4497'&& $rec_banknum != '5449') {
        						$data_return = array('error_status'=>true, 'error_message'=>'กรุณาติดต่อพนักงานค่ะ');
        					} elseif ($amount == $chk_slip_amount) { // เช็คว่ายอดเงินที่ลูกค้ากรอกตรงกับข้อมูลยอดเงินในสลิป
        						// if ($slip_tobank == 'SCB' && $slip_frombank == 'SCB') { // SCB โอน SCB เท่านั้น
        							$slip_frombank = $this->bankformat_model->get_Bankinitials($data_json->frombank);
        							$slip_tobank = $this->bankformat_model->get_Bankinitials($data_json->tobank);
        							$data_return = array('error_status'=>false, 'error_message'=>'ระบบกำลังดำเนินการค่ะ');
        							$slip_no = $data_json->slipno;
        							$transdate = $data_json->transdate; // "วันศุกร์ที่ 28 กุมภาพันธ์ พ.ศ.2563 14:37 น. / Fri 28 February 2020 2:37 pm"
        							$new_transdate = explode("/", $transdate);
        							$eng_transdate = trim($new_transdate[1]); // "Fri 28 February 2020 2:37 pm"
        							$eng_transdate_totime = strtotime($eng_transdate);
        							$slip_transdate = date('Y-m-d H:i:s', $eng_transdate_totime); // 2014-06-30 10:30:00
        							$slip_original_transdate = $data_json->transdate; // "วันศุกร์ที่ 28 กุมภาพันธ์ พ.ศ.2563 14:37 น. / Fri 28 February 2020 2:37 pm"
        							$slip_fromacname = $data_json->fromacname;
        							$slip_fromacnumber = preg_replace('/[^0-9]/', '', $data_json->fromacnumber); // xxxx-xx451-2 -> 4512
        							$slip_toacname = $data_json->toacname;
        							$slip_toacnumber = preg_replace('/[^0-9]/', '', $data_json->toacnumber); // xxxx-xx868-6 -> 8686
        							$slip_amount = $data_json->amount;
        							$data_slip = array(
        								"slip_no" => $slip_no,
        								"slip_transdate" => $slip_transdate,
        								"slip_original_transdate" => $slip_original_transdate,
        								"slip_frombank" => $slip_frombank,					
        								"slip_fromacname" => $slip_fromacname,
        								"slip_fromacnumber" => $slip_fromacnumber,
        								"slip_tobank" => $slip_tobank,					
        								"slip_toacname" => $slip_toacname,
        								"slip_toacnumber" => $slip_toacnumber,
        								"slip_amount" => $slip_amount,
        								'slip_flag' => '1'
        							);
        							
        							$this->db->select('slip_no');
        							$this->db->where('slip_no', $slip_no);
        							$rs_slip = $this->db->get('tb_slip');
        							if($rs_slip->num_rows()==0) { // ถ้าไม่เคยเพิ่มสลิปนี้เข้าระบบ
        								$this->db->insert('tb_slip', $data_slip);
        							}
        							$sql_userpass = 'SELECT * FROM tb_userpass WHERE type = "scb" AND REPLACE(banknum, "-", "") LIKE "%'.$slip_toacnumber.'%"';
        							$query_userpass = $this->db->query($sql_userpass);
        							if($query_userpass->num_rows()==1){
        								$row_userpass = $query_userpass->row();
        								$bank = 'scb';
        								$userpass_id = $row_userpass->userpass_id;
        								$ac = $row_userpass->acnum;
        								$usernamebank = $row_userpass->username;
        								$passwordbank = $row_userpass->password;
        								$bankname = $row_userpass->bankname;
        								$userpass_status = $row_userpass->up_status;
        								$row_xfer = $this->transfer_channel_model->get_by_userpass_id($userpass_id);
        								if ($row_xfer && $row_xfer->site_id) {
        									$row_website = $this->website_model->get_by_site_id($row_xfer->site_id);
        								} else {
        									echo 'กรุณาตรวจสอบกลุ่มลูกค้า (transfer-channel)';
        									die();	
        								}
        								$this->db->select('*');
        								$this->db->where('st_datein', $slip_transdate);
        								$this->db->where('st_in', '+'.number_format($slip_amount,2));
        								$this->db->where('st_ac', $usernamebank);
        								$this->db->where('st_bank', $bank);
        								$this->db->like('st_comment', $slip_fromacnumber, 'both');
        								$rs_statement = $this->db->get('tb_statement');
        								if($rs_statement->num_rows()==0){
        							        
        									$credit = str_replace(',','',$slip_amount);
        									$datein = $slip_transdate;
        									
        									//+ บันทึก Statement
        									$data = array(
        											'st_out'=>'.',
        											'st_in'=>'+'.number_format($slip_amount,2),
        											'st_datein'=> $slip_transdate,
        											'st_datein_original'=> $slip_transdate,
        											'st_comment'=> $slip_fromacname.' เข้า '.$slip_toacname.' / ' . $slip_fromacnumber . ' - SLIP',
        											'st_bank'=> $bank,
        											'st_ac'=> $usernamebank,
        											'created'=>date('Y-m-d H:i:s'),
        											'st_from_bank'=> $slip_frombank,
        											'st_acc'=> $slip_fromacnumber,
        										);
        									$this->db->insert('tb_statement', $data);
        									$st_id = $this->db->insert_id();
        									//+ บันทึก Statement												
        								// 	$sql = 'SELECT uag.site_id, uag.dealer, us.user_id, uag.username, us.nickname, us.bankno,us.phone, us.refer_id, up.userpass_id, up.username AS agusername, up.password AS agpassword,up.authcode,up.secretkey,us.newmember,uag.default_deposit FROM tb_users us LEFT JOIN tb_users_agent uag ON us.user_id=uag.user_id  LEFT JOIN tb_userpass up ON uag.userpass_id=up.userpass_id WHERE RIGHT(us.bankno, 4)="'.$slip_fromacnumber.'" AND uag.uag_status = "ใช้" AND bank="SCB" AND us.xfer_h_id_deposit="'.$row_xfer->xfer_h_id.'" AND uag.site_id="'.$row_xfer->site_id.'" AND default_deposit="Y"';
        								// 	$sql = 'SELECT uag.site_id, uag.dealer, us.user_id, uag.username, us.nickname, us.bankno,us.phone, us.refer_id, up.userpass_id, up.username AS agusername, up.password AS agpassword,up.authcode,up.secretkey,us.newmember,uag.default_deposit FROM tb_users us LEFT JOIN tb_users_agent uag ON us.user_id=uag.user_id  LEFT JOIN tb_userpass up ON uag.userpass_id=up.userpass_id WHERE RIGHT(us.bankno, 4)="'.$slip_fromacnumber.'" OR SUBSTR(us.bankno, 6, 4)="'.$slip_fromacnumber.'" AND uag.uag_status = "ใช้" AND us.xfer_h_id_deposit="'.$row_xfer->xfer_h_id.'" AND uag.site_id="'.$row_xfer->site_id.'" AND default_deposit="Y"';
        									$sql = 'SELECT uag.site_id, uag.dealer, us.user_id, uag.username, us.nickname, us.bankno, us.phone, us.refer_id, up.userpass_id, up.username AS agusername, up.password AS agpassword, up.authcode, up.secretkey, us.newmember, uag.default_deposit FROM tb_users us LEFT JOIN tb_users_agent uag ON us.user_id=uag.user_id LEFT JOIN tb_userpass up ON uag.userpass_id=up.userpass_id WHERE uag.uag_status = "ใช้" AND us.xfer_h_id_deposit="1" AND uag.site_id="1" AND default_deposit="Y" AND (RIGHT(us.bankno, 4)="'.$slip_fromacnumber.'" OR SUBSTRING(us.bankno, 6, 4)="'.$slip_fromacnumber.'")';
        									$query_user = $this->db->query($sql);
        									if($query_user->num_rows()==1){
        										$row_user = $query_user->row();
        										$agusername = $row_user->agusername;
        										$agpassword = $row_user->agpassword;
        										$authcode = $row_user->authcode;
        										$secretkey = $row_user->secretkey;
        										$dealer = $row_user->dealer;
        										$user_id = $row_user->user_id;					
        										$name = $row_user->nickname;
        										$username = $row_user->username;
        										$refer_id = $row_user->refer_id;
        										$newmember = $row_user->newmember;
        										$site_id = $row_user->site_id;
        										$agent_id = $row_user->userpass_id;
        										$phone = $row_user->phone;
        										
        										// เปิดใบงาน
        										$data = array(
        											'ws_code'=>'-',
        											'site_id'=>$site_id,
        											'ws_dealer'=>$dealer,
        											'ws_type'=>'deposit',
        											'ws_date'=>$datein,
        											'user_id'=>$user_id,
        											'ws_debank'=>$bank,
        											'ws_debankac'=>$usernamebank,
        											'ws_debankacnum'=>$ac,
        											'ws_debankname'=>$bankname,
        											'ws_credit'=>$credit,
        											'ws_total'=>$credit,
        											'st_id'=>$st_id,
        											'c_status'=>1,
        											'c_comment'=>'เปิดอัตโนมัติ จาก SLIP',
        											'b_status'=>1,
        											'b_comment'=>'ตรวจอัตโนมัติ จาก SLIP',
        											'b_date'=>date('Y-m-d H:i:s'),
        											'created'=>date('Y-m-d H:i:s')
        										);
        										//$this->db->set('ws_code', 'CONCAT(DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y   \'),IFNULL((SELECT SUBSTR(`ws_code`, 14) FROM tb_worksheet AS `alias` WHERE SUBSTR(`ws_code`, 1, 10) = DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y\') ORDER BY created DESC LIMIT 1)+ 1,1) )', FALSE); //CAST(`ws_code` as SIGNED integer)
        										$this->db->insert('tb_worksheet', $data);
        										$ws_id = $this->db->insert_id();	
        										if($this->db->affected_rows() > 0){
        											/*อัพเดทสถานะ รายการเงินฝาก*/
        											$data = array(						
        												'st_status'=>1,
        												'modified'=>date("Y-m-d H:i:s")
        											);
        											$this->db->update('tb_statement', $data, array('st_id'=>$st_id));
        											/*อัพเดทสถานะ รายการเงินฝาก*/
        											
        											if($newmember=='Y'){
        												/*อัพเดทใบงาน*/
        												$data = array(
        													'b_comment'=>'ตรวจอัตโนมัติ จาก SLIP สมาชิกใหม่ ฝากครั้งแรก',
        													'modified'=>date("Y-m-d H:i:s")
        												);
        												$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
        												$noti_msg = "มีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
        												$noti_msg = rawurlencode($noti_msg);
        												// เรียก Line เมื่อมีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก
        												$chline = curl_init();
        												curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
        												curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
        												curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
        												$data = curl_exec($chline);	
        												curl_close($chline);
        												// เรียก Line เมื่อมีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก
        											}else{
        												
        												// เช็คยอดฝากเท่ากันในเวลา 5 นาที
        												$sqlwsfiveminute = 'SELECT ws_id FROM tb_worksheet WHERE user_id='.$user_id.' AND ws_id!='.$ws_id.' AND ws_type = "deposit" AND ws_date BETWEEN "'.date('Y-m-d H:i:s',strtotime( '-2 minute' , strtotime($datein))).'" AND "'.date('Y-m-d H:i:s',strtotime( '+3 minute' , strtotime($datein))).'" AND (ws_credit="'.$credit.'"OR ws_credit="'.number_format($credit,2,'.','').'")';
        												$query_wsfiveminute = $this->db->query($sqlwsfiveminute);
        												if($query_wsfiveminute->num_rows()==0){
        													
        													if ($userpass_status == 1) {
        														// ทำการฝากเงินเข้าเกมส์
        														$dataeditcredit = $this->edit_credit($agusername,$agpassword,$name,$username,$credit,$dealer,$site_id,$user_id,$authcode,$secretkey);
        													} else {
        														$dataeditcredit = array();
        														$dataeditcredit['success']=false;
        													}
        													// หากทำการฝากสำเร็จ
        													if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
        														/*อัพเดทใบงาน*/
        														$data = array(						
        															'de_id'=>$dataeditcredit['de_id'],
        															'm_status'=>1,
        															'm_comment'=>'ตรวจอัตโนมัติ จาก SLIP',
        															'm_date'=>date('Y-m-d H:i:s'),
        															'modified'=>date("Y-m-d H:i:s")
        														);
        														$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
        														/*หาก creditbefore มากกว่า 10 ดึงโปรโมชั่นที่ลูกค้ารับ มาเช็ค ว่าทำการถอนไปหรือยัง*/
        														//$sql = 'SELECT pr_user_id,withdraw_pro FROM tb_promotion_user JOIN  tb_worksheet ON (tb_worksheet.ws_id=tb_promotion_user.ws_id OR tb_promotion_user.ws_id IS NULL) WHERE ws_dealer = "Pussy888" AND tb_promotion_user.user_id='.$user_id.' ORDER BY tb_promotion_user.created DESC limit 1';
        														$sql = 'SELECT pr_user_id,withdraw_pro,turn_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$dealer.'" ORDER BY created DESC limit 1';
        														$query_promotion_user = $this->db->query($sql);
        														if($query_promotion_user->num_rows()>0){
        															$row_promotion_user = $query_promotion_user->row();
        															if($row_promotion_user->withdraw_pro=='n'){
        																if($dataeditcredit['creditbefore']>10){	
        																	$newcredit_pro = $credit*$row_promotion_user->turn_pro;
        																	//+ เพิ่มจำนวนเครดิตทำเทริน
        																	$sql = "UPDATE tb_promotion_user SET credit_pro = credit_pro+".$newcredit_pro." WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
        																	$this->db->query($sql);
        																	//+ สิ้นสุดเพิ่มจำนวนเครดิตทำเทริน
        																}else{
        																	//+ ทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
        																	$sql = "UPDATE tb_promotion_user SET withdraw_pro = 'y', note='ปรับ withdraw_pro = y เนื่องจากมียอดก่อนฝาก น้อยกว่า 10',modified='".date("Y-m-d H:i:s")."' WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
        																	$this->db->query($sql);
        																	//+ สิ้นสุดทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
        																} // End if($dataeditcredit['creditbefore']>10){
        															} // End if($row_promotion_user->withdraw_pro=='n'){
        														} // End if($query_promotion_user->num_rows()>0){
        														
        														if ($row_website->site_line_callback_url) {
        															// เช็ค gid จาก username
        															$chgid = curl_init();
        															curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
        															curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
        															curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
        															$gid = curl_exec($chgid);
        															curl_close($chgid);
        				
        															// เรียก Line
        															$chline = curl_init();
        															curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=deposit&username='.$username.'&credit='.$credit.'&phone='.$phone);
        															curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
        															curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
        															$data = curl_exec($chline);	
        															curl_close($chline);
        															// เรียก Line
        														}
        													}else{
        														$noti_msg = "มีใบงานที่รอตรวจสอบ:: เว็บ:".$row_website->site_name.". เกม:$dealer. เอเยนต์:$agusername. ยูส:$username. ยอด:$credit บาท.";
        														$noti_msg = rawurlencode($noti_msg);
        														// // เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
        														$chline = curl_init();
        														curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg));
        														curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
        														curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
        														$data = curl_exec($chline);	
        														curl_close($chline);
        														// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
        													} // End if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
        												}else{
        													/*อัพเดทใบงาน*/
        													$data = array(
        														'b_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์ ฝากยอดเดียวกันในเวลา 5 นาที',
        														'modified'=>date("Y-m-d H:i:s")
        													);
        													$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
        													$noti_msg = "มีใบงานยอดเงินเดียวกันในเวลา 5 นาที:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
        													$noti_msg = rawurlencode($noti_msg);
        													// เรียก Line เมื่อมีใบงานยอดเงินเดียวกันในเวลา 5 นาที
        													$chline = curl_init();
        													curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
        													curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
        													curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
        													$data = curl_exec($chline);	
        													curl_close($chline);
        													// เรียก Line เมื่อมีใบงานยอดเงินเดียวกันในเวลา 5 นาที
        												}// End if($query_wsfiveminute->num_rows()==0){
        											} // End if($newmember=='Y'){
        										} // End if($this->db->affected_rows() > 0){
        									} // End if($query_user->num_rows()==1){
        								} // End if($rs_statement->num_rows()==0){
        							} else {
        								// ไม่ทำต่อเพราะมีธนาคารฝาก SCB ในระบบที่เลขท้าย 4 ตัวเหมือนกัน
        							}
        						// } else {
        						// 	$data_return = array('error_status'=>true, 'error_message'=>'เฉพาะลูกค้า SCB ฝากเข้า SCB เท่านั้น');
        						// }
        					} else {
        						$data_return = array('error_status'=>true, 'error_message'=>'ข้อมูลไม่ถูกต้อง');
        					}
        				} else {
        					$data_return = array('error_status'=>true, 'error_message'=>'ไม่พบสลิป');
        				}
        			}
    		    }
		}
		echo json_encode($row_statement->num_rows());
    }
    
    public function exam(){
	        $this->db->select('*');
			$this->db->from('tb_users a');
			$this->db->join('tb_users_agent b', 'b.user_id=a.user_id', 'left');
    		$this->db->join('tb_userpass c', 'c.userpass_id=a.userpass_id', 'left');
    		$this->db->where('b.user_id', '6');
    		$this->db->where('b.default_deposit', 'Y');
    		$query_uag = $this->db->get(); 
    		echo '<pre>';
    		print_r(json_encode($query_uag));
	}
	
		
}
