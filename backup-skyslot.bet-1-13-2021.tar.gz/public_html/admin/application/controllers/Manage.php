<?php
defined('BASEPATH') OR exit('No direct script access allowed');
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Manage extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
	}
	
	public function get_user(){

		$sql = "SELECT * FROM tb_users WHERE 1 AND username IS NOT NULL AND username != ''";
		$query = $this->db->query($sql);
		$count = $query->num_rows();
		echo $count;
		if($count>0){
			foreach($query->result() as $row_user){
				echo $row_user->user_id.'  -> <span style="background-color:red">'.$row_user->username.'</span>'; 
				echo '<br>';
			}
		}
	}
			
	function __destruct(){
		
	}
		
}