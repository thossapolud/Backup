<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Website extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth'));
		$auth = new auth();
		$auth->isnot_login();
		$auth->isnot_admin();
		$this->load->model('transfer_channel_model');
		$this->load->model('website_model');
	}

	public function index(){
		$data['Content'] = $this->load->view('website/index', NULL, true);
		$this->load->view('template/temp_main', $data);
	}

	public function get_website() {
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'site_name',2=>'site_url',3=>'site_status',4=>'site_id');

		// DB table to use
		$sTable = 'tb_website';
		//

		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);

		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}

		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);

				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}

		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++){
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);

				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
				}
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}

		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$rResult = $this->db->get($sTable);		
		
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;

		// Total data set length
		$iTotal = $this->db->count_all_results($sTable);

		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$aColumns = array(1=>'site_name',2=>'site_url',3=>'site_status',4=>'site_id');
			$row[0] = $iDisplayStart;		
			$row[1] = $aRow->site_name;
			$row[2] = $aRow->site_url;
			$row[3] = ($aRow->site_status == 1) ? '<span class="badge badge-success">ใช้งาน</span>':'<span class="badge badge-primary">ปิดใช้งาน</span>';		
			$row[4] = $aRow->site_id;
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}

	public function add() {
		$post = $this->input->post();
		if($post) {
			extract($post);
			// Get and Check if site_url is already used by other site_id
			$row_website_check_url = $this->db->get_where('tb_website', 'site_url = "'.$site_url.'"')->row();
			if ($row_website_check_url) {
				echo "เพิ่มเว็บไซต์ไม่สำเร็จ (โดเมนเนมซ้ำ";
			} else {
				// Get and Check if site_name is already used by other site_id
				$row_website_check_site_name = $this->website_model->get_by_site_name($site_name);
				if ($row_website_check_site_name) {
					echo "เพิ่มเว็บไซต์ไม่สำเร็จ (ชื่อเว็บไซต์ซ้ำ)";
				} else {
					$data = array(
						'site_name' => $site_name,
						'site_url' => $site_url,
						'site_created' => date('Y-m-d H:i:s'),
						'site_modified' => date('Y-m-d H:i:s')
					);
					$result = $this->website_model->add_website($data);
					if ($result === TRUE) {
						echo "เพิ่มเว็บไซต์สำเร็จ";
					} else {
						echo "เพิ่มเว็บไซต์ไม่สำเร็จ";
					}
				}
			}
		} else {
			echo "โปรดตรวจสอบข้อมูล";
		}
	}

	public function form_edit_website() {
		$site_id = $this->input->get('stid');
		if ($site_id) {
			$row_website = $this->website_model->get_by_site_id($site_id);
			$Content['row_website'] = $row_website;
			$Content['rs_xfer_deposit'] = $this->transfer_channel_model->get_deposit_by_site_id($row_website->site_id);
			$Content['rs_xfer_withdraw'] = $this->transfer_channel_model->get_withdraw_by_site_id($row_website->site_id);
			$this->load->view('website/form-edit-website', $Content);
		}
	}

	public function edit() {
		$post = $this->input->post();
		if($post) {
			extract($post);
			// Get and Check if site_url is already used by other site_id
			$row = $this->db->get_where('tb_website', 'site_id != '.$site_id.' AND site_url = "'.$site_url.'"')->row();
			if ($row) {
				$this->session->set_flashdata('msg_error', 'แก้ไขเว็บไซต์ไม่สำเร็จ (โดเมนเนมซ้ำ)');
				redirect('website');
			} else {
				$data = array(
					'site_url' => $site_url,
					'site_status' => $site_status,
					'site_def_xfer_h_id_deposit' => $site_def_xfer_h_id_deposit,
					'site_def_xfer_h_id_withdraw' => $site_def_xfer_h_id_withdraw,
					'site_line_chat_url' => $site_line_chat_url,
					'site_line_callback_url' => $site_line_callback_url,
					'site_announcement' => $site_announcement,
					'site_modified' => date('Y-m-d H:i:s')
				);
				$cond = array('site_id'=>$site_id);
				$result = $this->website_model->edit_website($data, $cond);
				if ($result === TRUE) {
					$this->session->set_flashdata('msg_success', 'แก้ไขเว็บไซต์สำเร็จ');
					redirect('website');
				} else {
					$this->session->set_flashdata('msg_error', 'แก้ไขเว็บไซต์ไม่สำเร็จ');
					redirect('website');
				}
			}
		}
		$this->session->set_flashdata('msg_error', 'กรุณาตรวจสอบข้อมูล');
		redirect('website');
	}

}
