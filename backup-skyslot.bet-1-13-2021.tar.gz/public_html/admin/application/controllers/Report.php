<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {
	var $auth;
	//var $history;
	var $datestart;
	var $dateend;
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth'));
		$this->auth = new auth();
		//$this->history = new history_log();
		$this->auth->isnot_login();

		$this->titlecomponent->add('รายงาน');
		
		$G = date('G', strtotime(date('Y-m-d H:i:s')));
		if($G>11){
			$this->datestart = date('Y-m-d').' 11:00:00';
			$this->dateend = date('Y-m-d 11:00:00',(strtotime ( '+1 day' , strtotime(date('Y-m-d')))));
			
		}else{
			$this->datestart = date('Y-m-d 11:00:00',(strtotime ( '-1 day' , strtotime(date('Y-m-d')))));
			$this->dateend = date('Y-m-d').' 11:00:00';
		}
	}
		
	public function bank_deposit(){
		$this->load->model('userpass_model');
		$this->load->model('statement_model');	

		$ac= "";
		$type = "";
		$username = "";
		
		if($this->input->post('datestart')&&$this->input->post('datestart')!=''&&$this->input->post('dateend')&&$this->input->post('dateend')!=''){
			$this->datestart = $this->input->post('datestart');
			$this->dateend = $this->input->post('dateend');
			$row_userpass = $this->userpass_model->get_by_bankid($this->input->post('ac'));
			if ($row_userpass) {
				$ac= $row_userpass->userpass_id;
				$type = $row_userpass->type;
				$username = $row_userpass->username;
			}
		}
		$this->titlecomponent->add('รายงาน');
		$this->titlecomponent->add('ธนาคารฝาก');
		$Content['datestart'] = $this->datestart;
		$Content['dateend'] = $this->dateend;
		$Content['ac'] = $ac;
		$Content['type'] = $type;
		$Content['rs_bank'] = $this->userpass_model->get_active_deposit_withdraw_bank(NULL,NULL,'deposit');
		$Content['row_statement'] = $this->statement_model->get_sumin($type,$username,$this->datestart,$this->dateend,1);
		$Content['row_statementnotopen'] = $this->statement_model->get_sumin($type,$username,$this->datestart,$this->dateend,0);
		$Content['rs_statement'] = $this->statement_model->get_st_in_report($type,$username,$this->datestart,$this->dateend,1);
		$data['Content'] = $this->load->view('report/bank-deposit', $Content, true);
		$this->load->view('template/temp_main', $data);
	}
	
	public function bank_withdraw(){
		$this->load->model('userpass_model');
		$this->load->model('worksheet_model');

		$ac= "";
		$type = "";
		$username = "";
		$bankname = "";
		
		if($this->input->post('datestart')&&$this->input->post('datestart')!=''&&$this->input->post('dateend')&&$this->input->post('dateend')!=''){
			$this->datestart = $this->input->post('datestart');
			$this->dateend = $this->input->post('dateend');
			$row_userpass = $this->userpass_model->get_by_bankid($this->input->post('ac'));
			if ($row_userpass) {
				$ac= $row_userpass->userpass_id;
				$type = $row_userpass->type;
				$username = $row_userpass->username;
				$bankname = $row_userpass->bankname;
			}
		}
		
		$this->titlecomponent->add('ธนาคาร ถอน '.$type);
		$Content['datestart'] = $this->datestart;
		$Content['dateend'] = $this->dateend;
		$Content['ac'] = $ac;
		$Content['type'] = $type;
		$Content['rs_bank'] = $this->userpass_model->get_active_deposit_withdraw_bank(NULL,NULL,'withdraw');
		$Content['row_statement'] = $this->worksheet_model->get_worksheet_withdraw_sumcredit($type,$username,$bankname,$this->datestart,$this->dateend);
		$Content['rs_statement'] = $this->worksheet_model->get_worksheet_withdraw_report($type,$username,$bankname,$this->datestart,$this->dateend);
		$data['Content'] = $this->load->view('report/bank-withdraw', $Content, true);
		$this->load->view('template/temp_main', $data);
	}
	
	public function promotion(){
		$dealer = $this->uri->segment(3,0);
		if($dealer){
			$this->load->model('promotion_user_model');
			if($this->input->post('datestart')&&$this->input->post('datestart')!=''&&$this->input->post('dateend')&&$this->input->post('dateend')!=''){
				$this->datestart = $this->input->post('datestart');
				$this->dateend = $this->input->post('dateend');
			}
			
			$this->titlecomponent->add('รับโปรโมชั่น '.$dealer);
			$Content['datestart'] = $this->datestart;
			$Content['dateend'] = $this->dateend;
	
			$Content['rs_promotionuser'] = $this->promotion_user_model->get_promotion_sumcredit($dealer,$this->datestart,$this->dateend);
			$Content['rs_promotionuserlist'] = $this->promotion_user_model->get_promotion_report($dealer,$this->datestart,$this->dateend);
			$data['Content'] = $this->load->view('report/promotion', $Content, true);
			$this->load->view('template/temp_main', $data);
		}
	}
	
	public function account_summary() {
		$this->auth->isnot_admin();

		if($this->input->post('datestart')&&$this->input->post('datestart')!=''&&$this->input->post('dateend')&&$this->input->post('dateend')!=''){
			$this->datestart = $this->input->post('datestart');
			$this->dateend = $this->input->post('dateend');
		}

		$sql = 'SELECT 
					ac.username, 
					SUM(acio.action=("login")) AS total_login, 
					SUM(acio.action=("logout")) AS total_logout, 
					IFNULL(worksheet_call,0) AS worksheet_call, 
					IFNULL(worksheet_bank,0) AS worksheet_bank, 
					IFNULL(worksheet_manage,0) AS worksheet_manage, 
					ac.ac_id 
				FROM tb_account ac 
				LEFT JOIN tb_account_loginout acio ON acio.ac_id = ac.ac_id 
				LEFT JOIN (
					SELECT c_id, COUNT(c_id) AS worksheet_call 
					FROM tb_worksheet 
					WHERE created >= "'.$this->datestart.'" AND 
						created < "'.$this->dateend.'" AND 
						c_id IS NOT NULL 
					GROUP BY c_id) 
					AS ws_c ON ws_c.c_id = ac.ac_id 
				LEFT JOIN (
					SELECT b_id, count(b_id) AS worksheet_bank 
					FROM tb_worksheet 
					WHERE b_date >= "'.$this->datestart.'" AND 
						b_date < "'.$this->dateend.'" AND 
						b_id IS NOT NULL 
					GROUP BY b_id) 
					AS ws_b ON ws_b.b_id = ac.ac_id 
				LEFT JOIN (
					SELECT m_id, count(m_id) AS worksheet_manage 
					FROM tb_worksheet 
					WHERE m_date >= "'.$this->datestart.'" AND 
						m_date < "'.$this->dateend.'" AND 
						m_id IS NOT NULL 
					GROUP BY m_id) 
					AS ws_m ON ws_m.m_id = ac.ac_id 
				WHERE acio.created >= "'.$this->datestart.'" AND 
					acio.created < "'.$this->dateend.'" 
				GROUP BY ac.ac_id, ac.username';
		$rs_account_summary = $this->db->query($sql);


		$this->titlecomponent->add('พนักงาน');
		$Content['datestart'] = $this->datestart;
		$Content['dateend'] = $this->dateend;

		$Content['rs_account_summary'] = $rs_account_summary;

		$data['Content'] = $this->load->view('report/account_summary', $Content, true);
		$this->load->view('template/temp_main', $data);
	}

	public function account_summary_detail() {
		$this->auth->isnot_admin();

		$this->load->model('account_model');

		if($this->input->get('datestart')&&$this->input->get('datestart')!=''&&$this->input->get('dateend')&&$this->input->get('dateend')!=''){
			$this->datestart = $this->input->get('datestart');
			$this->dateend = $this->input->get('dateend');
		}

		$ac_id = $this->input->get('acid');
		$row_account = $this->account_model->get_by_id($ac_id);

		$Content['row_account'] = $row_account;
		if ($row_account) {
			$this->db->select('action, user_agent, ip_address, created');
			$this->db->where('ac_id', $ac_id);
			$this->db->where('created >=', $this->datestart);
			$this->db->where('created <', $this->dateend);
			$this->db->order_by('created', 'asc');
			$rs_loginout_history =  $this->db->get('tb_account_loginout');
			$Content['rs_loginout_history'] = $rs_loginout_history;

			$sql = 'SELECT * FROM (
						SELECT ws_type,ws_credit,ws_pro,ws_total,created as datetime,ws_id 
						FROM tb_worksheet 
						WHERE c_id = "'.$ac_id.'" and created >= "'.$this->datestart.'" and created < "'.$this->dateend.'" ';
			$sql .= '	UNION ALL ';
			$sql .= '	SELECT ws_type,ws_credit,ws_pro,ws_total,b_date as datetime,ws_id 
						FROM tb_worksheet 
						WHERE b_id = "'.$ac_id.'" and b_date >= "'.$this->datestart.'" and b_date < "'.$this->dateend.'" ';
			$sql .= '	UNION ALL ';
			$sql .= '	SELECT ws_type,ws_credit,ws_pro,ws_total,b_date as datetime,ws_id 
						FROM tb_worksheet 
						WHERE m_id = "'.$ac_id.'" and m_date >= "'.$this->datestart.'" and m_date < "'.$this->dateend.'" ';
			$sql .= ' ) ws order by datetime asc';
			$rs_worksheet_history = $this->db->query($sql);
			$Content['rs_worksheet_history'] = $rs_worksheet_history;

			$this->load->view('report/account_summary_detail', $Content);
		}
	}
	
	public function summary(){		
		$dealer = ($this->input->post('dealer')!='')?$this->input->post('dealer'):'Pussy888';
		if($this->input->post('datestart')&&$this->input->post('datestart')!=''&&$this->input->post('dateend')&&$this->input->post('dateend')!=''){
			$this->datestart = $this->input->post('datestart');
			$this->dateend = $this->input->post('dateend');
		}
		
		$this->titlecomponent->add('สรุปยอด');			
		$Content['datestart'] = $this->datestart;
		$Content['dateend'] = $this->dateend;
		
		$this->load->model('agent_model');
		$this->load->model('userpass_model');
		$this->load->model('statement_model');
		$this->load->model('worksheet_model');
		$this->load->model('deposit_model');
		$this->load->model('withdraw_model');
		
		//+ แบงค์ฝาก
		$rs_bank_deposit = $this->userpass_model->get_active_deposit_withdraw_bank(NULL,NULL,'deposit');
		//+ แบงค์ถอน
		$rs_bank_withdraw = $this->userpass_model->get_active_deposit_withdraw_bank(NULL,NULL,'withdraw');
				
		if($dealer=='All'||$dealer=='Pussy888'){
			//++ PUSSY
			$Content['rs_pussy'] = $this->agent_model->get_by_dealer('Pussy888');			
			$depussy = array(); $denotopenpussy = array();
			if ($rs_bank_deposit->num_rows() > 0) {
				foreach ($rs_bank_deposit->result() as $row_bank) {
					$depussy[$row_bank->userpass_id] = $this->statement_model->get_sumin($row_bank->type, $row_bank->username, $this->datestart, $this->dateend,1,'Pussy888');
					$denotopenpussy[$row_bank->userpass_id] = $this->statement_model->get_sumin($row_bank->type, $row_bank->username, $this->datestart, $this->dateend,0);
				}
			}
			$wipussy = array();
			if ($rs_bank_withdraw->num_rows() > 0) {
				foreach ($rs_bank_withdraw->result() as $row_bank) {					
					$wipussy[$row_bank->userpass_id] = $this->worksheet_model->get_worksheet_withdraw_sumcredit_group($row_bank->type,$row_bank->username,$row_bank->bankname,$this->datestart,$this->dateend,'Pussy888')->row();
				}
			}			
			$Content['depussy'] = $depussy;
			$Content['denotopenpussy'] = $denotopenpussy;
			$Content['wipussy'] = $wipussy;
		}

		if($dealer=='All'||$dealer=='918kiss'){
			//++ 918KISS
			$Content['rs_scr'] = $this->agent_model->get_by_dealer('918kiss');			
			$descr = array(); $denotopenscr = array();
			if ($rs_bank_deposit->num_rows() > 0) {
				foreach ($rs_bank_deposit->result() as $row_bank) {
					$descr[$row_bank->userpass_id] = $this->statement_model->get_sumin($row_bank->type, $row_bank->username, $this->datestart, $this->dateend,1,'918kiss');
					$denotopenscr[$row_bank->userpass_id] = $this->statement_model->get_sumin($row_bank->type, $row_bank->username, $this->datestart, $this->dateend,0);
				}
			}
			$wiscr = array();
			if ($rs_bank_withdraw->num_rows() > 0) {
				foreach ($rs_bank_withdraw->result() as $row_bank) {					
					$wiscr[$row_bank->userpass_id] = $this->worksheet_model->get_worksheet_withdraw_sumcredit_group($row_bank->type,$row_bank->username,$row_bank->bankname,$this->datestart,$this->dateend,'918kiss')->row();
				}
			}			
			$Content['descr'] = $descr;
			$Content['denotopenscr'] = $denotopenscr;
			$Content['wiscr'] = $wiscr;
		}
		
		$Content['dealer'] = $dealer;
		$Content['rs_bank_deposit'] = $rs_bank_deposit;
		$Content['rs_bank_withdraw'] = $rs_bank_withdraw;
		$data['Content'] = $this->load->view('report/summary', $Content, true);
		$this->load->view('template/temp_main', $data);
	}
		
}
