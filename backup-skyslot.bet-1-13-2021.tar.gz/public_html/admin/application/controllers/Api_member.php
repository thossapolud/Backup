<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Api_member extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('history_log'));
        $this->history = new history_log();
	}
	
	/**
	 * Create member and game user
	 */
	public function create_member() {
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.0');
		$this->load->model('website_model');
		$this->load->model('agent_model');
		$post = $this->input->post();
        if ($post) {
            extract($post);
			$row_agent = $this->agent_model->get_default_by_site_id_and_dealer($site_id,$dealer);
			if ($row_agent) {
				$is_register = $this->check_already_register_before($row_agent->site_id, $row_agent->type, $row_agent->userpass_id, $phone, $bankno, $accountname);
				if($is_register['status']==false) {
					if ($row_agent->type == 'Ufa') {
						$data_return = $this->gen_game_user($row_agent->type, $row_agent->userpass_id, 0, $accountname);
					} else {
						$data_return = $this->gen_game_user($row_agent->type, $row_agent->userpass_id, 0, $bankno);
					}
					
					if ($data_return['status'] === true) {
						$username = $data_return['username'];
						$password = $data_return['password'];
						$row_website = $this->website_model->get_by_site_id($row_agent->site_id);
						
						if($is_register['have_user']==false){
							$data = array(
								'waitopen' => (isset($waitopen)) ? $waitopen : 'N',
								'nickname' => (isset($nickname)) ? trim($nickname) : '',
								'email' => (isset($email)) ? trim($email) : NULL,
								'phone' => $phone,
								'lineid' => $lineid,
								'accountname' => $accountname,
								'bank' => $bank,
								'bankno' => $bankno,
								'xfer_h_id_deposit' => $row_website->site_def_xfer_h_id_deposit,
								'xfer_h_id_withdraw' => $row_website->site_def_xfer_h_id_withdraw,
								'province' => 'AUTO',
								'refer' => ($lineuserid && $groupline_id) ? 'สมัครผ่านหน้าไลน์' : 'สมัครผ่านหน้าเว็บ',
								'other' => (isset($other)) ? trim($other) : '',
								'withdrawcode' => $withdrawcode,
								'register_date' => date('Y-m-d'),
								'add_by' => 'AUTO',
								'created' => date('Y-m-d H:i:s'),
							);
							$result = $this->db->insert('tb_users', $data);
							if ($result) {
								$user_id = $this->db->insert_id();							
								$data = array(
									'user_id' => $user_id,
									'site_id' => $row_agent->site_id,
									'dealer' => $row_agent->type,
									'userpass_id' => $row_agent->userpass_id,
									'username' =>$username,
									'password' => $password,	
									'default_deposit'=>'Y',								
									'open_date' =>date('Y-m-d H:i:s'),
									'uag_created' => date('Y-m-d H:i:s'),
								);
								$result = $this->db->insert('tb_users_agent', $data);
								$user_agid = $this->db->insert_id();
							} else {
								$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.1-1');
							}
						}else{
							$user_id = $is_register['user_id'];
							
							// Update username agent เก่าให้มีสถานะเติม ออโตตอนฝาก เป็น N
							$this->db->update('tb_users_agent', array('default_deposit'=>'N'), array('user_id'=>$user_id));
															
							$data = array(
								'user_id' => $user_id,
								'site_id' => $row_agent->site_id,
								'dealer' => $row_agent->type,
								'userpass_id' => $row_agent->userpass_id,
								'username' =>$username,
								'password' => $password,
								'default_deposit'=>'Y',									
								'open_date' =>date('Y-m-d H:i:s'),
								'uag_created' => date('Y-m-d H:i:s'),
							);
							$result = $this->db->insert('tb_users_agent', $data);
							$user_agid = $this->db->insert_id();
							if($result){
							}else{
								$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.1-2');
							}
						}
						
						$data = array(
							'dealer' => $row_agent->type,
							'username' => (isset($waitopen)) ? NULL : trim($username),
						);
						$this->history->save(array('action' => 'เพิ่ม', 'user_id' => $user_id, 'detail' => json_encode($data)));
						
						if ($row_website->site_line_callback_url && $lineuserid && $groupline_id) {
							//send to line
							$chline = curl_init();
							curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url . '?linepush=1&act=register&lineuserid=' . $lineuserid . '&password=' . urlencode($password) . '&username=' . $username . '&gid=' . $groupline_id . '&phone=' . $phone . '');
							curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
							$linedata = curl_exec($chline);
							curl_close($chline);
						}	
						
						/*if ($row_website->site_line_callback_url) {
							//curl มาที่ url /line/callbackall.php?act=updategamedf&linepush=1&username=022323232&phone=0984343434
							$chline = curl_init();
							curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url.'?act=updategamedf&linepush=1&username='.$username.'&phone='.$phone);
							curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
							$linedata = curl_exec($chline);
							curl_close($chline);
						}*/
						
						$return = array('errorCode' => 0, 'errorMessage' => 'สำเร็จ','username' => $username, 'password' => $password, 'phone' => $phone);
					
					} else {
						$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.2');
					}
				} else {
					$return = array('errorCode' => 1, 'errorMessage' => 'คุณเคยเป็นสมาชิกอยู่แล้ว '.$is_register['username'].' Ref.3');
				}
			} else {
				$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.4');
			}
		}
		echo json_encode($return);
    }
   
    /////// allreadyotp /////
    public function create_member_by_VerifyOtp(){
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.0');
		$this->load->model('website_model');
		$this->load->model('agent_model');
		$post = $this->input->post();
        if ($post) {
            extract($post);
			$is_verifyotp = $this->register_Verify_OTP($pintoken,$pin);
			if($is_verifyotp['errorCode']){ //ตรวจสอบ otp
				$return = array('errorCode' => 1, 'errorMessage' => 'pin ไม่ถูกต้อง หรือ ถูกใช้งานแล้ว Ref.otp');
				echo json_encode($is_verifyotp);
				return;
			}
			$row_agent = $this->agent_model->get_default_by_site_id_and_dealer($site_id,$dealer);
			if ($row_agent) {
				$is_register = $this->check_already_register_before($row_agent->site_id, $row_agent->type, $row_agent->userpass_id, $phone, $bankno, $accountname);
				if($is_register['status']==false) {
					if ($row_agent->type == 'Ufa') {
						$data_return = $this->gen_game_user($row_agent->type, $row_agent->userpass_id, 0, $accountname);
					} else {
						$data_return = $this->gen_game_user($row_agent->type, $row_agent->userpass_id, 0, $bankno);
					}
					
					if ($data_return['status'] === true) {
						$username = $data_return['username'];
						$password = $data_return['password'];
						$row_website = $this->website_model->get_by_site_id($row_agent->site_id);
						
						if($is_register['have_user']==false){
							$data = array(
								'waitopen' => (isset($waitopen)) ? $waitopen : 'N',
								'nickname' => (isset($nickname)) ? trim($nickname) : '',
								'email' => (isset($email)) ? trim($email) : NULL,
								'phone' => $phone,
								'lineid' => $lineid,
								'accountname' => $accountname,
								'bank' => $bank,
								'bankno' => $bankno,
								'xfer_h_id_deposit' => $row_website->site_def_xfer_h_id_deposit,
								'xfer_h_id_withdraw' => $row_website->site_def_xfer_h_id_withdraw,
								'province' => 'AUTO',
								'refer' => ($lineuserid && $groupline_id) ? 'สมัครผ่านหน้าไลน์' : 'สมัครผ่านหน้าเว็บ',
								'other' => (isset($other)) ? trim($other) : '',
								'withdrawcode' => $withdrawcode,
								'register_date' => date('Y-m-d'),
								'add_by' => 'AUTO',
								'created' => date('Y-m-d H:i:s'),
							);
							$result = $this->db->insert('tb_users', $data);
							if ($result) {
								$user_id = $this->db->insert_id();							
								$data = array(
									'user_id' => $user_id,
									'site_id' => $row_agent->site_id,
									'dealer' => $row_agent->type,
									'userpass_id' => $row_agent->userpass_id,
									'username' =>$username,
									'password' => $password,	
									'default_deposit'=>'Y',								
									'open_date' =>date('Y-m-d H:i:s'),
									'uag_created' => date('Y-m-d H:i:s'),
								);
								$result = $this->db->insert('tb_users_agent', $data);
								$user_agid = $this->db->insert_id();
							} else {
								$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.1-1');
							}
						}else{
							$user_id = $is_register['user_id'];
							
							// Update username agent เก่าให้มีสถานะเติม ออโตตอนฝาก เป็น N
							$this->db->update('tb_users_agent', array('default_deposit'=>'N'), array('user_id'=>$user_id));
															
							$data = array(
								'user_id' => $user_id,
								'site_id' => $row_agent->site_id,
								'dealer' => $row_agent->type,
								'userpass_id' => $row_agent->userpass_id,
								'username' =>$username,
								'password' => $password,
								'default_deposit'=>'Y',									
								'open_date' =>date('Y-m-d H:i:s'),
								'uag_created' => date('Y-m-d H:i:s'),
							);
							$result = $this->db->insert('tb_users_agent', $data);
							$user_agid = $this->db->insert_id();
							if($result){
							}else{
								$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.1-2');
							}
						}
						
						$data = array(
							'dealer' => $row_agent->type,
							'username' => (isset($waitopen)) ? NULL : trim($username),
						);
						$this->history->save(array('action' => 'เพิ่ม', 'user_id' => $user_id, 'detail' => json_encode($data)));
						
						if ($row_website->site_line_callback_url && $lineuserid && $groupline_id) {
							//send to line
							$chline = curl_init();
							curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url . '?linepush=1&act=register&lineuserid=' . $lineuserid . '&password=' . urlencode($password) . '&username=' . $username . '&gid=' . $groupline_id . '&phone=' . $phone . '');
							curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
							$linedata = curl_exec($chline);
							curl_close($chline);
						}	
						
						/*if ($row_website->site_line_callback_url) {
							//curl มาที่ url /line/callbackall.php?act=updategamedf&linepush=1&username=022323232&phone=0984343434
							$chline = curl_init();
							curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url.'?act=updategamedf&linepush=1&username='.$username.'&phone='.$phone);
							curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
							$linedata = curl_exec($chline);
							curl_close($chline);
						}*/
						
						$return = array('errorCode' => 0, 'errorMessage' => 'สำเร็จ','username' => $username, 'password' => $password);
					
					} else {
						$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.2');
					}
				} else {
					$return = array('errorCode' => 1, 'errorMessage' => 'คุณเคยเป็นสมาชิกอยู่แล้ว ยูสเกมส์ '.$is_register['username'].' Ref.3');
				}
			} else {
				$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.4');
			}
		}
		echo json_encode($return);
	}
    
	public function allreadyotprequest(){
        $return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.0');
        
		$this->load->model('website_model');
		$this->load->model('agent_model');
		$post = $this->input->post();
        if ($post) {
            extract($post);
			$row_agent = $this->agent_model->get_default_by_site_id_and_dealer($site_id,$dealer);
			if ($row_agent) {
				$is_register = $this->check_already_register_before($row_agent->site_id, $row_agent->type, $row_agent->userpass_id, $phone, $bankno, $accountname);
				if($is_register['status']==false) {
                    $return = array('errorCode' => 0, 'errorMessage' => 'รับ otp จาก SMS ที่เบอร์');
                } else {
					$return = array('errorCode' => 1, 'errorMessage' => 'คุณเคยเป็นสมาชิกอยู่แล้ว ยูสเกมส์ '.$is_register['username'].' Ref.3');
				}
			} else {
				$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.4');
			}
        }
        
        echo json_encode($return);
        // echo json_encode("asdasd");
        
    }
   
    public function register_Request_OTP(){
        $post = $this->input->post();
        if ($post) {
            extract($post);
            $this->load->library('otp');
    		$otp = new otp();
    		$token = $otp->Request_OTP($phone);
    		echo $token;
        }else{
            $return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ กรุณาติดต่อพนักงาน Ref.4');
        }
		
	}
	
	private function register_Verify_OTP($pintoken,$pin){
	    $this->load->library('otp');
		$otp = new otp();
		$verifyCode = $otp->Verify_OTP($pintoken,$pin);
		return $verifyCode;
	}
   
    //////////////////
	/**
	 * Get this user credit
	 * creditGame is credit that still in game
	 * creditBalance is credit that outside game
	 * creditTotal is creditGame combined with creditBalance
	 */
	public function get_game_user_credit($dealer=NULL,$user_id=NULL,$uniqueid=NULL,$refresh='N') {
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ');
		if ($dealer && $user_id && $uniqueid) {
			$this->load->model('user_model');
			$row_user = $this->user_model->get_by_id($user_id,$dealer);
			// if ($row_user->uniqueid == $uniqueid) {
				$this->load->model('agent_model');
				$row_agent = $this->agent_model->get_by_agent_id($row_user->userpass_id);
				if ($row_agent) {
					$this->load->library('interface_gateway');
					$this->interface_gateway->set_agent_login($dealer, $row_agent->username, $row_agent->password, $row_agent->authcode, $row_agent->secretkey);
					$checklogin = $this->interface_gateway->check_agent_login();
					if ($checklogin) {
						if ($refresh == 'Y') {
							$this->interface_gateway->refresh_player_credit($row_user->username);
						}
						$data_return = $this->interface_gateway->get_player_credit($row_user->username); // get current user credit
						$return = array(
							'errorCode' => 0,
							'errorMessage' => 'สำเร็จ',
							'creditGame' => $data_return['credit_game'],
							'creditBalance' => floor($data_return['credit_balance']), //$data_return['credit_balance'], //strip decimals
							'creditTotal' => $data_return['credit_game']+$data_return['credit_balance']
						);
					}
				}
			// }
		}
		echo json_encode($return);
	}
	
	/**
	 * Refresh this user in game credit (Fix Ufa delay credit)
	 */
	public function refresh_game_user_credit($dealer=NULL,$user_id=NULL,$uniqueid=NULL) {
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ');
		if ($dealer && $user_id && $uniqueid) {
			$this->load->model('user_model');
			$row_user = $this->user_model->get_by_id($user_id,$dealer);
			// if ($row_user->uniqueid == $uniqueid) {
				$this->load->model('agent_model');
				$row_agent = $this->agent_model->get_by_agent_id($row_user->userpass_id);
				if ($row_agent) {
					$this->load->library('interface_gateway');
					$this->interface_gateway->set_agent_login($dealer, $row_agent->username, $row_agent->password, $row_agent->authcode, $row_agent->secretkey);
					$checklogin = $this->interface_gateway->check_agent_login();
					if ($checklogin) {
						$data_return = $this->interface_gateway->refresh_player_credit($row_user->username); // refresh current user credit
					}
				}
			// }
		}
		echo json_encode($return);
	}
	
	/**
	 * Change game password on dealer system
	 */
	public function change_game_password($dealer=NULL,$user_id=NULL,$uniqueid=NULL) {
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ');
		$new_password = $this->input->post('password');
		if ($dealer && $user_id && $uniqueid && $new_password) {
			$this->load->model('user_model');
			$row_user = $this->user_model->get_by_id($user_id,$dealer);
			if ($row_user) {
				$this->load->model('agent_model');
				$row_agent = $this->agent_model->get_by_agent_id($row_user->userpass_id);
				$this->load->library('interface_gateway');
				$this->interface_gateway->set_agent_login($dealer, $row_agent->username, $row_agent->password, $row_agent->authcode, $row_agent->secretkey);
				$data_return = $this->interface_gateway->change_password($row_user->username, $new_password, $row_user->bankno);
				
				if ($data_return['status'] === true) {
					$new_password = $data_return['new_password'];
					$data = array(
						'password'=>$new_password,
						'uag_modified'=>date('Y-m-d H:i:s')
					);
					$this->db->update('tb_users_agent', $data, array('dealer'=>$dealer,'user_id'=>$user_id));		
					$return = array('errorCode' => 0, 'errorMessage' => 'เปลี่ยนรหัสผ่านใหม่สำเร็จ');
				}
			}
		}
		echo json_encode($return);
	}
	
	/**
	 * Withdraw credit on dealer system
	 */
	public function withdraw_credit($dealer=NULL,$user_id=NULL,$uniqueid=NULL,$type=NULL) {
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ');
		$credit = $this->input->post('credit');
		$credit = floor($credit);
		if ($dealer && $user_id && $uniqueid && $credit) {
			$this->load->model('user_model');
			$row_user = $this->user_model->get_by_id($user_id,$dealer);
			if ($row_user) {
				$this->load->model('agent_model');
				$row_agent = $this->agent_model->get_by_agent_id($row_user->userpass_id);
				$this->load->library('interface_gateway');
				$this->interface_gateway->set_agent_login($dealer, $row_agent->username, $row_agent->password, $row_agent->authcode, $row_agent->secretkey);
				$data_return = $this->interface_gateway->edit_credit($row_user->username, 2, $credit);
	
				if ($data_return["status"]===true) {
					$data = array(
						'site_id' => $row_user->site_id,
						'dealer' => $dealer,
						'name' => $row_user->nickname,
						'username' => $row_user->username,
						'agent' => $data_return["agent_name"],
						'creditagentbefore' => $data_return["agent_credit_before"],
						'creditbefore' => $data_return["credit_before"],
						'credit' => floatval($credit),
						'add_by_name' => ($type&&$type=='transfer')?'โยกเครดิตโดยสมาชิก ':'เพิ่มผ่านการถอนโดยสมาชิก',
						'created' => date('Y-m-d H:i:s')
					);
					$this->db->insert('tb_withdraw', $data);
					$wi_id = $this->db->insert_id();
					$return = array('errorCode' => 0, 'errorMessage' => 'ตัดเครดิตสำเร็จ', 'wi_id' => $wi_id);
				}
			}
		}
		echo json_encode($return);
	}
	
	/**
	 * Deposit credit on dealer system
	 */
	public function deposit_credit($dealer=NULL,$user_id=NULL,$uniqueid=NULL,$type=NULL) {
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ');
		$credit = $this->input->post('credit');
		$credit = floor($credit);
		if ($dealer && $user_id && $uniqueid && $credit) {
			$this->load->model('user_model');
			$row_user = $this->user_model->get_by_id($user_id,$dealer);
			if ($row_user) {
				$this->load->model('agent_model');
				$row_agent = $this->agent_model->get_by_agent_id($row_user->userpass_id);
				$this->load->library('interface_gateway');
				$this->interface_gateway->set_agent_login($dealer, $row_agent->username, $row_agent->password, $row_agent->authcode, $row_agent->secretkey);
				$data_return = $this->interface_gateway->edit_credit($row_user->username, 1, $credit);
	
				if ($data_return["status"]===true) {
					$data = array(
						'site_id' => $row_user->site_id,
						'dealer' => $dealer,
						'name' => $row_user->nickname,
						'username' => $row_user->username,
						'agent' => $data_return["agent_name"],
						'creditagentbefore' => $data_return["agent_credit_before"],
						'creditbefore' => $data_return["credit_before"],
						'credit' => floatval($credit),
						'add_by_name' =>  ($type&&$type=='transfer')?'โยกเครดิตโดยสมาชิก':'เพิ่มผ่านการเลือกโปรโมชั่น',
						'created' => date('Y-m-d H:i:s')
					);
					$this->db->insert('tb_deposit', $data);
					$de_id = $this->db->insert_id();
					$return = array('errorCode' => 0, 'errorMessage' => 'เติมเครดิตสำเร็จ', 'de_id' => $de_id, 'creditbefore' => $data_return["credit_before"]);
				}
			}
		}
		echo json_encode($return);
	}
	
	/**
	 * Get user profile
	 */
	public function get_user_profile($dealer=NULL,$username=NULL) {
		if ($dealer && $username) {
			$this->load->model('user_model');
			$row_user = $this->user_model->get_by_username($dealer, $username);
			if ($row_user) {
				echo json_encode($row_user);
			}
		}
	}
	
	/**
	 * Get user game
	 */
	public function get_user_allgame($phone=NULL) {
		if($phone) {
			$this->load->model('user_model');
			$rs_user = $this->user_model->get_by_phone($phone);
			if($rs_user->num_rows()>0) {
				foreach($rs_user->result() as $row){
					$result_array[] = $row;
				}
				echo json_encode($result_array);
			}
		}
	}
    
    /**
	 * Get token
	 */
	public function get_token($dealer=NULL,$user_id=NULL) {
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ');
		if ($dealer && $user_id) {
			$this->load->model('user_model');
			$row_user = $this->user_model->get_by_id($user_id,$dealer);
			if ($row_user) {
				$this->load->model('agent_model');
				$row_agent = $this->agent_model->get_by_agent_id($row_user->userpass_id);
				$this->load->library('interface_gateway');
				$this->interface_gateway->set_agent_login($dealer, $row_agent->username, $row_agent->password, $row_agent->authcode, $row_agent->secretkey);
				$data_return = $this->interface_gateway->get_token($row_user->username);
				if ($data_return['status'] === true) {		
					$return = array('errorCode' => 0, 'errorMessage' => 'สำเร็จ', 'Token'=>$data_return['token'], 'Url'=>$data_return['url']);
				}
			}
		}
		echo json_encode($return);
	}
	
	/**
     * Create new user on dealer system
     */
    private function gen_game_user($dealer, $agent_id, $start_credit=0, $user_contact=NULL) {
		$this->load->model('agent_model');
        $row_agent = $this->agent_model->get_by_agent_id($agent_id);
        $agent_username = $row_agent->username;
        $agent_password = $row_agent->password;
		$authcode = $row_agent->authcode;
        $secretkey = $row_agent->secretkey;
		if ($dealer == 'Ufa') {
			$sql = 'SELECT username FROM tb_users LEFT JOIN tb_users_agent ON tb_users_agent.user_id=tb_users.user_id	WHERE userpass_id = '.$agent_id.' AND dealer = "'.$dealer.'" ORDER BY username DESC LIMIT 0,1';
			$query = $this->db->query($sql);
			$row_last_user = $query->row();
			if ($row_last_user) {
				$last_username = $row_last_user->username;
				$last_number = str_replace($agent_username,"",$last_username);
				$new_number = str_pad($last_number + 1, strlen($last_number), "0", STR_PAD_LEFT);
			} else {
				$new_number = '00001';
			}
			$this->load->library('interface_gateway');
			$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password, $authcode, $secretkey);
			$data_return = $this->interface_gateway->create_user_auto($start_credit, $user_contact, $new_number);
			return $data_return;
		} else {
			$this->load->library('interface_gateway');
			$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password, $authcode, $secretkey);
			$data_return = $this->interface_gateway->create_user_auto($start_credit, $user_contact);
			return $data_return;
		}
	}
	
	/**
	* Check is this user already register this game on this website (Separated by website setting)
	*/
	private function check_already_register_before($site_id, $dealer, $userpass_id, $phone, $bankno, $accountname) {
		
		$data_register_return = array(
			'status' => false,
			'have_user'=>false,
			'user_id'=>'',
			'username'=>'',
			'status_message' => 'Failed to check already register',
		);
		
		$accountname = trim(str_replace(' ','',$accountname));
        $sql = "SELECT tb_users.user_id,username FROM tb_users LEFT JOIN tb_users_agent ON tb_users_agent.user_id=tb_users.user_id WHERE (phone = '$phone' OR bankno = '$bankno' OR REPLACE(accountname , ' ','') = '$accountname') AND dealer = '$dealer' AND site_id = '$site_id'";
        $result = $this->db->query($sql);
        $count = $result->num_rows();
        if($count) { // Already Register
			return $data_register_return = array(
				'status' => true,
				'username'=>$result->row()->username
			);
        } else {
			$sql="SELECT user_id FROM tb_users WHERE (phone = '$phone' OR bankno = '$bankno' OR REPLACE(accountname , ' ','') = '$accountname')";
			$result = $this->db->query($sql);
			$count = $result->num_rows();
			if($count==1){ // Already Have User
				return $data_register_return = array(
					'status' =>false,
					'have_user'=>true,
					'user_id'=>$result->row()->user_id,
					'username'=>''
				);
			}else{
				return $data_register_return = array(
					'status' =>false,
					'have_user'=>false,
					'user_id'=>'',
					'username'=>''
                );
                
			}
		}
		return $data_return;
	}
}