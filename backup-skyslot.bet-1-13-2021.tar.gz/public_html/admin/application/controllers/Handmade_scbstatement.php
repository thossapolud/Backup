<?php defined('BASEPATH') OR exit('No direct script access allowed');

set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Handmade_scbstatement extends CI_Controller {

	var $auth;
	//var $history;
	var $ch;
	var $cookie;
	var $urlslotxo = 'http://ag.slotxo.com/';
	var $urlslotxohttps = 'https://ag.slotxo.com/';
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth','history_log','bypasscaptcha'));
		$this->auth = new auth();
		$this->history = new history_log();
		$this->auth->isnot_login();	
		$this->load->model('userpass_model');	
	}
	
	public function set_scbdate($date,$h) {
		$date_array=explode("/",$date);
		$d=$date_array[0];
		$m=$date_array[1];	
		$y=$date_array[2];	
		$newformat="$y-$m-$d $h";
		$G = date('G', strtotime($newformat));
		if($G==23){
			$newformat=date('Y-m-d H:i:s',(strtotime ( '-1 day' , strtotime($newformat))));
		}
		return $newformat;
	}
	
	public function get_t($username){
		//$this->t = PUBPATH."/cookie/returnurl-getauto-".$username.".txt";
		$this->t = PUBPATH."/cookie/returnurl-".$username.".txt";
		$t = @file_get_contents($this->t);
		return $t;
	}
	
	public function formlogin($username, $password){
		curl_setopt($this->ch, CURLOPT_URL, $this->urlslotxo); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 120); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		$html = curl_exec($this->ch);
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
		$captchaImage = $dom->getElementsByTagName('img');
		//print_r($captchaImage->item(0)->getAttribute('src'));
		
		$t_login = parse_url($captchaImage->item(0)->getAttribute('src'));
		parse_str($t_login['query'], $query);
		$CaptchaDeText = $query['t'];
				
		curl_setopt($this->ch, CURLOPT_URL, $this->urlslotxo.$captchaImage->item(0)->getAttribute('src'));
		curl_setopt($this->ch, CURLOPT_REFERER, $this->urlslotxo.'Account/SignIn?url='.rawurlencode($this->urlslotxo).'&invalidateAntiForgeryToken=False');
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		$captcha = curl_exec($this->ch);
	
		$strFileName = PUBPATH."/cookie/slotxo-captcha.png";
		$objFopen = fopen($strFileName, 'wb');
		fwrite($objFopen, $captcha);
		fclose($objFopen);		
		
		$key = 'ef71d0838a308a6a0068dbab3bf314aa';
		$img_slotxo_captcha = PUBPATH.'/cookie/slotxo-captcha.png';		
		$CaptchaInputText = $this->bypasscaptcha->bc_submit_captcha($key, $img_slotxo_captcha);
		//echo '<hr>';
		//echo $captcha_value;
		
		/*echo '<hr>';
		$x = '<div class="captcha-container"> 
				<img class="captcha-image" id="CaptchaImage" src="'.base_url('cookie/slotxo-captcha.png').'">
  				<input id="CaptchaDeText" name="CaptchaDeText" value="785e09efc01b4aa98074d623ad163f9a" type="hidden"></div>';
		echo $x;*/
		
		$postdata='';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 switch($inputname){
				case '__RequestVerificationToken':
					$postdata .= $inputname.'='.$inputval.'&';
				break;
				case 'RedirectUrl':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case 'CaptchaDeText':
					$postdata .= $inputname.'='.rawurlencode($CaptchaDeText).'&';
				break;
				case 'CaptchaInputText':
					$postdata .= $inputname.'='.rawurlencode($CaptchaInputText).'&';
				break;
			 }
		}
		$postdata .= 'Username='.$username.'&Password='.$password; 
								
		curl_setopt($this->ch, CURLOPT_URL, $this->urlslotxo.'Account/SignIn');
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($this->ch, CURLOPT_POST, 1); 
		$html = curl_exec($this->ch);
				
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$input = $dom->getElementById('returnUrl');

		//Set Url for Check login
		//$this->session->set_userdata('t', parse_url($input->getAttribute('value'), PHP_URL_QUERY));
		$tFile = PUBPATH."/cookie/returnurl-".$username.".txt";
		$objFopen = fopen($tFile, 'w');
		fwrite($objFopen, parse_url($input->getAttribute('value'), PHP_URL_QUERY));
		fclose($objFopen);
		//print_r($input->getAttribute('value'));
	}
	
	private function checklogin($t){	 
		curl_setopt($this->ch, CURLOPT_URL, $this->urlslotxo.'?'.$t); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 120); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		//curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		$html = curl_exec($this->ch);
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$input = $dom->getElementById('returnUrl');
		//print_r($input->getAttribute('value'));
		$findme   = 'SignIn';
		$pos = strpos($input->getAttribute('value'), $findme);
		if($pos===false){
			return parse_url($input->getAttribute('value'), PHP_URL_QUERY);
		}
	}
	
	public function editcredit($usernameslotxo,$passwordslotxo,$ocode,$uplineocode,$name,$username,$credit,$comment=NULL){
		$data = array('success'=>0,'msg'=>'โปรดตรวจสอบข้อมูล');				
		
		$this->cookie = PUBPATH."/cookie/cookie-".$usernameslotxo.".txt";
		$this->ch = curl_init();
		$t = $this->get_t($usernameslotxo);
		if($t){
			$checklogin = $this->checklogin($t);
			parse_str($checklogin, $querystring);
			if(!isset($querystring['t'])){
				$this->formlogin($usernameslotxo,$passwordslotxo);
				$t = $this->get_t($usernameslotxo);
			}
		}else{
			$this->formlogin($usernameslotxo,$passwordslotxo);
			$t = $this->get_t($usernameslotxo);
		}					
		
		// GetPersonCreditSummary
		//curl_setopt($this->ch, CURLOPT_URL, $this->urlslotxo.'DataStatistic/GetPersonCreditSummary');
		//curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		//curl_setopt($this->ch, CURLOPT_POSTFIELDS, $t); 
		//curl_setopt($this->ch, CURLOPT_POST, 1); 
		//$html = curl_exec($this->ch);
		//$html = json_decode($html);	
		//$creditagentbefore = $html->CurrentAvailable->Amount;
		$creditagentbefore = 0;
				
		//Set score
		$url = $this->urlslotxo.'Person/Topup';
		$postdata = "ocode=".$ocode."&value=".$credit."&isUpdateAutoDeposit=false&autoDepositAmount=&uplineOCode=".$uplineocode."&".$t;			
		curl_setopt($this->ch, CURLOPT_URL, $url);	
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 120); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($this->ch, CURLOPT_POST, 1); 
		$html = curl_exec($this->ch);					
		if(is_string($html) && is_array(json_decode($html, true)) && (json_last_error() == JSON_ERROR_NONE)){	
			$html = json_decode($html);
			$creditbefore = str_replace(',','',$html->previousDownlineGiven);
			$data = array(
				'dealer'=>'Slotxo',
				'name'=>$name,
				'username'=>$username,
				'agent'=>$usernameslotxo,
				'creditagentbefore'=>$creditagentbefore,
				'creditbefore'=>$creditbefore,
				//'creditbefore'=>$html->previousDownlineGiven,
				'credit'=>$credit,
				'add_by_id'=>$this->session->userdata('ac_id'),
				'add_by_name'=>$this->session->userdata('name'),
				'created'=>date('Y-m-d H:i:s')
			);
			// ฝาก
			$action = 'เติม slotxo';					
			$this->db->insert('tb_deposit', $data);
			$de_id = $this->db->insert_id();
			
			if($this->db->affected_rows() > 0){
				//+ History Log 
				$data = array(
					'dealer'=>'Slotxo',
					'username'=>$username,
					'credit'=>$credit
				);
				$this->history->save(array('action'=>$action,'user_id'=>NULL,'detail'=>json_encode($data)));
				//+
			}
			$data = array('success'=>true,'msg'=>'Success !','de_id'=>$de_id,'creditbefore'=>$creditbefore);
		}else{
			$data = array('success'=>0,'msg'=>$html);
		}// End if(is_string($html) && is_array(json_decode($html, true)) && (json_last_error() == JSON_ERROR_NONE)){
		//curl_close($this->ch);	
		return $data;		
	}
		
	public function save(){
		$post = $this->input->post();
		if($post){
			extract($post);
			if($html!=''){
											
				$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
				@$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents
				$table = $dom->getElementById('DataProcess_GridView');			
				
				if($table){
					//$stringttable = $dom->saveHTML($table);  // save html table 
					$trs = $table->getElementsByTagName('tr'); // get this row table
					$trs_row = $trs->length;
					$i=1;
							
					if($trs_row>2){
						foreach($trs as $tr){
							if($i!=1&&$i!=$trs->length){
								$tds = $tr->getElementsByTagName('td'); // get the columns in this row
								$st_datein = $this->set_scbdate(trim($tds->item(0)->nodeValue),trim($tds->item(1)->nodeValue));
								$st_comment = trim($tds->item(2)->nodeValue).' / '.trim($tds->item(3)->nodeValue).' / '.trim($tds->item(6)->nodeValue);
								//+ สร้าง Where เพื่อเช็คข้อมูลในตาราง	
								$where_select = 'st_out= "'.trim($tds->item(4)->nodeValue).'" AND ';
								$where_select .= 'st_in= "'.trim($tds->item(5)->nodeValue).'" AND ';	
								$where_select .= 'st_datein= "'.$st_datein.'" AND ';
								$where_select .= 'st_bank="'.$bank.'" AND ';
								$where_select .= 'st_comment="'.$st_comment.'" AND ';
								$where_select .= 'st_datein>="'.date("Y-m-d", strtotime("-10 days")).' 00:00:00" AND ';
								$where_select .= 'st_ac="'.$usernamebank.'"';
								
								//+ ค่าสำหรับนำไปบันทึก	
								$row_value = array(
									'st_out'=>trim($tds->item(4)->nodeValue),
									'st_in'=>trim($tds->item(5)->nodeValue),
									'st_datein'=>$st_datein,
									'st_datein_original'=>trim($tds->item(0)->nodeValue).' '.trim($tds->item(1)->nodeValue),
									'st_comment'=>$st_comment,
									'st_bank'=>$bank,
									'st_ac'=>$usernamebank,
									'created'=>date('Y-m-d H:i:s'),
								);
								
								$sql = "SELECT * FROM tb_statement WHERE 1 AND ".$where_select."";
								$query = $this->db->query($sql);
								$count = $query->num_rows();
								if(!$count){
									$sql = "INSERT INTO tb_statement (".implode(", ", array_keys($row_value)).") VALUES ('".implode("', '", $row_value)."') ";
									$query = $this->db->query($sql);
									$st_id = $this->db->insert_id();
									$credit = preg_replace("/[^0-9\.]/", '', $tds->item(5)->nodeValue); // เครดิตที่ได้จาก รายการฝาก ธนาคาร
									
									if($credit!=''){
										//เริ่มทำการ เปิดใบงาน และ ฝากเงินเข้าระบบเกมส์
										$comment = preg_replace("/[^0-9]/", '', $st_comment);
										$strlen_comment = strlen($comment);
										if($strlen_comment<=5){
											$fourdigitlast = substr($comment,-4); // เลขบัญชี 4 ตัวท้าย
											$sql = 'SELECT user_id,userid,dealer,tb_users.username,nickname,bankno,tb_userpass.username AS agusername,tb_userpass.password AS agpassword ,tb_userpass.bankname,tb_userpass.agid,refer_id FROM tb_users LEFT JOIN tb_userpass ON tb_users.userpass_id=tb_userpass.userpass_id WHERE RIGHT(bankno, 4)="'.$fourdigitlast.'" AND status = "ใช้" AND bank="SCB" AND dealer="Slotxo"';
										}else{
											$sixdigitlast = substr($comment,-6); // เลขบัญชี 6 ตัวท้าย
											$sql = 'SELECT user_id,userid,dealer,tb_users.username,nickname,bankno,tb_userpass.username AS agusername,tb_userpass.password AS agpassword ,tb_userpass.bankname,tb_userpass.agid,refer_id FROM tb_users LEFT JOIN tb_userpass ON tb_users.userpass_id=tb_userpass.userpass_id WHERE RIGHT(bankno, 6)="'.$sixdigitlast.'" AND status = "ใช้" AND dealer="Slotxo"';
										}
										$query_user = $this->db->query($sql);
										if($query_user->num_rows()==1){
											$row_user = $query_user->row();
											$agusername = $row_user->agusername;
											$agpassword = $row_user->agpassword;
											$dealer = $row_user->dealer;
											$user_id = $row_user->user_id;
											$bankname = $row_user->bankname;
											$agid = $row_user->agid;
											$userid = $row_user->userid;
											$name = $row_user->nickname;
											$username = $row_user->username;
											$refer_id = $row_user->refer_id;
											
											// เปิดใบงาน
											$data = array(
												'ws_code'=>'-',
												'ws_dealer'=>$dealer,
												'ws_type'=>'deposit',
												'ws_date'=>$st_datein,
												'user_id'=>$user_id,
												'ws_debank'=>$bank,
												'ws_debankac'=>$usernamebank,
												'ws_debankacnum'=>'ac1',
												'ws_debankname'=>$bankname,
												'ws_credit'=>$credit,
												'ws_total'=>$credit,
												'st_id'=>$st_id,
												'c_id'=>$this->session->userdata('ac_id'),
												'c_status'=>1,
												'b_comment'=>'เปิดอัตโนมัติ ขณะบันทึกมือรายการฝาก จากแบงค์',
												'b_id'=>$this->session->userdata('ac_id'),
												'b_status'=>1,
												'b_comment'=>'ตรวจอัตโนมัติ ขณะบันทึกมือรายการฝาก จากแบงค์',
												'b_date'=>date('Y-m-d H:i:s'),
												'created'=>date('Y-m-d H:i:s')
											);
											//$this->db->set('ws_code', 'CONCAT(DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y   \'),IFNULL((SELECT SUBSTR(`ws_code`, 14) FROM tb_worksheet AS `alias` WHERE SUBSTR(`ws_code`, 1, 10) = DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y\') ORDER BY created DESC LIMIT 1)+ 1,1) )', FALSE); //CAST(`ws_code` as SIGNED integer)
											$this->db->insert('tb_worksheet', $data);
											$ws_id = $this->db->insert_id();	
											if($this->db->affected_rows() > 0){
												/*อัพเดทสถานะ รายการเงินฝาก*/
												$data = array(						
													'st_status'=>1,
													'modified'=>date("Y-m-d H:i:s")
												);
												$this->db->update('tb_statement', $data, array('st_id'=>$st_id));
												/*อัพเดทสถานะ รายการเงินฝาก*/
												
												/*ทำการฝากเงินเข้าเกมส์ Slotxo*/
												$dataeditcredit = $this->editcredit($agusername,$agpassword,$userid,$agid,$name,$username,$credit);
												// หากทำการฝากสำเร็จ
												if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
													/*อัพเดทใบงาน*/
													$data = array(						
														'de_id'=>$dataeditcredit['de_id'],
														'm_id'=>$this->session->userdata('ac_id'),
														'm_status'=>1,
														'm_comment'=>'ตรวจอัตโนมัติ ขณะบันทึกมือรายการฝาก จากแบงค์',
														'modified'=>date("Y-m-d H:i:s")
													);
													$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
													/*หาก creditbefore มากกว่า 10 ดึงโปรโมชั่นที่ลูกค้ารับ มาเช็ค ว่าทำการถอนไปหรือยัง*/
													$sql = 'SELECT pr_user_id,withdraw_pro FROM tb_promotion_user WHERE user_id='.$user_id.' ORDER BY created DESC limit 1';
													$query_promotion_user = $this->db->query($sql);
													if($query_promotion_user->num_rows()>0){
														$row_promotion_user = $query_promotion_user->row();
														if($row_promotion_user->withdraw_pro=='n'){
															if($dataeditcredit['creditbefore']>10){	
																//+ เพิ่มจำนวนเครดิตทำเทริน
																$sql = "UPDATE tb_promotion_user SET credit_pro = credit_pro+".$credit." WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
																$this->db->query($sql);
																//+ สิ้นสุดเพิ่มจำนวนเครดิตทำเทริน
															}else{
																//+ ทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
																$sql = "UPDATE tb_promotion_user SET withdraw_pro = 'y', note='ปรับ withdraw_pro = y เนื่องจากมียอดก่อนฝาก น้อยกว่า 10',modified='".date("Y-m-d H:i:s")."' WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
																$this->db->query($sql);
																//+ สิ้นสุดทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
															} // End if($dataeditcredit['creditbefore']>10){
														} // End if($row_promotion_user->withdraw_pro=='n'){
													} // End if($query_promotion_user->num_rows()>0){
													
													// เติมเครดิตให้เพื่อนที่แนะนำ
													//if($refer_id!=''){
//														$sql = 'SELECT ws_id FROM tb_worksheet WHERE user_id='.$user_id.' AND  ws_type="deposit" AND c_status = 1 AND b_status = 1 AND m_status = 1';
//														$query_ws = $this->db->query($sql);
//														if($query_ws->num_rows()==1){
//															$sql = 'SELECT user_id,userid,dealer,tb_users.username,nickname,bankno,tb_userpass.username AS agusername,tb_userpass.password AS agpassword ,tb_userpass.bankname,tb_userpass.agid FROM tb_users LEFT JOIN tb_userpass ON tb_users.userpass_id=tb_userpass.userpass_id WHERE user_id='.$refer_id.' AND status = "ใช้"';
//															$query_userrefer = $this->db->query($sql);
//															if($query_userrefer->num_rows()==1){
//																$row_user = $query_userrefer->row();
//																$agusername = $row_user->agusername;
//																$agpassword = $row_user->agpassword;
//																$dealer = $row_user->dealer;
//																$user_id = $row_user->user_id;
//																$bankname = $row_user->bankname;
//																$agid = $row_user->agid;
//																$userid = $row_user->userid;
//																$name = $row_user->nickname;
//																$username = $row_user->username;
//																
//																$promotion_id = 19;	
//																$row_promotion = $this->promotion_model->get_by_id($promotion_id);
//																$percent_pro = $row_promotion->percent;
//																$minimum_pro = 0;
//																$creditrefer = ($credit*$row_promotion->percent)/100;
//																$creditrefer = ($creditrefer>300)?300:$creditrefer;
//																$rate_pro = $creditrefer;
//																$turn_pro = $row_promotion->turn;
//																$credit_pro = $creditrefer;
//																
//																/*ทำการฝากเงินเข้าเกมส์ Slotxo ให้ผู้แนะนำ*/
//																$dataeditcreditrefer = $this->editcredit($agusername,$agpassword,$userid,$agid,$name,$username,$creditrefer,'เพิ่มผ่านโปรแนะนำเพื่อน');
//																// หากทำการฝากสำเร็จ
//																if((isset($dataeditcreditrefer)&&$dataeditcreditrefer['success']===true)){																	
//																	// เพิ่มการรับโปรโมชั่น
//																	$data = array(
//																		'pr_id'=>$promotion_id,
//																		'user_id'=>$user_id,
//																		'ws_id'=>$ws_id,
//																		'de_id'=>$dataeditcreditrefer['de_id'],
//																		'percent_pro'=>$percent_pro,
//																		'minimum_pro'=>$minimum_pro,
//																		'rate_pro'=>$rate_pro,
//																		'turn_pro'=>$turn_pro,
//																		'credit_pro'=>$credit_pro,
//																		'created'=>date('Y-m-d H:i:s')
//																	);
//																	$this->db->insert('tb_promotion_user', $data);
//																} // End if((isset($dataeditcreditrefer)&&$dataeditcreditrefer['success']===true)){												
//															} // End if($query_userrefer->num_rows()==1){
//														} // End if($query_ws->num_rows()==1){
//													} // End if($refer_id!=''){
													// เติมเครดิตให้เพื่อนที่แนะนำ
														
													// เรียก Line
													$chline = curl_init();					
													curl_setopt($chline, CURLOPT_URL, 'https://www.slotxo1688.com/line/callback.php?linepush=1&act=deposit&username='.$username.'&credit='.$credit.'');
													curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
													$data = curl_exec($chline);	
													curl_close($chline);
													// เรียก Line
													
												}else{
													// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
													$chline = curl_init();					
													curl_setopt($chline, CURLOPT_URL, 'https://www.slotxo1688.com/admin/linenotify/notifytoline/wait');
													curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
													$data = curl_exec($chline);	
													curl_close($chline);
													// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
												} // End if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
											} // End if($this->db->affected_rows() > 0){										
										}else{
											// เรียก Line เมื่อหาแบงค์ไม่เจอ หรือ เจอมากกว่า 1
											$chline = curl_init();					
											curl_setopt($chline, CURLOPT_URL, 'https://www.slotxo1688.com/admin/linenotify/notifytoline/bank');
											curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
											$data = curl_exec($chline);	
											curl_close($chline);
											// เรียก Line เมื่อหาแบงค์ไม่เจอ หรือ เจอมากกว่า 1
										} // End if($query_user->num_rows()==1){
										//เริ่มทำการ เปิดใบงาน และ ฝากเงินเข้าระบบเกมส์	
									} // End if($credit!=''){
								} // End if(!$count){								
							} // end if($i!=1&&$i!=$trs->length){
							$i++;	
						} // end foreach($trs as $tr){
					} // end if($trs_row>2){
					
				}else{
					echo 'ไม่มีรายการเกิดขึ้นในวันนี้'; die();
				} // End if($table){
					
				if($query){
					echo 'บันทึกสำเร็จ';
				}else{
					echo 'บันทึกไม่สำเร็จ';
				}
				
			} // End if($html!=''){
		} // End $post = $this->input->post();
	}
		
	function __destruct(){
		
	}
		
}