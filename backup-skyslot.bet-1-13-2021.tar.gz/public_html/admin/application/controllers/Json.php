<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Json extends CI_Controller {

	public  function __construct(){
		parent::__construct();
		$this->load->library('auth');
		$this->auth = new auth();
		$this->auth->isnot_login();
	}

	public function search_user_by_username_json(){
		$this->load->model('user_model');

		$site_id = $this->input->get('site_id');
		$dealer = $this->input->get('dealer');
		$username = $this->input->get('username');

		$rs_user = $this->user_model->search_by_username($site_id, $dealer, $username, 10);
		if($rs_user->num_rows()>0){
			$output = array();
			foreach($rs_user->result() as $row){
				$data['user_id'] = $row->user_id;
				$data['username'] = $row->username;
				$data['nickname'] = $row->nickname;
				$data['accountname'] = $row->accountname;
				$data['bankno'] = $row->bankno;
				$data['bank'] = $row->bank;
				$data['withdrawcode'] = $row->withdrawcode;				
				$data['detail'] = 'ชื่อบัญชี : '.$row->accountname;				
				$output[] = $data;
			}			
			echo json_encode($output);
		}
	}


	public function get_user_target_json(){
		$this->load->model('user_model');

		$dealer = $this->input->get('dealer');
		$user_id = $this->input->get('user_id');

		$rs_user = $this->user_model->get_user_by_dealer($dealer,$user_id);
		if($rs_user->num_rows()>0){
			$output = array();
			foreach($rs_user->result() as $row){
				$data['user_id'] = $row->user_id;
				$data['username'] = $row->username;
				$data['nickname'] = $row->nickname;	
				$data['accountname'] = $row->accountname;
				$data['bankno'] = $row->bankno;		
				$data['detail'] = 'ชื่อเล่น : '.$row->nickname;				
				$output[] = $data;
			}			
			echo json_encode($output);
		}
	}

	public function get_bank_statement(){
		$this->load->model('statement_model');

		$post = $this->input->post();
		if($post){
			extract($post);						
			$rs_statement = $this->statement_model->get_st_in($st_bank,$st_ac,$st_datein);
			$output = array();
			if($rs_statement->num_rows()>0){				
				foreach($rs_statement->result() as $row){
					$data['st_id'] = $row->st_id;
					$data['st_in'] = $row->st_in;
					$data['st_acc'] = $row->st_acc;
					$data['st_datein'] = $row->st_datein;
					$data['st_comment'] = $row->st_comment;
					$output[] = $data;
				}
			}
			echo json_encode($output);
		}
	}

	public function get_deposit_bank_by_site_id_json(){
		$this->load->model('userpass_model');

		$site_id = $this->input->get('site_id');
		$rs_bank = $this->userpass_model->get_deposit_bank_by_site_id($site_id);
		if($rs_bank){
			$output = array();
			foreach($rs_bank->result() as $row){
				$data['type'] = $row->type;
				$data['username'] = $row->username;	
				$data['acnum'] = $row->acnum;	
				$data['bankname'] = $row->bankname;
				$data['balance'] = $row->balance;	
				$data['available'] = $row->available;	
				$output[] = $data;
			}			
			echo json_encode($output);
		}
	}

}
