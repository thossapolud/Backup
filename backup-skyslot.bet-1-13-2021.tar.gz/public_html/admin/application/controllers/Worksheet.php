<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Worksheet extends CI_Controller {
	
	var $auth;
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth','history_log'));
		$this->auth = new auth();
		$this->auth->isnot_login();	
		$this->history = new history_log();	
		$this->load->model('agent_model');
		$this->load->model('dealer_model');
		$this->load->model('promotion_model');
		$this->load->model('statement_model');	
		$this->load->model('user_model');
		$this->load->model('userpass_model');
		$this->load->model('website_model');
		$this->load->model('worksheet_model');
		$this->titlecomponent->add('ใบงาน');
	}
	
	public function get_worksheet_remain(){
		$post = $this->input->post();
		if($post){
			extract($post);
			$worksheet_remain = $this->worksheet_model->get_remain_by_userid($user_id);
			echo $worksheet_remain;
		}
	}
	
	//+ สร้างภาพเล็ก
	public function make_thumb_img($tempimage, $width=NULL, $height=NULL, $newpath=NULL){
		if(!file_exists($newpath) and $newpath!='') {
			mkdir($newpath, DIR_WRITE_MODE, true);
		}		
		$this->load->library('image_lib');
        $config['image_library'] = 'gd2';
        $config['source_image']    = $tempimage;
        if($newpath)$config['new_image'] = $newpath;
        $config['maintain_ratio'] = TRUE;
        $config['width']     = $width;
        $config['height']    = $height;
        $this->image_lib->initialize($config); 
		@$this->image_lib->resize();
    } 
	
	//+ อัพโหลด img deposit
	public function upload_deposit_img(){			
		$this->load->library('upload');
		$post = $this->input->post();
		extract($post);
		
        $image_upload_folder = FCPATH.'/images/worksheet';
		
        if(!file_exists($image_upload_folder)) {
            mkdir($image_upload_folder, DIR_WRITE_MODE, true);
        }
				
        $this->upload_config = array(
            'upload_path'   => $image_upload_folder,
            'allowed_types' => 'png|jpg|jpeg',
            'max_size'      => 2048,
            'remove_space'  => TRUE,
            'encrypt_name'  => TRUE,
        );
				
		$this->upload->initialize($this->upload_config);
		
		if(!$this->upload->do_upload('depositfile')) {
            $upload_error = $this->upload->display_errors();
          	echo json_encode($upload_error);
        }else{
            $file_info = $this->upload->data();								
			$new_name = uniqid("de_".date('YmdHis').'_',false).$file_info['file_ext'];			
			rename($file_info['full_path'], $file_info['file_path'].$new_name);
			$this->make_thumb_img($file_info['file_path'].$new_name, 450, 450); //+ ทำให้เป็นภาพเล็ก 450x450				
			$file_info['name'] = $new_name;
            echo json_encode($file_info);
        }		
	}
	
	//+ อัพโหลด img withdraw
	public function upload_withdraw_img(){			
		$this->load->library('upload');
		$post = $this->input->post();
		extract($post);
		
        $image_upload_folder = FCPATH.'/images/worksheet';
		
        if(!file_exists($image_upload_folder)) {
            mkdir($image_upload_folder, DIR_WRITE_MODE, true);
        }
				
        $this->upload_config = array(
            'upload_path'   => $image_upload_folder,
            'allowed_types' => 'png|jpg|jpeg',
            'max_size'      => 2048,
            'remove_space'  => TRUE,
            'encrypt_name'  => TRUE,
        );
				
		$this->upload->initialize($this->upload_config);
		
		if(!$this->upload->do_upload('withdrawfile')) {
            $upload_error = $this->upload->display_errors();
          	echo json_encode($upload_error);
        }else{
            $file_info = $this->upload->data();								
			$new_name = uniqid("wi_".date('YmdHis').'_',false).$file_info['file_ext'];			
			rename($file_info['full_path'], $file_info['file_path'].$new_name);	
			$this->make_thumb_img($file_info['file_path'].$new_name, 450, 450); //+ ทำให้เป็นภาพเล็ก 450x450		
			$file_info['name'] = $new_name;
            echo json_encode($file_info);
        }		
	}
	
	private function save_history($ws_dealer,$username,$ws_id,$ws_code,$action){
		$data = array(
			'dealer'=>$ws_dealer,
			'username'=>$username,
			'ws_id'=>$ws_id,
			'ws_code'=>$ws_code						
		);
		$this->history->save(array('action'=>$action,'user_id'=>NULL,'detail'=>json_encode($data)));
	}
	
	public function create(){
		$post = $this->input->post();
		if($post){
			extract($post);
			if($method!=''&&$method=='createWorksheet'){
				$ws_debank = NULL;
				$ws_debankname = NULL;
				$ws_debankac = NULL;
				$ws_debankacnum = NULL;	
				if(isset($ws_bankac)&&$ws_type=='deposit'){
					$ws_bankac = explode('|',$ws_bankac);
					$ws_debank = $ws_bankac[0];
					$ws_debankac = $ws_bankac[1];
					$ws_debankacnum = $ws_bankac[2];
					$ws_debankname = $ws_bankac[3];
				}			
				$data = array(
					'ws_code'=>'-',
					'ws_dealer'=>$ws_dealer,
					'ws_type'=>$ws_type,
					'ws_date'=>$ws_date,
					'site_id'=>$site_id,
					'user_id'=>$user_id,
					'ws_deimg'=>(isset($ws_type)&&$ws_type=='deposit'&&$ws_deimg!='')?base_url('images/worksheet/'.$ws_deimg):NULL,
					'ws_debank'=>$ws_debank,
					'ws_debankac'=>$ws_debankac,
					'ws_debankacnum'=>$ws_debankacnum,
					'ws_debankname'=>$ws_debankname,
					'ws_credit'=>$ws_credit,
					//'ws_pro'=>(isset($ws_type)&&$ws_type=='deposit'&&$ws_pro!='')?$ws_pro:0,
					'ws_total'=>$ws_credit,
					'ws_dealer_target'=>(isset($ws_type)&&$ws_type=='transfer')?$ws_dealer_target:NULL,
					'user_id_target'=>(isset($ws_type)&&$ws_type=='transfer')?$user_id_target:NULL,
					'promotion_id'=>($promotion_id=='')?NULL:$promotion_id,
					'c_id'=>$this->session->userdata('ac_id'),
					'c_status'=>1,
					'c_comment'=>$c_comment,
					'b_status'=>(isset($ws_type)&&$ws_type=='transfer')?1:0,
					'b_date'=>(isset($ws_type)&&$ws_type=='transfer')?date('Y-m-d H:i:s'):NULL,
					'created'=>date('Y-m-d H:i:s')
				);
				//$this->db->set('ws_code', 'CONCAT(DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y   \'),IFNULL((SELECT SUBSTR(`ws_code`, 14) FROM tb_worksheet AS `alias` WHERE SUBSTR(`ws_code`, 1, 10) = DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y\') ORDER BY created DESC LIMIT 1)+ 1,1) )', FALSE); //CAST(`ws_code` as SIGNED integer)
				$this->db->insert('tb_worksheet', $data);
				$ws_id = $this->db->insert_id();				
				$row_worksheet = $this->db->select('ws_code')->where('ws_id', $ws_id)->get('tb_worksheet')->row();				
				if($this->db->affected_rows() > 0){
					//+ History Log 
					$this->save_history($ws_dealer,$username,$ws_id,$row_worksheet->ws_code,'Call เปิด ใบงาน');
					//+
				}
				echo 'เพิ่มเรียบร้อย';
			}
		}
	}
		
	public function bank_withdraw(){
		if(isset($_GET['wsid'])&&$_GET['wsid']!=''){
			$rs_worksheet = $this->worksheet_model->get_worksheet_witdraw_bank_by_id($_GET['wsid']);
			if($rs_worksheet->num_rows()>0){
				// $this->load->model('bankwithdraw_model');
				// $rs_bankwithdraw = $this->bankwithdraw_model->get_all();
				$row_worksheet = $rs_worksheet->row();
				$rs_bankwithdraw = $this->userpass_model->get_withdraw_bank_by_site_id($row_worksheet->site_id);
				if($row_worksheet->b_flag==0){
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					$data = array(						
						'b_flag'=>1,
						'b_flag_id'=>$this->session->userdata('ac_id'),
						'b_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					//+ History Log			
					$this->save_history($row_worksheet->ws_dealer,$row_worksheet->username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Bank เข้าเข้าจัดการ ใบงานถอน');
					//+
					$Content['rs_bankwithdraw'] = $rs_bankwithdraw;
					$Content['rs_worksheet'] = $rs_worksheet;
					$this->load->view('worksheet/bank-withdraw', $Content);
				}else{					
					$present_time = strtotime(date('Y-m-d H:i:s'));
					$end_time = strtotime($row_worksheet->b_flag_expire);				
					if($present_time>$end_time||$row_worksheet->b_flag_id==$this->session->userdata('ac_id')){
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
						$data = array(						
							'b_flag'=>1,
							'b_flag_id'=>$this->session->userdata('ac_id'),
							'b_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
						);
						$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
						//+ History Log			
						$this->save_history($row_worksheet->ws_dealer,$row_worksheet->username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Bank เข้าจัดการ ใบงานถอน');
						//+
						$Content['rs_bankwithdraw'] = $rs_bankwithdraw;
						$Content['rs_worksheet'] = $rs_worksheet;
						$this->load->view('worksheet/bank-withdraw', $Content);
					}else{					
						echo '<center><font color="#FF0000">** ใบงานกำลังถูกเข้าจัดการ กรุณารีเฟรช แล้วเลือกทำรายการอื่น**</font></center>';
					}					
				}// End if($row_worksheet->b_flag==0){
			} // End if($rs_worksheet->num_rows()>0){
		}
	}
	
	// Depost or Withdraw game credit
	private function edit_credit($post) {
		$data = array('success' => false, 'msg' => 'โปรดตรวจสอบข้อมูล');
		$de_id = null;
		$wi_id = null;
		extract($post);
		if ($ws_type == 'deposit') {
			$topup_type = 1;
			$credit = str_replace(',','',$ws_total);
			$addbyname = $this->session->userdata('name');
		} else if ($ws_type == 'withdraw') {
			$topup_type = 2;
			$credit = str_replace(',','',$ws_total);
			$addbyname = $this->session->userdata('name');
		} else if ($ws_type == 'transfer'){
			$user_id = $u2user_id;
			$userpass_id = $u2userpass_id;
			$username = $u2username;
			$ws_dealer = $ws_dealer_target;
			$nickname = $u1nickname;
			$topup_type = 1;
			$credit = str_replace(',','',$ws_total);
			$addbyname = 'โยกเครดิตโดย'.$this->session->userdata('name');
		}else {
			return $data = array('success' => false, 'msg' => 'โปรดตรวจสอบข้อมูล');
		}
		
		// Get and set agent login credential
		$row_agent = $this->agent_model->get_by_agent_id($userpass_id);
		$agent_id = $row_agent->userpass_id;
		$agent_username = $row_agent->username;
		$agent_password = $row_agent->password;
		$authcode = $row_agent->authcode;
		$secretkey = $row_agent->secretkey;
		if ($agent_id && $user_id) {
			$this->load->library('interface_gateway');
			$this->interface_gateway->set_agent_login($ws_dealer, $agent_username, $agent_password,$authcode,$secretkey);
			$data_return = $this->interface_gateway->edit_credit($username, $topup_type, $credit);
			if ($data_return["status"]===true) {
				$data = array(
					'site_id' => $site_id,
					'dealer' => $ws_dealer,
					'name' => $nickname,
					'username' => $username,
					'agent' => $data_return["agent_name"],
					'creditagentbefore' => $data_return["agent_credit_before"],
					'creditbefore' => $data_return["credit_before"],
					'credit' => floatval($credit),
					'add_by_id' => $this->session->userdata('ac_id'),
					'add_by_name' => ((isset($free)&&$free=='y')||(isset($promotion_id)&&$promotion_id!=''))?'เพิ่มผ่านการเลือกโปรโมชั่น':$addbyname,
					'created' => date('Y-m-d H:i:s'),
				);
				if ($ws_type == 'deposit'||$ws_type == 'transfer') {
					$action = ($ws_type == 'deposit')?'เติม ' . $ws_dealer:'โยก ' . $ws_dealer;
					$this->db->insert('tb_deposit', $data);
					$de_id = $this->db->insert_id();
				} else {
					$action = 'ถอน '. $ws_dealer;
					$this->db->insert('tb_withdraw', $data);
					$wi_id = $this->db->insert_id();
				}
				if ($this->db->affected_rows() > 0) {
					$data = array(
						'dealer' => $ws_dealer,
						'username' => $username,
						'credit' => floatval($credit),
					);
					$this->history->save(array('action' => $action, 'user_id' => $user_id, 'detail' => json_encode($data)));
				}
				$data['success'] = $data_return["status"];
				$data['de_id'] = $de_id;
				$data['wi_id'] = $wi_id;
				$data['creditbefore'] = $data_return["credit_before"];
			} else {
				return $data = array('success' => false, 'msg' => $data_return["status_message"]);
			}
		}
		return $data;
	}
	
	public function bank_withdraw_confirm(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);
			if($method!=''&&$method=='BankWithdrawConfirm'){							
				$ws_bankac = explode('|',$ws_bankac);
				$ws_wibank = $ws_bankac[0];
				$ws_wibankac = $ws_bankac[1];
				$ws_wibankacnum = $ws_bankac[2];
				$ws_wibankname = $ws_bankac[3];
				$data = array(
					'ws_wiimg'=>$ws_wiimg,
					'ws_wibank'=>$ws_wibank,
					'ws_wibankac'=>$ws_wibankac,
					'ws_wibankacnum'=>$ws_wibankacnum,
					'ws_wibankname'=>$ws_wibankname,
					'b_id'=>$this->session->userdata('ac_id'),
					'b_status'=>1,
					'b_date'=>date('Y-m-d H:i:s'),
					'modified'=>date('Y-m-d H:i:s')
				);					
				$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'ws_type'=>'withdraw','c_status'=>1,'b_status'=>0,'m_status'=>1));
				if($this->db->affected_rows() > 0){
					//+ History Log 
					$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Bank ตรวจ ใบงานถอน');
					//+
					$row_website = $this->website_model->get_by_site_id($site_id);
					if ($row_website->site_line_callback_url) {
						// เช็ค gid จาก username
						$chgid = curl_init();
						curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
						curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
						curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
						$gid = curl_exec($chgid);
						curl_close($chgid);
						// เรียก Line
						$chline = curl_init();
						curl_setopt($chline,CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=withdrawok&username='.$username.'&credit='.$ws_credit.'');
						curl_setopt($chline,CURLOPT_TIMEOUT, 5);
						curl_setopt($chline,CURLOPT_FOLLOWLOCATION, 1); 
						curl_setopt($chline,CURLOPT_RETURNTRANSFER, 1);
						$data = curl_exec($chline);
						curl_close($chline);
						// เรียก Line
					}
					$msg = array('error'=>'0','text'=>'ตรวจสอบ เรียบร้อย!');
				}
			}
		}
		echo json_encode($msg);
	}
	
	public function bank_deposit(){
		if(isset($_GET['wsid'])&&$_GET['wsid']!=''){
			$rs_worksheet = $this->worksheet_model->get_worksheet_bank_by_id($_GET['wsid']);
			if($rs_worksheet->num_rows()>0){
				$row_worksheet = $rs_worksheet->row();
				if($row_worksheet->b_flag==0){
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					$data = array(						
						'b_flag'=>1,
						'b_flag_id'=>$this->session->userdata('ac_id'),
						'b_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					//+ History Log			
					$this->save_history($row_worksheet->ws_dealer,$row_worksheet->username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Bank เข้าจัดการ ใบงานฝาก');
					//+
					$rs_statement = $this->statement_model->get_st_in($row_worksheet->ws_debank,$row_worksheet->ws_debankac,date('Y-m-d H:i',strtotime($row_worksheet->ws_date)));			
					$Content['rs_statement'] = $rs_statement;
					$Content['rs_worksheet'] = $rs_worksheet;
					$this->load->view('worksheet/bank-deposit', $Content);
				}else{	
					$present_time = strtotime(date('Y-m-d H:i:s'));
					$end_time = strtotime($row_worksheet->b_flag_expire);				
					if($present_time>$end_time){
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
						$data = array(						
							'b_flag'=>1,
							'b_flag_id'=>$this->session->userdata('ac_id'),
							'b_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
						);
						$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
						//+ History Log			
						$this->save_history($row_worksheet->ws_dealer,$row_worksheet->username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Bank เข้าจัดการ ใบงานฝาก');
						//+
						$rs_statement = $this->statement_model->get_st_in($row_worksheet->ws_debank,$row_worksheet->ws_debankac,date('Y-m-d H:i',strtotime($row_worksheet->ws_date)));			
						$Content['rs_statement'] = $rs_statement;
						$Content['rs_worksheet'] = $rs_worksheet;
						$this->load->view('worksheet/bank-deposit', $Content);
					}else{					
						echo '<center><font color="#FF0000">** ใบงานกำลังถูกเข้าจัดการ กรุณารีเฟรช แล้วเลือกทำรายการอื่น**</font></center>';
					}
				} // End if($row_worksheet->b_flag==0){
			}
		}
	}
	
	public function bank_deposit_confirm(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);
			if($method!=''&&$method=='BankDepositConfirm'){				
				$data = array(
					'st_id'=>(isset($st_id))?$st_id:NULL,
					'b_id'=>$this->session->userdata('ac_id'),
					'b_status'=>1,
					'b_date'=>date('Y-m-d H:i:s'),
					'modified'=>date('Y-m-d H:i:s')
				);
				$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'c_status'=>1,'b_status'=>0,'m_status'=>0));
				if($this->db->affected_rows() > 0){
					//+ Update tb_statement
					if(isset($st_id)&&$st_id!=''){
						$data = array(
							'st_status'=>1,
							'modified'=>date('Y-m-d H:i:s')
						);
						$this->db->update('tb_statement', $data, array('st_id'=>$st_id));
					}
					//+ History Log 
					$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Bank ตรวจ ใบงานฝาก');
					//+
					$msg = array('error'=>'0','text'=>'ตรวจสอบ เรียบร้อย!');
				}
			}
		}
		echo json_encode($msg);
	}
	
	public function bank_deposit_cancel(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);			
			$data = array(
				'b_id'=>$this->session->userdata('ac_id'),
				'b_comment'=>$b_comment,
				'b_status'=>2,
				'b_date'=>date('Y-m-d H:i:s'),
				'modified'=>date('Y-m-d H:i:s')
			);
			$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'ws_type'=>'deposit','c_status'=>1,'b_status'=>0,'m_status'=>0));
			if($this->db->affected_rows() > 0){
				//+ History Log 
				$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Bank ยกเลิก ใบงานฝาก');
				//+
				$msg = array('error'=>'0','text'=>'ยกเลิก เรียบร้อย!');
			}
		}
		echo json_encode($msg);
	}
	
	public function bank_withdraw_cancel(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);			
			$data = array(
				'b_id'=>$this->session->userdata('ac_id'),
				'b_comment'=>$b_comment,
				'b_status'=>2,
				'b_date'=>date('Y-m-d H:i:s'),
				'modified'=>date('Y-m-d H:i:s')
			);
			$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'ws_type'=>'withdraw','c_status'=>1,'b_status'=>0,'m_status'=>1));
			if($this->db->affected_rows() > 0){
				//+ History Log 
				$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Bank ยกเลิก ใบงานถอน');
				//+
				$msg = array('error'=>'0','text'=>'ยกเลิก เรียบร้อย!');
			}
		}
		echo json_encode($msg);
	}
	
	public function bank_leave(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปล่อยแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);			
			$data = array(
				'b_flag'=>0,
				'b_flag_id'=>NULL,
				'b_flag_expire'=>NULL,
				'modified'=>date('Y-m-d H:i:s')
			);
			$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
			if($this->db->affected_rows() > 0){
				//+ History Log 
				$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Bank ปล่อย ใบงาน');
				//+
				$msg = array('error'=>'0','text'=>'ปล่อย เรียบร้อย!');
			}
		}
		echo json_encode($msg);
	}
				
	public function manage_deposit(){
		if(isset($_GET['wsid'])&&$_GET['wsid']!=''){
			$rs_worksheet = $this->worksheet_model->get_worksheet_manage_by_id($_GET['wsid']);
			if($rs_worksheet->num_rows()>0){
				$row_worksheet = $rs_worksheet->row();
				if($row_worksheet->m_flag==0){
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					$data = array(						
						'm_flag'=>1,
						'm_flag_id'=>$this->session->userdata('ac_id'),
						'm_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					//+ History Log			
					$this->save_history($row_worksheet->ws_dealer,$row_worksheet->username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Manage เข้าจัดการ ใบงานฝาก');
					//+
					$Content['rs_worksheet'] = $rs_worksheet;
					$this->load->view('worksheet/manage-deposit', $Content);
				}else{
					$present_time = strtotime(date('Y-m-d H:i:s'));
					$end_time = strtotime($row_worksheet->m_flag_expire);				
					if($present_time>$end_time){
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
						$data = array(						
							'm_flag'=>1,
							'm_flag_id'=>$this->session->userdata('ac_id'),
							'm_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
						);
						$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/						
						//+ History Log			
						$this->save_history($row_worksheet->ws_dealer,$row_worksheet->username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Manage เข้าจัดการ ใบงานฝาก');
						//+
						$Content['rs_worksheet'] = $rs_worksheet;
						$this->load->view('worksheet/manage-deposit', $Content);
					}else{					
						echo '<center><font color="#FF0000">** ใบงานกำลังถูกเข้าจัดการ กรุณารีเฟรช แล้วเลือกทำรายการอื่น**</font></center>';
					}
				} // End if($row_worksheet->b_flag==0){
			} // End if($rs_worksheet->num_rows()>0){
		}
	}
		
	public function manage_withdraw(){
		if(isset($_GET['wsid'])&&$_GET['wsid']!=''){
			$rs_worksheet = $this->worksheet_model->get_worksheet_withdraw_manage_by_id($_GET['wsid']);
			if($rs_worksheet->num_rows()>0){
				$row_worksheet = $rs_worksheet->row();
				if($row_worksheet->m_flag==0){
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					$data = array(						
						'm_flag'=>1,
						'm_flag_id'=>$this->session->userdata('ac_id'),
						'm_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					//+ History Log			
					$this->save_history($row_worksheet->ws_dealer,$row_worksheet->username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Manage เข้าจัดการ ใบงานถอน');
					//+
					$Content['rs_worksheet'] = $rs_worksheet;
					$this->load->view('worksheet/manage-withdraw', $Content);
				}else{
					$present_time = strtotime(date('Y-m-d H:i:s'));
					$end_time = strtotime($row_worksheet->m_flag_expire);				
					if($present_time>$end_time){
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
						$data = array(						
							'm_flag'=>1,
							'm_flag_id'=>$this->session->userdata('ac_id'),
							'm_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
						);
						$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/	
						//+ History Log			
						$this->save_history($row_worksheet->ws_dealer,$row_worksheet->username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Manage เข้าจัดการ ใบงานถอน');
						//+					
						$Content['rs_worksheet'] = $rs_worksheet;
						$this->load->view('worksheet/manage-withdraw', $Content);
					}else{					
						echo '<center><font color="#FF0000">** ใบงานกำลังถูกเข้าจัดการ กรุณารีเฟรช แล้วเลือกทำรายการอื่น**</font></center>';
					}
				} // End if($row_worksheet->b_flag==0){
			} // End if($rs_worksheet->num_rows()>0){
		}
	}
	
	public function manage_transfer(){
		if(isset($_GET['wsid'])&&$_GET['wsid']!=''){
			$rs_worksheet = $this->worksheet_model->get_worksheet_transfer_manage_by_id($_GET['wsid']);
			if($rs_worksheet->num_rows()>0){
				$row_worksheet = $rs_worksheet->row();
				if($row_worksheet->m_flag==0){
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					$data = array(						
						'm_flag'=>1,
						'm_flag_id'=>$this->session->userdata('ac_id'),
						'm_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
					/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
					//+ History Log			
					$this->save_history($row_worksheet->ws_dealer,$row_worksheet->u1username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Manage เข้าจัดการ ใบงานโยก');
					//+
					$Content['rs_worksheet'] = $rs_worksheet;
					$this->load->view('worksheet/manage-transfer', $Content);
				}else{
					$present_time = strtotime(date('Y-m-d H:i:s'));
					$end_time = strtotime($row_worksheet->m_flag_expire);				
					if($present_time>$end_time){
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
						$data = array(						
							'm_flag'=>1,
							'm_flag_id'=>$this->session->userdata('ac_id'),
							'm_flag_expire'=>date("Y-m-d H:i:s", strtotime("+5 minute"))
						);
						$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
						/*อัพเดทสถานะการเข้าจัดการ และเวลาในการสิ้นสุด*/
						//+ History Log			
						$this->save_history($row_worksheet->ws_dealer,$row_worksheet->u1username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Manage เข้าจัดการ ใบงานโยก');
						//+						
						$Content['rs_worksheet'] = $rs_worksheet;
						$this->load->view('worksheet/manage-transfer', $Content);
					}else{					
						echo '<center><font color="#FF0000">** ใบงานกำลังถูกเข้าจัดการ กรุณารีเฟรช แล้วเลือกทำรายการอื่น**</font></center>';
					}
				} // End if($row_worksheet->b_flag==0){
			} // End if($rs_worksheet->num_rows()>0){
		}
	}
	
	public function manage_deposit_confirm(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);
			if($method!=''&&($method=='ManageDepositConfirm')){
				if ($ws_dealer) {
					$dataeditcredit = $this->edit_credit($post);
				}
				if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){	
					// Update NewMember
					$data = array(
						'newmember'=>'N',
						'modified'=>date('Y-m-d H:i:s')
					);
					$this->db->update('tb_users', $data, array('user_id'=>$user_id));
								
					$data = array(
						'ws_pro'=>$ws_pro*1,
						'ws_total'=>floatval(str_replace(',','',$ws_total)),
						'de_id'=>(isset($dataeditcredit))?$dataeditcredit['de_id']:null,
						'm_id'=>$this->session->userdata('ac_id'),
						'm_status'=>1,
						'm_date'=>date('Y-m-d H:i:s'),
						'modified'=>date('Y-m-d H:i:s')
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'c_status'=>1,'b_status'=>1,'m_status'=>0));
					if($this->db->affected_rows() > 0){
						//+ History Log 
						$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Manage ตรวจ ใบงานฝาก');
						//+
						if($promotion_id!=''){
							// เพิ่มการรับโปรโมชั่น
							$row_promotion = $this->promotion_model->get_by_id($promotion_id);
							$rate_pro = $ws_pro*1;
							$turn_pro = $row_promotion->turn;
							$credit_pro = $rate_pro*$row_promotion->turn;					
							$data = array(
								'pr_id'=>$promotion_id,
								'user_id'=>$user_id,
								'ws_id'=>$ws_id,
								'de_id'=>$dataeditcredit['de_id'],
								'percent_pro'=>$row_promotion->percent,
								'minimum_pro'=>$row_promotion->minimum,
								'rate_pro'=>$rate_pro,
								'turn_pro'=>$turn_pro,
								'credit_pro'=>$credit_pro+$dataeditcredit['creditbefore'],
								'created'=>date('Y-m-d H:i:s')
							);
							$this->db->insert('tb_promotion_user', $data);
						}else{
							/*หาก creditbefore มากกว่า 10 ดึงโปรโมชั่นที่ลูกค้ารับ มาเช็ค ว่าทำการถอนไปหรือยัง*/
							$sql = 'SELECT pr_user_id,withdraw_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$ws_dealer.'" ORDER BY created DESC limit 1';
							$query_promotion_user = $this->db->query($sql);
							if($query_promotion_user->num_rows()>0){
								$row_promotion_user = $query_promotion_user->row();
								if($row_promotion_user->withdraw_pro=='n'){
									if($dataeditcredit['creditbefore']>10){	
										//+ เพิ่มจำนวนเครดิตทำเทริน
										$sql = "UPDATE tb_promotion_user SET credit_pro = credit_pro+".floatval(str_replace(',','',$ws_total))." WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
										$this->db->query($sql);
										//+ สิ้นสุดเพิ่มจำนวนเครดิตทำเทริน
									}else{
										//+ ทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
										$sql = "UPDATE tb_promotion_user SET withdraw_pro = 'y', note='ปรับ withdraw_pro = y เนื่องจากมียอดก่อนฝาก น้อยกว่า 10' WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
										$this->db->query($sql);
										//+ สิ้นสุดทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
									} // End if($data['creditbefore']>10){
								} // End if($row_promotion_user->withdraw_pro=='n'){
							} // End if($query_promotion_user->num_rows()>0){	
						}// End if($promotion_id!=''){
							
						// เติมเครดิตให้เพื่อนที่แนะนำ
						//if($ws_type=='deposit'){
						//	$row_user = $this->user_model->get_by_id($user_id);
						//	$refer_id = $row_user->refer_id;
						//	if($refer_id!=''){
						//		$sql = 'SELECT ws_id FROM tb_worksheet WHERE user_id='.$user_id.' AND  ws_type="deposit" AND c_status = 1 AND b_status = 1 AND m_status = 1';
						//		$query_ws = $this->db->query($sql);
						//		if($query_ws->num_rows()==1){
						//			$sql = 'SELECT user_id,userid,dealer,tb_users.username,nickname,bankno,tb_userpass.username AS agusername,tb_userpass.password AS agpassword ,tb_userpass.bankname,tb_userpass.agid FROM tb_users LEFT JOIN tb_userpass ON tb_users.userpass_id=tb_userpass.userpass_id WHERE user_id='.$refer_id.' AND status = "ใช้"';
						//			$query_userrefer = $this->db->query($sql);
						//			if($query_userrefer->num_rows()==1){
						//				$row_user = $query_userrefer->row();
						//				$agusername = $row_user->agusername;
						//				//$agpassword = $row_user->agpassword;
						//				$dealer = $row_user->dealer;
						//				$user_id = $row_user->user_id;
						//				$agid = $row_user->agid;
						//				$userid = $row_user->userid;
						//				$name = $row_user->nickname;
						//				$username = $row_user->username;
						//				
						//				$promotion_id = 19;	
						//				$row_promotion = $this->promotion_model->get_by_id($promotion_id);
						//				$percent_pro = $row_promotion->percent;
						//				$minimum_pro = 0;
						//				$credit = str_replace(',','',$ws_total);
						//				$creditrefer = ($credit*$row_promotion->percent)/100;
						//				$creditrefer = ($creditrefer>300)?300:$creditrefer;
						//				$rate_pro = $creditrefer;
						//				$turn_pro = $row_promotion->turn;
						//				$credit_pro = $creditrefer;
						//				
						//				$dataeditcreditrefer = $this->editcreditrefer_slotxo($agusername,$userid,$agid,$name,$username,$creditrefer);
						//				// หากทำการฝากสำเร็จ
						//				if((isset($dataeditcreditrefer)&&$dataeditcreditrefer['success']===true)){
						//		
						//					// เพิ่มการรับโปรโมชั่น
						//					$data = array(
						//						'pr_id'=>$promotion_id,
						//						'user_id'=>$user_id,
						//						'ws_id'=>$ws_id,
						//						'de_id'=>$dataeditcreditrefer['de_id'],
						//						'percent_pro'=>$percent_pro,
						//						'minimum_pro'=>$minimum_pro,
						//						'rate_pro'=>$rate_pro,
						//						'turn_pro'=>$turn_pro,
						//						'credit_pro'=>$credit_pro,
						//						'created'=>date('Y-m-d H:i:s')
						//					);
						//					$this->db->insert('tb_promotion_user', $data);
						//					
						//				} // End if((isset($dataeditcreditrefer)&&$dataeditcreditrefer['success']===true)){
						//			} // End if($query_userrefer->num_rows()==1){
						//		} // End if($query_ws->num_rows()==1){
						//	} // End if($refer_id!=''){
						//} // if($ws_type=='deposit'){
						// เติมเครดิตให้เพื่อนที่แนะนำ
						
						$row_website = $this->website_model->get_by_site_id($site_id);
						if ($row_website->site_line_callback_url) {
							// เช็ค gid จาก username
							$chgid = curl_init();
							curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
							curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
							curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
							$gid = curl_exec($chgid);
							curl_close($chgid);
							// เรียก Line
							$chline = curl_init();
							curl_setopt($chline,CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=deposit&username='.$username.'&credit='.$ws_total.'&phone='.$phone);
							curl_setopt($chline,CURLOPT_TIMEOUT, 5);
							curl_setopt($chline,CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chline,CURLOPT_RETURNTRANSFER, 1);
							$data = curl_exec($chline);
							curl_close($chline);
							// เรียก Line
						}
						
						$msg = array('error'=>'0','text'=>'ตรวจสอบ เรียบร้อย!');
					}
				}else{
					$msg = array('error'=>'1','text'=>$dataeditcredit['msg']);
					//$msg = array('error'=>'1','text'=>'ไม่สามารถ ปรับเครดิตได้');
				}
			}
		}
		echo json_encode($msg);
	}
	
	public function manage_depositfree_confirm(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);
			if($method!=''&&($method=='ManageDepositConfirm')){
				if ($ws_dealer) {
					$data = $this->edit_credit($post);
				}
				if((isset($data)&&$data['success']===true)){	
					$de_id = (isset($data))?$data['de_id']:null;			
					$data = array(
						'm_id'=>$this->session->userdata('ac_id'),
						'm_status'=>1,
						'm_date'=>date('Y-m-d H:i:s'),
						'modified'=>date('Y-m-d H:i:s')
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'c_status'=>1,'b_status'=>1,'m_status'=>0));
					if($this->db->affected_rows() > 0){
						
						//+ Update Tb_promotion_user
						$data = array(
							'de_id'=>$de_id,
							'modified'=>date('Y-m-d H:i:s')
						);
						$this->db->update('tb_promotion_user', $data, array('ws_id'=>$ws_id));
						
						$row_website = $this->website_model->get_by_site_id($site_id);
						if ($row_website->site_line_callback_url) {
							// เช็ค gid จาก username
							$chgid = curl_init();
							curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
							curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
							curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
							$gid = curl_exec($chgid);
							curl_close($chgid);
							// เรียก Line
							$chline = curl_init();
							curl_setopt($chline,CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=promotion&username='.$username.'&credit='.$ws_total.'');
							curl_setopt($chline,CURLOPT_TIMEOUT, 5);
							curl_setopt($chline,CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chline,CURLOPT_RETURNTRANSFER, 1);
							$data = curl_exec($chline);
							curl_close($chline);
							// เรียก Line
						}
						//+ History Log 
						$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Manage ตรวจ ใบงานฝาก');						
						$msg = array('error'=>'0','text'=>'ตรวจสอบ เรียบร้อย!');
					}
				}else{
					$msg = array('error'=>'1','text'=>$data['msg']);
					//$msg = array('error'=>'1','text'=>'ไม่สามารถ ปรับเครดิตได้');
				}
			}
		}
		echo json_encode($msg);
	}
	
	public function manage_transfer_confirm(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);
			if($method!=''&&($method=='ManageTransferConfirm')){
				if ($ws_dealer_target) {
					$data = $this->edit_credit($post);
				}
				if((isset($data)&&$data['success']===true)){	
					$de_id = (isset($data))?$data['de_id']:null;			
					$data = array(
						'de_id'=>$de_id,
						'm_id'=>$this->session->userdata('ac_id'),
						'm_status'=>1,
						'm_date'=>date('Y-m-d H:i:s'),
						'modified'=>date('Y-m-d H:i:s')
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'c_status'=>1,'b_status'=>1,'m_status'=>0));
					if($this->db->affected_rows() > 0){						
						$row_website = $this->website_model->get_by_site_id($site_id);
						if ($row_website->site_line_callback_url) {
							// เช็ค gid จาก username
							$chgid = curl_init();
							curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$u2username.'');
							curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
							curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
							$gid = curl_exec($chgid);
							curl_close($chgid);
							// เรียก Line
							$chline = curl_init();
							curl_setopt($chline,CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=promotion&username='.$u2username.'&credit='.$ws_total.'');
							curl_setopt($chline,CURLOPT_TIMEOUT, 5);
							curl_setopt($chline,CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chline,CURLOPT_RETURNTRANSFER, 1);
							$data = curl_exec($chline);
							curl_close($chline);
							// เรียก Line
						}
						//+ History Log 
						$this->save_history($ws_dealer_target,$u2username,$ws_id,$ws_code,'Manage ตรวจ ใบงานโยก');						
						$msg = array('error'=>'0','text'=>'ตรวจสอบ เรียบร้อย!');
					}
				}else{
					$msg = array('error'=>'1','text'=>$data['msg']);
					//$msg = array('error'=>'1','text'=>'ไม่สามารถ ปรับเครดิตได้');
				}
			} // End if($method!=''&&($method=='ManageTransferConfirm')){	
		}
		echo json_encode($msg);
	}
	
	public function manage_withdraw_confirm(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);
			if($method!=''&&$method=='ManageWithdrawConfirm'){
				if ($ws_dealer) {
					$data = $this->edit_credit($post);
				}
				if((isset($data)&&$data['success']===true)){				
					$data = array(
						//'de_id'=>(isset($data))?$data['de_id']:null,
						'wi_id'=>(isset($data))?$data['wi_id']:null,
						'm_id'=>$this->session->userdata('ac_id'),
						'm_status'=>1,
						'm_date'=>date('Y-m-d H:i:s'),
						'modified'=>date('Y-m-d H:i:s')
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'ws_type'=>'withdraw','c_status'=>1,'b_status'=>0,'m_status'=>0));
					if($this->db->affected_rows() > 0){
						//+ History Log 
						$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Manage ตรวจ ใบงานถอน');
						//+
						$msg = array('error'=>'0','text'=>'ตรวจสอบ เรียบร้อย!');
					}
				}else{
					$msg = array('error'=>'1','text'=>$data['msg']);
					//$msg = array('error'=>'1','text'=>'ไม่สามารถ ปรับเครดิตได้');
				}
				
			}
		}
		echo json_encode($msg);
	}
	
	public function manage_withdraw_cancel(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);			
			$data = array(
				'm_id'=>$this->session->userdata('ac_id'),
				'm_comment'=>$m_comment,
				'm_status'=>2,
				'm_date'=>date('Y-m-d H:i:s'),
				'modified'=>date('Y-m-d H:i:s')
			);
			$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'ws_type'=>'withdraw','c_status'=>1,'b_status'=>0,'m_status'=>0));
			if($this->db->affected_rows() > 0){
				//+ History Log 
				$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Manage ยกเลิก ใบงานถอน');
				//+
				$msg = array('error'=>'0','text'=>'ยกเลิก เรียบร้อย!');
			}
		}
		echo json_encode($msg);
	}
	
	public function manage_deposit_cancel(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);			
			$data = array(
				'm_id'=>$this->session->userdata('ac_id'),
				'm_comment'=>$m_comment,
				'm_status'=>2,
				'm_date'=>date('Y-m-d H:i:s'),
				'modified'=>date('Y-m-d H:i:s')
			);
			$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'ws_type'=>'deposit','c_status'=>1,'b_status'=>1,'m_status'=>0));
			if($this->db->affected_rows() > 0){
				//+ History Log 
				$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Manage ยกเลิก ใบงานฝาก');
				//+
				// Delete From tb_promotion_user
				if($free=='y'){
					$this->db->delete('tb_promotion_user', array('ws_id'=>$ws_id));
				}
				$msg = array('error'=>'0','text'=>'ยกเลิก เรียบร้อย!');
			}
		}
		echo json_encode($msg);
	}
	
	public function manage_leave(){
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปล่อยแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);			
			$data = array(
				'm_flag'=>0,
				'm_flag_id'=>NULL,
				'm_flag_expire'=>NULL,
				'modified'=>date('Y-m-d H:i:s')
			);
			$username = ($method=='ManageTransferConfirm')?$u1username:$username;
			$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
			if($this->db->affected_rows() > 0){
				//+ History Log 
				$this->save_history($ws_dealer,$username,$ws_id,$ws_code,'Manage ปล่อย ใบงาน');
				//+
				$msg = array('error'=>'0','text'=>'ปล่อย เรียบร้อย!');
			}
		}
		echo json_encode($msg);
	}
	
	public function view(){
		if(isset($_GET['wsid'])&&$_GET['wsid']!=''){
			$rs_worksheet = $this->worksheet_model->get_worksheet_by_id($_GET['wsid']); //echo $this->db->last_query();
			$this->db->where('wc_ws_id',$_GET['wsid']);
			$this->db->order_by('wc_ws_id', 'DESC');
			$this->db->limit(1);
			$row_ws_log = $this->db->get('tb_ws_autolog')->row();
			$Content['row_ws_log'] = $row_ws_log;
			$Content['rs_worksheet'] = $rs_worksheet;
			$this->load->view('worksheet/view', $Content);
		}
	}
	
	public function call_notify_confirm(){
		$ws_id = $this->input->post('ws_id');
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if(isset($ws_id)&&$ws_id!=''){			
			$data = array(
				'n_id'=>$this->session->userdata('ac_id'),
				'n_status'=>1,
				'n_date'=>date('Y-m-d H:i:s'),
				'modified'=>date('Y-m-d H:i:s')
			);
			$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'c_status'=>1,'n_status'=>0));
			if($this->db->affected_rows() > 0){
				//+ History Log 
				$row_worksheet = $this->worksheet_model->get_worksheet_by_id($ws_id)->row();				
				$this->save_history($row_worksheet->ws_dealer,$row_worksheet->u1username,$row_worksheet->ws_id,$row_worksheet->ws_code,'Call แจ้งลูกค้า');
				//+
				$msg = array('error'=>'0','text'=>'ตรวจสอบ เรียบร้อย!');
			}
		}
		echo json_encode($msg);
	}
			
	public function call($show_ws_type=''){
		$this->titlecomponent->add('Call');
		$Content['rs_website'] = $this->website_model->get_by_status(1);
		$Content['rs_dealer'] = $this->dealer_model->get_by_dealer_status(1);
		$Content['rs_userpass'] = $this->userpass_model->get_userpass_bank_order_by_bankname();
		$Content['rs_promotion'] = $this->promotion_model->get_all();
		$Content['show_ws_type'] = $show_ws_type;
		$data['Content'] = $this->load->view('worksheet/call', $Content, true);
		$this->load->view('template/temp_main', $data);
	}
	
	public function call_all($ws_type=NULL){
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'ws_type',2=>'ws_dealer',3=>'accountname',4=>'uag.username',5=>'ws_date',6=>'ws_credit',7=>'ws_deimg',8=>'name',9=>'tb_worksheet.created',10=>'b_status',11=>'m_status',12=>'n_status',13=>'n_date',14=>'ws_id');
		// DB table to use
		$sTable = 'tb_worksheet';
		//
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);
		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}
		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);
				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++){
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);
				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					if($aColumns[$i]=='ws_date'||$aColumns[$i]=='tb_worksheet.created'){
						//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';						
						if(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch)){
							$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
						}						
					}else{
						//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
						$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}
				}
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
		if(isset($ws_type) && !empty($ws_type)){
			$this->db->where('ws_type', $ws_type);
		}
			
		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_users', 'tb_users.user_id=tb_worksheet.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws_dealer', 'LEFT');
		$this->db->join('tb_account', 'tb_account.ac_id=tb_worksheet.c_id', 'LEFT');
		$rResult = $this->db->get($sTable);
		
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;
		// Total data set length
		$this->db->join('tb_users', 'tb_users.user_id=tb_worksheet.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws_dealer', 'LEFT');
		$this->db->join('tb_account', 'tb_account.ac_id=tb_worksheet.c_id', 'LEFT');
		if(isset($ws_type) && !empty($ws_type)){
			$this->db->where('ws_type', $ws_type);
		}
		$iTotal = $this->db->count_all_results($sTable);
		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			
			//$b_status = ($aRow->m_status==2)?conv_ws_status($aRow->m_status):conv_ws_status($aRow->b_status);
			//$m_status = ($aRow->b_status==2)?conv_ws_status($aRow->b_status):conv_ws_status($aRow->m_status);		
			if($aRow->ws_type=='withdraw'){
				$b_status = ($aRow->m_status==2)?conv_ws_status($aRow->m_status):conv_ws_status($aRow->b_status);
				$m_status = conv_ws_status($aRow->m_status);
			}else{
				$b_status = conv_ws_status($aRow->b_status);
				$m_status = ($aRow->b_status==2)?conv_ws_status($aRow->b_status):conv_ws_status($aRow->m_status);
			}
			$n_status = '';
			if(($aRow->b_status==1&&$aRow->m_status==1)||($aRow->b_status==2&&$aRow->m_status==0)||($aRow->b_status==0&&$aRow->m_status==2)||($aRow->b_status==1&&$aRow->m_status==2)||($aRow->b_status==2&&$aRow->m_status==1)){ 
				$n_status = '';// $n_status = ($aRow->n_status==1)?'<i class="glyphicon glyphicon-ok text-success" title="แจ้งลูกค้า : '.$aRow->n_date.'"></i> ':$aRow->n_status;
			}
			$firstname = substr($aRow->accountname, 0, strpos($aRow->accountname, ' '));
			$row[0] = $iDisplayStart;		
			$row[1] = conv_ws_type($aRow->ws_type);
			$row[2] = $aRow->ws_dealer;
			$row[3] = $firstname;			
			$row[4] = $aRow->username;
			$row[5] = $aRow->ws_date;
			$row[6] = number_format($aRow->ws_credit,2);
			$row[7] = $aRow->ws_deimg;
			$row[8] = $aRow->name;	
			$row[9] = $aRow->created;
			$row[10] = $b_status;	
			$row[11] = $m_status;
			$row[12] = $n_status;
			$row[13] = $aRow->n_date;
			$row[14] = $aRow->ws_id;		 
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}
	
	public function bank(){
		$this->titlecomponent->add('Bank');
		//$Content['rs_userpass'] = $this->userpass_model->get_userpass_bank();
		$data['Content'] = $this->load->view('worksheet/bank', null, true);
		$this->load->view('template/temp_main', $data);
	}
	
	public function bank_all(){
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'ws_type',2=>'ws_dealer',3=>'accountname',4=>'uag.username',5=>'ws_date',6=>'ws_credit',7=>'ws_deimg',8=>'name',9=>'tb_worksheet.created',10=>'ws_id');
		// DB table to use
		$sTable = 'tb_worksheet';
		//
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);
		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}
		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);
				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++){
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);
				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					if($aColumns[$i]=='ws_date'||$aColumns[$i]=='tb_worksheet.created'){
						//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';						
						if(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch)){
							$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
						}						
					}else{
						//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
						$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}
				}
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
		
		$this->db->where('c_status', 1);
		//$this->db->where('b_status', 0);
		//$this->db->where('m_status', 0);			
		$where = "(ws_type = 'withdraw' AND b_status = 0 AND m_status = 1) OR (ws_type = 'deposit' AND b_status = 0 AND m_status = 0)";	
		$this->db->where($where, NULL, FALSE); 
		
		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_users', 'tb_users.user_id=tb_worksheet.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws_dealer', 'LEFT');
		$this->db->join('tb_account', 'tb_account.ac_id=tb_worksheet.c_id', 'LEFT');
		$rResult = $this->db->get($sTable);		
		$x = $this->db->last_query();
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;
		// Total data set length
		$this->db->where('c_status', 1);
		//$this->db->where('b_status', 0);
		//$this->db->where('m_status', 0);
		$where = "(ws_type = 'withdraw' AND b_status = 0 AND m_status = 1) OR (ws_type = 'deposit' AND b_status = 0 AND m_status = 0)";	
		$this->db->where($where, NULL, FALSE);		
		$this->db->join('tb_users', 'tb_users.user_id=tb_worksheet.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws_dealer', 'LEFT');
		$this->db->join('tb_account', 'tb_account.ac_id=tb_worksheet.c_id', 'LEFT');
		$iTotal = $this->db->count_all_results($sTable);
		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$firstname = substr($aRow->accountname, 0, strpos($aRow->accountname, ' '));
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$row[0] = $iDisplayStart;		
			$row[1] = conv_ws_type($aRow->ws_type);
			$row[2] = $aRow->ws_dealer;
			$row[3] = $firstname;			
			$row[4] = $aRow->username;
			$row[5] = $aRow->ws_date;
			//$row[5] = $x;
			$row[6] = number_format($aRow->ws_credit,2);
			$row[7] = $aRow->ws_deimg;
			$row[8] = $aRow->name;	
			$row[9] = $aRow->created;	
			$row[10] = $aRow->ws_id;		 
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}
	
	public function manage(){		
		$this->titlecomponent->add('Manage');
		//$Content['rs_userpass'] = $this->userpass_model->get_userpass_bank();
		$data['Content'] = $this->load->view('worksheet/manage', null, true);
		$this->load->view('template/temp_main', $data);
	}
	
	public function manage_all(){
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'ws_type',2=>'ws_dealer',3=>'accountname',4=>'uag.username',5=>'ws_date',6=>'ws_credit',7=>'ws_deimg',8=>'a1.name as a1name',9=>'tb_worksheet.created',10=>'ws_wiimg',11=>'a2.name as a2name',12=>'ws_id');
		// DB table to use
		$sTable = 'tb_worksheet';
		//
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);
		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1'){
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}
		// Ordering
		if(isset($iSortCol_0)){
			for($i=0; $i<intval($iSortingCols); $i++){
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);
				if($bSortable == 'true'){					
					if($aColumns[intval($this->db->escape_str($iSortCol))]=='a1.name as a1name'){
						$this->db->order_by('a1name', $this->db->escape_str($sSortDir));
					}elseif($aColumns[intval($this->db->escape_str($iSortCol))]=='a2.name as a2name'){
						$this->db->order_by('a2name', $this->db->escape_str($sSortDir));
					}else{
						$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
					}
				}
			}
		}
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++){
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);
				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					if($aColumns[$i]=='ws_date'||$aColumns[$i]=='tb_worksheet.created'){
						//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';						
						if(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch)){
							$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
						}						
					}elseif($aColumns[$i]=='a1.name as a1name'){
						$like[] = "a1.name LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}elseif($aColumns[$i]=='a2.name as a2name'){
						$like[] = "a2.name LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}else{
						//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
						$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}
				}
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
		
		$this->db->where('c_status', 1);
		//$this->db->where('b_status', 1);
		//$this->db->where('m_status', 0);
		$where = "(ws_type = 'withdraw' AND b_status = 0 AND m_status = 0) OR (ws_type = 'deposit' AND b_status = 1 AND m_status = 0)";	
		$where .= " OR (ws_type = 'transfer' AND b_status = 1 AND m_status = 0)";
		$this->db->where($where, NULL, FALSE);
			
		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_users', 'tb_users.user_id=tb_worksheet.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws_dealer', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=tb_worksheet.c_id', 'LEFT');
		$this->db->join('tb_account a2', 'a2.ac_id=tb_worksheet.b_id', 'LEFT');
		$rResult = $this->db->get($sTable);		
		//echo $this->db->get_compiled_select($sTable); die();
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;
		// Total data set length
		$this->db->where('c_status', 1);
		//$this->db->where('b_status', 1);
		//$this->db->where('m_status', 0);
		$where = "(ws_type = 'withdraw' AND b_status = 0 AND m_status = 0) OR (ws_type = 'deposit' AND b_status = 1 AND m_status = 0)";	
		$where .= " OR (ws_type = 'transfer' AND b_status = 1 AND m_status = 0)";	
		$this->db->where($where, NULL, FALSE);
		$this->db->join('tb_users', 'tb_users.user_id=tb_worksheet.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws_dealer', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=tb_worksheet.c_id', 'LEFT');
		$this->db->join('tb_account a2', 'a2.ac_id=tb_worksheet.b_id', 'LEFT');
		// echo $this->db->get_compiled_select($sTable); die();
		$iTotal = $this->db->count_all_results($sTable);
		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$firstname = substr($aRow->accountname, 0, strpos($aRow->accountname, ' '));
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$row[0] = $iDisplayStart;		
			$row[1] = conv_ws_type($aRow->ws_type);
			$row[2] = $aRow->ws_dealer;
			$row[3] = $firstname;			
			$row[4] = $aRow->username;
			$row[5] = $aRow->ws_date;
			$row[6] = number_format($aRow->ws_credit,2);
			$row[7] = $aRow->ws_deimg;
			$row[8] = $aRow->a1name;
			$row[9] = $aRow->created;		
			$row[10] = $aRow->ws_wiimg;
			$row[11] = $aRow->a2name;	
			$row[12] = $aRow->ws_id;	 
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}
	
	public function all(){
		$this->titlecomponent->add('ทั้งหมด');
		//$Content['rs_userpass'] = $this->userpass_model->get_userpass_bank();
		$data['Content'] = $this->load->view('worksheet/all', null, true);
		$this->load->view('template/temp_main', $data);
	}
	
	public function worksheet_all(){
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'ws_type',2=>'ws_dealer',3=>'accountname',4=>'uag.username',5=>'ws_date',6=>'ws_credit',7=>'a1.name AS a1name',8=>'tb_worksheet.created',9=>'a2.name AS a2name',10=>'b_status',11=>'b_date',12=>'a3.name AS a3name',13=>'m_status',14=>'m_date',16=>'ws_id');
		// DB table to use
		$sTable = 'tb_worksheet';
		//
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);
		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}
		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);
				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++){
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);
				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					if($aColumns[$i]=='ws_date'||$aColumns[$i]=='tb_worksheet.created'){
						//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';						
						if(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch)){
							$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
						}						
					}elseif($aColumns[$i]=='a1.name AS a1name'){
						$like[] = "a1.name LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}elseif($aColumns[$i]=='a2.name AS a2name'){
						$like[] = "a2.name LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}elseif($aColumns[$i]=='a3.name AS a3name'){
						$like[] = "a3.name LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}else{
						//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
						$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}
				}
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
			
		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_users', 'tb_users.user_id=tb_worksheet.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws_dealer', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=tb_worksheet.c_id', 'LEFT');
		$this->db->join('tb_account a2', 'a2.ac_id=tb_worksheet.b_id', 'LEFT');
		$this->db->join('tb_account a3', 'a3.ac_id=tb_worksheet.m_id', 'LEFT');
		$rResult = $this->db->get($sTable);		
		
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;
		// Total data set length
		$this->db->join('tb_users', 'tb_users.user_id=tb_worksheet.user_id', 'LEFT');
		$this->db->join('tb_users_agent uag', 'uag.user_id=tb_users.user_id AND uag.dealer=ws_dealer', 'LEFT');
		$this->db->join('tb_account a1', 'a1.ac_id=tb_worksheet.c_id', 'LEFT');
		$this->db->join('tb_account a2', 'a2.ac_id=tb_worksheet.b_id', 'LEFT');
		$this->db->join('tb_account a3', 'a3.ac_id=tb_worksheet.m_id', 'LEFT');
		$iTotal = $this->db->count_all_results($sTable);
		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			
			//$b_status = ($aRow->m_status==2)?conv_ws_status($aRow->m_status):conv_ws_status($aRow->b_status);
			//$m_status = ($aRow->b_status==2)?conv_ws_status($aRow->b_status):conv_ws_status($aRow->m_status);
						
			$m_duration = 0;
			$b_duration = 0;
			//if($aRow->m_status==1){	
				if($aRow->ws_type=='withdraw'){
					$b_status = ($aRow->m_status==2)?conv_ws_status($aRow->m_status):conv_ws_status($aRow->b_status);
					$m_status = conv_ws_status($aRow->m_status);
				
					$m_duration = duration_minute($aRow->created,$aRow->m_date);
					$m_status .= ($m_duration>5)?'<br><span class="badge badge-error">'.$m_duration.' นาที</span>':'<br><span class="badge badge-default">'.$m_duration.' นาที</span>';
					$b_duration = duration_minute($aRow->m_date,$aRow->b_date);
					$b_status .= ($b_duration>5)?'<br><span class="badge badge-error">'.$b_duration.' นาที</span>':'<br><span class="badge badge-default">'.$b_duration.' นาที</span>';
				}else{
					$b_status = conv_ws_status($aRow->b_status);
					$m_status = ($aRow->b_status==2)?conv_ws_status($aRow->b_status):conv_ws_status($aRow->m_status);
				
					$m_duration = duration_minute($aRow->b_date,$aRow->m_date);
					$m_status .= ($m_duration>5)?'<br><span class="badge badge-error">'.$m_duration.' นาที</span>':'<br><span class="badge badge-default">'.$m_duration.' นาที</span>';
					$b_duration = duration_minute($aRow->created,$aRow->b_date);
					$b_status .= ($b_duration>5)?'<br><span class="badge badge-error">'.$b_duration.' นาที</span>':'<br><span class="badge badge-default">'.$b_duration.' นาที</span>';
				}
			//}			
						
			$t_duration = $m_duration+$b_duration;
			$t_duration = ($t_duration>5)?'<span class="badge badge-error">'.$t_duration.' นาที</span>':'<span class="badge badge-default">'.$t_duration.' นาที</span>';
			
			$firstname = substr($aRow->accountname, 0, strpos($aRow->accountname, ' '));
			$row[0] = $iDisplayStart;		
			$row[1] = conv_ws_type($aRow->ws_type);
			$row[2] = $aRow->ws_dealer;
			$row[3] = $firstname;			
			$row[4] = $aRow->username;
			$row[5] = $aRow->ws_date;
			$row[6] = number_format($aRow->ws_credit,2);
			$row[7] = $aRow->a1name;	
			$row[8] = $aRow->created;
			$row[9] = '';
			$row[10] = $aRow->a2name.'<br>'.$b_status;	
			$row[11] = '';
			$row[12] = '';
			$row[13] = $aRow->a3name.'<br>'.$m_status;
			$row[14] = '';
			$row[15] = $t_duration;
			$row[16] = $aRow->ws_id;		 
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}
	public function add_wiimg(){
		$post = $this->input->post();
		$msgtype = 'msg_error';
		$msg = 'บันทึกภาพไม่สำเร็จ';
		if($post){
			extract($post);
			if($ws_wiimg!=''){				
				$data = array(
					'ws_wiimg'=>$ws_wiimg,
				);					
				$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'c_status'=>1));
				if($this->db->affected_rows() > 0){
					$msgtype = 'msg_success';
					$msg = 'บันทึกภาพสำเร็จ';
					//+ History Log 
					$data = array(
						'username'=>$username,
						'ws_id'=>$ws_id,
						'ws_wiimg'=>$ws_wiimg
					);		
					$this->history->save(array('action'=>'Call เพิ่มรูป ใบงานถอน','user_id'=>$this->session->userdata('ac_id'),'detail'=>json_encode($data)));				
				}
			}
		}
		$this->session->set_flashdata($msgtype, $msg);
		redirect('worksheet/call/withdraw');
	}
	public function add_queue() {
		// $msg = array('error'=>'1','text'=>'ปิดการใช้งาน add_queue ชั่วคราว');
		// echo json_encode($msg);
		// die();
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		
		if($post){
			extract($post);
			$ws_id = $wsid;
			$ws_bankac = explode('|',$wsbankac);
			$rs_worksheet = $this->worksheet_model->get_worksheet_witdraw_bank_by_id($ws_id);
			if($rs_worksheet->num_rows()==1&&count($ws_bankac)==4){
				$row_worksheet = $rs_worksheet->row();				
				if($row_worksheet->b_flag==1&&$row_worksheet->b_flag_id==$this->session->userdata('ac_id')){
					$wibank = $ws_bankac[0];
					$wibankac = $ws_bankac[1];
					$wibankacnum = $ws_bankac[2];
					$wibankname = $ws_bankac[3];										
					$sql = 'SELECT * FROM tb_userpass WHERE type="'.$wibank.'" AND username="'.$wibankac.'" AND bankname="'.$wibankname.'" AND acnum="'.$wibankacnum.'" AND up_status = 1';
					$query_bankwithdraw = $this->db->query($sql);
					if($query_bankwithdraw->num_rows()==1){
						$row_bankwithdraw = $query_bankwithdraw->row();
						$usernamebank = $row_bankwithdraw->username;
						$passwordbank = $row_bankwithdraw->password;
						$lastdigitphone = $row_bankwithdraw->lastdigitphone;
						if($usernamebank!=''&&$passwordbank!=''&&$lastdigitphone!=''){				
							$data = array(
								'ws_wibank'=>$row_bankwithdraw->type,
								'ws_wibankac'=>$row_bankwithdraw->username,
								'ws_wibankname'=>$row_bankwithdraw->bankname,
								'ws_wibankacnum'=>$row_bankwithdraw->acnum,
								'b_id'=>$this->session->userdata('ac_id'),
								'b_status'=>3,
								'b_comment'=>'รอจัดการ: '.date('Y-m-d H:i:s'),
								'b_date'=>date('Y-m-d H:i:s'),
								'modified'=>date('Y-m-d H:i:s')
							);					
							$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'ws_type'=>'withdraw','c_status'=>1,'b_status'=>0,'m_status'=>1));
							if($this->db->affected_rows() > 0){
								//+ History Log 
								$data = array(
									'dealer'=>$row_worksheet->ws_dealer,
									'username'=>$row_worksheet->username,
									'ws_id'=>$row_worksheet->ws_id
								);		
								$this->history->save(array('action'=>'Bank รอจัดการ ใบงานถอน','user_id'=>$this->session->userdata('ac_id'),'detail'=>json_encode($data)));				
								$msg = 'ใบงานกำลังรอการจัดการ';
								$msg = array('error'=>'0','text'=>$msg,'username'=>$row_worksheet->username);
								echo json_encode($msg); die();	
							}
						}else{							
							$msg = array('error'=>'1','text'=>'เช็ค Username / Password / Last digit phone Bank');
						} // End if($usernamebank!=''&&$passwordbank!=''&&$lastdigitphone!=''){	
					} // End if($query_bankwithdraw->num_rows()==1){		
					
					// ปล่อยใบงาน
					$data = array(
						'b_flag'=>0,
						'b_flag_id'=>NULL,
						'b_flag_expire'=>NULL,
						'modified'=>date('Y-m-d H:i:s')
					);
					$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'c_status'=>1,'b_status'=>0,'m_status'=>1));
			
				} // End if($row_worksheet->b_flag==1&&$row_worksheet->b_flag_id==$this->session->userdata('ac_id')){
			} // End if($rs_worksheet->num_rows()==1&&count($ws_bankac)==3){
		} // End if($post){	
		echo json_encode($msg);
	}
	public function revert_queue() {
		// $msg = array('error'=>'1','text'=>'ปิดการใช้งาน revert_queue ชั่วคราว');
		// echo json_encode($msg);
		// die();
		
		$post = $this->input->post();
		$msg = array('error'=>'1','text'=>'ใบงานอาจถูกปรับสถานะแล้ว โปรดรีเฟรชหน้า แล้วตรวจสอบ');
		if($post){
			extract($post);
			$ws_id = $wsid;
			$rs_worksheet = $this->worksheet_model->get_worksheet_by_id($ws_id);
			if($rs_worksheet->num_rows()==1){
				$row_worksheet = $rs_worksheet->row();
				if($row_worksheet->ws_type=='withdraw'){
					if($row_worksheet->b_status==3||$row_worksheet->b_status==5||$row_worksheet->b_status==4){
						// ปล่อยใบงาน
						$data = array(
							'ws_wibank'=>NULL,
							'ws_wibankac'=>NULL,
							'ws_wibankname'=>NULL,
							'ws_wibankacnum'=>NULL,
							'b_id'=>NULL,
							'b_status'=>0,
							'b_comment'=>NULL,
							'b_date'=>date('Y-m-d H:i:s'),
							'b_flag'=>0,
							'b_flag_id'=>NULL,
							'b_flag_expire'=>NULL,
							'modified'=>date('Y-m-d H:i:s')
						);
						$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'c_status'=>1,'b_status'=>$row_worksheet->b_status,'m_status'=>1));
						if($this->db->affected_rows() > 0){
							//+ History Log 
							$data = array(
								'dealer'=>$row_worksheet->ws_dealer,
								'username'=>$row_worksheet->u1username,
								'ws_id'=>$row_worksheet->ws_id
							);		
							$this->history->save(array('action'=>'พนักงาน ย้อน ใบงานถอน '.$row_worksheet->b_status.'=>0'. ' ('.@$row_worksheet->b_comment.')','user_id'=>$this->session->userdata('ac_id'),'detail'=>json_encode($data)));				
							$msg = 'ย้อนใบงานกลับไปสถานะ รอตรวจ สำเร็จ';
							$msg = array('error'=>'0','text'=>$msg,'username'=>$row_worksheet->u1username);
							echo json_encode($msg); die();	
						}
					}
				}
			}
		}
		echo json_encode($msg);
	}
	
}
