<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_reCaptcha extends CI_Controller {
    public function verify_reCaptcha(){
        $secretKey = "6Ld9F_YZAAAAABUToIgunJjeycUqaHqvnlDabo1U";
        $captcha = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);

		// post request to server
		$url = 'https://www.google.com/recaptcha/api/siteverify';
		$data = 'secret='.$secretKey.'&response='.$captcha;
			// echo
		$this->curl = curl_init();
        curl_setopt($this->curl, CURLOPT_URL, $url);
		curl_setopt($this->curl, CURLOPT_HEADER, false);
		curl_setopt($this->curl, CURLOPT_HTTPHEADER, array("Content-type: application/x-www-form-urlencoded"));
		// curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($this->curl, CURLOPT_POST, TRUE);
		curl_setopt($this->curl, CURLOPT_POSTFIELDS, $data);
		$result = curl_exec($this->curl);
		$result = json_decode($result, TRUE);
		curl_close($this->curl);
// 		echo json_encode($result['score']);
		if($result['success'] && $result['score'] > 0.4){
		    echo json_encode(array('errorCode' => 0));
		}else{
		    echo json_encode(array('errorCode' => 1));
		}
// 		print_r($result);
    }
}