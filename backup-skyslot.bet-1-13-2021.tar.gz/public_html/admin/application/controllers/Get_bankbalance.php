<?php
defined('BASEPATH') OR exit('No direct script access allowed');
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Get_bankbalance extends CI_Controller {

	var $auth;
	var $chkbank;
	var $chscb;
	var $chbbl;
	var $chktb;
	var $filecookiektb;
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('bypasscaptcha'));
	}
	
	// ==================== KBANK ============================================
	public function kbank_balance($username,$password,$filecookie){

		$cookie = PUBPATH."cookie/cookie-".$filecookie.".txt";				
		//+ Login		
		$this->chkbank = curl_init(); 
		curl_setopt($this->chkbank, CURLOPT_URL, 'https://online.kasikornbankgroup.com/K-Online/login.do'); 
		curl_setopt($this->chkbank, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->chkbank, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->chkbank, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->chkbank, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->chkbank, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->chkbank, CURLOPT_COOKIEJAR, $cookie); 
		curl_setopt($this->chkbank, CURLOPT_COOKIEFILE, $cookie);  // <-- add this line
		curl_setopt($this->chkbank, CURLOPT_REFERER, 'https://online.kasikornbankgroup.com/K-Online/indexHome.jsp');	
		$html = curl_exec($this->chkbank);		
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
	
		$postdata='';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 if($inputname==='tokenId'){
				 $postdata .= $inputname.'='.$inputval.'&';
			 }
		}
		$postdata .= 'userName='.$username.'&password='.$password.'&cmd=authenticate&locale=th&custType=&app=0';
		curl_setopt($this->chkbank, CURLOPT_POST, 1);
		curl_setopt($this->chkbank, CURLOPT_POSTFIELDS, $postdata);	
		curl_exec($this->chkbank);
		
		//+ Get txtParam
		curl_setopt($this->chkbank, CURLOPT_URL, 'https://online.kasikornbankgroup.com/K-Online/ib/redirectToIB.jsp');
		$html = curl_exec($this->chkbank);
			
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents
		$inputs = $dom->getElementsByTagName('input');
		
		$postdata='';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 $postdata .= $inputname.'='.$inputval;
		}
		
		//+ Login To Ebank
		curl_setopt($this->chkbank, CURLOPT_URL, 'https://ebank.kasikornbankgroup.com/retail/security/Welcome.do');
		curl_setopt($this->chkbank, CURLOPT_POST, 1);
		curl_setopt($this->chkbank, CURLOPT_POSTFIELDS, $postdata);
		curl_exec($this->chkbank);
		
		//+ AccountSummary	
		curl_setopt($this->chkbank, CURLOPT_URL, 'https://ebank.kasikornbankgroup.com/retail/cashmanagement/inquiry/AccountSummary.do?action=list_domain2');
		$html = curl_exec($this->chkbank);
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents
		$table20 = $dom->getElementsByTagName('table')->item(20); // get table contents.
		$Balance = $table20->getElementsByTagName('tr')->item(1)->getElementsByTagName('td')->item(2)->nodeValue;
		$Available = $table20->getElementsByTagName('tr')->item(1)->getElementsByTagName('td')->item(3)->nodeValue;
		
		curl_setopt($this->chkbank, CURLOPT_URL, 'https://online.kasikornbankgroup.com/K-Online/logout.do?cmd=success');
		curl_exec($this->chkbank);
		curl_close($this->chkbank);
		
		return array('balance'=>$Balance, 'available'=>$Available);

	}
	
	// ==================== BBL ============================================
	public function bbl_balance($username,$password,$filecookie){	
		
		$cookie = PUBPATH."cookie/cookie-".$filecookie.".txt";				
		//+ Login		
		$this->chbbl = curl_init(); 
		curl_setopt($this->chbbl, CURLOPT_URL, 'https://ibanking.bangkokbank.com/SignOn.aspx'); 
		curl_setopt($this->chbbl, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->chbbl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->chbbl, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->chbbl, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->chbbl, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->chbbl, CURLOPT_COOKIEJAR, $cookie); 
		curl_setopt($this->chbbl, CURLOPT_COOKIEFILE, $cookie);  // <-- add this line
		curl_setopt($this->chbbl, CURLOPT_REFERER, 'https://ibanking.bangkokbank.com/SignOn.aspx');	
		$html = curl_exec($this->chbbl);		
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
	
		$postdata='';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value'); 
			 switch($inputname){
				case '__VIEWSTATE':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case 'txtID':
					$postdata .= $inputname.'='.$username.'&';
				break;
				case 'txtPwd':
					$postdata .= $inputname.'='.$password.'&';
				break;
				 default:
					$postdata .= $inputname.'='.$inputval.'&';
			 }
		}
		$postdata = substr($postdata,0,-1);	
		
		curl_setopt($this->chbbl, CURLOPT_POST, 1);
		curl_setopt($this->chbbl, CURLOPT_POSTFIELDS, $postdata);	
		curl_exec($this->chbbl);
		
		//+ AccountSummary	
		curl_setopt($this->chbbl, CURLOPT_URL, 'https://ibanking.bangkokbank.com/workspace/16AccountActivity/wsp_AccountSummary_AccountSummaryPage.aspx');
		$html = curl_exec($this->chbbl);
		
		$dom = new DOMDocument('1.0', 'UTF-8'); // create DOM object
		@$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));// load it's all html contents	
		//$dom->loadHTML($html);// load it's all html contents	
		$Balance = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lblAcctBal')->nodeValue;
		$Available = $dom->getElementById('ctl00_ctl00_C_CW_gvDepositAccts_ctl02_lblAcctAvailBal')->nodeValue;		
							
		curl_setopt($this->chbbl, CURLOPT_URL, 'https://ibanking.bangkokbank.com/LogOut.aspx');
		curl_exec($this->chbbl);
		curl_close($this->chbbl);				
			
		return array('balance'=>$Balance, 'available'=>$Available);
			
	}
	
	// ==================== SCB ============================================
	public function scb_balance($username,$password,$filecookie){				
		$cookie = PUBPATH."cookie/cookie-".$filecookie.".txt";				
		//+ Login		
		$this->chscb = curl_init(); 
		curl_setopt($this->chscb, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/lgn/login.aspx'); 
		curl_setopt($this->chscb, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->chscb, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->chscb, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->chscb, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->chscb, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->chscb, CURLOPT_COOKIEJAR, $cookie); 
		curl_setopt($this->chscb, CURLOPT_COOKIEFILE, $cookie);  // <-- add this line
		curl_setopt($this->chscb, CURLOPT_REFERER, 'https://www.scbeasy.com/online/easynet/page/lgn/login.aspx');	

		$postdata = 'LANG=T&LOGIN='.$username.'&PASSWD='.$password.'&lgin.x=32&lgin.y=10';			
		curl_setopt($this->chscb, CURLOPT_POST, 1);
		curl_setopt($this->chscb, CURLOPT_POSTFIELDS, $postdata);
		$html = curl_exec($this->chscb);	
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
		
		$sessioneasy='';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 if($inputname==='SESSIONEASY'){
				 $sessioneasy .= $inputname.'='.$inputval;
			 }
		}
		
		//+ Firstpage	
		//curl_setopt($this->chscb, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/acc/acc_mpg.aspx');
		//curl_setopt($this->chscb, CURLOPT_POST, 1);
		//curl_setopt($this->chscb, CURLOPT_POSTFIELDS, $sessioneasy);
		//$html = curl_exec($this->chscb);
		
		//$dom = new DOMDocument(); // create DOM object
		//@$dom->loadHTML($html);// load it's all html contents	
		//$table = $dom->getElementById('DataProcess_SaCaGridView');
		//$Balance = $table->getElementsByTagName('tr')->item(2)->getElementsByTagName('td')->item(4)->nodeValue;
		//$Available = $table->getElementsByTagName('tr')->item(2)->getElementsByTagName('td')->item(5)->nodeValue;
		
		//+ Bank Balance
		curl_setopt($this->chscb, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/acc/acc_bnk_bln.aspx');
		curl_setopt($this->chscb, CURLOPT_POST, 1);
		curl_setopt($this->chscb, CURLOPT_POSTFIELDS, $sessioneasy);
		$html = curl_exec($this->chscb);
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$table = $dom->getElementById('DataProcess_Saving');
		$stringttable = $dom->saveHTML($table);  // save html table 
		$Balance = $table->getElementsByTagName('tr')->item(0)->getElementsByTagName('td')->item(1)->nodeValue;
		$Available = $table->getElementsByTagName('tr')->item(1)->getElementsByTagName('td')->item(1)->nodeValue;				
									
		curl_setopt($this->chscb, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/lgn/logout.aspx');
		curl_exec($this->chscb);
		curl_close($this->chscb);				
			
		return array('balance'=>$Balance, 'available'=>$Available);
		
	}
	
	// ==================== KTB ============================================
	private function get_captcha(){		
		//$key = '28c31caadd6053728ce2eb53b8e56919'; // Key เก่า
		$key = 'ef71d0838a308a6a0068dbab3bf314aa'; // Key ใหม่
		$img_captcha = PUBPATH."/images/captcha.png";		
		$value = $this->bypasscaptcha->bc_submit_captcha($key, $img_captcha);
		return $value;
	}
	
	private function get_imgcaptcha(){
		curl_setopt($this->chktb, CURLOPT_URL, 'https://www.ktbnetbank.com/consumer/');
		curl_setopt($this->chktb, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->chktb, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
		curl_setopt($this->chktb, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->chktb, CURLOPT_RETURNTRANSFER, 1);	
		//curl_setopt($this->chktb, CURLOPT_COOKIEJAR, $this->filecookiektb); 
		curl_setopt($this->chktb, CURLOPT_COOKIEFILE, $this->filecookiektb);	
		$html = curl_exec($this->chktb);
		//print_r($html);
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents			
		$img_captcha = $dom->getElementById('imageCodeDisplayId')->getAttribute('src'); // get src img captcha	
		
		curl_setopt($this->chktb, CURLOPT_URL, 'https://www.ktbnetbank.com'.$img_captcha);
		$captcha = curl_exec($this->chktb);
		
		$strFileName = PUBPATH."/images/captcha.png";
		$objFopen = fopen($strFileName, 'w');
		fwrite($objFopen, $captcha);
		fclose($objFopen);	
	}
	
	private function get_sessId($username){
		$this->sessId = PUBPATH."/cookie/sessId-".$username.".txt";
		$sessId = @file_get_contents($this->sessId);
		return $sessId;
	}
	
	private function checklogin($sessId){	 
		//+ Get Detail For Check Login
		curl_setopt($this->chktb, CURLOPT_URL,'https://www.ktbnetbank.com/consumer/SavingAccount.do?cmd=init&sessId='.$sessId.'&_=1514531984376');
		curl_setopt($this->chktb, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->chktb, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->chktb, CURLOPT_TIMEOUT, 60); 
		//curl_setopt($this->chktb, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->chktb, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->chktb, CURLOPT_COOKIEFILE, $this->filecookiektb);  // <-- add this line
		$xml = curl_exec($this->chktb);		
		//print_r($xml);
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadXML($xml);// load it's all xml contents	
		$oid = @$dom->getElementsByTagName('OID')->item(0)->nodeValue;
		//$accountnodisplay = $dom->getElementsByTagName('ACCOUNTNODISPLAY')->item(0)->nodeValue;
		return array('oid'=>$oid);
	}
	
	private function formlogin($username,$password){
		$this->get_imgcaptcha();
		$captcha = $this->get_captcha();
		
		//+ Login
		curl_setopt($this->chktb, CURLOPT_URL, 'https://www.ktbnetbank.com/consumer/Login.do'); 
		curl_setopt($this->chktb, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->chktb, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->chktb, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->chktb, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->chktb, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->chktb, CURLOPT_COOKIEJAR, $this->filecookiektb); 
		curl_setopt($this->chktb, CURLOPT_COOKIEFILE, $this->filecookiektb);  // <-- add this line
		curl_setopt($this->chktb, CURLOPT_REFERER, 'https://www.ktbnetbank.com/consumer/Login.do');	
		
		$postdata = 'cmd=login&&userId='.$username.'&password='.$password.'&imageCode='.$captcha;	
		curl_setopt($this->chktb, CURLOPT_POST, 1);
		curl_setopt($this->chktb, CURLOPT_POSTFIELDS, $postdata);
		$html = curl_exec($this->chktb);	
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents			
		$header = $dom->getElementsByTagName('script')->item(2)->nodeValue;
		//$header = $dom->getElementsByTagName('script')->item(3)->nodeValue;
		if($header){
			preg_match_all("#sessionKey = '(.*)';#", $header, $session);
			$sessId = $session[1][0];			
			if(!$sessId){
				$header = $dom->getElementsByTagName('script')->item(3)->nodeValue;
				preg_match_all("#sessionKey = '(.*)';#", $header3, $session);
				$sessId = $session[1][0];	
				
				$sFile = PUBPATH."/cookie/sessId-".$username.".txt";
				$objFopen = fopen($sFile, 'w');
				fwrite($objFopen, $sessId);
				fclose($objFopen);
			}else{
				$sFile = PUBPATH."/cookie/sessId-".$username.".txt";
				$objFopen = fopen($sFile, 'w');
				fwrite($objFopen, $sessId);
				fclose($objFopen);	
			}
		}
	}
	
	public function ktb_balance($username,$password,$filecookie){			
				
		$this->filecookiektb = PUBPATH."cookie/cookie-".$filecookie.".txt";
		$this->chktb = curl_init();
		
		$sessId = $this->get_sessId($username);
		if($sessId){
			$checklogin = $this->checklogin($sessId);
			if(!isset($checklogin['oid'])){
				$this->formlogin($username,$password);
				$sessId = $this->get_sessId($username);
			}
		}else{
			$this->formlogin($username,$password);
			$sessId = $this->get_sessId($username);
		}
		
		if(isset($sessId)){
			//+ detail
			curl_setopt($this->chktb, CURLOPT_URL,'https://www.ktbnetbank.com/consumer/SavingAccount.do?cmd=init&sessId='.$sessId.'&_=1514531984376');
			$xml = curl_exec($this->chktb);				
			$dom = new DOMDocument(); // create DOM object
			@$dom->loadXML($xml);// load it's all xml contents	
			$oid = $dom->getElementsByTagName('OID')->item(0)->nodeValue;
			$accountnodisplay = $dom->getElementsByTagName('ACCOUNTNODISPLAY')->item(0)->nodeValue;
			
			//+ Balance
			curl_setopt($this->chktb, CURLOPT_CONNECTTIMEOUT, 30);
			curl_setopt($this->chktb, CURLOPT_USERAGENT, "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:44.0) Gecko/20100101 Firefox/44.0");
			curl_setopt($this->chktb, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($this->chktb, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($this->chktb, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($this->chktb, CURLOPT_COOKIEFILE, $this->filecookiektb);
			curl_setopt($this->chktb, CURLOPT_HEADER, 0);
			curl_setopt($this->chktb, CURLOPT_TIMEOUT, 120);					
			curl_setopt($this->chktb, CURLOPT_URL, "https://www.ktbnetbank.com/consumer/SavingAccount.do?cmd=init&sessId=$sessId&_=".rand(11111111111111111, 99999999999999999));
			$account = curl_exec($this->chktb);	
			$xml = simplexml_load_string($account);
			$data=array();
			foreach($xml->DATA as $x){
				if($x->OID == $oid){
					$data['index'] = trim($x->OID);
					$data['typeid'] = trim($x->TYPE);
					$data['accnumber'] = str_replace("KTB*","",trim($x->ACCOUNTNODISPLAY));
					$data['accname'] = trim($x->ACCOUNT_NAME);
					$data['balance'] = 0 + str_replace(",","",trim($x->AMOUNT));
					$data['available'] = 0 + str_replace(",","",trim($x->WITHDRAWABLE));
				}
			}					
			if(count($data)>0){
				return array('balance'=>$data['balance'], 'available'=>$data['available']);
			}
		}
					
		curl_setopt($this->chktb, CURLOPT_URL, 'https://www.ktbnetbank.com/consumer/index.jsp?logout=true');
		curl_exec($this->chktb);
		curl_close($this->chktb);
		//@unlink($this->filecookiektb);				
	}
		
}
