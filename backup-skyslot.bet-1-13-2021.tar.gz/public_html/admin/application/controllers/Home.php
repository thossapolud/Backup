<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {
		parent::__construct();

		$this->load->library('auth');

		$auth = new auth();
		$auth->isnot_login();

		$this->load->model('agent_model');
		$this->load->model('user_model');
		$this->load->model('deposit_model');
		$this->load->model('withdraw_model');
		$this->load->model('deposit_withdraw_model');
		$this->load->model('userpass_model');
		$this->load->model('statement_model');
		$this->load->model('worksheet_model');
		$this->load->model('promotion_user_model');
	}

	public function index() {
		if ($this->input->post('start') && $this->input->post('start') != '' && $this->input->post('end') && $this->input->post('end') != '') {
			$start = $this->input->post('start');
			$end = $this->input->post('end');
		} else {
			$G = date('G', strtotime(date('Y-m-d H:i:s')));
			if($G>11){
				$start = date('Y-m-d').' 11:01:00';
				$end = date('Y-m-d 11:00:00',(strtotime ( '+1 day' , strtotime(date('Y-m-d')))));
			}else{
				$start = date('Y-m-d 11:01:00',(strtotime ( '-1 day' , strtotime(date('Y-m-d')))));
				$end = date('Y-m-d').' 11:00:00';
			}
		}

		$Content['total_register'] = $this->user_model->get_num_register();
		$Content['total_register_site'] = $this->user_model->get_num_register_site();
		$Content['total_register_today'] = $this->user_model->get_num_register_by_date($start,$end,NULL,NULL,NULL);
		$Content['total_register_deposit_today'] = $this->user_model->get_num_register_deposit_by_date($start,$end,NULL,NULL,NULL);
		$Content['total_active_today'] = $this->user_model->get_num_active_by_date($start, $end,NULL,NULL,NULL);
	
		$Content['deposit_credit_today'] = $this->deposit_model->get_sumcountcredit($start, $end,NULL,NULL,NULL);
		$Content['depositpromotion_credit_today'] = $this->deposit_model->get_sumcountcreditpromotion($start, $end,NULL,NULL,NULL);
		$Content['withdraw_credit_today'] = $this->withdraw_model->get_sumcountcredit($start, $end,NULL,NULL,NULL);
		$Content['tin_credit_today'] = $this->deposit_model->get_sumcountcredittransfer($start, $end,NULL,NULL,NULL);
		$Content['tout_credit_today'] = $this->withdraw_model->get_sumcountcredittransfer($start, $end,NULL,NULL,NULL);

		$Content['deposit_today'] = $this->statement_model->get_sumin(NULL, NULL, $start, $end);
		$Content['withdraw_today'] = $this->worksheet_model->get_worksheet_withdraw_sumcredit(NULL,NULL,NULL,$start, $end);

		$Content['rs_agent_pussy'] = $this->agent_model->get_by_dealer('Pussy888');
		$Content['rs_agent_scr'] = $this->agent_model->get_by_dealer('918kiss');

		$Content['rs_bank_deposit'] = $this->userpass_model->get_active_deposit_withdraw_bank(NULL,NULL,'deposit');
		$Content['rs_bank_withdraw'] = $this->userpass_model->get_active_deposit_withdraw_bank(NULL,NULL,'withdraw');
		$Content['latest_de_wi'] = $this->deposit_withdraw_model->get_deposit_withdraw(NULL,NULL,NULL,NULL,NULL,15);

		$Content['rs_deposit_top'] = $this->deposit_model->get_sumcountcredit_top($start, $end, 5);
		$Content['rs_depositnotwithdraw_top'] = $this->deposit_model->get_sumcountcreditnotwithdraw_top($start, $end, 5);
		$Content['rs_withdraw_top'] = $this->withdraw_model->get_sumcountcredit_top($start, $end, 5);
		
		$Content['start'] = $start;
		$Content['end'] = $end;
		$data['Content'] = $this->load->view('home/index', $Content, true);
		$this->load->view('template/temp_main', $data);
	}

	function register_bydate() {
		$post = $this->input->post();
		if ($post) {
			extract($post);
			$data = array();
			$totalregister = 0;
			$totalopen = 0;
			$totaloldopen = 0;
			// $dealers = array('918kiss', 'Slotxo');
			$dealers = $this->userpass_model->get_dealers()->result();
			foreach ($dealers as $dealer) {
				$userregister = $this->user_model->get_numrows_register_by_date($dealer->type, $datestart, $dateend);
				$useropen = $this->user_model->get_numrows_open_by_date($dealer->type, $datestart, $dateend);
				$useroldopen = $this->user_model->get_numrows_oldopen_by_date($dealer->type, $datestart, $dateend);
				$totalregister += $userregister;
				$totalopen += $useropen;
				$totaloldopen += $useroldopen;
				$data[$dealer->type] = array('userregister' => $userregister, 'useropen' => $useropen, 'useroldopen' => $useroldopen);
			}
			$data['รวม'] = array('userregister' => $totalregister, 'useropen' => $totalopen, 'useroldopen' => $totaloldopen);
			echo json_encode($data);
		}
	}

}