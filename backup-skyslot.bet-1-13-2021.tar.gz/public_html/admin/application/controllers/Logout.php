<?php
class Logout extends CI_Controller{
	
	function __construct(){	
		parent::__construct();
	}
	
	function index(){	
		$this->load->library(array('loginout_log'));		
		$loginout_log = new loginout_log();
		$loginout_log->save_logout();
		
		$this->session->sess_destroy();	
		$this->session->unset_userdata('login');
		$this->session->unset_userdata('ac_id');
		$this->session->unset_userdata('level');
		$this->session->unset_userdata('name');
		redirect('login');	
	}
	
}
?>