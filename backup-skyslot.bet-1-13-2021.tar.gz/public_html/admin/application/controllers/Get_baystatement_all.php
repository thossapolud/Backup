<?php defined('BASEPATH') OR exit('No direct script access allowed');

set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Get_baystatement_all extends CI_Controller {
	
	var $auth;
	var $ch;
	var $cookie;
	var $is_from_cron_job = false;
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth','history_log'));
		$this->auth = new auth();
		$this->history = new history_log();
		$cron = $this->uri->segment(5);
		if ($cron != 1) { // If not from cron job
			$this->auth = new auth();
			$this->auth->isnot_login();
		} else {
			$this->is_from_cron_job = true;
		}
		$this->load->model('website_model');
		$this->load->model('userpass_model');
		$this->load->model('transfer_channel_model');
	}
	
	private function set_baydate($date) {
		$date_array=explode(" ",$date);
		$date_array2=explode("/",$date_array[0]);		
		$d=$date_array2[0];
		$m=$date_array2[1];	
		$y=$date_array2[2];
		$h = $date_array[1];	
		$newformat="$y-$m-$d $h".":00";
		return $newformat;
	}
	
	private function get_portfolio(){
		//+ MyPortfolio && Check Session
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?d'); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line	
		$html = curl_exec($this->ch);	
						
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$a = $dom->getElementById('ctl00_cphSectionData_rptDeposit_ctl01_ltField002');				
		preg_match("/MyAccount.aspx\?token=([^&]*)/",$html,$token);
		$data=array();
		if(!empty($token)&&$token[1]){
			
			$data['token'] = $token[1];
			$data['ma'] = trim($a->getAttribute('account'));
			$data['accnumber'] = trim($a->getAttribute('accno'));
								
			$divs= $dom->getElementsByTagName('div');
			$i=1;
			foreach($divs as $div){ 
				if($div->getAttribute('class')=='amc') {
					if($i==1){
						$data['canuse'] = $div->nodeValue;
					}
					if($i==2){
						$data['total'] = $div->nodeValue;
					}
					$i++;
				}
			 }
			 
		}
		return $data;
	}
	
	private function login_bay($usernamebank,$passwordbank){
		//+ Login	
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Common/Login.aspx'); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line		
		$html = curl_exec($this->ch);	
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
		
		$postdata='__EVENTTARGET=ctl00%24cphForLogin%24lbtnLoginNew&__EVENTARGUMENT=&';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 switch($inputname){
				case '__VIEWSTATE':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__EVENTVALIDATION':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__VIEWSTATEGENERATOR':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
			 }
		}
		//$postdata = substr($postdata,0,-1);
		$postdata .='user=&password=&username=&password=&ctl00%24cphForLogin%24username='.$usernamebank.'&ctl00%24cphForLogin%24password=&ctl00%24cphForLogin%24hdPassword='.rawurlencode($passwordbank).'&ctl00%24cphForLogin%24hddLanguage=TH';
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Common/Login.aspx');		
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($this->ch, CURLOPT_POST, 1);
		$html = curl_exec($this->ch);
		//print_r($html);
		if(preg_match("#Last Logged in#",$html)){
			return true;
		}else{
			return false;
		}
	}
	
	// domain.com/app/get-baystatement/get/bay/ac1
	// For cron job :
	// domain.com/app/get-baystatement/get/bay/ac1/1
	public function get() {
		$bank = $this->uri->segment(3);
		$acnum = $this->uri->segment(4);
		if($bank && $bank == 'bay' && $acnum){
			$row_userpass = $this->userpass_model->get_by_bankac($bank,$acnum);
			if ($row_userpass) {
				if ($row_userpass->autojob_status != 1 && $this->is_from_cron_job === true) {
					echo 'This acnum auto status is not active';
					die();
				} else {
					$userpass_id = $row_userpass->userpass_id;
					$usernamebank = $row_userpass->username;
					$passwordbank = $row_userpass->password;
					$bankname = $row_userpass->bankname;
					$userpass_status = $row_userpass->up_status;
				}
			} else {
				echo 'Invalid acnum';
				die();
			}
			
			if($usernamebank!=''&&$passwordbank!=''){
				$row_xfer = $this->transfer_channel_model->get_by_userpass_id($userpass_id);
				if ($row_xfer && $row_xfer->site_id) {
					$row_website = $this->website_model->get_by_site_id($row_xfer->site_id);
				} else {
					echo 'กรุณาตรวจสอบกลุ่มลูกค้า (transfer-channel)';
					die();	
				}
				$this->ch = curl_init();
				$this->cookie = PUBPATH."cookie/cookie-".$bank."-".$acnum."-".$usernamebank.".txt";
				
				$data_portfolio = $this->get_portfolio();
				if(empty($data_portfolio)){
					$this->login_bay($usernamebank,$passwordbank);
					$data_portfolio = $this->get_portfolio();
				}
								
				//+ MyAccount & Today's Statement	
				curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyAccount.aspx?token='.$data_portfolio['token'].'&ma='.$data_portfolio['ma'].''); 
				curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
				curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
				curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
				curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
				curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
				curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
				$html = curl_exec($this->ch);	
				//print_r($html); die();
							
				$dom = new DOMDocument(); // create DOM object
				@$dom->loadHTML($html);// load it's all html contents	
				$tables= $dom->getElementsByTagName('table');				
				if($tables->length==1){
					
					//+ Update Balance
					$sql = "UPDATE tb_userpass SET balance='".trim($data_portfolio['total'])."', available='".trim($data_portfolio['canuse'])."' WHERE userpass_id=".$userpass_id;
					$this->db->query($sql); 				
					//+ Update Balance
					$Available = preg_replace("/[^0-9\.]/", '', trim($data_portfolio['canuse']));
					
					$table = $tables->item(0);
					//$stringttable = $dom->saveHTML($table);  // save html table					
					//echo $stringttable; die();
					
					$trs = $table->getElementsByTagName('tr'); // get this row table
					$trs_row = $trs->length;
					$i=1;	
					if($trs_row>2){
						foreach($trs as $tr){
							if($i!=1&&$i!=$trs_row){								
								$tds = $tr->getElementsByTagName('td'); // get the columns in this row
								if($tds->length>1){
																	
									$st_datein = $this->set_baydate(trim($tds->item(0)->nodeValue));
									$st_datein_original = trim($tds->item(0)->nodeValue);
									$st_in = trim($tds->item(3)->nodeValue);
									$st_out = trim($tds->item(2)->nodeValue);
									$st_comment = trim($tds->item(1)->nodeValue).' / '.trim($tds->item(4)->nodeValue).' / '.trim($tds->item(5)->nodeValue);
									$comment = substr(preg_replace("/[^0-9]/", '', $tds->item(1)->nodeValue),-7); // เลขบัญชี 7 ตัวท้าย ที่โอนเข้ามา
									$comment = (strlen($comment)>=7)?substr($comment,-7):$st_comment;
									$st_from_bank = substr(preg_replace("/[^0-9]/", '', $tds->item(1)->nodeValue),0,2); // เลข 2 ตัวหน้า โอนมาจากธนาคารไหน
									$st_from_bank = (strlen($st_from_bank)==2)?conv_banknumtobank($st_from_bank):'';
									//+ สร้าง Where เพื่อเช็คข้อมูลในตาราง	
									$where_select = 'st_out= "'.$st_out.'" AND ';
									$where_select .= 'st_in= "'.$st_in.'" AND ';	
									$where_select .= 'st_datein= "'.$st_datein.'" AND ';
									$where_select .= 'st_bank="'.$bank.'" AND ';
									$where_select .= 'st_datein>="'.date("Y-m-d", strtotime("-3 days")).' 00:00:00" AND ';
									$where_select .= 'st_ac="'.$usernamebank.'" AND ';
									$where_select .= 'st_comment LIKE "%'.$comment.'%"';
																									
									//+ ค่าสำหรับนำไปบันทึก	
									$row_value = array(
										'st_out'=>$st_out,
										'st_in'=>$st_in,
										'st_balance'=>number_format($Available,2,'.',''),
										'st_datein'=>$st_datein,
										'st_datein_original'=>$st_datein_original,
										'st_comment'=>$st_comment,
										'st_bank'=>$bank,
										'st_ac'=>$usernamebank,
										'created'=>date('Y-m-d H:i:s'),
										'st_from_bank'=>$st_from_bank,
									);
									
									$sql = "SELECT * FROM tb_statement WHERE 1 AND ".$where_select."";
									$query = $this->db->query($sql);
									$count = $query->num_rows();
									if(!$count){
										$sql = "INSERT INTO tb_statement (".implode(", ", array_keys($row_value)).") VALUES ('".implode("', '", $row_value)."') ";
										$query = $this->db->query($sql);
										$st_id = $this->db->insert_id();
										$credit = preg_replace("/[^0-9\.]/", '', $tds->item(3)->nodeValue); // เครดิตที่ได้จาก รายการฝาก ธนาคาร
										
										if ($row_userpass->actype=='deposit') {
											if($credit!=''){
												//เริ่มทำการ เปิดใบงาน และ ฝากเงินเข้าระบบเกมส์
												$sql = 'SELECT uag.site_id, uag.dealer, us.user_id, uag.username, us.nickname, us.bankno, us.refer_id, 
up.userpass_id, up.username AS agusername, up.password AS agpassword,up.authcode,up.secretkey, uag.default_deposit FROM tb_users us LEFT JOIN tb_users_agent uag ON us.user_id=uag.user_id  LEFT JOIN tb_userpass up ON uag.userpass_id=up.userpass_id WHERE RIGHT(us.bankno, 7)="'.$comment.'" AND uag.uag_status = "ใช้" AND us.xfer_h_id_deposit="'.$row_xfer->xfer_h_id.'" AND us.site_id="'.$row_xfer->site_id.'" AND default_deposit="Y"';
												
												$query_user = $this->db->query($sql);
												if($query_user->num_rows()==1){
													$row_user = $query_user->row();
													$agusername = $row_user->agusername;
													$agpassword = $row_user->agpassword;
													$authcode = $row_user->authcode;
													$secretkey = $row_user->secretkey;
													$dealer = $row_user->dealer;
													$user_id = $row_user->user_id;
													$name = $row_user->nickname;
													$username = $row_user->username;
													$refer_id = $row_user->refer_id;
													$site_id = $row_user->site_id;
													$agent_id = $row_user->userpass_id;
													// เปิดใบงาน
													$data = array(
														'ws_code'=>'-',
														'site_id'=>$site_id,
														'ws_dealer'=>$dealer,
														'ws_type'=>'deposit',
														'ws_date'=>$st_datein,
														'user_id'=>$user_id,
														'ws_debank'=>$bank,
														'ws_debankac'=>$usernamebank,
														'ws_debankacnum'=>$acnum,
														'ws_debankname'=>$bankname,
														'ws_credit'=>$credit,
														'ws_total'=>$credit,
														'st_id'=>$st_id,
														// 'c_id'=> $this->is_from_cron_job ? NULL : $this->session->userdata('ac_id'),
														'c_status'=>1,
														'c_comment'=>'เปิดอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์',
														// 'b_id'=> $this->is_from_cron_job ? NULL : $this->session->userdata('ac_id'),
														'b_status'=>1,
														'b_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์',
														'b_date'=>date('Y-m-d H:i:s'),
														'created'=>date('Y-m-d H:i:s')
													);
													//$this->db->set('ws_code', 'CONCAT(DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y   \'),IFNULL((SELECT SUBSTR(`ws_code`, 14) FROM tb_worksheet AS `alias` WHERE SUBSTR(`ws_code`, 1, 10) = DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y\') ORDER BY created DESC LIMIT 1)+ 1,1) )', FALSE); //CAST(`ws_code` as SIGNED integer)
													$this->db->insert('tb_worksheet', $data);
													$ws_id = $this->db->insert_id();	
													if($this->db->affected_rows() > 0){
														/*อัพเดทสถานะ รายการเงินฝาก*/
														$data = array(						
															'st_status'=>1,
															'modified'=>date("Y-m-d H:i:s")
														);
														$this->db->update('tb_statement', $data, array('st_id'=>$st_id));
														/*อัพเดทสถานะ รายการเงินฝาก*/
														if ($userpass_status == 1) {
															// ทำการฝากเงินเข้าเกมส์
															$dataeditcredit = $this->edit_credit($agusername,$agpassword,$name,$username,$credit,$dealer,$site_id, $user_id,$authcode,$secretkey);
															// $dataeditcredit = array();
															// $dataeditcredit['success']=false;
														} else {
															$dataeditcredit = array();
															$dataeditcredit['success']=false;
														}
														// หากทำการฝากสำเร็จ
														if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
															/*อัพเดทใบงาน*/
															$data = array(						
																'de_id'=>$dataeditcredit['de_id'],
																// 'm_id'=> $this->is_from_cron_job ? NULL : $this->session->userdata('ac_id'),
																'm_status'=>1,
																'm_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์',
																'm_date'=>date('Y-m-d H:i:s'),
																'modified'=>date("Y-m-d H:i:s")
															);
															$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
															/*หาก creditbefore มากกว่า 10 ดึงโปรโมชั่นที่ลูกค้ารับ มาเช็ค ว่าทำการถอนไปหรือยัง*/
															$sql = 'SELECT pr_user_id,withdraw_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$dealer.'" ORDER BY created DESC limit 1';
															$query_promotion_user = $this->db->query($sql);
															if($query_promotion_user->num_rows()>0){
																$row_promotion_user = $query_promotion_user->row();
																if($row_promotion_user->withdraw_pro=='n'){
																	if($dataeditcredit['creditbefore']>10){	
																		//+ เพิ่มจำนวนเครดิตทำเทริน
																		$sql = "UPDATE tb_promotion_user SET credit_pro = credit_pro+".$credit." WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
																		$this->db->query($sql);
																		//+ สิ้นสุดเพิ่มจำนวนเครดิตทำเทริน
																	}else{
																		//+ ทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
																		$sql = "UPDATE tb_promotion_user SET withdraw_pro = 'y', note='ปรับ withdraw_pro = y เนื่องจากมียอดก่อนฝาก น้อยกว่า 10',modified='".date("Y-m-d H:i:s")."' WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
																		$this->db->query($sql);
																		//+ สิ้นสุดทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
																	} // End if($dataeditcredit['creditbefore']>10){
																} // End if($row_promotion_user->withdraw_pro=='n'){
															} // End if($query_promotion_user->num_rows()>0){
															if ($row_website->site_line_callback_url) {
																// เช็ค gid จาก username
																$chgid = curl_init();
																curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
																curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
																curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
																$gid = curl_exec($chgid);
																curl_close($chgid);
																// เรียก Line
																$chline = curl_init();
																curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=deposit&username='.$username.'&credit='.$credit.'');
																curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
																curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
																$data = curl_exec($chline);	
																curl_close($chline);
																// เรียก Line
															}
														}else{
															$noti_msg = "มีใบงานที่รอตรวจสอบ:: เว็บ:".$row_website->site_name.". เกม:$dealer. เอเยนต์:$agusername. ยูส:$username. ยอด:$credit บาท.";
															$noti_msg = rawurlencode($noti_msg);
															// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
															$chline = curl_init();
															curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg));
															curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
															curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
															$data = curl_exec($chline);	
															curl_close($chline);
															// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ	
														} // End if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
													} // End if($this->db->affected_rows() > 0){										
												}else{
													$noti_msg = "มียอดเงินเข้าที่ไม่ได้เปิดใบงาน:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
													$noti_msg = rawurlencode($noti_msg);
													// เรียก Line เมื่อหาแบงค์ไม่เจอ หรือ เจอมากกว่า 1
													$chline = curl_init();
													curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
													curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
													curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
													$data = curl_exec($chline);	
													curl_close($chline);
													// เรียก Line เมื่อหาแบงค์ไม่เจอ หรือ เจอมากกว่า 1											
												} // End if($query_user->num_rows()==1){
												//เริ่มทำการ เปิดใบงาน และ ฝากเงินเข้าระบบเกมส์		
											} // End if($credit!=''){												
										}
									}// End if(!$count){	
								} // End if($tds->length>1){
							} // End if($i!=1&&$i!=$trs->length){
							$i++;
						} // End foreach($trs as $tr){
					} // End if($trs_row>2){					
				
					//echo 'เลขบัญชี : '.$data_portfolio['accnumber'];
					//echo '<hr>';
					//echo 'ยอดเงินใช้ได้ : '.$data_portfolio['canuse'];
					//echo '<hr>';
					//echo 'ทั้งหมด : '.$data_portfolio['total'];
					//echo '<hr>';
					//echo $stringttable;
					//die();
				}else{
					echo 'ไม่มีรายการ'; die();
				} // Endif($tables->length==1){
							
				if($query){
					echo 'ดึงข้อมูลสำเร็จ';
				}else{
					echo 'ดึงไม่สำเร็จ';
				}
			}else{
				echo 'เช็ค Username / Password Bank';
			} // End if($username!=''&&$password!=''){
		} // End if($bank && $bank!=''){
	}
	
	private function edit_credit($agent_username, $agent_password, $nickname, $username, $credit, $dealer, $site_id, $user_id, $authcode, $secretkey) {
		// return $data = array('success' => false, 'msg' => 'ปิดออโต้ไว้ก่อน');
		if ($agent_username && $agent_password && $username && $credit && $dealer && $site_id) {
			$this->load->library('interface_gateway');
			$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password, $authcode, $secretkey);
			// Check if user receive promotion then need to refresh credit (Fix Ufa delay credit)
			$sql = 'SELECT pr_user_id,withdraw_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$dealer.'" ORDER BY created DESC limit 1';
			$query_check_promotion_user = $this->db->query($sql);
			if($query_check_promotion_user->num_rows()>0){
				$row_check_promotion_user = $query_check_promotion_user->row();
				if($row_check_promotion_user->withdraw_pro=='n'){
					$data_return = $this->interface_gateway->refresh_player_credit($username);
					if((isset($data_return)&&$data_return['status']===false)){
						return $data = array('success' => false, 'msg' => 'ไม่สามารถดึงข้อมูลเครดิตล่าสุดได้');
					}
				}
			}
			// Check if user receive promotion then need to refresh credit (Fix Ufa delay credit)
			$data_return = $this->interface_gateway->edit_credit($username, 1, $credit);
		} else {
			return $data = array('success' => false, 'msg' => 'โปรดตรวจสอบข้อมูล');
		}
		if ($data_return["status"]===true) {
			$data = array(
				'site_id' => $site_id,
				'dealer' => $dealer,
				'name' => $nickname,
				'username' => $username,
				'agent' => $data_return["agent_name"],
				'creditagentbefore' => $data_return["agent_credit_before"],
				'creditbefore' => $data_return["credit_before"],
				'credit' => $credit,
				// 'add_by_id'=> $this->is_from_cron_job ? '' : $this->session->userdata('ac_id'),
				'add_by_name'=> 'เพิ่มผ่านการดึงอัตโนมัติ',
				'created' => date('Y-m-d H:i:s'),
			);
			$this->db->insert('tb_deposit', $data);
			$de_id = $this->db->insert_id();
			if($this->db->affected_rows() > 0){
				if ($this->is_from_cron_job === false) { // If not call from cron job then insert to tb_history log
					//+ History Log 
					$data = array('dealer' => $dealer, 'username' => $username, 'credit' => $credit);
					$action = 'เติม '.$dealer;
					$this->history->save(array('action'=>$action,'user_id'=>NULL,'detail'=>json_encode($data)));
					//+
				}
			}
			$data = array('success'=>$data_return["status"],'msg'=>'Success !','de_id'=>$de_id,'creditbefore'=>$data_return["credit_before"]);
			return $data;
		}
		return $data = array('success' => false, 'msg' => 'เติมเครดิตไม่สำเร็จ');
	}
		
	function __destruct(){
		if($this->ch) {
			curl_close($this->ch);
		}
		$this->db->close();
	}
		
}
