<?php defined('BASEPATH') OR exit('No direct script access allowed');

set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Sms_scb_all extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('bypasscaptcha'));
		$this->load->model('website_model');
		$this->load->model('userpass_model');
		$this->load->model('transfer_channel_model');
	}
	
	// For use this function please specify bank acnum : https://domain.com/admin/sms-scb?acnum=ac1
	public function index(){
		$acnum = $this->input->get('acnum');
		$content = file_get_contents('php://input');
		$data = json_decode($content);
		//Validate parsed JSON data
		//arrange to new string
		
		//ถ้ามาจาก kbank
		//$bankstring = "23/05@05:16 100.00 จากKBNK/x188896เข้าx547368 ใช้ได้51,032.24บ";
		//$bankstring = "25/05@16:07 1.00 จากKBNK/x345039เข้าx146332 ใช้ได้172.01บ";
		//scb
		//$bankstring = "23/05@15:02 11.00 โอนจากHAEMANN SINKIเข้าx547368 ใช้ได้53,830.84บ - SMS from 027777777.";
		//ktb
		//$bankstring = "23/05@15:05 1,112.00 จากKTBA/x276920เข้าx547368 ใช้ได้53,842.84บ - SMS from 027777777.";
		//$bankstring = "1,000.00 บาท โอนไปบช นาย สุพจน์ ชูศรี, หากสงสัยโทร. 027776780 - SMS from 027777777 Scb.";
		
		$bankstring = $data->sms;
		$fromno = $data->phoneNumber;
		if($fromno == '027777777'){
										
			echo "bankstring=" .  $bankstring . "<br>";
			$newsms = explode(" ", $bankstring,3);
			$amount = $newsms[1];
			$datein_original = $newsms[0];
			$datesms = explode('@',$datein_original);
			$datesms2 = explode('/',$datesms[0]);
			$datein = date('Y').'-'.$datesms2[1].'-'.$datesms2[0].' '.$datesms[1].':00';
			
			echo "amount=" .  $newsms[1] . "<br>";
			echo "newsms[2]=" . $newsms[2] . "<br>";
			
			$detail = explode("เข้าx",$newsms[2]);
			
			
			echo "toaccount=" .  $detail[1] . "<br>";
			echo "detail[0]=" .  $detail[0] . "<br>";
			echo "detail[1]=" .  $detail[1] . "<br>";
			//check ถ้ามาจาก scb ให้เก็บชื่อคน
			if(strstr($bankstring, "โอนจาก")){
				$frombank = "SCB";
				$fromaccount = str_replace("โอนจาก","", $detail[0]);//โอนจากHAEMANN SINKI
			}else{
				$from = explode("/x",$detail[0]); //จากKBNK/x188896
				$frombank = str_replace("จาก","", $from[0]);//จากKBNK
				$fromaccount = $from[1]; //188896
			}
			$detail = explode(" ",$detail[1]); //547368
			$toaccount = $detail[0];
			echo "from[0]=" .  $from[0] . "<br>";
			echo "from[1]=" .  $from[1] . "<br><br><br><br><br>";
			
			
			echo 'datein='.$datein."<br>";
			echo "amount=" .  $amount . "<br>";
			echo "fromaccount=" .  $fromaccount . "<br>";
			echo "toaccount=" .  $toaccount . "<br>";
			echo "frombank=" .  $frombank . "<br>";
			$total = str_replace("ใช้ได้","", $detail[1]); //51,032.24บ
			$total = str_replace(",","", $total); //51032.24บ
			$total = str_replace("บ","", $total); //51032.24
			echo "total=" .  $total . "<br>"; 
			
			// เพิ่มลงตาราง tb_sms
			$sqlsms = "INSERT INTO tb_sms (sms_no, sms_from,sms_fromaccount,sms_toaccount, sms_credit,sms_debit,sms_msg,sms_total, sms_time,sms_create,sms_flag) VALUES ('$fromno', '$frombank', '$fromaccount','$toaccount','0','".str_replace(',','',$amount)."', '".htmlspecialchars($bankstring)."','$total', '$datein', '".date('Y-m-d H:i:s')."','1')";
			$query_sms = $this->db->query($sqlsms);
			//die();
			
			if(strstr($bankstring, "OTP")){
				$newsms0 = explode("<OTP ", $bankstring);
				if(count($newsms0)==2){
					$newsms1 = explode("<Ref. ", $newsms0[1]);
					print_r($newsms0);
					echo '<hr>';
					print_r($newsms1);
					echo '<hr>';
					$otp = substr(trim($newsms1[0]),0,-1);
					echo $otp;
					echo '<hr>';
					$ref = substr($newsms1[1],0,4);
					echo $ref;
					
					$this->db->select('smsotp_id');
					$this->db->where('sms_ref', $ref);
					$this->db->where('sms_otp', $otp);
					$rs_sms = $this->db->get('tb_smsotp');
					if($rs_sms->num_rows()==0){						
						// เพิ่มลงตาราง tb_smsotp
						$sqlsms = "INSERT INTO tb_smsotp (sms_ref, sms_otp,sms_msg,sms_created) VALUES ('$ref', '$otp', '".htmlspecialchars($bankstring)."', '".date('Y-m-d H:i:s')."')";
						$query_sms = $this->db->query($sqlsms);
						//die();
					}
				} // End if(count($newsms0)==2){
				die();
			} // End if(strstr($bankstring, "OTP")){
			if(!strstr($bankstring, "โอนไป")&&!strstr($bankstring, "ถอน/โอนเงิน")&&!strstr($bankstring, "เข้าบ/ช")){
			
				$bank = 'scb';
				$row_userpass = $this->userpass_model->get_by_bankac($bank,$acnum,$toaccount);
				$userpass_id = $row_userpass->userpass_id;
				$usernamebank = $row_userpass->username;
				$passwordbank = $row_userpass->password;
				$bankname = $row_userpass->bankname;
				$userpass_status = $row_userpass->up_status;
				if(!$row_userpass){
					echo 'กรุณาตรวจสอบกลุ่มลูกค้า (userpass-bank)';
					die();
				}
				
				$row_xfer = $this->transfer_channel_model->get_by_userpass_id($userpass_id);
				if ($row_xfer && $row_xfer->site_id) {
					$row_website = $this->website_model->get_by_site_id($row_xfer->site_id);
				} else {
					echo 'กรุณาตรวจสอบกลุ่มลูกค้า (transfer-channel)';
					die();	
				}
				if($frombank!='SCB'&&$fromaccount!=''){
					/* ดึงรายการ ยอดฝากจาก แบงค์ */
					$this->db->select('*');
					$this->db->where('st_datein', $datein);
					$this->db->where('st_in', '+'.$amount);
					$this->db->where('st_ac', $usernamebank);
					$this->db->where('st_bank', $bank);
					$this->db->like('st_comment', $fromaccount, 'both'); 
					$rs_statement = $this->db->get('tb_statement');
					if($rs_statement->num_rows()==0){				
						
						$credit = str_replace(',','',$amount);
						//+ บันทึก Statement
						$data = array(
							'st_out'=>' ',
							'st_in'=>'+'.$amount,
							'st_balance'=>$total,
							'st_datein'=>$datein,
							'st_datein_original'=>$datein_original,
							'st_comment'=>$bankstring,
							'st_bank'=>$bank,
							'st_ac'=>$usernamebank,
							'created'=>date('Y-m-d H:i:s'),
							'st_from_bank'=>$frombank,
							'st_acc'=>$fromaccount,
						);
						$this->db->insert('tb_statement', $data); die();
						$st_id = $this->db->insert_id();
						//+ บันทึก Statement
						$sql = 'SELECT uag.site_id, uag.dealer, us.user_id, uag.username, us.nickname, us.bankno, us.phone, us.refer_id, 
up.userpass_id, up.username AS agusername, up.password AS agpassword,up.authcode,up.secretkey,us.newmember,uag.default_deposit FROM tb_users us LEFT JOIN tb_users_agent uag ON us.user_id=uag.user_id  LEFT JOIN tb_userpass up ON uag.userpass_id=up.userpass_id WHERE RIGHT(us.bankno, 6)="'.$fromaccount.'" AND uag.uag_status = "ใช้" AND bank!="SCB" AND us.xfer_h_id_deposit="'.$row_xfer->xfer_h_id.'" AND uag.site_id="'.$row_xfer->site_id.'" AND default_deposit="Y"';
						// $sql = 'SELECT user_id,dealer,tb_users.username,nickname,bankno,tb_userpass.username AS agusername,tb_userpass.password AS agpassword ,tb_userpass.bankname,tb_userpass.agid,refer_id,tb_users.site_id 
						// 		FROM tb_users LEFT JOIN tb_userpass ON tb_users.userpass_id=tb_userpass.userpass_id 
						// 		WHERE RIGHT(bankno, 6)="'.$fromaccount.'" AND status = "ใช้"  AND bank!="SCB" AND xfer_h_id_deposit="'.$row_xfer->xfer_h_id.'" AND tb_users.site_id="'.$row_xfer->site_id.'"';
						$query_user = $this->db->query($sql);
						if($query_user->num_rows()==1){
							
							$row_user = $query_user->row();
							$agusername = $row_user->agusername;
							$agpassword = $row_user->agpassword;
							$authcode = $row_user->authcode;
							$secretkey = $row_user->secretkey;
							$dealer = $row_user->dealer;
							$user_id = $row_user->user_id;					
							$name = $row_user->nickname;
							$username = $row_user->username;
							$refer_id = $row_user->refer_id;
							$newmember = $row_user->newmember;
							$site_id = $row_user->site_id;
							$agent_id = $row_user->userpass_id;
							$phone = $row_user->phone;
							
							// เปิดใบงาน
							$data = array(
								'ws_code'=>'-',
								'site_id'=>$site_id,
								'ws_dealer'=>$dealer,
								'ws_type'=>'deposit',
								'ws_date'=>$datein,
								'user_id'=>$user_id,
								'ws_debank'=>$bank,
								'ws_debankac'=>$usernamebank,
								'ws_debankacnum'=>$acnum,
								'ws_debankname'=>$bankname,
								'ws_credit'=>$credit,
								'ws_total'=>$credit,
								'st_id'=>$st_id,
								'c_status'=>1,
								'c_comment'=>'เปิดอัตโนมัติ จาก SMS',
								'b_status'=>1,
								'b_comment'=>'ตรวจอัตโนมัติ จาก SMS',
								'b_date'=>date('Y-m-d H:i:s'),
								'created'=>date('Y-m-d H:i:s')
							);
							//$this->db->set('ws_code', 'CONCAT(DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y   \'),IFNULL((SELECT SUBSTR(`ws_code`, 14) FROM tb_worksheet AS `alias` WHERE SUBSTR(`ws_code`, 1, 10) = DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y\') ORDER BY created DESC LIMIT 1)+ 1,1) )', FALSE); //CAST(`ws_code` as SIGNED integer)
							$this->db->insert('tb_worksheet', $data);
							$ws_id = $this->db->insert_id();	
							if($this->db->affected_rows() > 0){
								/*อัพเดทสถานะ รายการเงินฝาก*/
								$data = array(						
									'st_status'=>1,
									'modified'=>date("Y-m-d H:i:s")
								);
								$this->db->update('tb_statement', $data, array('st_id'=>$st_id));
								/*อัพเดทสถานะ รายการเงินฝาก*/
								if($newmember=='Y'){
									/*อัพเดทใบงาน*/
									$data = array(
										'b_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์ สมาชิกใหม่ ฝากครั้งแรก',
										'modified'=>date("Y-m-d H:i:s")
									);
									$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
									
									$noti_msg = "มีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
									$noti_msg = rawurlencode($noti_msg);
									// เรียก Line เมื่อมีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก
									$chline = curl_init();
									curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
									curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
									curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
									$data = curl_exec($chline);	
									curl_close($chline);
									// เรียก Line เมื่อมีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก
								}else{	
									// เช็คยอดฝากเท่ากันในเวลา 5 นาที
									$sqlwsfiveminute = 'SELECT ws_id FROM tb_worksheet WHERE user_id='.$user_id.' AND ws_id!='.$ws_id.' AND ws_type = "deposit" AND ws_dealer = "'.$dealer.'" AND ws_date BETWEEN "'.date('Y-m-d H:i:s',strtotime( '-2 minute' , strtotime($datein))).'" AND "'.date('Y-m-d H:i:s',strtotime( '+3 minute' , strtotime($datein))).'" AND (ws_credit="'.$credit.'"OR ws_credit="'.number_format($credit,2,'.','').'")';
									$query_wsfiveminute = $this->db->query($sqlwsfiveminute);
									if($query_wsfiveminute->num_rows()==0){
										
										if ($userpass_status == 1) {
											// ทำการฝากเงินเข้าเกมส์
											$dataeditcredit = $this->edit_credit($agusername,$agpassword,$name,$username,$credit,$dealer,$site_id,$user_id,$authcode,$secretkey);
										} else {
											$dataeditcredit = array();
											$dataeditcredit['success']=false;
										}
										// หากทำการฝากสำเร็จ
										if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
											/*อัพเดทใบงาน*/
											$data = array(						
												'de_id'=>$dataeditcredit['de_id'],
												'm_status'=>1,
												'm_comment'=>'ตรวจอัตโนมัติ จาก SMS',
												'm_date'=>date('Y-m-d H:i:s'),
												'modified'=>date("Y-m-d H:i:s")
											);
											$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
											/*หาก creditbefore มากกว่า 10 ดึงโปรโมชั่นที่ลูกค้ารับ มาเช็ค ว่าทำการถอนไปหรือยัง*/
											$sql = 'SELECT pr_user_id,withdraw_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$dealer.'" ORDER BY created DESC limit 1';
											$query_promotion_user = $this->db->query($sql);
											if($query_promotion_user->num_rows()>0){
												$row_promotion_user = $query_promotion_user->row();
												if($row_promotion_user->withdraw_pro=='n'){
													if($dataeditcredit['creditbefore']>10){	
														//+ เพิ่มจำนวนเครดิตทำเทริน
														$sql = "UPDATE tb_promotion_user SET credit_pro = credit_pro+".$credit." WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
														$this->db->query($sql);
														//+ สิ้นสุดเพิ่มจำนวนเครดิตทำเทริน
													}else{
														//+ ทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
														$sql = "UPDATE tb_promotion_user SET withdraw_pro = 'y', note='ปรับ withdraw_pro = y เนื่องจากมียอดก่อนฝาก น้อยกว่า 10',modified='".date("Y-m-d H:i:s")."' WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
														$this->db->query($sql);
														//+ สิ้นสุดทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
													} // End if($dataeditcredit['creditbefore']>10){
												} // End if($row_promotion_user->withdraw_pro=='n'){
											} // End if($query_promotion_user->num_rows()>0){
												
											if ($row_website->site_line_callback_url) {
												// เช็ค gid จาก username
												$chgid = curl_init();
												curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
												curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
												curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
												$gid = curl_exec($chgid);
												curl_close($chgid);
												// เรียก Line
												$chline = curl_init();
												curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=deposit&username='.$username.'&credit='.$credit.'&phone='.$phone);
												curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
												curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
												$data = curl_exec($chline);	
												curl_close($chline);
												// เรียก Line
											}
										
										}else{
											$noti_msg = "มีใบงานที่รอตรวจสอบ:: เว็บ:".$row_website->site_name.". เกม:$dealer. เอเยนต์:$agusername. ยูส:$username. ยอด:$credit บาท.";
											$noti_msg = rawurlencode($noti_msg);
											// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
											$chline = curl_init();
											curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg));
											curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
											curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
											$data = curl_exec($chline);	
											curl_close($chline);
											// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
										}// End if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
									
									}else{
										/*อัพเดทใบงาน*/
										$data = array(
											'b_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์ ฝากยอดเดียวกันในเวลา 5 นาที',
											'modified'=>date("Y-m-d H:i:s")
										);
										$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
										$noti_msg = "มีใบงานยอดเงินเดียวกันในเวลา 5 นาที:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
										$noti_msg = rawurlencode($noti_msg);
										// เรียก Line เมื่อมีใบงานยอดเงินเดียวกันในเวลา 5 นาที
										$chline = curl_init();
										curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
										curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
										curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
										$data = curl_exec($chline);	
										curl_close($chline);
										// เรียก Line เมื่อมีใบงานยอดเงินเดียวกันในเวลา 5 นาที
									}
								} // End if($query_wsfiveminute->num_rows()==0){
							} // End if($this->db->affected_rows() > 0){
							
						}else {
							$noti_msg = "มียอดเงินเข้าที่ไม่ได้เปิดใบงาน:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
							$noti_msg = rawurlencode($noti_msg);
							// เรียก Line เมื่อหาแบงค์ไม่เจอ หรือ เจอมากกว่า 1
							$chline = curl_init();
							curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
							curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
							$data = curl_exec($chline);	
							curl_close($chline);
							// เรียก Line เมื่อหาแบงค์ไม่เจอ หรือ เจอมากกว่า 1
						}// End if($query_user->num_rows()==1){
						
					} // End if($rs_statement->num_rows()==0){
						
				}else{
									
					/* ดึงรายการ ยอดฝากจาก แบงค์ เพื่อมาเช็คนำไป update ชื่อภาษาอังกฤษ ตาราง tb_users*/
					$this->db->select('*');
					$this->db->where('st_datein', $datein);
					$this->db->where('st_in', '+'.$amount);
					$this->db->where('st_ac', '+'.$usernamebank);
					$rs_statement = $this->db->get('tb_statement');
					
					if($rs_statement->num_rows()==1){
						$row_statement = $rs_statement->row();
						$st_comment = $row_statement->st_comment;
						$st_comment = explode('/', $row_statement->st_comment);
						$cardnumber = preg_replace("/[^0-9]/", '', $st_comment[2]); // ตัวเลขบัตรปชชที่โอนมา
						$cardnumber = (strlen($cardnumber)>4)?substr($cardnumber,-4):$cardnumber;
						$sql = 'SELECT user_id FROM tb_users LEFT JOIN tb_users_agent uag ON us.user_id=uag.user_id WHERE (accountname_en IS NULL OR accountname_en ="") AND bank="SCB" AND RIGHT(bankno, 4)="'.$cardnumber.'" AND xfer_h_id_deposit="'.$row_xfer->xfer_h_id.'" AND uag.site_id="'.$row_xfer->site_id.'"';
						$rs_users = $this->db->query($sql);
						if($rs_users->num_rows()==1){
							$row_user = $rs_users->row();
							/*อัพเดทชื่อภาษาอังกฤษ ตาราง tb_users*/
							$data = array(						
								'accountname_en'=>$fromaccount
							);
							$this->db->update('tb_users', $data, array('user_id'=>$row_user->user_id));
						}				
					} // End if($rs_statement->num_rows()==1){
					/* ดึงรายการ ยอดฝากจาก แบงค์ เพื่อมาเช็คนำไป update ชื่อภาษาอังกฤษ ตาราง tb_users*/
										
					if($fromaccount!=''){
						/* ดึงรายการ tb_user ด้วย ชื่อภาษาอังกฤษ*/
						$sql = 'SELECT uag.site_id, uag.dealer, us.user_id, uag.username, us.nickname, us.bankno,us.phone, us.refer_id, 
up.userpass_id, up.username AS agusername, up.password AS agpassword,up.authcode,up.secretkey,us.newmember,uag.default_deposit FROM tb_users us LEFT JOIN tb_users_agent uag ON us.user_id=uag.user_id  LEFT JOIN tb_userpass up ON uag.userpass_id=up.userpass_id WHERE accountname_en="'.$fromaccount.'" AND status = "ใช้" AND bank="SCB" AND xfer_h_id_deposit="'.$row_xfer->xfer_h_id.'" AND uag.site_id="'.$row_xfer->site_id.'" AND default_deposit="Y"';
						$query_user = $this->db->query($sql);
						if($query_user->num_rows()==1){
							$row_user = $query_user->row();
							$fourdigitlast = substr($row_user->bankno,-4); // เลขบัญชี 4 ตัวท้าย
							
							/* ดึงรายการ ยอดฝากจาก แบงค์ เพื่อเช็คแล้วนำไปเติมบนเกมส์*/
							$this->db->select('*');
							$this->db->where('st_datein', $datein);
							$this->db->where('st_in', '+'.$amount);
							$this->db->where('st_ac', $usernamebank);
							$this->db->where('st_bank', $bank);
							$this->db->like('st_comment', $fourdigitlast, 'both'); 
							$rs_statement = $this->db->get('tb_statement');
							if($rs_statement->num_rows()==0){
								
								$credit = str_replace(',','',$amount);
								//+ บันทึก Statement
								$data = array(
									'st_out'=>' ',
									'st_in'=>'+'.$amount,
									'st_datein'=>$datein,
									'st_datein_original'=>$datein_original,
									'st_comment'=>$bankstring.' / '.$fourdigitlast,
									'st_bank'=>$bank,
									'st_ac'=>$usernamebank,
									'created'=>date('Y-m-d H:i:s'),
								);
								$this->db->insert('tb_statement', $data); die();
								$st_id = $this->db->insert_id();
								//+ บันทึก Statement
								
								$agusername = $row_user->agusername;
								$agpassword = $row_user->agpassword;
								$authcode = $row_user->authcode;
								$secretkey = $row_user->secretkey;
								$dealer = $row_user->dealer;
								$user_id = $row_user->user_id;					
								$name = $row_user->nickname;
								$username = $row_user->username;
								$refer_id = $row_user->refer_id;
								$site_id = $row_user->site_id;
								$phone = $row_user->phone;
								
								// เปิดใบงาน
								$data = array(
									'ws_code'=>'-',
									'site_id'=>$site_id,
									'ws_dealer'=>$dealer,
									'ws_type'=>'deposit',
									'ws_date'=>$datein,
									'user_id'=>$user_id,
									'ws_debank'=>$bank,
									'ws_debankac'=>$usernamebank,
									'ws_debankacnum'=>$acnum,
									'ws_debankname'=>$bankname,
									'ws_credit'=>$credit,
									'ws_total'=>$credit,
									'st_id'=>$st_id,
									'c_status'=>1,
									'b_comment'=>'เปิดอัตโนมัติ จาก SMS',
									'b_status'=>1,
									'b_comment'=>'ตรวจอัตโนมัติ จาก SMS',
									'b_date'=>date('Y-m-d H:i:s'),
									'created'=>date('Y-m-d H:i:s')
								);
								//$this->db->set('ws_code', 'CONCAT(DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y   \'),IFNULL((SELECT SUBSTR(`ws_code`, 14) FROM tb_worksheet AS `alias` WHERE SUBSTR(`ws_code`, 1, 10) = DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y\') ORDER BY created DESC LIMIT 1)+ 1,1) )', FALSE); //CAST(`ws_code` as SIGNED integer)
								$this->db->insert('tb_worksheet', $data);
								$ws_id = $this->db->insert_id();	
								if($this->db->affected_rows() > 0){
									/*อัพเดทสถานะ รายการเงินฝาก*/
									$data = array(						
										'st_status'=>1,
										'modified'=>date("Y-m-d H:i:s")
									);
									$this->db->update('tb_statement', $data, array('st_id'=>$st_id));
									/*อัพเดทสถานะ รายการเงินฝาก*/
									
									if ($userpass_status == 1) {
										// ทำการฝากเงินเข้าเกมส์
										$dataeditcredit = $this->edit_credit($agusername,$agpassword,$name,$username,$credit,$dealer,$site_id,$user_id,$authcode,$secretkey);
									} else {
										$dataeditcredit = array();
										$dataeditcredit['success']=false;
									}
									// หากทำการฝากสำเร็จ
									if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
										/*อัพเดทใบงาน*/
										$data = array(						
											'de_id'=>$dataeditcredit['de_id'],
											'm_status'=>1,
											'm_comment'=>'ตรวจอัตโนมัติ จาก SMS',
											'm_date'=>date('Y-m-d H:i:s'),
											'modified'=>date("Y-m-d H:i:s")
										);
										$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
										/*หาก creditbefore มากกว่า 10 ดึงโปรโมชั่นที่ลูกค้ารับ มาเช็ค ว่าทำการถอนไปหรือยัง*/
										$sql = 'SELECT pr_user_id,withdraw_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$dealer.'" ORDER BY created DESC limit 1';
										$query_promotion_user = $this->db->query($sql);
										if($query_promotion_user->num_rows()>0){
											$row_promotion_user = $query_promotion_user->row();
											if($row_promotion_user->withdraw_pro=='n'){
												if($dataeditcredit['creditbefore']>10){	
													//+ เพิ่มจำนวนเครดิตทำเทริน
													$sql = "UPDATE tb_promotion_user SET credit_pro = credit_pro+".$credit." WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
													$this->db->query($sql);
													//+ สิ้นสุดเพิ่มจำนวนเครดิตทำเทริน
												}else{
													//+ ทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
													$sql = "UPDATE tb_promotion_user SET withdraw_pro = 'y', note='ปรับ withdraw_pro = y เนื่องจากมียอดก่อนฝาก น้อยกว่า 10',modified='".date("Y-m-d H:i:s")."' WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
													$this->db->query($sql);
													//+ สิ้นสุดทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
												} // End if($dataeditcredit['creditbefore']>10){
											} // End if($row_promotion_user->withdraw_pro=='n'){
										} // End if($query_promotion_user->num_rows()>0){
										
										if ($row_website->site_line_callback_url) {
											// เช็ค gid จาก username
											$chgid = curl_init();
											curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
											curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
											curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
											$gid = curl_exec($chgid);
											curl_close($chgid);
											// เรียก Line
											$chline = curl_init();
											curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=deposit&username='.$username.'&credit='.$credit.'&phone='.$phone);
											curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
											curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
											$data = curl_exec($chline);	
											curl_close($chline);
											// เรียก Line
										}
														
									}else{
										$noti_msg = "มีใบงานที่รอตรวจสอบ:: เว็บ:".$row_website->site_name.". เกม:$dealer. เอเยนต์:$agusername. ยูส:$username. ยอด:$credit บาท.";
										$noti_msg = rawurlencode($noti_msg);
										// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
										$chline = curl_init();
										curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg));
										curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
										curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
										$data = curl_exec($chline);	
										curl_close($chline);
										// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
									}// End if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
								} // End if($this->db->affected_rows() > 0){
								
							} // End if($rs_statement->num_rows()==0){
							/* ดึงรายการ ยอดฝากจาก แบงค์ เพื่อเช็คแล้วนำไปเติมบนเกมส์*/
							
						} // End if($query_user->num_rows()==1){
						/* ดึงรายการ tb_user ด้วย ชื่อภาษาอังกฤษ*/
					} // End if($fromaccount!=''){
						
				} // End if($frombank!='SCB'){
			
			} // End if(!strstr($bankstring, "โอนไป")){
		
		}else{
			echo 'Not from SKYBETSCB';
		} // End if($fromno == '027777777'){				
	}
	// Every dealer
	private function edit_credit($agent_username, $agent_password, $nickname, $username, $credit, $dealer, $site_id, $user_id, $authcode, $secretkey) {
		// return $data = array('success' => false, 'msg' => 'ปิดออโต้ไว้ก่อน');
		if ($agent_username && $agent_password && $username && $credit && $dealer && $site_id) {
			$this->load->library('interface_gateway');
			$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password, $authcode, $secretkey);
			$data_return = $this->interface_gateway->edit_credit($username, 1, $credit);
		} else {
			return $data = array('success' => false, 'msg' => 'โปรดตรวจสอบข้อมูล');
		}
		if ($data_return["status"]===true) {
			$data = array(
				'site_id' => $site_id,
				'dealer' => $dealer,
				'name' => $nickname,
				'username' => $username,
				'agent' => $data_return["agent_name"],
				'creditagentbefore' => $data_return["agent_credit_before"],
				'creditbefore' => $data_return["credit_before"],
				'credit' => $credit,
				'add_by_name'=> 'เพิ่มผ่าน SMS',
				'created' => date('Y-m-d H:i:s'),
			);
				
			$this->db->insert('tb_deposit', $data);
			$de_id = $this->db->insert_id();	
			$data = array('success'=>$data_return["status"],'msg'=>'Success !','de_id'=>$de_id,'creditbefore'=>$data_return["credit_before"]);
			return $data;
		}
		return $data = array('success' => false, 'msg' => 'เติมเครดิตไม่สำเร็จ');
	}
	
	function __destruct(){
		
	}
		
}
