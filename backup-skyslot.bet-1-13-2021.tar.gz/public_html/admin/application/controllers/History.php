<?php defined('BASEPATH') OR exit('No direct script access allowed');

class History extends CI_Controller {
		
	public function __construct(){
		parent::__construct();
		$this->load->library('auth');
		$auth = new auth();
		$auth->isnot_login();
		$auth->isnot_admin();
		$this->titlecomponent->add('ประวัติการใช้งาน');
	}	
	
	public function index(){		
		$data['Content'] = $this->load->view('history/index', null, true);
		$this->load->view('template/temp_main', $data);
	}
	
	public function list_table(){
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'name',2=>'ip_address',3=>'action',4=>'detail',5=>'tb_history.created');
		 
		// DB table to use
		$sTable = "tb_history";
				 
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);
		
		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1'){
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}
		 
		// Ordering
		if(isset($iSortCol_0)){
			for($i=0; $i<intval($iSortingCols); $i++){
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);
		 
				if($bSortable == 'true'){					
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}
		 
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++)
			{
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);
				if(isset($bSearchable) && $bSearchable == 'true'){
					if($aColumns[$i]=='created'){
						//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';						
						if(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch)){
							$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
						}						
					}else{
						//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
						$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}
				}				
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
		
		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_account a1', 'a1.ac_id=tb_history.ac_id', 'LEFT');
		$rResult = $this->db->get($sTable);
		
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;
		
		// Total data set length
		$this->db->join('tb_account a1', 'a1.ac_id=tb_history.ac_id', 'LEFT');
		$iTotal = $this->db->count_all_results($sTable);
		
		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);
		$text = '';  
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array($iDisplayStart);
			$row[] = $aRow->name;
			$row[] = $aRow->ip_address;
			$row[] = $aRow->action;	
			$detail = json_decode($aRow->detail,true);
			$text = (isset($detail['dealer']))?'Dealer : '.$detail['dealer']:'';			
			$text .= (isset($detail['username']))?' | Username : '.$detail['username']:'';
			$text .= (isset($detail['credit']))?' | Credit : '.$detail['credit']:'';
			$text .= (isset($detail['ws_code']))?' | เลขที่บิล : '.$detail['ws_code']:'';
			$text .= (isset($detail['ws_wiimg']))?' | รูป : '.$detail['ws_wiimg']:'';			
			$row[] = $text;
			$row[] = $aRow->created;			
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}
	
}