<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Userpass_agent extends CI_Controller {

	public function __construct() {

		parent::__construct();

		$this->load->library(array('auth'));
		$this->load->library('interface_gateway');

		$auth = new auth();
		if ($this->uri->segment(2, 0) !== 'bind') {
			$auth->isnot_login();
			$auth->isnot_admin();
		}
		$this->load->model('agent_model');
		$this->load->model('userpass_model');
		$this->load->model('website_model');
	}

	public function index() {
		$dealer = $this->input->get('dl');
		if ($dealer) {
			$Content['dealer'] = $dealer;
			$Content['rs_website'] = $this->website_model->get_by_status(1);
			$data['Content'] = $this->load->view('userpass-agent/index', $Content, true);
			$this->load->view('template/temp_main', $data);
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.index.1';
			die();
		}
	}

	/**
	 * Get agents userpass data to display in datatable. For ajax use.
	 */
	public function all() {
		$dealer = $this->input->get('dl');

		/* 
			* Array of database columns which should be read and sent back to DataTables. Use a space where
			* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array('site.site_name', 'up.username', 'up.password', 'up.default_agent', 'up.userpass_id');

		// DB table to use
		$sTable = 'tb_userpass up';
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);

		// Paging
		if (isset($iDisplayStart) && $iDisplayLength != '-1') {
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}

		// Ordering
		if (isset($iSortCol_0)) {
			for ($i = 0; $i < intval($iSortingCols); $i++) {
				$iSortCol = $this->input->get_post('iSortCol_' . $i, true);
				$bSortable = $this->input->get_post('bSortable_' . intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_' . $i, true);

				if ($bSortable == 'true') {
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}

		/*
			 * Filtering
			 * NOTE this does not match the built-in DataTables filtering which does it
			 * word by word on any field. It's possible to do here, but concerned about efficiency
			 * on very large tables, and MySQL's regex functionality is very limited
		*/
		if (isset($sSearch) && !empty($sSearch)) {
			for ($i = 0; $i <= count($aColumns); $i++) {
				$bSearchable = $this->input->get_post('bSearchable_' . $i, true);

				// Individual column filtering
				if (isset($bSearchable) && $bSearchable == 'true') {
					//if($aColumns[$i]=='created'){
					//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';
					//}else{
					$like[] = $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($sSearch) . "%'";
					//}
				}
			}
		}
		if (isset($like) && !empty($like)) {
			$where = "(" . implode(" OR ", $like) . ")";
			$this->db->where($where, NULL, FALSE);
		}
		$this->db->where('up.type', $dealer);

		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_website site', 'site.site_id=up.site_id');
		$rResult = $this->db->get($sTable);

		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;

		// Total data set length
		$this->db->where('up.type', $dealer);
		$iTotal = $this->db->count_all_results($sTable);

		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array(),
		);

		foreach ($rResult->result() as $aRow) {
			$iDisplayStart = $iDisplayStart + 1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$row[0] = $iDisplayStart;
			$row[1] = $aRow->site_name;
			$row[2] = $aRow->username;
			$row[3] = $aRow->password;
			$row[4] = ($aRow->default_agent == 1) ? 'Y' : 'N';
			$row[5] = $aRow->userpass_id;
			$output['aaData'][] = $row;
		}
		echo json_encode($output);
	}

	/**
	 * Add new agent userpass data
	 */
	public function add() {
		$post = $this->input->post();
		if ($post) {
			extract($post);
			if ($site_id && $dealer && $username && $password) {
				$row = $this->db->get_where('tb_userpass', 'username = "'.$username.'" AND type = "'.$dealer.'"')->row();
				if ($row) {
					$this->session->set_flashdata('msg_error', "เพิ่มเอเย่นต์ไม่สำเร็จ (มีเอเย่นต์นี้แล้ว)");
					redirect('userpass-agent?dl='.$dealer);
				} else {
					$this->interface_gateway->set_agent_login($dealer, $username, $password);
					$rs_create_agent = $this->interface_gateway->create_agent();
					
					if ($rs_create_agent["status"] === true) {
						$data = array(
							'site_id' => $site_id,
							'username' => $username,
							'password' => $password,
							'type' => $dealer,
							'acnum' => 'dealer',
							'created' => date('Y-m-d H:i:s'),
						);
						$this->db->insert('tb_userpass', $data);
						$this->session->set_flashdata('msg_success', 'เพิ่มเรียบร้อย');
						redirect('userpass-agent?dl=' . $dealer);
					} else {
						$this->session->set_flashdata('msg_error', $rs_create_agent["status_message"]);
						redirect('userpass-agent?dl='.$dealer);
					}
				}
			} else {
				echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.add.1';
				die();
			}
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.add.2';
			die();
		}
	}

	/**
	 * Form edit agent interface
	 */
	public function form_edit_interface() {
		$agent_id = $this->input->get('agid');
		$dealer = $this->input->get('dl');
		if ($dealer && $agent_id) {
			$row_agent = $this->agent_model->get_by_agent_id($agent_id);
			if ($row_agent) {
				$row_itf = $this->agent_model->get_interface_by_agent_id($agent_id);
				$Content['dealer'] = $dealer;
				$Content['row_agent'] = $row_agent;
				$Content['row_itf'] = $row_itf;
				$this->load->view('userpass-agent/form-edit-interface', $Content);
			} else {
				echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.form_edit_interface.1';
				die();
			}
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.form_edit_interface.2';
			die();
		}
	}

	/**
	 * Edit agent interface
	 */
	public function edit_interface() {
		$post = $this->input->post();
		if ($post) {
			extract($post);
			if ($itf_agent_id) {
				$row_itf = $this->agent_model->get_interface_by_itf_auth($itf_auth);
				if ($row_itf) {
					if ($itf_id) {
						if ($row_itf->itf_id != $itf_id) {
							$this->session->set_flashdata('msg_error', 'ไม่สำเร็จ รหัสในการเชื่อมต่อซ้ำกับเอเย่นต์อื่น');
							redirect('userpass-agent?dl=' . $dealer);
						}
					}
					else {
						echo 'รหัสในการเชื่อมต่อซ้ำกับเอเย่นต์อื่น Ref.Userpass_agent.edit_interface.1';
						$this->session->set_flashdata('msg_error', 'ไม่สำเร็จ รหัสในการเชื่อมต่อซ้ำกับเอเย่นต์อื่น');
						redirect('userpass-agent?dl=' . $dealer);
					}
				}

				$data = array(
					'itf_auth' => $itf_auth,
					'itf_chat_url' => $itf_chat_url,
					'itf_callback_url' => $itf_callback_url,
					'itf_modified' => date('Y-m-d H:i:s'),
				);
				if ($itf_id) {
					$result = $this->db->update('tb_interface_agent', $data, array('itf_id' => $itf_id, 'itf_agent_id' => $itf_agent_id));
				} else {
					$data['itf_agent_id'] = $itf_agent_id;
					$data['itf_created'] = date('Y-m-d H:i:s');
					$result = $this->db->insert('tb_interface_agent', $data);
				}

				// After insert or update
				if ($result) {
					$this->session->set_flashdata('msg_success', 'สำเร็จ');
					redirect('userpass-agent?dl=' . $dealer);
				} else {
					$this->session->set_flashdata('msg_error', 'ไม่สำเร็จ กรุณาตรวจสอบข้อมูล');
					redirect('userpass-agent?dl=' . $dealer);
				}
			} else {
				echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.edit_interface.1';
				die();
			}
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.edit_interface.2';
			die();
		}
	}

	public function view() {
		$agent_id = $this->uri->segment(3, 0);
		$row_userpass = $this->agent_model->get_by_agent_id($agent_id);
		if ($row_userpass) {
			$this->interface_gateway->set_agent_login($row_userpass->type, $row_userpass->username, $row_userpass->password);
			$bind_data = $this->interface_gateway->init_bind_agent();
			$Content['bind_data'] = $bind_data;
			$Content['row_userpass'] = $row_userpass;
			$Content['row_website'] = $this->website_model->get_by_site_id($row_userpass->site_id);
			$data['Content'] = $this->load->view('userpass-agent/view', $Content, true);
			$this->load->view('template/temp_main', $data);
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.view.1';
			die();
		}
	}

	/**
	 * Edit agent userpass data
	 */
	public function edit() {
		$post = $this->input->post();
		if ($post) {
			extract($post);

			if ($default_agent == 1) {
				$this->db->update('tb_userpass', array('default_agent' => 0), array('userpass_id !=' => $userpasstoedit, 'type' => $dealer, 'site_id'=>$site_id));
			}

			$data = array(
				'username' => $username,
				'password' => $password,
				'default_agent' => $default_agent,
				'modified' => date('Y-m-d H:i:s'),
			);
			$result = $this->db->update('tb_userpass', $data, array('userpass_id' => $userpasstoedit, 'type' => $dealer));
			if ($result) {
				$this->session->set_flashdata('msg_success', 'แก้ไขสำเร็จ');
			} else {
				$this->session->set_flashdata('msg_error', 'แก้ไขไม่สำเร็จ กรุณาตรวจสอบข้อมูล');
			}
			redirect('userpass-agent/view/' . $userpasstoedit);
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.edit.1';
			die();
		}
	}

	/**
	 * Delete agent userpass data
	 */
	public function delete() {
		$dealer = $this->input->post('dealer');
		$userpasstodelete = $this->input->post('userpasstodelete');
		$row_agent = $this->agent_model->get_by_agent_id($userpasstodelete);
		if ($row_agent) {
			$this->db->delete('tb_userpass', array('userpass_id' => $row_agent->userpass_id, 'type' => $dealer));
			$this->session->set_flashdata('msg_success', 'ลบเรียบร้อย');
			redirect('userpass-agent?dl=' . $dealer);
		} else {
			$this->session->set_flashdata('msg_error', 'ลบไม่สำเร็จ โปรดตรวจสอบข้อมูล');
			redirect('userpass-agent?dl=' . $dealer);
		}
	}

	public function bind() {
		$agent_id = $this->uri->segment(3, 0);
		$row_agent = $this->agent_model->get_by_agent_id($agent_id);
		if ($row_agent) {
			$this->interface_gateway->set_agent_login($row_agent->type, $row_agent->username, $row_agent->password);
			$bind_data = $this->interface_gateway->init_bind_agent();
			if ($bind_data['status']) {
				echo $bind_data['bind_data'];
			} else {
				echo $bind_data['status_message'];
			}
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.Userpass_agent.bind.1';
			die();
		}
	}

}
