<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Sms_otpbay extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
	}
		
	public function index(){		
		$content = file_get_contents('php://input');
		$data = json_decode($content);		
		$bankstring = $data->sms;
		$fromno = $data->phoneNumber;	
		//$bankstring = 'Ref:9799 OTP:340967 โอนให้ THALOENGSAK N SCB 4170380538';										
		if(strstr($bankstring, "OTP")){			
			$newsms0 = explode(" OTP:", $bankstring);
			if(count($newsms0)==2){
				
				$newsms1 = explode("Ref:", $newsms0[0]);
				$ref = trim($newsms1[1]);				
				$newsms2 = explode(" โอนให้ ", $newsms0[1]);
				$otp = trim($newsms2[0]);
								
				$this->db->select('smsotp_id');
				$this->db->where('sms_ref', $ref);
				$this->db->where('sms_otp', $otp);
				$rs_sms = $this->db->get('tb_smsotp');
				if($rs_sms->num_rows()==0){						
					// เพิ่มลงตาราง tb_smsotp
					$sqlsms = "INSERT INTO tb_smsotp (sms_ref, sms_otp,sms_msg,sms_created) VALUES ('$ref', '$otp', '".htmlspecialchars($bankstring)."', '".date('Y-m-d H:i:s')."')";
					$query_sms = $this->db->query($sqlsms);
					echo $sqlsms;
				}
			} // End if(count($newsms0)==2){
			die();
		}else{
			echo 'OTP EMPTY';
		}// End if(strstr($bankstring, "OTP")){	
	}
					
}