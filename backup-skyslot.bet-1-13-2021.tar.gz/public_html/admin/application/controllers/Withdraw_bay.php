<?php defined('BASEPATH') OR exit('No direct script access allowed');

error_reporting(0);
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Withdraw_bay extends CI_Controller {

	var $auth;
	var $history;
	var $ch;	
	var $cookie;
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth','history_log','bypasscaptcha'));

		// if ($_SERVER['REMOTE_ADDR'] === $_SERVER['SERVER_ADDR']) {
		if ($this->uri->segment(2)==='process_queue' || $this->uri->segment(2)==='process-queue') {

		} else {
			$this->auth = new auth();
			$this->auth->isnot_login();	
		}
		$this->history = new history_log();	
		$this->load->model('userpass_model');
		$this->load->model('worksheet_model');
	}
	
	public function get_portfolio(){
		//+ MyPortfolio && Check Session
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?d'); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line	
		$html = curl_exec($this->ch);

		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$a = $dom->getElementById('ctl00_cphSectionData_rptDeposit_ctl01_ltField002');				
		preg_match("/MyAccount.aspx\?token=([^&]*)/",$html,$token);
		$data=array();
		if(!empty($token)&&$token[1]){
			
			$data['token'] = $token[1];
			$data['ma'] = trim($a->getAttribute('account'));
			$data['accnumber'] = trim($a->getAttribute('accno'));
								
			$divs= $dom->getElementsByTagName('div');
			$i=1;
			foreach($divs as $div){ 
				if($div->getAttribute('class')=='amc') {
					if($i==1){
						$data['canuse'] = $div->nodeValue;
					}
					if($i==2){
						$data['total'] = $div->nodeValue;
					}
					$i++;
				}
			 }
			 
		}
		return $data;
	}
	
	public function get_captcha($usernamebank){
		$key = 'ef71d0838a308a6a0068dbab3bf314aa'; // Key ใหม่
		$img_captcha = PUBPATH."/images/captchabay".$usernamebank.".png";		
		$value = $this->bypasscaptcha->bc_submit_captcha($key, $img_captcha);
		return $value;
	}
	
	public function login_bay($usernamebank,$passwordbank){
		//+ Login	
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Common/Login.aspx'); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line		
		$html = curl_exec($this->ch);	
		
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents	
		$inputs = $dom->getElementsByTagName('input');
		
		$postdata='__EVENTTARGET=ctl00%24cphForLogin%24lbtnLoginNew&__EVENTARGUMENT=&';
		foreach ($inputs as $input) {		
			 $inputname = $input->getAttribute('name');
			 $inputval = $input->getAttribute('value');		
			 switch($inputname){
				case '__VIEWSTATE':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__EVENTVALIDATION':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
				break;
				case '__VIEWSTATEGENERATOR':
					$postdata .= $inputname.'='.rawurlencode($inputval).'&';
			 }
		}
		//$postdata = substr($postdata,0,-1);
		$postdata .='user=&password=&username=&password=&ctl00%24cphForLogin%24username='.$usernamebank.'&ctl00%24cphForLogin%24password=&ctl00%24cphForLogin%24hdPassword='.rawurlencode($passwordbank).'&ctl00%24cphForLogin%24hddLanguage=TH';
		
		$imgcaptcha = $dom->getElementById('ctl00_cphForLogin_captcha');
		if(isset($imgcaptcha)){				
			$src_captcha = $imgcaptcha->getAttribute('src'); // get src img captcha
			list($type, $src_captcha) = explode(';', $src_captcha);
			list(, $src_captcha) = explode(',', $src_captcha);
			$data = base64_decode($src_captcha);			
			file_put_contents(PUBPATH."/images/captchabay".$usernamebank.".png", $data);			
			$captcha = $this->get_captcha($usernamebank);			
			$postdata .= '&'.rawurlencode('ctl00$cphForLogin$tbInput').'='.rawurlencode($captcha);
		}
		
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Common/Login.aspx');		
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($this->ch, CURLOPT_POST, 1);
		$html = curl_exec($this->ch);
		//print_r($html);
		if(preg_match("#Last Logged in#",$html)){
			return true;
		}else{
			return false;
		}
	}

	public function process_queue(){
		// $msg = array('error'=>'1','text'=>'ปิดการใช้งาน process_queue ชั่วคราว');
		// echo json_encode($msg);
		// die();

		$start_process_time = date('Y-m-d H:i:s');
		$start_process_time_5 = date('Y-m-d H:i:s',strtotime('-5 minutes'));

		// เช็คว่ามีใบงานกำลังประมวลผลอยู่ไหม
		$sql = 'SELECT * FROM tb_worksheet 
				WHERE ws_type = "withdraw" AND b_status = 4 AND ws_wibank = "bay" 
				ORDER BY ws_id LIMIT 1';
		$query_curr_process = $this->db->query($sql);
		if($query_curr_process->num_rows()==1){ // ถ้ามีใบงานกำลังประมวลผล
			$row_curr_process = $query_curr_process->row();
			$present_time = strtotime(date('Y-m-d H:i:s'));
			$can_revert_time = strtotime("+10 minute",strtotime($row_curr_process->modified));
			if(($present_time>$can_revert_time)) {
				echo 'withdraw_bay.process_queue: มีใบงานกำลังประมวลผลอยู่ ws_id:' .$row_curr_process->ws_id;
				// ปล่อยใบงาน
				$data = array(
					'ws_wibank'=>NULL,
					'ws_wibankac'=>NULL,
					'ws_wibankname'=>NULL,
					'ws_wibankacnum'=>NULL,
					'b_id'=>NULL,
					'b_status'=>0,
					'b_comment'=>'ไม่สำเร็จ: '.date('Y-m-d H:i:s') . ' (ยกเลิกการประมวลผลเนื่องจากทำงานเกิน 10 นาที)',
					'b_date'=>date('Y-m-d H:i:s'),
					'b_flag'=>0,
					'b_flag_id'=>NULL,
					'b_flag_expire'=>NULL,
					'modified'=>date('Y-m-d H:i:s')
				);
				$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_curr_process->ws_id,'c_status'=>1,'b_status'=>4,'m_status'=>1));
				if($this->db->affected_rows() > 0){
					echo 'withdraw_bay.process_queue: ยกเลิกการประมวลผลเนื่องจากทำงานเกิน 10 นาที ws_id:' .$row_curr_process->ws_id;
					$data = array(
						'dealer'=>$row_curr_process->ws_dealer,
						'username'=>$row_curr_process->username,
						'ws_id'=>$row_curr_process->ws_id
					);
					$this->history->save(array('action'=>'AT ย้อน ใบงานถอน '.$row_curr_process->b_status.'=>0'. ' ('.@$row_curr_process->b_comment.')','user_id'=>NULL,'detail'=>json_encode($data)));
				}
			} else {
				echo 'withdraw_bay.process_queue: มีใบงานกำลังประมวลผลอยู่ ws_id:' .$row_curr_process->ws_id;
			}
			die();
		} else { // End if($query_curr_process->num_rows()==1){ ถ้าไม่มีใบงานกำลังประมวลผลแล้ว
			// เช็คว่ามีใบงานรอจัดการไหม
			$sql = 'SELECT ws_id,b_id FROM tb_worksheet 
			WHERE ws_type = "withdraw" AND b_status = 3 AND ws_wibank = "bay" 
			ORDER BY ws_id LIMIT 1';
			$query_new_process = $this->db->query($sql);
			if($query_new_process->num_rows()>0){ // ถ้ามีใบงานรอจัดการ
				$msg = array('error'=>'1','text'=>'เกิดข้อผิดพลาดในการประมวลผลใบงานถอน');

				$row_new_process = $query_new_process->row();
				$ws_id = $row_new_process->ws_id;
				$add_queue_by = $row_new_process->b_id;

				// อัพเดตให้เป็นกำลังประมวลผล
				$data = array(
					// 'b_id'=>NULL,
					'b_status'=>4,
					'b_comment'=>'กำลังประมวลผล: '.date('Y-m-d H:i:s'),
					'b_date'=>date('Y-m-d H:i:s'),
					'modified'=>date('Y-m-d H:i:s')
				);
				$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id,'c_status'=>1,'b_status'=>3,'m_status'=>1));
				if($this->db->affected_rows()==0){
					echo 'withdraw_bay.process_queue: เปลี่ยนสถานะใบงานเป็นสถานะประมวลผลไม่สำเร็จ';
					die();
				}
				$rs_worksheet = $this->worksheet_model->get_worksheet_withdraw_auto_bank_by_id($ws_id);
				if($rs_worksheet->num_rows()==1){
					$row_worksheet = $rs_worksheet->row();				
					if($row_worksheet->b_status==4){
						$wibank = $row_worksheet->ws_wibank;
						$wibankac = $row_worksheet->ws_wibankac;
						$wibankname = $row_worksheet->ws_wibankname;
						$wibankname = $row_worksheet->ws_wibankname;
						$sql = 'SELECT * FROM tb_userpass WHERE type="'.$wibank.'" AND username="'.$wibankac.'" AND bankname="'.$wibankname.'" AND up_status = 1';
						$query_bankwithdraw = $this->db->query($sql);
						if($query_bankwithdraw->num_rows()==1){
							$row_bankwithdraw = $query_bankwithdraw->row();
							$usernamebank = $row_bankwithdraw->username;
							$passwordbank = $row_bankwithdraw->password;
							$lastdigitphone = $row_bankwithdraw->lastdigitphone;				
							if($usernamebank!=''&&$passwordbank!=''&&$lastdigitphone!=''){
								$this->ch = curl_init();
								$this->cookie = PUBPATH."cookie/cookie-withdraw-".$wibank."-".$usernamebank.".txt";
								
								$data_portfolio = $this->get_portfolio();
								if(empty($data_portfolio)){
									$this->login_bay($usernamebank,$passwordbank);
									$data_portfolio = $this->get_portfolio();
								}
								$beforebalance = trim(str_replace(',','',$data_portfolio['total'])); // ออมทรัพย์ :  ยอดในบ.ช (฿)
								
								//+ OtherTransfer
								curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/FundTransfer/OtherTransfer.aspx?pgno=11'); 
								curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
								curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
								curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
								curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
								curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
								curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
								$html = curl_exec($this->ch);	
															
								$dom = new DOMDocument(); // create DOM object
								@$dom->loadHTML($html);// load it's all html contents	
								$inputs = $dom->getElementsByTagName('input');
								
								$postdata = rawurlencode('ctl00$smMain').'='.rawurlencode('ctl00$smMain|ctl00$cphSectionData$btnSubmit').'&';
								foreach ($inputs as $input) {		
									$inputname = $input->getAttribute('name');
									$inputval = $input->getAttribute('value');
									switch($inputname){
										case '__EVENTTARGET':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__EVENTARGUMENT':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__LASTFOCUS':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__VIEWSTATE':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__VIEWSTATEGENERATOR':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__PREVIOUSPAGE':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__EVENTVALIDATION':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;									
										case 'ctl00$hddIsLoadComplete':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;									
										case 'ctl00$cphSectionData$hdnIsP2P':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;										
										case 'ctl00$cphSectionData$ddlBanking':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;									
										case 'ctl00$cphSectionData$txtAccTo':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($row_worksheet->bankno).'&';
											break;
										case 'ctl00$cphSectionData$txtAmountTransfer':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($row_worksheet->ws_credit).'&';
											break;
										case 'ctl00$cphSectionData$alertType':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case 'ctl00$cphSectionData$notify_receiver':
											$postdata .= rawurlencode($inputname).'=0&';
											break;		
										case 'ctl00$cphSectionData$hdScheduleUI':
											$postdata .= rawurlencode($inputname).'=0&';
											break;
										case 'ctl00$cphSectionButton$hfDefault':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case 'ctl00$cphSectionButton$hfToDefault':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case 'ctl00$cphSectionButton$hfMainAccount':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case 'ctl00$cphSectionButton$hfToAccount':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;									
										case 'ctl00$cphSectionButton$hfFromAccNo':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case 'ctl00$cphSectionButton$hfToAccNo':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($row_worksheet->bankno).'&';
											break;
										case 'ctl00$cphSectionButton$hfToCode':
											$postdata .= rawurlencode($inputname).'='.conv_bankwithdrawnum($row_worksheet->bank).'&';
											$postdata .= 'ctl00$cphSectionData$ddlBanking'.'='.conv_bankwithdrawnum($row_worksheet->bank).'&';
											break;											
										case 'ctl00$cphSectionButton$hfEmail':
											$postdata .= rawurlencode($inputname).'=0&';
											break;
										case 'ctl00$cphSectionButton$hfSMS':
											$postdata .= rawurlencode($inputname).'=0&';
											break;
									}
								}
															
								$postdata .= 'ctl00%24cphSectionData$scheduleType=now&ctl00%24hddNoAcc=&ctl00%24bannerTop%24hdTransactionType=&';
								$postdata .= 'ctl00%24bannerTop%24hdCampaignCode=&ctl00%24bannerTop%24hdCampaignTxnType=&';
								$postdata .= 'ctl00%24bannerTop%24hdCampaignMutualFundType=&ctl00%24bannerTop%24hdCampaignTransferType=&';
								$postdata .= 'ctl00%24bannerTop%24hdAccNo=&ctl00%24bannerTop%24hdBillerId=&ctl00%24bannerTop%24hdUrlRedirect=&';
								$postdata .= 'ctl00%24bannerTop%24hdAmount=&ctl00%24bannerTop%24hdTxnIsSuccess=&ctl00%24bannerTop%24hdBillerCategory=&';
								$postdata .= 'ctl00%24bannerTop%24hdBillerName=&ctl00%24bannerTop%24hdAJAXData=&ctl00%24hdnCurrentPageQuickMenu=&';
								$postdata .= 'ctl00%24hdnPageIndexQuickMenuLoaded=&ctl00%24cphSectionData%24ddlFixedType=&ctl00%24cphSectionData%24txtOtherReason=&';
								$postdata .= 'ctl00%24cphSectionData%24txtPaymentDate_Once=&ctl00%24cphSectionData%24ddlRecurring=&';
								$postdata .= 'ctl00%24cphSectionData%24txtRecurringDateStart=&ctl00%24cphSectionData%24txtRecurringDateEnd=&';
								$postdata .= 'ctl00%24cphSectionData%24txtEmailNotifyTo=&ctl00%24cphSectionData%24txtEmailNotifyToName=&';
								$postdata .= 'ctl00%24cphSectionData%24txtEmailNotifyToRemark=&ctl00%24cphSectionData%24txtSMSNotifyToMobileNo=&';
								$postdata .= 'ctl00%24cphSectionData%24txtSMSNotifyToName=&ctl00%24cphSectionData%24txtMemo=&ctl00%24cphSectionData%24hdScheduleId=&';
								$postdata .= 'ctl00%24cphSectionData%24hdTransactionCode=&ctl00%24cphSectionButton%24hfOthereasonID=&';
								$postdata .= 'ctl00%24cphSectionButton%24hfCannotAccess=&ctl00%24hdSessionIDWS=&ctl00%24hddHasSess=&';
								$postdata .= '__ASYNCPOST=true&ctl00%24cphSectionData%24btnSubmit='.rawurlencode('ดำเนินการ');
								
								curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
								curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
								curl_setopt($this->ch, CURLOPT_POST, 1);
								curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
								$html = curl_exec($this->ch);
								//print_r($html); die();

								$urlconfirm = 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/FundTransfer/ConfirmTransfer.aspx?token='.$data_portfolio['token'];	
								curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 0); 
								curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
								curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
								curl_setopt($this->ch, CURLOPT_REFERER, $urlconfirm);			
								curl_setopt($this->ch, CURLOPT_URL, $urlconfirm);							
								$html = curl_exec($this->ch);
	
								$dom = new DOMDocument(); // create DOM object
								@$dom->loadHTML($html);// load it's all html contents	
								
								$ref = 'undifined';
								$divs = $dom->getElementsByTagName("div");
								foreach ($divs as $div){
									$class = $div->getAttribute("class");
									if($class=='input_input_half'){
										if(is_numeric(trim($div->nodeValue))){
											$ref = preg_replace("/[^0-9]/", '', $div->nodeValue);
										}
									}							
								}

								if($ref=='undifined'){
									$msg = array('error'=>'1','text'=>'ไม่พบ รหัสอ้างอิง หรือ เลขบัญชีปลายทางไม่ถูกต้อง');	
										
									// ปล่อยใบงาน
									$data = array(
										'b_status'=>5,
										'b_comment'=>'ไม่สำเร็จ: '.date('Y-m-d H:i:s') . '(ไม่พบ รหัสอ้างอิง หรือ เลขบัญชีปลายทางไม่ถูกต้อง)',
										'b_date'=>date('Y-m-d H:i:s'),
										'b_flag'=>0,
										'b_flag_id'=>NULL,
										'b_flag_expire'=>NULL,
										'modified'=>date('Y-m-d H:i:s')
									);
									$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'c_status'=>1,'b_status'=>4,'m_status'=>1));						
									echo json_encode($msg); die();
								}
																			
								$otp = '000000';
								for($i=0; $i <=35; $i++) {
									sleep(3); // this should halt for 15 seconds for every loop
									$this->db->select('smsotp_id,sms_otp');
									$this->db->where('sms_ref', $ref);
									$this->db->where('sms_created >=',$start_process_time_5);
									$rs_sms = $this->db->get('tb_smsotp');
									if($rs_sms->num_rows()==1){
										$otp = $rs_sms->row()->sms_otp;
									}
									if($otp!='000000') {
										break;
									}
								}					
								
								if($otp=='000000'){
									$msg = array('error'=>'1','text'=>'OTP ไม่เข้าระบบ โปรดตรวจสอบโทรศัพท์');	
										
									// ปล่อยใบงาน
									$data = array(
										'b_status'=>5,
										'b_comment'=>'ไม่สำเร็จ: '.date('Y-m-d H:i:s') . '(OTP ไม่เข้าระบบ โปรดตรวจสอบโทรศัพท์) Ref : '.$ref,
										'b_date'=>date('Y-m-d H:i:s'),
										'b_flag'=>0,
										'b_flag_id'=>NULL,
										'b_flag_expire'=>NULL,
										'modified'=>date('Y-m-d H:i:s')
									);
									$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'c_status'=>1,'b_status'=>4,'m_status'=>1));						
									echo json_encode($msg); die();
								}
								
								$inputs = $dom->getElementsByTagName('input');							
								$postdata = rawurlencode('ctl00$smMain').'='.rawurlencode('ctl00$cphSectionData$OTPBox1$udpOTPBox|ctl00$cphSectionData$OTPBox1$btnConfirm').'&';
								foreach ($inputs as $input) {		
									$inputname = $input->getAttribute('name');
									$inputval = $input->getAttribute('value');
									switch($inputname){
										case '__EVENTTARGET':
											$postdata .= rawurlencode($inputname).'='.rawurlencode('ctl00$cphSectionData$OTPBox1$btnConfirm').'&';
											break;
										case '__EVENTARGUMENT':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__VIEWSTATE':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__VIEWSTATEGENERATOR':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__PREVIOUSPAGE':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
										case '__EVENTVALIDATION':
											$postdata .= rawurlencode($inputname).'='.rawurlencode($inputval).'&';
											break;
									}
								}
								
								$postdata .= 'ctl00%24hddNoAcc=&ctl00%24bannerTop%24hdTransactionType=&ctl00%24bannerTop%24hdCampaignCode=&';
								$postdata .= 'ctl00%24bannerTop%24hdCampaignTxnType=&ctl00%24bannerTop%24hdCampaignMutualFundType=&';
								$postdata .= 'ctl00%24bannerTop%24hdCampaignTransferType=&ctl00%24bannerTop%24hdAccNo=&';
								$postdata .= 'ctl00%24bannerTop%24hdBillerId=&ctl00%24bannerTop%24hdUrlRedirect=&';							
								$postdata .= 'ctl00%24bannerTop%24hdAmount=&ctl00%24bannerTop%24hdTxnIsSuccess=&ctl00%24bannerTop%24hdBillerCategory=&';
								$postdata .= 'ctl00%24bannerTop%24hdBillerName=&ctl00%24bannerTop%24hdAJAXData=&ctl00%24hddIsLoadComplete=false&';							
								$postdata .= 'ctl00%24hdnCurrentPageQuickMenu=&ctl00%24hdnPageIndexQuickMenuLoaded=&ctl00%24cphSectionData%24OTPBox1%24Password2=&';							
								$postdata .= 'ctl00%24cphSectionData%24OTPBox1%24txtTemp=&ctl00%24cphSectionData%24OTPBox1%24hddOTPPassword='.$otp.'&';
								$postdata .= 'username=&password=&ctl00%24cphSectionData%24OTPBox1%24txtOTPPassword=&ctl00%24hdSessionIDWS=&';					
								$postdata .= 'ctl00%24hddHasSess=&__ASYNCPOST=true';							
								
								curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 0); 
								curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
								curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
								curl_setopt($this->ch, CURLOPT_REFERER, $urlconfirm);
								curl_setopt($this->ch, CURLOPT_POST, 1);
								curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
								$html = curl_exec($this->ch);
								preg_match("/CompletedTransfer.aspx%3ftoken%3d([^&]*)/",$html,$token);
								$token = strstr($token[1], '%26Txn%3dsuccess', true);
								
								$urlcomplete = 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/FundTransfer/CompletedTransfer.aspx?token='.$token.'&Txn=success';				
								curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
								curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
								curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);	
								curl_setopt($this->ch, CURLOPT_URL, $urlcomplete);	
								curl_setopt($this->ch, CURLOPT_REFERER, $urlconfirm);						
								$html = curl_exec($this->ch);
								
								$contentsuccess = '';
								$dom = new DOMDocument(); // create DOM object
								@$dom->loadHTML($html);// load it's all html contents
								$DivSuccessMsg = $dom->getElementById('ctl00_cphSectionData_pnlSuccessMsg');
								$SuccessMsg = trim($dom->getElementById('ctl00_cphSectionData_pnlSuccessMsg')->nodeValue);
								$DivTransfer = $dom->getElementById('ctl00_cphSectionData_pnlTransferLocal');
								$contentsuccess = $dom->saveHTML($DivSuccessMsg);  // save html table
								$contentsuccess .= $dom->saveHTML($DivTransfer);  // save html table
															
								$data_portfolio = $this->get_portfolio(); 
								$afterbalance = trim(str_replace(',','',$data_portfolio['total'])); // ออมทรัพย์ :  ยอดในบ.ช (฿)
								echo $contentsuccess;
								echo '<hr>';
								echo 'SuccessMsg > '.$SuccessMsg;
								echo '<hr>';
								echo 'beforebalance > '.$beforebalance;
								echo '<hr>';
								echo 'afterbalance > '.$afterbalance;
								echo '<hr>';
								if($beforebalance>$afterbalance||$SuccessMsg=='การโอนเงินเสร็จสมบูรณ์'){
									$data = array(
										'ws_wibank'=>$row_bankwithdraw->type,
										'ws_wibankac'=>$row_bankwithdraw->username,
										'ws_wibankname'=>$row_bankwithdraw->bankname,
										//'ws_wibankacnum'=>$row_bankwithdraw->acnum,
										'beforebalance'=>$beforebalance,
										'afterbalance'=>$afterbalance,
										'b_status'=>1,
										'b_comment'=>'ตรวจอัตโนมัติ ผ่านการถอน BAY ONLINE',
										'b_date'=>date('Y-m-d H:i:s'),
										'modified'=>date('Y-m-d H:i:s')
									);					
									// $this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'ws_type'=>'withdraw','c_status'=>1,'b_status'=>4,'m_status'=>1));
									$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id));
									if($this->db->affected_rows() > 0){
										$result = 'success';
										//+ History Log 
										$data = array(
											'dealer'=>$row_worksheet->ws_dealer,
											'username'=>$row_worksheet->username,
											'ws_id'=>$row_worksheet->ws_id
										);
										$this->history->save(array('action'=>'AT Bank ตรวจ ใบงานถอน (รอจัดการโดย '.@$add_queue_by.')','user_id'=>NULL,'detail'=>json_encode($data)));

										$data_ws_autolog = array(
											'wc_ws_id'=>$row_worksheet->ws_id,
											'wc_beforebalance'=>$beforebalance,
											'wc_afterbalance'=>$afterbalance,
											'wc_html'=>$contentsuccess,
											'wc_created'=>date('Y-m-d H:i:s')
										);					
										$this->db->insert('tb_ws_autolog', $data_ws_autolog);

										// $this->load->model('website_model');
										// $row_website = $this->website_model->get_by_site_id($row_worksheet->site_id);
								
										$msg = 'โอนเงิน สำเร็จ <br> ยอดก่อนโอน : '.$beforebalance.'<br> ยอดหลังโอน : '.$afterbalance;
										$msg = array('error'=>'0','text'=>$msg,'username'=>$row_worksheet->username);								
										echo json_encode($msg); die();	
									} // if($this->db->affected_rows() > 0){
								}else{								
									$msg = array('error'=>'1','text'=>'ไม่สำเร็จ โปรดลองใหม่ในภายหลัง');
								} // End if($beforebalance>$afterbalance){
							}else{							
								$msg = array('error'=>'1','text'=>'เช็ค Username / Password / Last digit phone Bank');
								$msg_text_for_b_comment = 'เช็ค Username / Password / Last digit phone Bank';
							} // End if($usernamebank!=''&&$passwordbank!=''&&$lastdigitphone!=''){	
						} else {
							$msg = array('error'=>'1','text'=>'เช็ค ธนาคาร / ชื่อบัญชี / Username Bank');
							$msg_text_for_b_comment = 'เช็ค ธนาคาร / ชื่อบัญชี / Username Bank';
						} // End if($query_bankwithdraw->num_rows()==1){		
						
						// ปล่อยใบงาน
						$data = array(
							'b_status'=>5,
							'b_comment'=>'ไม่สำเร็จ: '.date('Y-m-d H:i:s') . @$msg_text_for_b_comment,
							'b_date'=>date('Y-m-d H:i:s'),
							'b_flag'=>0,
							'b_flag_id'=>NULL,
							'b_flag_expire'=>NULL,
							'modified'=>date('Y-m-d H:i:s')
						);
						$this->db->update('tb_worksheet', $data, array('ws_id'=>$row_worksheet->ws_id,'c_status'=>1,'b_status'=>4,'m_status'=>1));
						echo json_encode($msg);
						die();
					} // End if($rs_worksheet->num_rows()==1&&count($ws_bankac)==3){
				} // End if(rs_worksheet->num_rows()==1){
			} else { // End if($query_new_process->num_rows()>0){ ถ้าไม่มีใบงานรอจัดการแล้ว
				echo 'withdraw_bay.process_queue: ไม่มีใบงานรอจัดการแล้ว';
				die();
			}
		}
	}

	function __destruct(){
		if($this->ch) {
			curl_close($this->ch);
		}
		$this->db->close();
	}
		
}