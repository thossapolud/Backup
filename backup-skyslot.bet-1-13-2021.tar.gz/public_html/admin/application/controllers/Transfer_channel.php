<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Transfer_channel extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth'));
		$auth = new auth();
		$auth->isnot_login();
		$auth->isnot_admin();
		$this->load->model('transfer_channel_model');
		$this->load->model('userpass_model');
		$this->load->model('website_model');
	}

	public function index(){
		$Content['rs_website'] = $this->website_model->get_by_status(1);
		$data['Content'] = $this->load->view('transfer-channel/index', $Content, true);
		$this->load->view('template/temp_main', $data);
	}

	public function get_transfer_channel() {
		$xfer_h_type = $this->input->get('xht'); // bank account for deposit or withdraw

		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'site.site_name',2=>'xh.xfer_h_name',3=>'xh.xfer_h_desc',4=>'xh.xfer_h_type',5=>'xh.xfer_h_status',6=>'xh.xfer_h_id');

		// DB table to use
		$sTable = 'tb_xfer_channel xh';
		//

		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);

		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}

		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);

				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}

		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++){
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);

				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
				}
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
		if ($xfer_h_type) {
			$this->db->where('xh.xfer_h_type', $xfer_h_type);
		}

		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->join('tb_website site', 'site.site_id=xh.site_id');
		$rResult = $this->db->get($sTable);		
		
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;

		// Total data set length
		$iTotal = $this->db->count_all_results($sTable);

		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$aColumns = array(1=>'site.site_name',2=>'xh.xfer_h_name',3=>'xh.xfer_h_desc',4=>'xh.xfer_h_type',5=>'xh.xfer_h_status',6=>'xh.xfer_h_id');
			$row[0] = $iDisplayStart;		
			$row[1] = $aRow->site_name;
			$row[2] = $aRow->xfer_h_name;
			$row[3] = $aRow->xfer_h_desc;			
			$row[4] = conv_ws_type($aRow->xfer_h_type);
			$row[5] = ($aRow->xfer_h_status == 1) ? '<span class="badge badge-success">ใช้งาน</span>':'<span class="badge badge-primary">ปิดใช้งาน</span>';
			$row[6] = $aRow->xfer_h_id;	 
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}

	public function add() {
		$post = $this->input->post();
		if($post) {
			extract($post);
			$row = $this->transfer_channel_model->get_by_xfer_h_name($xfer_h_name);
			if ($row) {
				$this->session->set_flashdata('msg_error', 'เพิ่มกลุ่มลูกค้าไม่สำเร็จ (ชื่อกลุ่มลูกค้าซ้ำ)');
				redirect('transfer-channel');
			} else {
				$data = array(
					'site_id' => $site_id,
					'xfer_h_name' => $xfer_h_name,
					'xfer_h_desc' => $xfer_h_desc,
					'xfer_h_type' => $xfer_h_type,
					'xfer_h_created' => date('Y-m-d H:i:s'),
					'xfer_h_modified' => date('Y-m-d H:i:s')
				);
				$result = $this->transfer_channel_model->add_xfer_h($data);
				if ($result === TRUE) {
					$this->session->set_flashdata('msg_success', 'เพิ่มกลุ่มลูกค้าสำเร็จ');
					redirect('transfer-channel');
				} else {
					$this->session->set_flashdata('msg_error', 'เพิ่มกลุ่มลูกค้าไม่สำเร็จ');
					redirect('transfer-channel');
				}
			}
		}
	}

	public function form_edit_transfer_channel() {
		$xfer_h_id = $this->input->get('xcid');
		if ($xfer_h_id) {
			$row_xfer_h = $this->transfer_channel_model->get_by_xfer_h_id($xfer_h_id);
			if ($row_xfer_h) {
				$rs_xfer_detail = $this->transfer_channel_model->get_detail_all()->result();
				$arr_userpass_id= array();
				foreach($rs_xfer_detail as $row){
					$arr_userpass_id[] = $row->userpass_id;
				}
				$Content['row_website'] = $this->website_model->get_by_site_id($row_xfer_h->site_id);
				// $Content['rs_avail_bank'] = $this->userpass_model->get_bank_avail_for_add_xfer_channel_by_actype($row_xfer_h->xfer_h_type);
				$Content['rs_avail_bank'] = $this->userpass_model->get_bank_by_site_id_actype_and_not_in_userpass_id($row_xfer_h->site_id,$row_xfer_h->xfer_h_type,$arr_userpass_id);
				$Content['rs_current_bank'] = $this->transfer_channel_model->get_detail_by_xfer_h_id($xfer_h_id);
				$Content['row_xfer_h'] = $row_xfer_h;
				$this->load->view('transfer-channel/form-edit-transfer-channel', $Content);
			}
			else {
				echo 'กรุณาตรวจสอบข้อมูล';
				die();
			}
		}
		else {
			echo 'กรุณาตรวจสอบข้อมูล';
			die();
		}
	}

	public function get_bank_by_site_id_actype_and_not_in_userpass_id() {
		$site_id = $this->input->post('site_id');
		$xfer_h_type = $this->input->post('xfer_h_type');
		$rs_xfer_detail = $this->transfer_channel_model->get_detail_all()->result();
		$arr_userpass_id= array();
		foreach($rs_xfer_detail as $row){
			$arr_userpass_id[] = $row->userpass_id;
		}
		$rs_avail_bank = $this->userpass_model->get_bank_by_site_id_actype_and_not_in_userpass_id($site_id, $xfer_h_type, $arr_userpass_id);
		$output = array();
		if($rs_avail_bank->num_rows()>0){				
			foreach($rs_avail_bank->result() as $row){
				$data['userpass_id'] = $row->userpass_id;
				$data['type'] = strtoupper($row->type);
				$data['bankname'] = $row->bankname;
				$output[] = $data;
			}
		}
		echo json_encode($output);
	}

	public function get_transfer_channel_detail() {
		$xfer_h_id = $this->input->post('xfer_h_id');
		$rs_xfer_detail = $this->transfer_channel_model->get_detail_by_xfer_h_id($xfer_h_id);
		$output = array();
		if($rs_xfer_detail->num_rows()>0){				
			foreach($rs_xfer_detail->result() as $row){
				$data['xfer_d_id'] = $row->xfer_d_id;
				$data['type'] = strtoupper($row->type);
				$data['acnum'] = $row->acnum;
				$data['bankname'] = $row->bankname;
				$output[] = $data;
			}
		}
		echo json_encode($output);
	}

	// edit transfer channel header
	public function edit() {
		$post = $this->input->post();
		if($post) {
			extract($post);
			$data = array(
				'xfer_h_desc' => $xfer_h_desc,
				'xfer_h_status' => $xfer_h_status,
				'xfer_h_modified' => date('Y-m-d H:i:s')
			);
			$cond = array('xfer_h_id'=>$xfer_h_id);
			$result = $this->transfer_channel_model->edit_xfer_h($data, $cond);
			if ($result === TRUE) {
				$this->session->set_flashdata('msg_success', 'แก้ไขกลุ่มลูกค้าสำเร็จ');
				redirect('transfer-channel');
			} else {
				$this->session->set_flashdata('msg_error', 'แก้ไขกลุ่มลูกค้าไม่สำเร็จ');
				redirect('transfer-channel');
			}
			
		}
		$this->session->set_flashdata('msg_error', 'กรุณาตรวจสอบข้อมูล');
		redirect('transfer-channel');
	}

	public function add_detail() {
		$post = $this->input->post();
		if($post) {
			extract($post);
			$data = array(
				'xfer_h_id' => $xfer_h_id,
				'userpass_id' => $userpass_id,
				'xfer_d_created' => date('Y-m-d H:i:s'),
				'xfer_d_modified' => date('Y-m-d H:i:s')
			);
			$result = $this->transfer_channel_model->add_xfer_d($data);
			if ($result === TRUE) {
				echo ("เพิ่มบัญชีสำเร็จ");
				die();
			} else {
				echo ("เพิ่มบัญชีไม่สำเร็จ");
				die();
			}
		}
		echo ("กรุณาตรวจสอบข้อมูล");
		die();
	}

	public function delete_detail() {
		$xfer_h_id = $this->input->post('xfer_h_id');
		$xfer_d_id = $this->input->post('xfer_d_id');
		if ($xfer_h_id && $xfer_d_id) {
			$cond = array(
				'xfer_h_id' => $xfer_h_id,
				'xfer_d_id' => $xfer_d_id
			);
			$result = $this->transfer_channel_model->delete_xfer_d($cond);
			if ($result) {
				echo ("ลบบัญชีสำเร็จ");
				die();
			} else {
				echo ("ลบบัญชีไม่สำเร็จ");
				die();
			}
		}
		echo ("กรุณาตรวจสอบข้อมูล");
		die();
	}
}
