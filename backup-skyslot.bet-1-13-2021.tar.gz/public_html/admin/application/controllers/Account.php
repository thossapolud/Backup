<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Account extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth'));
		$auth = new auth();
		$auth->isnot_login();
		$auth->isnot_admin();
		$this->load->model('account_model');
		$this->load->model('option_model');
	}

	public function index(){
		$Content['row_line_notify_token'] = $this->option_model->get_by_opt_name('SYS_LINE_NOTIFY_TOKEN', 'default')->row();
		$data['Content'] = $this->load->view('account/index', $Content, true);
		$this->load->view('template/temp_main', $data);
	}

	public function all(){
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array('name','status','username','email', 'phone', 'ac_id');

		// DB table to use
		$sTable = 'tb_account';
		
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);

		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}

		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);

				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}

		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=0; $i<=count($aColumns); $i++)
			{
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);

				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					//if($aColumns[$i]=='created'){
						//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';
					//}else{
						$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					//}
				}
			}
		}
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
		$this->db->where('level !=', 'admin');
		

		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$rResult = $this->db->get($sTable);

		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;

		// Total data set length
		$iTotal = $this->db->count_all($sTable);

		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$row[0] = $iDisplayStart;			
			$name = ($aRow->status=='เลิกใช้')?'<i class="oi oi-x text-danger" title="เลิกใช้"></i> '.$aRow->name:$aRow->name;
			$row[1] = $name;
			$row[2] = $aRow->status;
			$row[3] = $aRow->username;
			$row[4] = $aRow->email;
			$row[5] = $aRow->phone;
			$row[6] = $aRow->ac_id;			
			$output['aaData'][] = $row;			
		}		 
		echo json_encode($output);
	}
	
	public function add(){
		$post = $this->input->post();
		if($post){
			extract($post);
			$data = array(
				'name'=>$name,
				'username'=>$username,
				'password'=>md5($password),
				'phone'=>$phone,
				'email'=>$email,
				'level'=>$level,
				'add_by_id'=>$this->session->userdata('ac_id'),
				'created'=>date('Y-m-d H:i:s')
			);
			$this->db->insert('tb_account', $data);
			$this->session->set_flashdata('msg_success', 'เพิ่มเรียบร้อย');
			redirect('account');
		}
	}

	public function edit(){
		$post = $this->input->post();
		if($post){
			extract($post);
			$data = array(
				'name'=>$name,
				'username'=>$username,				
				'phone'=>$phone,
				'email'=>$email,
				'status'=>$status,
				'level'=>$level,
				'modified'=>date('Y-m-d H:i:s')
			);
			if(isset($password)&&$password!=''){$data['password']=md5($password);}
			$this->db->update('tb_account', $data, array('ac_id'=>$accounttoedit));
			$this->session->set_flashdata('msg_success', 'แก้ไขเรียบร้อย');
			redirect('account/view/'.$accounttoedit);
		}
	}

	public function udpate_line_notify() {
		$line_notify_token = $this->input->post('line_notify_token');
		$cond = array(
			'opt_code' => 'SYS_LINE_NOTIFY_TOKEN',
			'opt_name' => 'default'
		);
		$result = $this->option_model->delete_option($cond);
		if ($result) {
			if ($line_notify_token) {
				$data = array(
					'opt_code' => 'SYS_LINE_NOTIFY_TOKEN',
					'opt_name' => 'default',
					'opt_value' => $line_notify_token,
				);
				
				$this->option_model->add_option($data);
			}
		}
		$this->session->set_flashdata('msg_success', 'แก้ไข Line Notify เรียบร้อย');
		redirect('account');
	}

	public function view(){
		$id = $this->uri->segment(3,0);
		$row_account = $this->account_model->get_by_id($this->uri->segment(3));
		if(count($row_account)>0){
			$this->load->model('account_loginout_model');
			$this->load->model('history_model');
			$Content['row_account'] = $row_account;
			$Content['rs_loginout'] = $this->account_loginout_model->get_by_acid($row_account->ac_id);
			$Content['rs_history'] = $this->history_model->get_by_acid($row_account->ac_id);
			$data['Content'] = $this->load->view('account/view', $Content, true);
			$this->load->view('template/temp_main', $data);
		}else{
			redirect('account');
		}
	}
	
	public function check_username(){
		$username = $this->input->post('username');
		$accountid = $this->input->post('accountid');
		$rs_user = $this->account_model->get_by_username($username,$accountid);
		if($rs_user->num_rows()>0){
			$row_user = $rs_user->row();
			$data = array(
				'result'=>'Y',
				'name'=>$row_user->name,
			);
		}else{
			$data = array(
				'result'=>'N'
			);
		}
		$data = json_encode($data);
		echo $data;
	}
}
