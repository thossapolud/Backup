<?php defined('BASEPATH') OR exit('No direct script access allowed');

set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Sms_compare_scb_all extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
	}
		
	public function index(){
		$this->db->select('*');
		$this->db->where('sms_from', 'SCB');
		$this->db->where('sms_create>=',date("Y-m-d", strtotime("-3 days")).' 00:00:00');
		$this->db->group_by("sms_time");
		$rs_sms = $this->db->get('tb_sms');
		if($rs_sms->num_rows()>0){
			foreach($rs_sms->result() as $row_sms){
				$datein = $row_sms->sms_time;
				$st_in = number_format($row_sms->sms_debit,2);
				
				/* ดึงรายการ ยอดฝากจาก แบงค์ เพื่อมาเช็คนำไป update ชื่อภาษาอังกฤษ ตาราง tb_users*/
				$this->db->select('*');
				$this->db->where('st_datein', $datein);
				$this->db->where('st_in', '+'.$st_in);
				$this->db->like('st_comment', 'ENET', 'both');
				$rs_statement = $this->db->get('tb_statement');
				//echo $rs_statement->num_rows(); die();
				if($rs_statement->num_rows()==1){
					$row_statement = $rs_statement->row();
					$st_comment = $row_statement->st_comment;
					$st_comment = explode('/', $row_statement->st_comment);
					$cardnumber = preg_replace("/[^0-9]/", '', $st_comment[2]); // ตัวเลขบัตรปชชที่โอนมา
					$cardnumber = (strlen($cardnumber)>4)?substr($cardnumber,-4):$cardnumber;					
					$sql = 'SELECT user_id, username, accountname FROM tb_users WHERE bank="SCB" AND RIGHT(bankno, 4)="'.$cardnumber.'"';
					$rs_users = $this->db->query($sql);
					if($rs_users->num_rows()==1){
						$row_user = $rs_users->row();
						/*อัพเดทชื่อภาษาอังกฤษ ตาราง tb_users*/
						$data = array(						
							'accountname_en'=>$row_sms->sms_fromaccount
						);
						$this->db->update('tb_users', $data, array('user_id'=>$row_user->user_id));
						if($this->db->affected_rows() > 0){
							
							echo 'Update User_id : '.$row_user->user_id.' / Username : '.$row_user->username.' / Accountname : '.$row_user->accountname.' / Accountname_en : '.$row_sms->sms_fromaccount;
							echo '<hr>';
						}
					}				
				} // End if($rs_statement->num_rows()==1){
				/* ดึงรายการ ยอดฝากจาก แบงค์ เพื่อมาเช็คนำไป update ชื่อภาษาอังกฤษ ตาราง tb_users*/
				
			}
		}		
	}	
		
	function __destruct(){
		
	}
		
}
