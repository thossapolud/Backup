<?php if( !defined('BASEPATH')) exit('No direc script access allowed');

class Login extends CI_Controller{

	public function __construct(){
		parent::__construct();		
		//if($this->session->userdata('logined'))redirect(site_url('home'));
		$this->load->library(array('auth', 'loginout_log'));
		$auth = new auth();
		$auth->is_login();
	}
	
	public function index(){
		$this->load->view('login/index');
	}

	public function check(){
		define('SITE_KEY', '6Lcu3dYUAAAAAMTVgFXDDvKVX8uSQabpPMWlZTAp');
		define('SECRET_KEY', '6Lcu3dYUAAAAAJeNAL_ijlWJnDy1A3QGwn4JdX8L');

		$post = $this->input->post();
		if($post){
			extract($post);
			//$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".SECRET_KEY."&response={$gtoken}");
			//$json_response = json_decode($response);

			//if($json_response->success == true && $json_response->score > 0.5){
				extract($post);
				$this->load->model('account_model');
				$rs_account = $this->account_model->get_by_userpass($username, $password, 'ใช้');
				if($rs_account->num_rows()>0){
					$row_account = $rs_account->row();
					$this->session->set_userdata('login', true);
					$this->session->set_userdata('ac_id', $row_account->ac_id);
					$this->session->set_userdata('level', $row_account->level);
					$this->session->set_userdata('name', $row_account->name);
					$loginout_log = new loginout_log();
					$loginout_log->save_login();
					redirect(site_url());
				}else{
					$this->session->set_flashdata('msg_error', 'Username / Password ไม่ถูกต้อง');				
					redirect(site_url('login'));
				}
				exit();
			//}else{
			//	// echo "Risky Traffic";
			//	$this->session->set_flashdata('msg_error', 'กรุณาลองใหม่อีกครั้ง');
			//	redirect(site_url('login'));
			//}
		}
	}
		
}