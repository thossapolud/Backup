<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_verifyOtp extends CI_Controller {
    public function Request_OTP(){
		$phone = $this->input->post('phone');
		$this->curl = curl_init();
		curl_setopt_array($this->curl, array(
			CURLOPT_URL => 'https://otp.thaibulksms.com/v1/otp/request',
			CURLOPT_RETURNTRANSFER => TRUE,
			CURLOPT_HEADER => FALSE,
			CURLOPT_HTTPHEADER => [
				'Accept: application/json',
				'Content-Type: application/x-www-form-urlencoded'
			],
			CURLOPT_POST => TRUE,
			CURLOPT_POSTFIELDS => 'key=1685489138010691&secret=24e84acc5cb2417aa19e884b193132ad&msisdn='.$phone,
		));
		$result = curl_exec($this->curl);
		$result = json_decode($result);
		curl_close($this->curl);
		$token = $result->data->token;
		echo $token;
	}
	public function Verify_OTP(){
		$token = $this->input->post('token');
		$otp = $this->input->post('otp');
		$this->curl = curl_init();
		curl_setopt_array($this->curl, array(
			CURLOPT_URL => 'https://otp.thaibulksms.com/v1/otp/verify',
			CURLOPT_RETURNTRANSFER => TRUE,
			CURLOPT_HEADER => FALSE,
			CURLOPT_HTTPHEADER => [
				'Accept: application/json',
				'Content-Type: application/x-www-form-urlencoded'
			],
			CURLOPT_POST => TRUE,
			CURLOPT_POSTFIELDS => 'key=1685489138010691&secret=24e84acc5cb2417aa19e884b193132ad&token='.$token.'&pin='.$otp,
		));
		$result = curl_exec($this->curl);
		$result = json_decode($result);
		curl_close($this->curl);
		echo $result;
	}
}