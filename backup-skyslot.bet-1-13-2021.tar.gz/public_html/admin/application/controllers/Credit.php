<?php defined('BASEPATH') OR exit('No direct script access allowed');

set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok');

class Credit extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library(array('auth', 'history_log'));
		$auth = new auth();
		$auth->isnot_login();
		$this->history = new history_log();
	}
	
	public function index() {
		$this->load->model('website_model');
		$this->load->model('dealer_model');
		$this->load->model('agent_model');
		$site_id = $this->input->get('wbid');
		$dealer = $this->input->get('dl');
		$agent_id = $this->input->get('agid');
		$username = $this->input->get('username');
		$this->load->model('user_model');
		
		$row_website = $this->website_model->get_by_site_id($site_id);
		if ($row_website) {
			$row_dealer = $this->dealer_model->get_by_code($dealer);
			if ($row_dealer) {
				// set html title tag
				$this->titlecomponent->add('เติม / ถอน');
				$this->titlecomponent->add($row_website->site_name);
				$this->titlecomponent->add($dealer);
				if ($agent_id) {
					$row_agent = $this->agent_model->get_by_agent_id($agent_id);
					if ($row_agent) {
						$this->titlecomponent->add($row_agent->username);
						$agent_username = $row_agent->username;
						$agent_password = $row_agent->password;
						$authcode = $row_agent->authcode;
       					$secretkey = $row_agent->secretkey;
						if ($username) {
							$Content['rs_users'] = $this->user_model->get_by_like_username($site_id, $dealer, $username, $agent_id);
						}
						$this->load->library('interface_gateway');
						$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password, $authcode, $secretkey);
						$Content['balance'] = $this->interface_gateway->get_agent_credit();
						$Content['rs_agent'] = $this->agent_model->get_by_site_id_and_dealer($site_id, $dealer);
						$Content['row_website'] = $row_website;
						$Content['dealer'] = $dealer;
						$Content['agent_id'] = $agent_id;
						$Content['ac_username'] = $agent_username;
						$Content['username'] = $username;
						$data['Content'] = $this->load->view('credit/index', $Content, true);
						$this->load->view('template/temp_main', $data);	
					} else { // Not found this agent_id data
						echo 'กรุณาตรวจสอบข้อมูล Ref.credit.index.1';
						die();
					}
				} else {
					$Content['rs_agent'] = $this->agent_model->get_by_site_id_and_dealer($site_id, $dealer);
					$Content['row_website'] = $row_website;
					$Content['dealer'] = $dealer;
					$Content['agent_id'] = $agent_id;
					$data['Content'] = $this->load->view('credit/index', $Content, true);
					$this->load->view('template/temp_main', $data);	
				}
			} else { // Not found this dealer_code data
				echo 'กรุณาตรวจสอบข้อมูล Ref.credit.index.2';
				die();
			}
		} else { // Not found this site_id data
			echo 'กรุณาตรวจสอบข้อมูล Ref.credit.index.3';
			die();
		}
	}
	
	public function editcredit() {
		$return_message = "ไม่สำเร็จ";
		$post = $this->input->post();
		if ($post) {
			extract($post);
			if ($method && ($method == 'deposit' || $method == 'withdraw')) {
				if ($method == 'deposit') {
					$topup_type = 1;
					$credit = str_replace(',', '', $credit);
				} else if ($method == 'withdraw') {
					$topup_type = 2;
					$credit = str_replace(',', '', $credit);
				}
				$this->load->model('agent_model');
				$row_agent = $this->agent_model->get_by_agent_id($ac);
				$agent_username = $row_agent->username;
				$agent_password = $row_agent->password;
				$authcode = $row_agent->authcode;
       			$secretkey = $row_agent->secretkey;
				if ($agent_username && $agent_password) {
					$this->load->library('interface_gateway');
					$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password, $authcode, $secretkey);
					$data_return = $this->interface_gateway->edit_credit($username, $topup_type, $credit);
					if ($data_return["status"] === true) {
						$data = array(
							'site_id' => $row_agent->site_id,
							'dealer' => $dealer,
							'name' => $name,
							'username' => $username,
							'agent' => $data_return["agent_name"],
							'creditagentbefore' => $data_return["agent_credit_before"],
							'creditbefore' => $data_return["credit_before"],
							'credit' => floatval($credit),
							'add_by_id' => $this->session->userdata('ac_id'),
							'add_by_name' => $this->session->userdata('name'),
							'created' => date('Y-m-d H:i:s'),
						);
						if ($method == 'deposit') {
							$action = 'เติม ' . $dealer;
							$this->db->insert('tb_deposit', $data);
						} else {
							$action = 'ถอน ' . $dealer;
							$this->db->insert('tb_withdraw', $data);
						}
						if ($this->db->affected_rows() > 0) {
							// Add History Log
							$data = array(
								'dealer' => $dealer,
								'username' => $username,
								'credit' => floatval($credit),
							);
							$this->history->save(array('action' => $action, 'user_id' => NULL, 'detail' => json_encode($data)));
							if ($method == 'deposit') {
								$noti_msg = "มีการเติมเครดิตไม่ผ่านใบงาน";
							} else {
								$noti_msg = "มีการถอนเครดิตไม่ผ่านใบงาน";
							}
							$this->load->model('website_model');
							$row_website = $this->website_model->get_by_site_id($row_agent->site_id);
							$noti_msg .= ":: เว็บ:".$row_website->site_name.". เกม:$dealer. เอเยนต์:$agent_username. ยูส:$username. ยอด:$credit บาท. โดย:".$this->session->userdata('name').".";
							$noti_msg = rawurlencode($noti_msg);
							// เรียก noti เติมเงินเข้าเกมส์ไม่สำเร็จ
							$chnoti = curl_init();
							curl_setopt($chnoti, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg));
							curl_setopt($chnoti, CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($chnoti, CURLOPT_RETURNTRANSFER, 1);
							$data = curl_exec($chnoti);	
							curl_close($chnoti);
							$return_message = "สำเร็จ";
						}
					} else {
						$return_message = "ไม่สำเร็จ " . $data_return["status_message"];
					}
				}
			}
		}
		echo $return_message;
	}
	public function deposit_withdraw() {
		$this->load->model('website_model');
		$this->load->model('dealer_model');
		$this->load->model('agent_model');
		$site_id = $this->input->get('wbid');
		$dealer = $this->input->get('dl');
		$agent_id = $this->input->get('agid');
		
		$row_website = $this->website_model->get_by_site_id($site_id);
		if ($row_website) {
			$row_dealer = $this->dealer_model->get_by_code($dealer);
			if ($row_dealer) {
				$this->titlecomponent->add('รายการเติม / ถอน');
				$this->titlecomponent->add($row_website->site_name);
				$this->titlecomponent->add($dealer);
				
				$Content['rs_agent'] = $this->agent_model->get_by_site_id_and_dealer($site_id, $dealer);
				$Content['row_website'] = $row_website;
				$Content['dealer'] = $dealer;
				$Content['agent_id'] = $agent_id;
				$data['Content'] = $this->load->view('credit/deposit-withdraw', $Content, true);
				$this->load->view('template/temp_main', $data);
			} else {
				echo 'กรุณาตรวจสอบข้อมูล Ref.credit.deposit_withdraw.1';
				die();
			}
		} else {
			echo 'กรุณาตรวจสอบข้อมูล Ref.credit.deposit_withdraw.2';
			die();
		}
	}
	public function deposit_withdraw_all() {
		$this->load->model('agent_model');
		$site_id = $this->input->get('wbid');
		$dealer = $this->input->get('dl');
		$agent_id = $this->input->get('agid');
		
		$row_agent = $this->agent_model->get_by_agent_id($agent_id);	
		if ($row_agent) {
			$agent_username = $row_agent->username;
		} else {
			$agent_username = null;
		}
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
			* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1 => '"เติม" AS type', 2 => 'name', 3 => 'username', 4 => 'creditagentbefore', 5 => 'creditbefore', 6 => 'credit', 7 => 'add_by_name', 8 => 'created');
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);
		// Select Data deposit
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if (isset($sSearch) && !empty($sSearch)) {
			for ($i = 1; $i <= count($aColumns); $i++) {
				$bSearchable = $this->input->get_post('bSearchable_' . $i, true);
				// Individual column filtering
				if (isset($bSearchable) && $bSearchable == 'true') {
					if ($aColumns[$i] == 'created') {
						if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch)) {
							//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';
							$like[] = $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($sSearch) . "%'";
						}
					} else {
						//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
						$like[] = $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($sSearch) . "%'";
					}
				}
			}
		}
		if (isset($like) && !empty($like)) {
			$where = "(" . implode(" OR ", $like) . ")";
			$this->db->where($where, NULL, FALSE);
		}
		$this->db->where('site_id', $site_id);
		$this->db->where('dealer', $dealer);
		if($agent_username)$this->db->where('agent', $agent_username);
		if ($this->session->userdata('level') != 'admin') {
			$this->db->where('add_by_id', $this->session->userdata('ac_id'));
		}
		// DB table deposit
		$sTableDeposit = 'tb_deposit';
		//
		$this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->from($sTableDeposit);
		$query1 = $this->db->get_compiled_select(); // It resets the query just like a get()
		// Select Data withdraw
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if (isset($sSearch) && !empty($sSearch)) {
			for ($i = 1; $i <= count($aColumns); $i++) {
				$bSearchable = $this->input->get_post('bSearchable_' . $i, true);
				// Individual column filtering
				if (isset($bSearchable) && $bSearchable == 'true') {
					if ($aColumns[$i] == 'created') {
						if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch)) {
							//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';
							$like[] = $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($sSearch) . "%'";
						}
					} else {
						//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
						$like[] = $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($sSearch) . "%'";
					}
				}
			}
		}
		if (isset($like) && !empty($like)) {
			$where = "(" . implode(" OR ", $like) . ")";
			$this->db->where($where, NULL, FALSE);
		}
		$this->db->where('site_id', $site_id);
		$this->db->where('dealer', $dealer);
		if($agent_username)$this->db->where('agent', $agent_username);
		if ($this->session->userdata('level') != 'admin') {
			$this->db->where('add_by_id', $this->session->userdata('ac_id'));
		}
		// Paging
		if (isset($iDisplayStart) && $iDisplayLength != '-1') {
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}
		// Ordering
		if (isset($iSortCol_0)) {
			for ($i = 0; $i < intval($iSortingCols); $i++) {
				$iSortCol = $this->input->get_post('iSortCol_' . $i, true);
				$bSortable = $this->input->get_post('bSortable_' . intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_' . $i, true);
				if ($bSortable == 'true') {
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}
		$aColumns = array(1 => '"ถอน" AS type', 2 => 'name', 3 => 'username', 4 => 'creditagentbefore', 5 => 'creditbefore', 6 => 'credit', 7 => 'add_by_name', 8 => 'created');
		// DB table withdraw
		$sTableWithdraw = 'tb_withdraw';
		//
		$this->db->select(str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$this->db->from($sTableWithdraw);
		$query2 = $this->db->get_compiled_select();
		// DB query UNION
		$rResult = $this->db->query($query1 . " UNION ALL " . $query2);
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;
		// Total data set length
		$iTotal = $rResult->num_rows();
		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array(),
		);
		foreach ($rResult->result() as $aRow) {
			$iDisplayStart = $iDisplayStart + 1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$row = array();
			$row[0] = $iDisplayStart;
			$row[1] = $aRow->type;
			$row[2] = $aRow->name;
			$row[3] = $aRow->username;
			$row[4] = $aRow->creditagentbefore;
			$row[5] = $aRow->creditbefore;
			$row[6] = $aRow->credit;
			$row[7] = $aRow->add_by_name;
			$row[8] = $aRow->created;
			$output['aaData'][] = $row;
		}
		echo json_encode($output);
	}
	public function get_player_credit() {
		$this->load->model('user_model');
		$this->load->model('agent_model');
		$return = array('errorCode' => 1, 'errorMessage' => 'ไม่สำเร็จ');
		$user_id = $this->input->post('user_id');
		$dealer = $this->input->post('dealer');
		
		$row_user = $this->user_model->get_by_id($user_id,$dealer);
		if ($row_user) {
			$row_agent = $this->agent_model->get_by_agent_id($row_user->userpass_id);
			if ($row_agent) {
				$agent_id = $row_agent->userpass_id;
				$agent_username = $row_agent->username;
				$agent_password = $row_agent->password;
				$authcode = $row_agent->authcode;
        		$secretkey = $row_agent->secretkey;
				$this->load->library('interface_gateway');
				$this->interface_gateway->set_agent_login($row_user->dealer, $agent_username, $agent_password, $authcode, $secretkey);
				$checklogin = $this->interface_gateway->check_agent_login();
				if ($checklogin) {
					$this->interface_gateway->refresh_player_credit($row_user->username);
					$data_return = $this->interface_gateway->get_player_credit($row_user->username); // get current usr credit
					$return = array(
						'errorCode' => 0,
						'errorMessage' => 'สำเร็จ',
						'creditGame' => $data_return['credit_game'],
						'creditBalance' => $data_return['credit_balance'],
						'creditTotal' => $data_return['credit_game']+$data_return['credit_balance']
					);
				}
			}
		}
		echo json_encode($return);
	}
}
