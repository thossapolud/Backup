<?php defined('BASEPATH') OR exit('No direct script access allowed');

set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
ini_set('date.timezone', 'Asia/Bangkok'); 

class Get_ktbstatement_all extends CI_Controller {
	var $auth;
	//var $history;
	var $ch;
	var $cookie;
	var $sessId;
	var $sessId_path;
	
	public function __construct(){
		parent::__construct();
		$this->ch = curl_init();
		$this->load->library(array('auth','bypasscaptcha'));
		//$this->history = new history_log();
		$cron = $this->uri->segment(5);
		if ($cron != 1) { // If not from cron job
			$this->auth = new auth();
			$this->auth->isnot_login();
		} else {
			$this->is_from_cron_job = true;
		}
		$this->load->model('website_model');
		$this->load->model('userpass_model');
		$this->load->model('transfer_channel_model');
	}
	
	public function set_ktbdate($date) {
		$date_array=explode(" ",$date);
		$ymd=explode('-',$date_array[0]);
		$newformat= $ymd[2].'-'.$ymd[1].'-'.$ymd[0].' '.$date_array[1];
		return $newformat;
	}
	
	function get_captcha(){
		$key = '0aab403ac4f7c3f7bfeeedfff51e0274'; // Key ใหม่
		$img_captcha = PUBPATH."cookie/captcha-ktb.png";		
		$value = $this->bypasscaptcha->bc_submit_captcha($key, $img_captcha);
		return $value;
	}
	
	function get_imgcaptcha(){
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.ktbnetbank.com/consumer/');
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);	
		$html = curl_exec($this->ch);
		//print_r($html);
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents			
		$img_captcha = $dom->getElementById('imageCodeDisplayId')->getAttribute('src'); // get src img captcha	
		
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.ktbnetbank.com'.$img_captcha);
		$captcha = curl_exec($this->ch);
		
		$strFileName = PUBPATH."cookie/captcha-ktb.png";
		$objFopen = fopen($strFileName, 'w');
		fwrite($objFopen, $captcha);
		fclose($objFopen);	
	}
	
	private function get_sessId($usernamebank,$bank,$acnum){
		$this->sessId_path = PUBPATH."cookie/sessId-".$bank."-".$acnum."-".$usernamebank.".txt";
		$this->sessId = $this->sessId_path;
		$sessId = @file_get_contents($this->sessId);
		return $sessId;
	}
	
	private function checklogin($sessId){	 
		//+ Get Detail For Check Login
		curl_setopt($this->ch, CURLOPT_URL,'https://www.ktbnetbank.com/consumer/SavingAccount.do?cmd=init&sessId='.$sessId.'&_=1514531984376');
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		//curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
		$xml = curl_exec($this->ch);		
		//print_r($xml);
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadXML($xml);// load it's all xml contents	
		$oid = @$dom->getElementsByTagName('OID')->item(0)->nodeValue;
		//$accountnodisplay = $dom->getElementsByTagName('ACCOUNTNODISPLAY')->item(0)->nodeValue;
		return array('oid'=>$oid);
	}
	
	private function formlogin($username,$password){
		$this->get_imgcaptcha();
		$captcha = $this->get_captcha();
		
		//+ Login
		curl_setopt($this->ch, CURLOPT_URL, 'https://www.ktbnetbank.com/consumer/Login.do'); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);  // <-- add this line
		curl_setopt($this->ch, CURLOPT_REFERER, 'https://www.ktbnetbank.com/consumer/Login.do');	
		
		$postdata = 'cmd=login&&userId='.$username.'&password='.$password.'&imageCode='.$captcha;	
		curl_setopt($this->ch, CURLOPT_POST, 1);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		$html = curl_exec($this->ch);	
		// print_r($html); die();
		$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html);// load it's all html contents			
		$header = $dom->getElementsByTagName('script')->item(5)->nodeValue;
		// print_r($dom->getElementsByTagName('script')->item(5)->nodeValue);
		// echo '<br><br>';
		// preg_match_all("#sessionKey = '(.*)';#", $header, $session);
		// $sessId = $session[1][0];
		// print_r($session);
		// die();
		//$header = $dom->getElementsByTagName('script')->item(3)->nodeValue;
		if($header){
			preg_match_all("#sessionKey = '(.*)';#", $header, $session);
			$sessId = $session[1][0];
			
			if(!$sessId){
				$header = $dom->getElementsByTagName('script')->item(3)->nodeValue;
				preg_match_all("#sessionKey = '(.*)';#", $header3, $session);
				$sessId = $session[1][0];	
				
				$sFile = $this->sessId_path;
				$objFopen = fopen($sFile, 'w');
				fwrite($objFopen, $sessId);
				fclose($objFopen);
			}else{
				$sFile = $this->sessId_path;
				$objFopen = fopen($sFile, 'w');
				fwrite($objFopen, $sessId);
				fclose($objFopen);	
			}
		}
	}
		
	public function get(){
		$bank = $this->uri->segment(3);
		$acnum = $this->uri->segment(4);
		if($bank && $bank == 'ktb' && $acnum){
			$row_userpass = $this->userpass_model->get_by_bankac($bank,$acnum);
			if ($row_userpass) {
				if ($row_userpass->autojob_status != 1 && $this->is_from_cron_job === true) {
					echo 'This acnum auto status is not active';
					die();
				} else {
					$userpass_id = $row_userpass->userpass_id;
					$usernamebank = $row_userpass->username;
					$passwordbank = $row_userpass->password;
					$bankname = $row_userpass->bankname;
					$userpass_status = $row_userpass->up_status;
				}
			} else {
				echo 'Invalid acnum';
				die();
			}
			if($usernamebank!=''&&$passwordbank!=''){
				$row_xfer = $this->transfer_channel_model->get_by_userpass_id($userpass_id);
				if ($row_xfer && $row_xfer->site_id) {
					$row_website = $this->website_model->get_by_site_id($row_xfer->site_id);
				} else {
					echo 'กรุณาตรวจสอบกลุ่มลูกค้า (transfer-channel)';
					die();	
				}			
				
				$this->cookie = PUBPATH."cookie/cookie-".$bank."-".$acnum."-".$usernamebank.".txt";
				
				$sessId = $this->get_sessId($usernamebank,$bank,$acnum);
				if($sessId){
					$checklogin = $this->checklogin($sessId);
					if(!isset($checklogin['oid'])){
						$this->formlogin($usernamebank,$passwordbank);
						$sessId = $this->get_sessId($usernamebank,$bank,$acnum);
						// echo 'b'; die();
					}
					// echo 'c'; die();
				}else{
					$this->formlogin($usernamebank,$passwordbank);
					$sessId = $this->get_sessId($usernamebank,$bank,$acnum);
					// echo 'a'; die();
				}
				
				if(isset($sessId)){
					//+ detail
					curl_setopt($this->ch, CURLOPT_URL,'https://www.ktbnetbank.com/consumer/SavingAccount.do?cmd=init&sessId='.$sessId.'&_=1514531984376');
					$xml = curl_exec($this->ch);
					$dom = new DOMDocument(); // create DOM object
					@$dom->loadXML($xml);// load it's all xml contents	
					$oid = $dom->getElementsByTagName('OID')->item(0)->nodeValue;
					$accountnodisplay = $dom->getElementsByTagName('ACCOUNTNODISPLAY')->item(0)->nodeValue;
					
					//+ Balance
					curl_setopt($this->ch, CURLOPT_CONNECTTIMEOUT, 30);
					curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:44.0) Gecko/20100101 Firefox/44.0");
					curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
					curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
					curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
					curl_setopt($this->ch, CURLOPT_HEADER, 0);
					curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);					
					curl_setopt($this->ch, CURLOPT_URL, "https://www.ktbnetbank.com/consumer/SavingAccount.do?cmd=init&sessId=$sessId&_=".rand(11111111111111111, 99999999999999999));
					$account = curl_exec($this->ch);
					$xml = simplexml_load_string($account);
					$data=array();
					foreach($xml->DATA as $x){
						if($x->OID == $oid){
							$data['index'] = trim($x->OID);
							$data['typeid'] = trim($x->TYPE);
							$data['accnumber'] = str_replace("KTB*","",trim($x->ACCOUNTNODISPLAY));
							$data['accname'] = trim($x->ACCOUNT_NAME);
							$data['balance'] = 0 + str_replace(",","",trim($x->AMOUNT));
							$data['available'] = 0 + str_replace(",","",trim($x->WITHDRAWABLE));
						}
					}					
					if(count($data)>0){
						//+ Update Balance
						$sql = "UPDATE tb_userpass SET balance='".$data['balance']."', available='".$data['available']."' WHERE userpass_id=".$userpass_id;
						$this->db->query($sql); 				
						//+ Update Balance
						$Available = preg_replace("/[^0-9\.]/", '', trim($data['available']));
					}
					// print_r($data); die();
					//+ viewStatement
					$postdata = 'from_date=&to_date=&radios=&specific_peroid=&accountNo='.$oid.'&accountNoDisp='.$accountnodisplay.'.&newAliasName=&oldAliasName=&avaliableBalance=3%2C394.29&accountSelectedItem=%5Bobject%20Object%5D&amount=&radiosEditAmount=&note=&sessId='.$sessId;
									
					curl_setopt($this->ch, CURLOPT_URL, "https://www.ktbnetbank.com/consumer/SavingAccount.do?cmd=showDetails&r=0.".rand(1000000000000000,9999999999999999));
					curl_setopt($this->ch, CURLOPT_POST, 1);
					curl_setopt($this->ch, CURLOPT_TIMEOUT, 300);
					curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
					$data = curl_exec($this->ch);
					//print_r($data); die();
					
					//+ viewStatement		
					//$postdata = 'from_date=01-01-2018&to_date=15-01-2018&radios=date_peroid&specific_peroid=currentMonth&accountNo='.$oid.'&accountNoDisp='.$accountnodisplay.'.&newAliasName=&oldAliasName=&avaliableBalance=3%2C389.29&accountSelectedItem=%5Bobject%20Object%5D&amount=&radiosEditAmount=&note=&sessId='.$sessId;		
					
					$postdata = 'from_date='.date("d-m-Y",time()).'&to_date='.date("d-m-Y",time()).'&radios=date_peroid&specific_peroid=currentMonth&accountNo='.$oid.'&accountNoDisp='.$accountnodisplay.'.&newAliasName=&oldAliasName=&avaliableBalance=3%2C394.29&accountSelectedItem=%5Bobject%20Object%5D&amount=&radiosEditAmount=&note=&sessId='.$sessId;
							
					curl_setopt($this->ch, CURLOPT_URL, 'https://www.ktbnetbank.com/consumer/SavingAccount.do?cmd=viewStatement');
					curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);
					curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);		
					curl_setopt($this->ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);		
					curl_setopt($this->ch, CURLOPT_COOKIESESSION, 0);	
					curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
					curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
					curl_setopt($this->ch, CURLOPT_POST, 1);
					curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
					$xml = curl_exec($this->ch);
					// print_r($xml);
					$dom = new DOMDocument(); // create DOM object
					@$dom->loadXML($xml);// load it's all xml contents	
					$datas = $dom->getElementsByTagName('DATA');
					$datas_len = $datas->length;
					$i = 1;
					// print_r($datas); die();
					foreach ($datas as $data) {
						if(empty($data->getElementsByTagName('ERRORMESSAGE')->item(0)->nodeValue)){
							$st_datein = $this->set_ktbdate(trim($data->getElementsByTagName('DATE')->item(0)->nodeValue));
							$amount = str_replace(',','',trim($data->getElementsByTagName('AMOUNT')->item(0)->nodeValue));
							if($amount<0){
								$st_out = trim($data->getElementsByTagName('AMOUNT')->item(0)->nodeValue);
								$st_in = NULL;
							}else{
								$st_in = trim($data->getElementsByTagName('AMOUNT')->item(0)->nodeValue);
								$st_out = NULL;
							}
							$st_balance = trim($data->getElementsByTagName('BALANCE')->item(0)->nodeValue);
							$st_comment = trim($data->getElementsByTagName('TRANSACTION')->item(0)->nodeValue).' / '.trim($data->getElementsByTagName('DESCRIPTION')->item(0)->nodeValue).' / '.trim($data->getElementsByTagName('CHEQUE_NO')->item(0)->nodeValue).' / '.trim($data->getElementsByTagName('TAX')->item(0)->nodeValue).' / '.trim($data->getElementsByTagName('BRANCH')->item(0)->nodeValue);
							
							$st_from_bank = substr(preg_replace("/[^0-9]/", '', trim($data->getElementsByTagName('DESCRIPTION')->item(0)->nodeValue)),0,3); // เลข 2 ตัวหน้า โอนมาจากธนาคารไหน
							$st_from_bank = (strlen($st_from_bank)==3)?conv_banknumtobank($st_from_bank):'';
							$st_acc = trim($data->getElementsByTagName('DESCRIPTION')->item(0)->nodeValue); // มาจากบัญชีไหน (รหัสธนาคาร-เลขบัญชีธนาคาร)
							$st_acc = substr($st_acc, -9);
							//+ สร้าง Where เพื่อเช็คข้อมูลในตาราง	
							$where_select = 'st_out= "'.$st_out.'" AND ';
							$where_select .= 'st_in= "'.$st_in.'" AND ';	
							// $where_select .= 'st_datein= "'.$st_datein.'" AND ';
							$where_select .= 'st_bank="'.$bank.'" AND ';
							$where_select .= 'st_datein>="'.date("Y-m-d", strtotime("-3 days")).' 00:00:00" AND ';
							$where_select .= 'st_ac="'.$usernamebank.'" AND ';
							$where_select .= 'DATE(st_datein) = "'.date("Y-m-d", strtotime($st_datein)).'" AND ';
							$where_select .= 'st_balance = "'.$st_balance.'" AND ';
							$where_select .= 'st_acc = "'.$st_acc.'"';
							//+ ค่าสำหรับนำไปบันทึก	
							$row_value = array(
								'st_out'=>$st_out,
								'st_in'=>$st_in,
								'st_balance'=>isset($Available)?number_format($Available,2,'.',''):'',
								'st_datein'=>$st_datein,
								'st_datein_original'=>trim($data->getElementsByTagName('DATE')->item(0)->nodeValue),							
								'st_balance'=>$st_balance,
								'st_comment'=>$st_comment,
								'st_bank'=>$bank,
								'st_ac'=>$usernamebank,
								'created'=>date('Y-m-d H:i:s'),
								'st_from_bank'=>$st_from_bank,
								'st_acc'=>$st_acc,
							);
							
							$sql = "SELECT * FROM tb_statement WHERE 1 AND ".$where_select."";
							$query = $this->db->query($sql);
							$count = $query->num_rows();
							if(!$count){
								$sql = "INSERT INTO tb_statement (".implode(", ", array_keys($row_value)).") VALUES ('".implode("', '", $row_value)."') ";
								$query = $this->db->query($sql);
								$st_id = $this->db->insert_id();
								$credit = preg_replace("/[^0-9\.]/", '', $st_in); // เครดิตที่ได้จาก รายการฝาก ธนาคาร
								if ($row_userpass->actype=='deposit') {
									if($credit!=''){
										//เริ่มทำการ เปิดใบงาน และ ฝากเงินเข้าระบบเกมส์
										$sql = 'SELECT uag.site_id, uag.dealer, us.user_id, uag.username, us.nickname, us.bankno, us.refer_id, 
up.userpass_id, up.username AS agusername, up.password AS agpassword,up.authcode,up.secretkey, uag.default_deposit FROM tb_users us LEFT JOIN tb_users_agent uag ON us.user_id=uag.user_id  LEFT JOIN tb_userpass up ON uag.userpass_id=up.userpass_id WHERE RIGHT(us.bankno, 9)="'.$st_acc.'" AND uag.uag_status = "ใช้" AND us.xfer_h_id_deposit="'.$row_xfer->xfer_h_id.'" AND us.site_id="'.$row_xfer->site_id.'" AND default_deposit="Y"';
										
										$query_user = $this->db->query($sql);
										if($query_user->num_rows()==1){
											$row_user = $query_user->row();
											$agusername = $row_user->agusername;
											$agpassword = $row_user->agpassword;
											$authcode = $row_user->authcode;
											$secretkey = $row_user->secretkey;
											$dealer = $row_user->dealer;
											$user_id = $row_user->user_id;
											$name = $row_user->nickname;
											$username = $row_user->username;
											$refer_id = $row_user->refer_id;
											$newmember = $row_user->newmember;
											$site_id = $row_user->site_id;
											$agent_id = $row_user->userpass_id;
											// เปิดใบงาน
											$data = array(
												'ws_code'=>'-',
												'site_id'=>$site_id,
												'ws_dealer'=>$dealer,
												'ws_type'=>'deposit',
												'ws_date'=>$st_datein,
												'user_id'=>$user_id,
												'ws_debank'=>$bank,
												'ws_debankac'=>$usernamebank,
												'ws_debankacnum'=>$acnum,
												'ws_debankname'=>$bankname,
												'ws_credit'=>$credit,
												'ws_total'=>$credit,
												'st_id'=>$st_id,
												// 'c_id'=> $this->is_from_cron_job ? NULL : $this->session->userdata('ac_id'),
												'c_status'=>1,
												'c_comment'=>'เปิดอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์',
												// 'b_id'=> $this->is_from_cron_job ? NULL : $this->session->userdata('ac_id'),
												'b_status'=>1,
												'b_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์',
												'b_date'=>date('Y-m-d H:i:s'),
												'created'=>date('Y-m-d H:i:s')
											);
											//$this->db->set('ws_code', 'CONCAT(DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y   \'),IFNULL((SELECT SUBSTR(`ws_code`, 14) FROM tb_worksheet AS `alias` WHERE SUBSTR(`ws_code`, 1, 10) = DATE_FORMAT(NOW()+ INTERVAL 12 HOUR, \'%d-%m-%Y\') ORDER BY created DESC LIMIT 1)+ 1,1) )', FALSE); //CAST(`ws_code` as SIGNED integer)
											$this->db->insert('tb_worksheet', $data);
											$ws_id = $this->db->insert_id();	
											if($this->db->affected_rows() > 0){
												/*อัพเดทสถานะ รายการเงินฝาก*/
												$data = array(						
													'st_status'=>1,
													'modified'=>date("Y-m-d H:i:s")
												);
												$this->db->update('tb_statement', $data, array('st_id'=>$st_id));
												/*อัพเดทสถานะ รายการเงินฝาก*/
												if($newmember=='Y'){
													/*อัพเดทใบงาน*/
													$data = array(
														'b_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์ สมาชิกใหม่ ฝากครั้งแรก',
														'modified'=>date("Y-m-d H:i:s")
													);
													$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
													
													$noti_msg = "มีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
													$noti_msg = rawurlencode($noti_msg);
													// เรียก Line เมื่อมีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก
													$chline = curl_init();
													curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
													curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
													curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
													$data = curl_exec($chline);	
													curl_close($chline);
													// เรียก Line เมื่อมีใบงานฝากจากสมาชิกใหม่ ฝากครั้งแรก
												}else{	
													// เช็คยอดฝากเท่ากันในเวลา 5 นาที
													$sqlwsfiveminute = 'SELECT ws_id FROM tb_worksheet WHERE user_id='.$user_id.' AND ws_id!='.$ws_id.' AND ws_type = "deposit" AND ws_dealer = "'.$dealer.'" AND ws_date BETWEEN "'.date('Y-m-d H:i:s',strtotime( '-2 minute' , strtotime($st_datein))).'" AND "'.date('Y-m-d H:i:s',strtotime( '+3 minute' , strtotime($st_datein))).'" AND (ws_credit="'.$credit.'"OR ws_credit="'.number_format($credit,2,'.','').'")';
													$query_wsfiveminute = $this->db->query($sqlwsfiveminute);
													if($query_wsfiveminute->num_rows()==0){
														
														if ($userpass_status == 1) {
															// ทำการฝากเงินเข้าเกมส์
															// $dataeditcredit = $this->edit_credit($agusername,$agpassword,$name,$username,$credit,$dealer,$site_id, $user_id,$authcode,$secretkey);
															$dataeditcredit = array();
															$dataeditcredit['success']=false;
														} else {
															$dataeditcredit = array();
															$dataeditcredit['success']=false;
														}
														
														// หากทำการฝากสำเร็จ
														if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
															/*อัพเดทใบงาน*/
															$data = array(						
																'de_id'=>$dataeditcredit['de_id'],
																// 'm_id'=> $this->is_from_cron_job ? NULL : $this->session->userdata('ac_id'),
																'm_status'=>1,
																'm_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์',
																'm_date'=>date('Y-m-d H:i:s'),
																'modified'=>date("Y-m-d H:i:s")
															);
															$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
															/*หาก creditbefore มากกว่า 10 ดึงโปรโมชั่นที่ลูกค้ารับ มาเช็ค ว่าทำการถอนไปหรือยัง*/
															$sql = 'SELECT pr_user_id,withdraw_pro,turn_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$dealer.'" ORDER BY created DESC limit 1';
															$query_promotion_user = $this->db->query($sql);
															if($query_promotion_user->num_rows()>0){
																$row_promotion_user = $query_promotion_user->row();
																if($row_promotion_user->withdraw_pro=='n'){
																	if($dataeditcredit['creditbefore']>10){	
																		$credit_pro_addup = $credit * $row_promotion_user->turn_pro;
																		//+ เพิ่มจำนวนเครดิตทำเทริน
																		$sql = "UPDATE tb_promotion_user SET credit_pro = credit_pro+$credit_pro_addup WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
																		$this->db->query($sql);
																		//+ สิ้นสุดเพิ่มจำนวนเครดิตทำเทริน
																	}else{
																		//+ ทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
																		$sql = "UPDATE tb_promotion_user SET withdraw_pro = 'y', note='ปรับ withdraw_pro = y เนื่องจากมียอดก่อนฝาก น้อยกว่า 10',modified='".date("Y-m-d H:i:s")."' WHERE pr_user_id=".$row_promotion_user->pr_user_id."";
																		$this->db->query($sql);
																		//+ สิ้นสุดทำการปรับยอด ที่ต้องทำเทรินก่อนถอนให้เป็น y
																	} // End if($dataeditcredit['creditbefore']>10){
																} // End if($row_promotion_user->withdraw_pro=='n'){
															} // End if($query_promotion_user->num_rows()>0){
															if ($row_website->site_line_callback_url) {
																// เช็ค gid จาก username
																$chgid = curl_init();
																curl_setopt($chgid, CURLOPT_URL, $row_website->site_line_callback_url.'?username='.$username.'');
																curl_setopt($chgid, CURLOPT_FOLLOWLOCATION, 1);
																curl_setopt($chgid, CURLOPT_RETURNTRANSFER, 1);
																$gid = curl_exec($chgid);
																curl_close($chgid);
																// เรียก Line
																$chline = curl_init();
																curl_setopt($chline, CURLOPT_URL, $row_website->site_line_callback_url.'?gid='.$gid.'&linepush=1&act=deposit&username='.$username.'&credit='.$credit.'');
																curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
																curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
																$data = curl_exec($chline);	
																curl_close($chline);
																// เรียก Line
															}
														}else{
															$noti_msg = "มีใบงานที่รอตรวจสอบ:: เว็บ:".$row_website->site_name.". เกม:$dealer. เอเยนต์:$agusername. ยูส:$username. ยอด:$credit บาท.";
															$noti_msg = rawurlencode($noti_msg);
															// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ
															$chline = curl_init();
															curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg));
															curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
															curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
															$data = curl_exec($chline);	
															curl_close($chline);
															// เรียก Line เติมเงินเข้าเกมส์ไม่สำเร็จ	
														} // End if((isset($dataeditcredit)&&$dataeditcredit['success']===true)){
												
													}else{
														/*อัพเดทใบงาน*/
														$data = array(
															'b_comment'=>'ตรวจอัตโนมัติ ขณะดึงรายการฝาก จากแบงค์ ฝากยอดเดียวกันในเวลา 5 นาที',
															'modified'=>date("Y-m-d H:i:s")
														);
														$this->db->update('tb_worksheet', $data, array('ws_id'=>$ws_id));
														$noti_msg = "มีใบงานยอดเงินเดียวกันในเวลา 5 นาที:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
														$noti_msg = rawurlencode($noti_msg);
														// เรียก Line เมื่อมีใบงานยอดเงินเดียวกันในเวลา 5 นาที
														$chline = curl_init();
														curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
														curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
														curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
														$data = curl_exec($chline);	
														curl_close($chline);
														// เรียก Line เมื่อมีใบงานยอดเงินเดียวกันในเวลา 5 นาที
													} // End if($query_wsfiveminute->num_rows()==0){
												} // End if($this->db->affected_rows() > 0){
											}
										}else{
											$noti_msg = "มียอดเงินเข้าที่ไม่ได้เปิดใบงาน:: เว็บ:".$row_website->site_name.". ธนาคาร:$bank. บัญชี:$bankname.";
											$noti_msg = rawurlencode($noti_msg);
											// เรียก Line เมื่อหาแบงค์ไม่เจอ หรือ เจอมากกว่า 1
											$chline = curl_init();
											curl_setopt($chline, CURLOPT_URL, site_url('linenotify/notifytoline/'.$noti_msg.''));
											curl_setopt($chline, CURLOPT_FOLLOWLOCATION, 1); 
											curl_setopt($chline, CURLOPT_RETURNTRANSFER, 1);
											$data = curl_exec($chline);	
											curl_close($chline);
											// เรียก Line เมื่อหาแบงค์ไม่เจอ หรือ เจอมากกว่า 1											
										} // End if($query_user->num_rows()==1){
										//เริ่มทำการ เปิดใบงาน และ ฝากเงินเข้าระบบเกมส์		
									} // End if($credit!=''){												
								}
							}
							$i++;
						}else{
							echo $data->getElementsByTagName('ERRORMESSAGE')->item(0)->nodeValue; die();
						} // End if(empty($data->getElementsByTagName('ERRORMESSAGE')->item(0)->nodeValue)){						
					} // End foreach ($datas as $data) {
						
					if($query){
						echo 'ดึงข้อมูลสำเร็จ';
					}else{
						echo 'ดึงไม่สำเร็จ';
					}					
					
				}else{
					echo 'กรุณาดึงใหม่อีกรอบ'; die();
				} // End if(isset($sessId)){
							
				curl_setopt($this->ch, CURLOPT_URL, 'https://www.ktbnetbank.com/consumer/index.jsp?logout=true');
				curl_exec($this->ch);
				curl_close($this->ch);
				//@unlink($this->cookie);				
				
			}else{
				echo 'เช็ค Username / Password Bank';
			} // End if($username!=''&&$password!=''){
		} // End if($bank && $bank!=''){
	}
	
	private function edit_credit($agent_username, $agent_password, $nickname, $username, $credit, $dealer, $site_id, $user_id,$authcode,$secretkey) {
		// return $data = array('success' => false, 'msg' => 'ปิดออโต้ไว้ก่อน');
		if ($agent_username && $agent_password && $username && $credit && $dealer && $site_id) {
			$this->load->library('interface_gateway');
			$this->interface_gateway->set_agent_login($dealer, $agent_username, $agent_password,$authcode,$secretkey);
			// Check if user receive promotion then need to refresh credit (Fix Ufa delay credit)
			$sql = 'SELECT pr_user_id,withdraw_pro FROM tb_promotion_user WHERE user_id='.$user_id.' AND pr_user_dealer="'.$dealer.'" ORDER BY created DESC limit 1';
			$query_check_promotion_user = $this->db->query($sql);
			if($query_check_promotion_user->num_rows()>0){
				$row_check_promotion_user = $query_check_promotion_user->row();
				if($row_check_promotion_user->withdraw_pro=='n'){
					$data_return = $this->interface_gateway->refresh_player_credit($username);
					if((isset($data_return)&&$data_return['status']===false)){
						return $data = array('success' => false, 'msg' => 'ไม่สามารถดึงข้อมูลเครดิตล่าสุดได้');
					}
				}
			}
			// Check if user receive promotion then need to refresh credit (Fix Ufa delay credit)
			$data_return = $this->interface_gateway->edit_credit($username, 1, $credit);
		} else {
			return $data = array('success' => false, 'msg' => 'โปรดตรวจสอบข้อมูล');
		}
		if ($data_return["status"]===true) {
			$data = array(
				'site_id' => $site_id,
				'dealer' => $dealer,
				'name' => $nickname,
				'username' => $username,
				'agent' => $data_return["agent_name"],
				'creditagentbefore' => $data_return["agent_credit_before"],
				'creditbefore' => $data_return["credit_before"],
				'credit' => $credit,
				// 'add_by_id'=> $this->is_from_cron_job ? '' : $this->session->userdata('ac_id'),
				'add_by_name'=> 'เพิ่มผ่านการดึงอัตโนมัติ',
				'created' => date('Y-m-d H:i:s'),
			);
			$this->db->insert('tb_deposit', $data);
			$de_id = $this->db->insert_id();
			if($this->db->affected_rows() > 0){
				if ($this->is_from_cron_job === false) { // If not call from cron job then insert to tb_history log
					//+ History Log 
					$data = array('dealer' => $dealer, 'username' => $username, 'credit' => $credit);
					$action = 'เติม '.$dealer;
					$this->history->save(array('action'=>$action,'user_id'=>NULL,'detail'=>json_encode($data)));
					//+
				}
			}
			$data = array('success'=>$data_return["status"],'msg'=>'Success !','de_id'=>$de_id,'creditbefore'=>$data_return["credit_before"]);
			return $data;
		}
		return $data = array('success' => false, 'msg' => 'เติมเครดิตไม่สำเร็จ');
	}
		
	function __destruct(){
		// if($this->ch) {
		// 	curl_close($this->ch);
		// }
		$this->db->close();
	}
		
}