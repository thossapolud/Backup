<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kbank_statement extends CI_Controller {

	var $auth;
	//var $history;
	
	public function __construct(){
		parent::__construct();
		$this->load->library(array('auth'));
		$this->auth = new auth();
		//$this->history = new history_log();
		$this->auth->isnot_login();		
		// $this->load->model('statement_model');
		$this->load->model('userpass_model');
		$this->titlecomponent->add('ธนาคาร');
		$this->titlecomponent->add('KBANK');	
	}

	public function ac(){
		$acnum = $this->input->get('acnum');
		if ($acnum) {
			$this->titlecomponent->add('KBANK '.$acnum);
			$row_userpass = $this->userpass_model->get_by_bankac('kbank',$acnum);
			if ($row_userpass) {
				$Content['row_userpass'] = $row_userpass;
				$data['Content'] = $this->load->view('kbank-statement/ac', $Content, true);
				$this->load->view('template/temp_main', $data);
			} else {
				echo 'ไม่พบข้อมูลบัญชีธนาคารนี้';
			}
		} else {
			echo 'ไม่พบข้อมูลบัญชีธนาคารนี้';
		}
	}
	
	public function ac_all(){
		$acnum = $this->input->get('acnum');
		$row_userpass = $this->userpass_model->get_by_bankac('kbank',$acnum);
		/* Array of database columns which should be read and sent back to DataTables. Use a space where
		* you want to insert a non-database field (for example a counter or static image)
		*/
		$aColumns = array(1=>'st_datein',2=>'st_in',3=>'st_out',4=>'st_acc',5=>'st_balance',6=>'st_comment',7=>'st_status');
		// DB table to use
		$sTable = 'tb_statement';
		//
		$iDisplayStart = $this->input->get_post('iDisplayStart', true);
		$iDisplayLength = $this->input->get_post('iDisplayLength', true);
		$iSortCol_0 = $this->input->get_post('iSortCol_0', true);
		$iSortingCols = $this->input->get_post('iSortingCols', true);
		$sSearch = $this->input->get_post('sSearch', true);
		$sEcho = $this->input->get_post('sEcho', true);
		// Paging
		if(isset($iDisplayStart) && $iDisplayLength != '-1')
		{
			$this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
		}
		// Ordering
		if(isset($iSortCol_0))
		{
			for($i=0; $i<intval($iSortingCols); $i++)
			{
				$iSortCol = $this->input->get_post('iSortCol_'.$i, true);
				$bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
				$sSortDir = $this->input->get_post('sSortDir_'.$i, true);
				if($bSortable == 'true')
				{
					$this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
				}
			}
		}
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		if(isset($sSearch) && !empty($sSearch)){
			for($i=1; $i<=count($aColumns); $i++){
				$bSearchable = $this->input->get_post('bSearchable_'.$i, true);
				// Individual column filtering
				if(isset($bSearchable) && $bSearchable == 'true'){
					if($aColumns[$i]=='st_datein'){
						//(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch))? $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch)) : '';						
						if(preg_match('/^\d{4}-\d{2}-\d{2}$/', $sSearch)){
							$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
						}						
					}else{
						//$this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
						$like[] = $aColumns[$i]." LIKE '%".$this->db->escape_like_str($sSearch)."%'";
					}
				}
			}
		}
		
		if(isset($like) && !empty($like)){
			$where = "(".implode(" OR ", $like).")";
			$this->db->where($where, NULL, FALSE);
		}
		
		// เลือกจากธนาคาร
		$this->db->where('st_bank', 'kbank');
		$this->db->where('st_ac', $row_userpass->username);
		
		// Select Data
		$this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
		$rResult = $this->db->get($sTable);		
		
		// Data set length after filtering
		$this->db->select('FOUND_ROWS() AS found_rows');
		$iFilteredTotal = $this->db->get()->row()->found_rows;
		// Total data set length
		$this->db->where('st_bank', 'kbank');
		$this->db->where('st_ac', $row_userpass->username);
		$iTotal = $this->db->count_all_results($sTable);
		// Output
		$output = array(
			'sEcho' => intval($sEcho),
			'iTotalRecords' => $iTotal,
			'iTotalDisplayRecords' => $iFilteredTotal,
			'aaData' => array()
		);		
		foreach($rResult->result() as $aRow){
			$iDisplayStart = $iDisplayStart+1; //+ นำค่าเริ่มต้นการแบ่งหน้า มาบวก 1 เพื่อแสดงจำนวนรายการแต่ละหน้า
			$st_in = preg_replace("/[^0-9\.]/", '', $aRow->st_in);
			// $st_in = ($st_in!='')?'+'.$st_in:'';
			$row = array();
			$row[0] = $iDisplayStart;		
			$row[1] = $aRow->st_datein;
			$row[2] = $st_in;
			$row[3] = $aRow->st_out;			
			$row[4] = $aRow->st_acc;
			$row[5] = $aRow->st_balance;
			$row[6] = $aRow->st_comment;
			$row[7] = $aRow->st_status;				 
			$output['aaData'][] = $row;
		}		 
		echo json_encode($output);
	}

}
