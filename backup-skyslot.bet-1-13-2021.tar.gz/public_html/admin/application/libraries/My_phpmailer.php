<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class My_phpmailer {
	public function __construct(){
		require_once('PHPMailer/class.phpmailer.php');
	}
	
	public function set_defult(){
			$mail = new PHPMailer();						
			$mail->IsHTML (true);
			$mail->SMTPAuth    = true;		
			$mail->IsSMTP(); // เปิดใช้ Smtp
			//$mail->SMTPSecure	= "ssl"; 
			$mail->CharSet = 'UTF-8';
			
			$mail->Host = 'ssl://smtp.gmail.com'; // ส่งผ่าน Smtp ของ google
			//$mail->Host = 'foo.footballsod.com';			
			$mail->Port = 465; // พอร์ต
							
			$mail->Username = 'footballsod@gmail.com'; // Account ของ Gmail
			$mail->Password = 'ClawTiger18++';
			
			//$mail->Username = 'info@gatefootball.com'; // Account ของ Gmail
			//$mail->Password = 'WebMail18++';
			
			return $mail;
	}
}