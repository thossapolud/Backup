<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Interface_royalcasino {

	protected $CI;

	private $_root_url = 'https://test.os.huoys.com/merchant';
	private $_access_token = '';
	private $_gc_thb_xr = 0.0001; // Exchange rate from 1 Game credit to Thai Baht
	private $_thb_gc_xr = 10000; // Exchange rate from 1 Thai Baht to Game credit

	public function __construct() {
		$this->CI = &get_instance();
		$this->ch = curl_init();
	}

	/**
	 * Set agent user credential for login to Royal agent website
	 *
	 * @param string $username  Set agent username
	 * @param string $password  Set agent password
	 */
	public function set_agent_login($username, $password) {
		$this->agent_username = $username;
		$this->agent_password = $password;
		$this->is_login = false;
	}

	/**
	 * Login with agent user credential
	 *
	 * @return boolean Successfully login or not
	 */
	private function _agent_login() {
		$url = $this->_root_url . '/token/'. $this->agent_username .'/' . $this->agent_password;
		curl_setopt($this->ch, CURLOPT_URL, $url);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
		$return = curl_exec($this->ch);
		$json_result = json_decode($return);

		if ($json_result->errorcode == 0 && $json_result->errormsg == 'success') {
			$this->_access_token = $json_result->data->access_token;
			// echo $this->_access_token;
			return $this->is_login = true;
		} else {
			return $this->is_login = false;
		}
	}

	/**
	 * Check agent user currently login or not.
	 * If not login then try to login to website
	 *
	 * @return boolean Currently login or not
	 */
	public function check_agent_login() {
		if ($this->is_login) {
			return $this->is_login = true;
		} else {
			return $this->is_login = $this->_agent_login();
		}
	}

	/**
	 * Edit member credit
	 * When adjust or Deposit or Withdrawal Royal user credit
	 *
	 * @param string $royal_user  Username to edit credit
	 * @param string $royal_edit_type  Edit credit type : 1=Deposit , 2=Withdrawal
	 * @param float $royal_credit_edit  Credit amount
	 * @return array  Status indicate success or fail and basic credit information
	 */
	public function edit_credit($royal_user, $royal_edit_type, $royal_credit_edit) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Royal agent website yet.
		}

		if ($check_login) {
			if ($royal_edit_type == 1) { // Deposit Credit
				$agent_credit_before = $this->get_agent_credit(); // Get current agent credit balance
				$credit_before = $this->get_user_credit($royal_user); // Get current user credit balance

				$game_credit_edit = $this->_convert_thb_to_gc($royal_credit_edit); // convert THB to GC
				$game_credit_edit = floor($game_credit_edit); // Must be number without decimal. If not Royal will return error

				$url = $this->_root_url . '/trade/'. $royal_user .'/' . $game_credit_edit;
				curl_setopt($this->ch, CURLOPT_URL, $url);
				curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
				curl_setopt($this->ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer '. $this->_access_token));
				$return = curl_exec($this->ch);
				$json_result = json_decode($return);

				if ($json_result->errorcode == 0 && $json_result->errormsg == 'success') {
					return $data_return = array(
						'status' => true,
						'credit_before' => $credit_before,
						'credit_edit' => floor($royal_credit_edit),
						'agent_name' => $this->agent_username,
						'agent_credit_before' => $agent_credit_before,
					);
				} else {
					return $data_return = array(
						'status' => false,
						'status_message' => $json_result->errormsg . ' Ref.' . $json_result->errorcode,
					);
				}
			} else { // Unknown or Unsupported credit edit type
				return $data_return = array(
					'status' => false,
					'status_message' => 'Unknown or Unsupported credit edit type',
				);
			}
		}	else { // Fail to login to agent website
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}

	/**
	 * Get agent credit balance
	 *
	 * @return float|false  Current agent credit balance or false if failed
	 */
	public function get_agent_credit() {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Royal agent website yet.
		}

		if ($check_login) {
			$url = $this->_root_url . '/me';
			curl_setopt($this->ch, CURLOPT_URL, $url);
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
			curl_setopt($this->ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer '. $this->_access_token));
			$return = curl_exec($this->ch);
			$json_result = json_decode($return);
			
			if ($json_result->errorcode == 0 && $json_result->errormsg == 'success') {
				$credit = $this->_convert_gc_to_thb($json_result->data->coin); // convert GC to THB
				return number_format($credit, 2, '.', '');
			} else { // Fail on calling api
				return false;
			}
		} else { // Fail get access token
			return false;
		}
	}

	/**
	 * Get user credit balance
	 *
	 * @param string  $royal_user  Username to get credit
	 * @return float|false  Current user credit balance or false if failed
	 */
	public function get_user_credit($royal_user) {
		$credit = 0;
		return number_format($credit, 2, '.', '');
	}

	public function create_agent() {
		$url = $this->_root_url . '/reg/'. $this->agent_username .'/' . $this->agent_password;
		curl_setopt($this->ch, CURLOPT_URL, $url);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
		$return = curl_exec($this->ch);
		$json_result = json_decode($return);

		if ($json_result->errorcode == 0 && $json_result->errormsg == 'success') {
			return $data_return = array(
				'status' => true,
				'agent_username' => $json_result->data->AppID, // AppID in Royal Casino API
				'agent_password' => $json_result->data->AppKey, // AppKey in Royal Casino API
			);
		} else { // Fail to regis new merchant (agent)
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->errormsg . ' Ref.' . $json_result->errorcode,
			);
		}
	}

	public function init_bind_agent() {
		$url = $this->_root_url . '/bind';
		curl_setopt($this->ch, CURLOPT_URL, $url);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
		curl_setopt($this->ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer '. $this->_access_token));
		$return = curl_exec($this->ch);
		$json_result = json_decode($return); // If success decode will be null because success return HTML , fail return JSON
		if ($json_result) { // Fail to get bind merchant (agent) button
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->errormsg . ' Ref.' . $json_result->errorcode,
			);
		} else {
			return $data_return = array(
				'status' => true,
				'bind_data' => $return,
			);
		}
	}


	private function _convert_gc_to_thb($in) {
		$out = $in * $this->_gc_thb_xr; // Convert GC to THB
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}

	private function _convert_thb_to_gc($in) {
		$out = $in * $this->_thb_gc_xr; // Convert THB to GC
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}

}