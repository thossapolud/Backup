<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
class Otp {
	
	protected $key = '1685489138010691';
	protected $secret = '24e84acc5cb2417aa19e884b193132ad';
	
	function Request_OTP($phone){
		$this->curl = curl_init();
		curl_setopt_array($this->curl, array(
			CURLOPT_URL => 'https://otp.thaibulksms.com/v1/otp/request',
			CURLOPT_RETURNTRANSFER => TRUE,
			CURLOPT_HEADER => FALSE,
			CURLOPT_HTTPHEADER => [
				'Accept: application/json',
				'Content-Type: application/x-www-form-urlencoded'
			],
			CURLOPT_POST => TRUE,
			CURLOPT_POSTFIELDS => 'key='.$this->key.'&secret='.$this->secret.'&msisdn='.$phone,
		));
		$result = curl_exec($this->curl);
		$result = json_decode($result);
		curl_close($this->curl);
		$token = $result->data->token;
		return $token;
    }
    function Verify_OTP($token,$pin){
		$this->curl = curl_init();
		curl_setopt_array($this->curl, array(
			CURLOPT_URL => 'https://otp.thaibulksms.com/v1/otp/verify',
			CURLOPT_RETURNTRANSFER => TRUE,
			CURLOPT_HEADER => FALSE,
			CURLOPT_HTTPHEADER => [
				'Accept: application/json',
				'Content-Type: application/x-www-form-urlencoded'
			],
			CURLOPT_POST => TRUE,
			CURLOPT_POSTFIELDS => 'key='.$this->key.'&secret='.$this->secret.'&token='.$token.'&pin='.$pin,
		));
		$result = curl_exec($this->curl);
		curl_close($this->curl);
		if (strpos($result, "success") !== false) {
			$verifyCode = array('errorCode' => 0, 'errorMessage' => 'pin ถูกต้อง');
			return $verifyCode;
		}else{
			$verifyCode = array('errorCode' => 1, 'errorMessage' => 'pin ไม่ถูกต้อง หรือ ถูกใช้งานแล้ว');
			return $verifyCode;
		}
	}	
}