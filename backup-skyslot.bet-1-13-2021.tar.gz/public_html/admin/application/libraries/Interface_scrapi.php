<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Interface_scrapi {

	protected $CI;

	private $_root_url = 'http://api.918kiss.com:9991/';
	private $_gc_thb_xr = 10; // Exchange rate from 1 Game credit to Thai Baht
	private $_thb_gc_xr = 0.1; // Exchange rate from 1 Thai Baht to Game credit

	public function __construct() {
		$this->CI = &get_instance();
	}

	/**
	 * Set agent user credential for login to Ufa agent website
	 *
	 * @param string $username  Set agent username
	 * @param string $password  Set agent password
	 */
	public function set_agent_login($username, $password, $authcode=NULL, $secretkey=NULL) {
		$this->agent_username = $username;
		$this->agent_password = $password;
		$this->is_login = false;		
		$this->authcode=$authcode;
		$this->secretkey=$secretkey;
		$this->secondPassWd='888999';
	}
	
	/**
	 * Check agent user currently login or not.
	 * If not login then try to login to website
	 *
	 * @return boolean Currently login or not
	 */
	public function check_agent_login() {
		return $this->is_login = true;
	}

	/**
	 * Edit member credit
	 * When adjust or Deposit or Withdrawal Scr user credit
	 *
	 * @param string $scr_user  Username to edit credit
	 * @param string $scr_edit_type  Edit credit type : 1=Deposit , 2=Withdrawal
	 * @param float $scr_credit_edit  Credit amount
	 * @return array  Status indicate success or fail and basic credit information
	 */
	public function edit_credit($scr_user, $scr_edit_type, $scr_credit_edit) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		
		$agent_credit_before = $this->get_agent_credit(); // Get current agent credit balance
		$arr_player_credit = $this->get_player_credit($scr_user); // Get current user credit balance
		$credit_balance = $arr_player_credit['credit_balance']; // Get current user credit balance			
		$credit_before = $credit_balance; // Set user balance before deposit or withdraw credit

		$max_value = $this->_convert_thb_to_gc($agent_credit_before);
		$score_num = $this->_convert_thb_to_gc($scr_credit_edit);

		if ($scr_edit_type == 1) { // Deposit credit
			$score_num = number_format($score_num,2,'.','');
		} else if ($scr_edit_type == 2) { // Withdrawal credit
			$score_num = '-'.number_format($score_num,2,'.','');
		} else { // Unknown or Unsupported credit edit type
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unknown or Unsupported credit edit type',
			);
		}
		
		$time = time();
		$signlower = strtolower($this->authcode.$scr_user.$time.$this->secretkey);
		$sign = strtoupper(md5($signlower));
				
		$url = $this->_root_url.'ashx/account/setScore.ashx?action=setServerScore&scoreNum='.$score_num.'&userName='.$scr_user.'&ActionUser='.$this->agent_username;
		$url .= '&ActionIp=192.0.1.1&time='.$time.'&authcode='.$this->authcode.'&sign='.$sign;
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);		
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->success===true){
			return $data_return = array(
				'status' => true,
				'credit_before' => $credit_before,
				'credit_edit' => $scr_credit_edit,
				'agent_name' => $this->agent_username,
				'agent_credit_before' => $agent_credit_before,
			);
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->msg,
			);
		}
		
		return $data_return;
	}

	/**
	 * Get agent credit balance
	 *
	 * @return float|false  Current agent credit balance or false if failed
	 */
	public function get_agent_credit(){		
		$credit = 0;
		$time = time();
		$signlower = strtolower($this->authcode.$this->agent_username.$time.$this->secretkey);
		$sign = strtoupper(md5($signlower));
		$url = $this->_root_url.'ashx/account/account.ashx?action=getUserInfo&userName='.$this->agent_username.'&time='.$time.'&authcode='.$this->authcode.'&sign='.$sign;
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);		
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->success===true){
			$credit = $this->_convert_gc_to_thb($json_result->MoneyNum); // convert GC to THB
			return number_format($credit, 2, '.', '');
		}else{
			return false;
		}
	}
	
	/**
	 * Get user credit balance
	 *
	 * @param string  $scr_user  Username to get credit
	 * @return float|false  Current user credit balance or false if failed
	 */
	public function get_player_credit($scr_user) {
		$credit_balance = 0;
		$time = time();
		$signlower = strtolower($this->authcode.$scr_user.$time.$this->secretkey);
		$sign = strtoupper(md5($signlower));		
		$url = $this->_root_url.'ashx/account/account.ashx?action=getUserInfo&userName='.$scr_user.'&time='.$time.'&authcode='.$this->authcode.'&sign='.$sign;
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);		
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->success===true){
			$credit_balance = $this->_convert_gc_to_thb($json_result->MoneyNum); // convert GC to THB
			$data_return = array(
				'status' => true,
				'player_username' =>  $scr_user,
				'credit_game' => trim(preg_replace("/[^0-9\.]/", '', '0.00')),
				'credit_balance' => trim(preg_replace("/[^0-9\.]/", '', $credit_balance))
			);
			return $data_return;
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unable to get data'
			);
		}
	}
	
	/**
	 * Create new 918Kiss user
	 * @param float $credit  Innitial Credit
	 * @return array  Status indicate success or fail. And user credential if success
	 */	
	public function create_user_auto($credit = 0, $contact = NULL) {
		
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to create new user',
		);
				
		//  RandomUserName
		$time = time();
		$signlower = strtolower($this->authcode.$this->agent_username.$time.$this->secretkey);
		$sign = strtoupper(md5($signlower));			
		$url = $this->_root_url.'ashx/account/account.ashx?action=RandomUserName';
		$url .= '&userName='.$this->agent_username.'&UserAreaId=2';
		$url .= '&time='.$time.'&authcode='.$this->authcode.'&sign='.$sign;
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);		
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		$scr_username = $json_result->account;
		$scr_password = 'Cola888abc';
		
		//  AddPlayer
		$time = time();
		$signlower = strtolower($this->authcode.$scr_username.$time.$this->secretkey);
		$sign = strtoupper(md5($signlower));			
		$url = $this->_root_url.'ashx/account/account.ashx?action=AddPlayer&agent='.$this->agent_username.'&pwdtype=1&Flag=1';
		$url .= '&PassWd='.$scr_password.'&userName='.$scr_username;
		$url .= '&Name=-&Tel=-&Memo=N/A&UserAreaId=2&UserType=1';
		$url .= '&time='.$time.'&authcode='.$this->authcode.'&sign='.$sign;
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);		
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->success===true){
			return $data_return = array(
				'status' => true,
				'username' => $scr_username,
				'password' => $scr_password,
			);
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->msg,
			);
		}

		return $data_return;
	}
	
	public function change_password($scr_user, $new_password=NULL, $contact='') {
		
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to change password',
		);
		
		$time = time();
		$signlower = strtolower($this->authcode.$scr_user.$time.$this->secretkey);
		$sign = strtoupper(md5($signlower));		
		$url = $this->_root_url.'ashx/account/account.ashx?action=editUser2&pwdtype=1&Flag=1';
		$url .= '&userName='.$scr_user.'&PassWd='.$new_password.'&Name=-&Tel=-&Memo=-';
		$url .= '&time='.$time.'&authcode='.$this->authcode.'&sign='.$sign;		
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);		
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->success===true){
			return $data_return  = array(
				'status' => true ,
				'new_password' => $new_password 
			);
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->msg,
			);
		}
		
		return $data_return;
	}

	public function edit_user($scr_user, $scr_edit_type, $password, $name, $tel, $memo) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {

		} else { // Fail to login to agent website
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}

	private function _convert_gc_to_thb($in) {
		$out = $in * $this->_gc_thb_xr; // Convert GC to THB
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}

	private function _convert_thb_to_gc($in) {
		$out = $in * $this->_thb_gc_xr; // Convert THB to GC
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}
}