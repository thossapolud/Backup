<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Interface_ufabet {

	protected $CI;

	private $_root_url = 'http://ag.ufabet.com';

	public function __construct() {
		$this->CI = &get_instance();
		$this->CI->load->helper('catcha');
	}

	/**
	 * Set agent user credential for login to Ufa agent website
	 *
	 * @param string $username  Set agent username
	 * @param string $password  Set agent password
	 */
	public function set_agent_login($username, $password) {
		$this->agent_username = $username;
		$this->agent_password = $password;
		$this->is_login = false;
	}

	/**
	 * Login with agent user credential
	 *
	 * @return boolean Successfully login or not
	 */
	private function _agent_login() {
		@unlink($this->cookie);

		//$this->ch = curl_init();
		$url = 'http://ag.ufabet.com/Public/Default11.aspx?lang=EN-US';
		curl_setopt($this->ch, CURLOPT_URL, $url);
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		$html = curl_exec($this->ch);

		$dom = new DOMDocument();
		@$dom->loadHTML($html);
		$input = $dom->getElementsByTagName('input');
		$cat = $this->_vcode();

		if ($cat) {
			$in['__VIEWSTATEGENERATOR'] = $dom->getElementById('__VIEWSTATEGENERATOR')->getAttribute('value');
			$in['__EVENTVALIDATION'] = $dom->getElementById('__EVENTVALIDATION')->getAttribute('value');
			$in['__VIEWSTATE'] = $dom->getElementById('__VIEWSTATE')->getAttribute('value');
			$in['__EVENTARGUMENT'] = $dom->getElementById('__EVENTARGUMENT')->getAttribute('value');
			$in['txtCode'] = $cat;
			$in['__EVENTTARGET'] = 'btnSignIn';
			$in['lstLang'] = 'Default11.aspx%3Flang%3DEN-US';
			$in['txtUserName'] = $this->agent_username;
			$in['txtPassword'] = $this->agent_password;

			$post = http_build_query($in);
			curl_setopt($this->ch, CURLOPT_URL, 'http://ag.ufabet.com/Public/Default11.aspx?lang=EN-US');
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($this->ch, CURLOPT_POST, 1);
			$html = curl_exec($this->ch);

			$url = 'http://ag.ufabet.com/AccInfo.aspx';
			curl_setopt($this->ch, CURLOPT_URL, $url);
			curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			$html = curl_exec($this->ch);

			@$dom = new DOMDocument();
			@$dom->loadHTML($html);
			@$input = @$dom->getElementsByTagName('input');
			@$checkinput = $dom->getElementById('__VIEWSTATEGENERATOR')->getAttribute('value');

			if ((strpos(curl_getinfo($this->ch, CURLINFO_EFFECTIVE_URL), '/Public/Default11.aspx') !== false)) {
				return $this->is_login = false;
			} else {
				return $this->is_login = true;
			}
		} else {
			return $this->is_login = false;;
		}
	}

	/**
	 * Check agent user currently login or not.
	 * If not login then try to login to website
	 *
	 * @return boolean Currently login or not
	 */
	public function check_agent_login() {
		$this->cookie = FCPATH . "temp/ufa/cookie-" . strtolower($this->agent_username) . ".txt";

		$this->ch = curl_init();
		$url = 'http://ag.ufabet.com/AccInfo.aspx';
		curl_setopt($this->ch, CURLOPT_URL, $url);
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		$html = curl_exec($this->ch);

		@$dom = new DOMDocument();
		@$dom->loadHTML($html);
		@$input = @$dom->getElementsByTagName('input');
		@$checkinput = $dom->getElementById('__VIEWSTATEGENERATOR')->getAttribute('value');

		if ((strpos(curl_getinfo($this->ch, CURLINFO_EFFECTIVE_URL), '/Public/Default11.aspx') !== false)) {
			if ($checkinput) {
				return $this->is_login = $this->_agent_login();
			} else {
				return  $this->is_login = false;
			}
		} else {
			return $this->is_login = true;
		}
	}

	/**
	 * Edit member credit
	 * When adjust or Deposit or Withdrawal Ufa user credit
	 *
	 * @param string $ufa_user  Username to edit credit
	 * @param string $ufa_edit_type  Edit credit type : 1=Deposit , 2=Withdrawal
	 * @param float $ufa_credit_edit  Credit amount
	 * @return array  Status indicate success or fail and basic credit information
	 */
	public function edit_credit($ufa_user, $ufa_edit_type, $ufa_credit_edit) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);

		$ufa_credit_edit = floor($ufa_credit_edit);

		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			$agent_credit_before = $this->get_agent_credit(); // Get current agent credit balance
			$arr_player_credit = $this->get_player_credit($ufa_user); // Get current user credit balance
			// var_dump($arr_player_credit);
			if ($ufa_edit_type == 2) {
				if (($arr_player_credit['credit_game'] + $arr_player_credit['credit_balance']) < $ufa_credit_edit) {
					// $return = array('errorCode' => 1, 'errorMessage' => 'เงินในกระเป๋าเกมไม่เพียงพอค่ะ');
					return $data_return = array(
						'status' => false,
						'status_message' => 'เงินในกระเป๋าเกมไม่เพียงพอค่ะ'.' มี:'.$arr_player_credit['credit_balance'].'/ค้าง:'.$arr_player_credit['credit_game'],
					);
				} elseif ($arr_player_credit['credit_balance'] < $ufa_credit_edit) {
					// $return = array('errorCode' => 1, 'errorMessage' => 'กรุณาโยกเงินออกจากเกม แล้วทำรายการอีกครั้งค่ะ');
					return $data_return = array(
						'status' => false,
						'status_message' => 'กรุณาโยกเงินออกจากเกม แล้วทำรายการอีกครั้งค่ะ'.' มี:'.$arr_player_credit['credit_balance'].'/ค้าง:'.$arr_player_credit['credit_game'],
					);
				}
			}
			

			$credit_balance = $arr_player_credit['credit_balance'];
			$credit_before = $arr_player_credit['credit_game'] + $arr_player_credit['credit_balance']; // Set user balance before deposit or withdraw credit

			// Start getting credit limit and prepare to edit
			$url = 'http://ag.ufabet.com/_SubAg1/MemberSet.aspx?userName=' . $ufa_user . '&set=1';
			curl_setopt($this->ch, CURLOPT_URL, $url);
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
			$html = curl_exec($this->ch);
			$dom = new DOMDocument();
			@$dom->loadHTML($html);
			$input = $dom->getElementsByTagName('input');
			$select = $dom->getElementsByTagName('select');

			foreach ($input as $input) {
				if ($input->getAttribute("type") == 'radio') {
					if ($input->hasAttribute('checked') && $input->getAttribute('checked') === "checked") {
						$inp[$input->getAttribute('name')] = $input->getAttribute('value');
					}
				} else {
					$inp[$input->getAttribute('name')] = $input->getAttribute('value');
				}
			}
			$optionTags = $dom->getElementsByTagName('option');
			foreach ($optionTags as $optionTags) {
				if ($optionTags->hasAttribute('selected') && $optionTags->getAttribute('selected') === "selected") {
					$inp[$optionTags->parentNode->getAttribute('name')] = $optionTags->getAttribute('value');
				}
			}

			$credit_limit = str_replace(',', '', $inp['txtTotalLimit']);
			$inp['__EVENTTARGET'] = 'btnUpdateC';
			// End getting credit limit and prepare to edit

			if ($ufa_edit_type == 1) { // Deposit credit
				$inp['txtTotalLimit'] = $credit_limit + $ufa_credit_edit; // Increase credit limit
				$post = http_build_query($inp);

				$url = 'http://ag.ufabet.com/_SubAg1/MemberSet.aspx?userName=' . $ufa_user . '&set=1';
				curl_setopt($this->ch, CURLOPT_URL, $url);
				curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
				curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
				curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
				curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
				curl_setopt($this->ch, CURLOPT_POST, 1);
				$html = curl_exec($this->ch);

				// $dom = new DOMDocument();
				// @$dom->loadHTML($html);
				// $credit_limit_after = str_replace(',', '', $dom->getElementById('txtTotalLimit')->getAttribute('value'));
				// if check credit_limit_after credit_limit credit_topup to check is deposit successfully or not

				return $data_return = array(
					'status' => true,
					'credit_before' => $credit_before,
					'credit_edit' => $ufa_credit_edit,
					'agent_name' => $this->agent_username,
					'agent_credit_before' => $agent_credit_before,
				);
			} else if ($ufa_edit_type == 2) { // Withdrawal credit
				if ($credit_balance >= $ufa_credit_edit) { // Check enough credit to withdrawal
					if ($credit_limit >= $ufa_credit_edit) { // If withdraw from credit limit is enough
						// Start withdraw from credit limit
						$inp['txtTotalLimit'] = max($credit_limit - $ufa_credit_edit, 0); // Decrease credit limit
						$post = http_build_query($inp);
						$url = 'http://ag.ufabet.com/_SubAg1/MemberSet.aspx?userName=' . $ufa_user . '&set=1';
						curl_setopt($this->ch, CURLOPT_URL, $url);
						curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
						curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
						curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
						curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
						curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
						curl_setopt($this->ch, CURLOPT_POST, 1);
						$html = curl_exec($this->ch);
						// End withdraw from credit limit
					} else { // If must withdraw from both credit limit and credit transfer
						// Start withdraw from credit limit to 0
						$inp['txtTotalLimit'] = 0; // Decrease credit limit
						$post = http_build_query($inp);
						$url = 'http://ag.ufabet.com/_SubAg1/MemberSet.aspx?userName=' . $ufa_user . '&set=1';
						curl_setopt($this->ch, CURLOPT_URL, $url);
						curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
						curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
						curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
						curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
						curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
						curl_setopt($this->ch, CURLOPT_POST, 1);
						$html = curl_exec($this->ch);
						// End withdraw from credit limit

						// Start withdraw from credit transfer
						$url = 'http://ag.ufabet.com/_SubAg/AccBal.aspx?role=sa&userName=' . $this->agent_username . '&searchKey=' . $ufa_user . '&pageIndex=1';
						curl_setopt($this->ch, CURLOPT_URL, $url);
						curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
						curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
						curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
						curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
						curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
						curl_setopt($this->ch, CURLOPT_POST, 1);
						$html = curl_exec($this->ch);
						$dom = new DOMDocument();
						@$dom->loadHTML($html);
						$table = $dom->getElementById('AccBal_cm1_g'); // get table contents.

						foreach ($table->getElementsByTagName('tr') as $tr) {
							$tds = $tr->getElementsByTagName('td'); // get the columns in this row
							if ((trim($tds->item(1)->nodeValue) == trim($ufa_user)) & trim($tds->item(5)->nodeValue) > 0) {
								$bb = ($tds->item(5));
								foreach ($bb->getElementsByTagName('a')->item(0)->attributes as $attribute_name => $attribute_node) {
									if ($attribute_name == 'href') {
										$url_tran = $attribute_node->nodeValue;
									}
								}
							}
						}

						if ($url_tran) {
							$url_tran = 'http://ag.ufabet.com' . $url_tran;
							curl_setopt($this->ch, CURLOPT_URL, $url_tran);
							curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
							curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
							curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
							curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
							curl_setopt($this->ch, CURLOPT_POST, 1);
							$html = curl_exec($this->ch);

							$dom = new DOMDocument();
							@$dom->loadHTML($html);
							$input = $dom->getElementsByTagName('input');

							foreach ($input as $input) {
								if ($input->getAttribute("type") == 'radio') {
									if ($input->hasAttribute('checked') && $input->getAttribute('checked') === "checked") {
										$inkk[$input->getAttribute('name')] = $input->getAttribute('value');
									}
								} else {
									$inkk[$input->getAttribute('name')] = $input->getAttribute('value');
								}
							}

							$inkk['AccPay_cm1$txtAmount'] = $credit_limit - $ufa_credit_edit; // Withdraw from credit transfer
							unset($inkk['AccPay_cm1$btnCancel']);
							$post = http_build_query($inkk);

							curl_setopt($this->ch, CURLOPT_URL, $url_tran);
							curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
							curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
							curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
							curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
							curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
							curl_setopt($this->ch, CURLOPT_POST, 1);

							$html = curl_exec($this->ch);
						}
						// End withdraw from credit transfer
					}
					return $data_return = array(
						'status' => true,
						'credit_before' => $credit_before,
						'credit_edit' => $ufa_credit_edit,
						'agent_name' => $this->agent_username,
						'agent_credit_before' => $agent_credit_before,
					);
				} else { // Not enough credit to withdrawal
					return $data_return = array(
						'status' => false,
						'status_message' => 'Not enough credit to withdrawal',
					);
				}
			} else { // Unknown or Unsupported credit edit type
				return $data_return = array(
					'status' => false,
					'status_message' => 'Unknown or Unsupported credit edit type',
				);
			}
		} else { // Fail to login to agent website
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}

	/**
	 * Get agent credit balance
	 *
	 * @return float|false  Current agent credit balance or false if failed
	 */
	public function get_agent_credit() {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			$url = 'http://ag.ufabet.com/AccInfo.aspx';

			curl_setopt($this->ch, CURLOPT_URL, $url);
			curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
			$html = curl_exec($this->ch);

			$dom = new DOMDocument();
			@$dom->loadHTML($html);
			$credit = ($dom->getElementById('lblsCredit')->lastChild->nodeValue);
			$credit = str_replace(',', '', $credit);

			return number_format($credit, 2, '.', '');
		} else {
			return false;
		}
	}

	/**
	 * Get user credit balance
	 *
	 * @param string  $ufa_user  Username to get credit
	 * @return float|false  Current user credit balance or false if failed
	 */
	public function get_user_credit($ufa_user) {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			// $url = 'http://ag.ufabet.com/_SubAg_Sub/AccBal.aspx?role=sa&userName=' . $this->agent_username . '&searchKey=' . $ufa_user . '&pageIndex=1';
			$url = 'http://ag.ufabet.com/_SubAg/AccBal.aspx?role=sa&userName=' . $this->agent_username . '&searchKey=' . $ufa_user . '&pageIndex=1';
			curl_setopt($this->ch, CURLOPT_URL, $url);
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
			// curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
			// curl_setopt($this->ch, CURLOPT_POST, 1);
			$html = curl_exec($this->ch);

			$dom = new DOMDocument();
			@$dom->loadHTML($html);
			$table = $dom->getElementById('AccBal_cm1_g'); // get table contents.

			foreach ($table->getElementsByTagName('tr') as $tr) {
				$tds = $tr->getElementsByTagName('td'); // get the columns in this row
				if ((trim($tds->item(1)->nodeValue) == trim($ufa_user)) & trim($tds->item(9)->nodeValue) >= 0) {
					$credit = trim($tds->item(9)->nodeValue);
				}
			}
			$credit = preg_replace("/[^0-9\.]/", '', $credit);
			if (is_numeric($credit)) {
				return number_format($credit, 2, '.', '');
			} else {
				return false;
			}			
		} else {
			return false;
		}
	}

	/**
	 * Get user credit balance both in and out game
	 */
	public function get_player_credit($ufa_user) {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			// $url = $this->_root_url . '/_SubAg_Sub/AccBal.aspx?role=sa&userName=' . $this->agent_username . '&searchKey=' . $ufa_user . '&pageIndex=1';
			$url = $this->_root_url . '/_SubAg/AccBal.aspx?role=sa&userName=' . $this->agent_username . '&searchKey=' . $ufa_user . '&pageIndex=1';
			curl_setopt($this->ch, CURLOPT_URL, $url);
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
			$html = curl_exec($this->ch);

			$dom = new DOMDocument();
			@$dom->loadHTML($html);
			$table = $dom->getElementById('AccBal_cm1_g'); // get table contents.

			foreach ($table->getElementsByTagName('tr') as $tr) {
				$tds = $tr->getElementsByTagName('td'); // get the columns in this row
				if ((trim($tds->item(1)->nodeValue) == trim($ufa_user))/* & trim($tds->item(9)->nodeValue) >= 0*/) {
					$data_return = array(
						'status' => true,
						'player_username' =>  trim($tr->getElementsByTagName('td')->item(1)->nodeValue),
						'credit_game' => trim(preg_replace("/[^0-9\.]/", '', $tr->getElementsByTagName('td')->item(6)->nodeValue)),
						'credit_balance' => trim(preg_replace("/[^0-9\.]/", '', $tr->getElementsByTagName('td')->item(9)->nodeValue))
					);
					return $data_return;
				}
			}
			return $data_return = array(
				'status' => false,
				'status_message' => 'Player not found'
			);
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unable to get data'
			);
		}
	}

	/**
	 * Refresh user credit in game. To get latest credit
	 */
	public function refresh_player_credit($ufa_user) {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			// $url = $this->_root_url . '/_SubAg_Sub/AccBal.aspx?role=sa&userName=' . $this->agent_username . '&searchKey=' . $ufa_user . '&pageIndex=1';
			$url = $this->_root_url . '/_SubAg/AccBal.aspx?role=sa&userName=' . $this->agent_username . '&searchKey=' . $ufa_user . '&pageIndex=1';
			curl_setopt($this->ch, CURLOPT_URL, $url);
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
			$html = curl_exec($this->ch);

			$dom = new DOMDocument();
			@$dom->loadHTML($html);
			$table = $dom->getElementById('AccBal_cm1_g'); // get table contents.

			$tr_i = 0;
			foreach ($table->getElementsByTagName('tr') as $tr) {
				$tr_i++; // Returns $tr_i, then increments $tr_i by one.
				$tds = $tr->getElementsByTagName('td'); // get the columns in this row
				if ((trim($tds->item(1)->nodeValue) == trim($ufa_user))) {
					$td_cell = $dom->getElementById('AccBal_cm1_g_ctl'.sprintf("%02d", $tr_i).'_hidId');
					$accId = $td_cell->getAttribute('value');

					$url = 'http://ag.ufabet.com/IGCashOut.aspx?accId=' . $accId;
					curl_setopt($this->ch, CURLOPT_URL, $url);
					curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
					curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
					curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
					curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
					$html = curl_exec($this->ch);
					// print_r($html);
					// die();
					$dom = new DOMDocument();
					@$dom->loadHTML($html);
					$iframe_src = $dom->getElementsByTagName('iframe')->item(0)->getAttribute('src');
					// $iframe_attr = $iframe->childNodes;

					$url_parts = parse_url($iframe_src);
					parse_str($url_parts['query'], $url_query);
					
					$param_accid = $url_query['accids'];
					$param_sid = $url_query['sid'];
					$param_agname = $url_query['aname'];
					$param_home = $url_query['home'];

					$url_ig = $iframe_src;
					curl_setopt($this->ch, CURLOPT_URL, $url_ig);
					curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
					curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
					curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
					curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
					$html = curl_exec($this->ch);

					$dom = new DOMDocument();
					@$dom->loadHTML($html);

					foreach ($dom->getElementsByTagName('thead') as $tr) {
						$refresh_success = 0;
						$refresh_fail = 0;

						$tds = $tr->getElementsByTagName('td');
						foreach ($tds as $td) {
							if ($td->nodeValue != 'Username') {
								$param_game = $td->nodeValue;

								$url_checkbalance = 'http://igtx.time399.com/apiAg.aspx?home='.$param_home.'&game='.$param_game.'&accid='.$param_accid.'&action=checkbalance&sid='.$param_sid.'&agname='.$param_agname.'';
								curl_setopt($this->ch, CURLOPT_URL, $url_checkbalance);
								curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
								curl_setopt($this->ch, CURLOPT_TIMEOUT, 3);
								curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
								curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
								$s_xml = curl_exec($this->ch);
								$o_xml = new SimpleXMLElement($s_xml);
								// var_dump($o_xml);
								// Code 0 OK
								if ($o_xml->errcode == '0') {
									$refresh_success++;
								} else {
									$refresh_fail++;
								}
							}
						}

						if ($refresh_success+$refresh_fail > 0) {
							$data_return = array(
								'status' => true,
								'refresh_success' =>  $refresh_success,
								'refresh_fail' => $refresh_fail
							);
							return $data_return;
						}
					}
					$data_return = array(
						'status' => false,
						'status_message' =>  'Unable to refresh game credit'
					);
					return $data_return;
				}
			}
			return $data_return = array(
				'status' => false,
				'status_message' => 'Player not found'
			);
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unable to get data'
			);
		}
	}

	/**
	 * Create new Ufa user
	 * @param float $credit  Innitial Credit
	 * @return array  Status indicate success or fail. And user credential if success
	 */	
	public function create_user_auto($credit = 0, $contact = NULL, $ufa_user_number = NULL) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to create new user',
		);

		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			// $credit = 0;
			/* เอาออกเพราะไม่ดึงยูสล่าสุดจากทาง Ufa
			$url = 'http://ag.ufabet.com/_SubAg/MemberList.aspx?type=member&role=sa&userName=' . $this->agent_username;
			curl_setopt($this->ch, CURLOPT_URL, $url);
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
			$html = curl_exec($this->ch);

			$dom = new DOMDocument();
			@$dom->loadHTML($html);
			$page_index = $dom->getElementById('MemberList_cm1_lblPageIndex')->nodeValue;
			$page_index = (trim($page_index));

			if ($page_index) {
				$page_index_array = explode("|", $page_index);
				$last_page = trim(end($page_index_array));
				$url = 'http://ag.ufabet.com/_SubAg/MemberList.aspx?type=member&role=sa&userName=' . $this->agent_username . '&sKey=&isDeleted=-1&sortByType=0&pageIndex=' . $last_page;
				curl_setopt($this->ch, CURLOPT_URL, $url);
				curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
				curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);

				$html = curl_exec($this->ch);
				$dom = new DOMDocument();
				@$dom->loadHTML($html);
				$table = $dom->getElementById('MemberList_cm1_g');

				foreach ($table->getElementsByTagName('table') as $tr_in) {
					$m = str_replace("Copy", "", trim($tr_in->nodeValue));
					$n = strlen(trim($m));

					if ($n == 12 || $n == 11 || $n == 13) {
						$user_array[] = $m;
					}
				}

				if ($last_page > 1) { // For safe situation. Find last gen user from one before last page too !!!!
					$pre_last_page = $last_page - 1 ;
					$url = 'http://ag.ufabet.com/_SubAg/MemberList.aspx?type=member&role=sa&userName=' . $this->agent_username . '&sKey=&isDeleted=-1&sortByType=0&pageIndex=' . $pre_last_page;
					curl_setopt($this->ch, CURLOPT_URL, $url);
					curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
					curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
	
					$html = curl_exec($this->ch);
					$dom = new DOMDocument();
					@$dom->loadHTML($html);
					$table = $dom->getElementById('MemberList_cm1_g');
	
					foreach ($table->getElementsByTagName('table') as $tr_in) {
						$m = str_replace("Copy", "", trim($tr_in->nodeValue));
						$n = strlen(trim($m));
	
						if ($n == 12 || $n == 11 || $n == 13) {
							$user_array[] = $m;
						}
					}
				}

				sort($user_array);

				if (end($user_array)) {
					$latestnumber = trim(end($user_array));
					$num = substr($latestnumber, -5);
					$textMatch = substr($latestnumber, 0, 6);
					$text = $textMatch;
					$ufa_user_number = str_pad($num + 1, 5, "0", STR_PAD_LEFT);
				} else {
					$ufa_user_number = '00001';
				}
			} else {
				$ufa_user_number = '00001';
			}
			*/

			if ($ufa_user_number) {
				$ufa_username = $this->agent_username . '' . $ufa_user_number;

				$ufa_username_master_template = $this->agent_username . '00000CP';

				/* เอาออกเพราะ gen ตาม user template
					$input = $dom->getElementsByTagName('input');

					foreach ($input as $input) {
						if ($input->getAttribute("type") == 'radio') {
							if ($input->hasAttribute('checked') && $input->getAttribute('checked') === "checked") {
								$ink[$input->getAttribute('name')] = $input->getAttribute('value');
							}
						} else {
							$ink[$input->getAttribute('name')] = $input->getAttribute('value');
						}
					}

					$ink['__EVENTTARGET'] = 'btnNew';
					$post = http_build_query($ink);
					$url = 'http://ag.ufabet.com/_SubAg/MemberList.aspx?type=member&role=sa&userName=' . $this->agent_username;
					curl_setopt($this->ch, CURLOPT_URL, $url);
					curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
					curl_setopt($this->ch, CURLOPT_POST, 1);
				*/
				$url = 'http://ag.ufabet.com/_SubAg1/MemberSet.aspx?cName='.$ufa_username_master_template.'&set=1';
				curl_setopt($this->ch, CURLOPT_URL, $url);

				$html = curl_exec($this->ch);
				$dom = new DOMDocument();
				@$dom->loadHTML($html);

				$input = $dom->getElementsByTagName('input');
				$select = $dom->getElementsByTagName('select');

				foreach ($input as $input) {
					if ($input->getAttribute("type") == 'radio') {
						if ($input->hasAttribute('checked') && $input->getAttribute('checked') === "checked") {
							$inp[$input->getAttribute('name')] = $input->getAttribute('value');
						}
					} else {
						$inp[$input->getAttribute('name')] = $input->getAttribute('value');
					}
				}

				$optionTags = $dom->getElementsByTagName('option');

				foreach ($optionTags as $optionTags) {
					if ($optionTags->hasAttribute('selected') && $optionTags->getAttribute('selected') === "selected") {
						$inp[$optionTags->parentNode->getAttribute('name')] = $optionTags->getAttribute('value');
					}
				}

				$inp['Usa'] = 'btnUsaYes';
				$aa = $inp['txtTotalLimit'];
				$inp['__EVENTTARGET'] = 'btnSave2';
				$inp['txtTotalLimit'] = $credit;
				$inp['txtPassword'] = 'aa123' . rand(100, 999) . '';
				$inp['txtUserName'] = trim($ufa_user_number);
				if ($contact) {
					$inp['txtContact'] = trim($contact);
				}
				$post = http_build_query($inp);
				$url = 'http://ag.ufabet.com/_SubAg1/MemberSet.aspx';
				curl_setopt($this->ch, CURLOPT_URL, $url);
				curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0");
				curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post);
				curl_setopt($this->ch, CURLOPT_POST, 1);
				$html = curl_exec($this->ch);

				if (preg_match('/User Name already exists/',$html)) {
					return $data_return = array(
						'status' => false,
						'status_message' => 'Username already exists'
					);
				} else {
					return $data_return = array(
						'status' => true,
						'username' => $ufa_username,
						'password' => $inp['txtPassword'],
					);
				}
			} else {
				return $data_return = array(
					'status' => false,
					'status_message' => 'Failed to create new user',
				);
			}
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}

		return $data_return;
	}

	public function change_password($ufa_user, $new_password=NULL) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to change password',
		);

		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			$ufa_user = trim($ufa_user);
			
			$url = 'http://ag.ufabet.com/_SubAg1/MemberSet.aspx?userName='.$ufa_user.'&set=1';
			curl_setopt($this->ch, CURLOPT_URL, $url); 
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);	
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 60); 	
			$html = curl_exec($this->ch);

			$dom = new DOMDocument(); // create DOM object
			@$dom->loadHTML($html);// load it's all html contents	
			$input = $dom->getElementsByTagName('input');
			$select = $dom->getElementsByTagName('select');
			
			foreach($input as $input) {
				if ($input->getAttribute("type")=='radio') {
					if ($input->hasAttribute('checked') && $input->getAttribute('checked') === "checked") {
						$inp[$input->getAttribute('name')] = $input->getAttribute('value');
					}
				} else {
					$inp[$input->getAttribute('name')] = $input->getAttribute('value');
				}
			}

			$optionTags = $dom->getElementsByTagName('option');
			foreach($optionTags as $optionTags) {
				if ($optionTags->hasAttribute('selected') && $optionTags->getAttribute('selected') === "selected") {
					$inp[$optionTags->parentNode->getAttribute('name')]  =   $optionTags->getAttribute('value');
				}
			}

			// $credit_before = $inp['txtTotalLimit'];
			// $inp['__EVENTTARGET'] = 'btnSave2';
			// $ran = rand ( 10000 , 99999 );
			// $inp['txtTotalLimit'] = str_replace(',', '', $inp['txtTotalLimit']) ;
			// $inp['txtPassword'] = 'Aaa'.$ran.'+';
			$credit_before = $inp['txtTotalLimit'];
			$inp['__EVENTTARGET'] = 'btnSave2';
			$ran = rand( 10000 , 99999 );
			$inp['txtTotalLimit'] = str_replace(',', '', $inp['txtTotalLimit']);
			if ($new_password) {
				$inp['txtPassword'] = $new_password;
			} else {
				$inp['txtPassword'] = 'Aa'.$ran.'';
			}
			
			$post = http_build_query($inp);
			$url = 'http://ag.ufabet.com/_SubAg1/MemberSet.aspx?userName='.$ufa_user.'&set=1';

			curl_setopt($this->ch, CURLOPT_URL, $url); 
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);	
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post); 
			curl_setopt($this->ch, CURLOPT_POST, 1); 
			$html = curl_exec($this->ch);
			$dom = new DOMDocument(); // create DOM object
			@$dom->loadHTML($html);// load it's all html contents	
			$credit_after = $dom->getElementById('txtTotalLimit')->getAttribute('value');

			return $data_return  = array(
				'status' => true ,
				'new_password' => $inp['txtPassword'] 
			);
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}

	/**
	 * Download CAPCHA image from ufabet and Read CAPCHA image
	 *
	 * @return string  CAPCHA characters in captcha
	 */
	private function _vcode() {
		curl_setopt($this->ch, CURLOPT_URL, 'http://ag.ufabet.com/Public/img.aspx');

		$vcode = curl_exec($this->ch);
		$strFileName = FCPATH . "temp/ufa/capcha-" . $this->agent_username . "-vcode.png";
		$objFopen = fopen($strFileName, 'w');

		fwrite($objFopen, $vcode);
		fclose($objFopen);

		// $key = '802f1c658b66950362ad0cfa4e73c274'; // GONGSUN COMMENT 13/05/2019
		// $key = 'b715a383cabf7d14d189c425da99b166'; // GONGSUN ADD 13/05/2019
		$key = '0aab403ac4f7c3f7bfeeedfff51e0274'; // GONGSUN ADD 18/06/2019
		$img_vcode = $strFileName;
		$vcode_value = bc_submit_captcha($key, $img_vcode);

		return $vcode_value;
	}
}