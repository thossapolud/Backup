<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
class Loginout_log {
	
	private $CI;
	private $_log_table_name = 'tb_account_loginout';
	
	function __construct(){
		$this->CI =& get_instance();
		$this->CI->load->database();
	}
		
	function save_login(){
		// if this domain use cloudflare then use HTTP_X_FORWARDED_FOR to get real client ip
		// else use normal CI function
		$ip_address = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $this->CI->input->ip_address();
		$data = array(
            'ac_id' => $this->CI->session->userdata('ac_id'),
            'action' => 'Login',
            'user_agent' => $this->CI->input->user_agent(),
            'ip_address' => $ip_address,
            'created' => date('Y-m-d H:i:s')
        );
        $this->CI->db->insert($this->_log_table_name, $data);
	}
	
	function save_logout(){
		// if this domain use cloudflare then use HTTP_X_FORWARDED_FOR to get real client ip
		// else use normal CI function
		$ip_address = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $this->CI->input->ip_address();
		$data = array(
            'ac_id' => $this->CI->session->userdata('ac_id'),
			'action' => 'Logout',
			'user_agent' => $this->CI->input->user_agent(),
            'ip_address' => $ip_address,
            'created' => date('Y-m-d H:i:s')
        );
        $this->CI->db->insert($this->_log_table_name, $data);
	}
	
}