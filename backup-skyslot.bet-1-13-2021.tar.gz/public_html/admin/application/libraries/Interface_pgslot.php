<?php if (!defined('BASEPATH')) {exit('No direct script access allowed');}

class Interface_pgslot{

	protected $CI;

	private $_root_url = 'https://api-prod.pgslot-api.com/';
	private $_gc_thb_xr = 10; // Exchange rate from 1 Game credit to Thai Baht
	private $_thb_gc_xr = 0.1; // Exchange rate from 1 Thai Baht to Game credit

	public function __construct() {
		$this->CI = &get_instance();
	}

	/**
	 * Set agent user credential for login to agent website
	 *
	 * @param string $username  Set agent username
	 * @param string $password  Set agent password
	 */
	public function set_agent_login($username, $password, $authcode=NULL, $secretkey=NULL) {
		$this->agent_username = $username;
		$this->agent_password = $password;
		$this->is_login = false;		
		$this->authcode=$authcode;
		$this->secretkey=$secretkey;
		$this->iterations=1000;
	}
	
	/**
	 * Check agent user currently login or not.
	 * If not login then try to login to website
	 *
	 * @return boolean Currently login or not
	 */
	public function check_agent_login() {
		return $this->is_login = true;
	}

	/**
	 * Edit member credit
	 * When adjust or Deposit or Withdrawal Pgslot user credit
	 *
	 * @param string $pgslotuser  Username to edit credit
	 * @param string $pgslotedit_type  Edit credit type : 1=Deposit , 2=Withdrawal
	 * @param float $pgslotcredit_edit  Credit amount
	 * @return array  Status indicate success or fail and basic credit information
	 */
	public function edit_credit($pgslotuser, $pgslotedit_type, $pgslotcredit_edit) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		
		$agent_credit_before = $this->get_agent_credit(); // Get current agent credit balance

		if ($pgslotedit_type == 1) { // Deposit credit
			$amount = number_format($pgslotcredit_edit,2,'.','');
			$url = $this->_root_url.'partner/deposit';
		} else if ($pgslotedit_type == 2) { // Withdrawal credit
			$amount = number_format($pgslotcredit_edit,2,'.','');
			$url = $this->_root_url.'partner/withdraw';
		} else { // Unknown or Unsupported credit edit type
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unknown or Unsupported credit edit type',
			);
		}
		
		$post = array("username" => $pgslotuser, "amount"=>$amount, "agent" => $this->agent_username);
		$password = json_encode($post);
		$hash = hash_pbkdf2('sha512', $password, $this->secretkey, $this->iterations, 64, true);
		$signature = base64_encode($hash);
		
		//  Deposit OR Withdraw
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'x-amb-signature: '.$signature));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $password);
		$result = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->status->code===0){
			return $data_return = array(
				'status' => true,
				'credit_before' => $json_result->data->balance->before,
				'credit_edit' => $pgslotcredit_edit,
				'agent_name' => $this->agent_username,
				'agent_credit_before' => $agent_credit_before,
			);
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->status->message,
			);
		}		
		return $data_return;
	}

	/**
	 * Get agent credit balance
	 *
	 * @return float|false  Current agent credit balance or false if failed
	 */
	public function get_agent_credit(){		
		$agentcredit = 0;
		return $agentcredit;
	}
	
	/**
	 * Get user credit balance
	 *
	 * @param string  $pgslotuser  Username to get credit
	 * @return float|false  Current user credit balance or false if failed
	 */
	public function get_player_credit($pgslotuser) {
				
		$post = array("username" => $pgslotuser, "agent" => $this->agent_username);
		$password = json_encode($post);
		$hash = hash_pbkdf2('sha512', $password, $this->secretkey, $this->iterations, 64, true);
		$signature = base64_encode($hash);
		
		//  Get Player Credit
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->_root_url."partner/balance");
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'x-amb-signature: '.$signature));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $password);
		$result = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->status->code===0){
			$credit_balance = $json_result->data->balance;
			$data_return = array(
				'status' => true,
				'player_username' =>  $pgslotuser,
				'credit_game' => trim(preg_replace("/[^0-9\.]/", '', '0.00')),
				'credit_balance' => trim(preg_replace("/[^0-9\.]/", '', $credit_balance))
			);
			return $data_return;
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->status->message,
			);
		}
	}
	
	/**
	 * Create new Pgslot user
	 * @param float $credit  Innitial Credit
	 * @return array  Status indicate success or fail. And user credential if success
	 */	
	public function create_user_auto($credit = 0, $contact = NULL) {
		
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to create new user',
		);
				
		//  Username / Password
		$pgslot_username = $this->generate_username();
		$pgslot_password = 'Skybet4abc';
		
		$post = array("username" => $pgslot_username, "password" => $pgslot_password, "agent" => $this->agent_username);
		$password = json_encode($post);
		$hash = hash_pbkdf2('sha512', $password, $this->secretkey, $this->iterations, 64, true);
		$signature = base64_encode($hash);
		
		//  AddPlayer
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->_root_url."partner/create");
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'x-amb-signature: '.$signature));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $password);
		$result = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->status->code===0){
			return $data_return = array(
				'status' => true,
				'username' => $pgslot_username,
				'password' => $pgslot_password,
			);
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->status->message,
			);
		}
		return $data_return;
	}
	
	public function change_password($pgslotuser, $new_password=NULL, $contact='') {
		
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to change password',
		);
		
		$post = array("username" => $pgslotuser, "newPassword" => $new_password, "agent" => $this->agent_username);
		$password = json_encode($post);
		$hash = hash_pbkdf2('sha512', $password, $this->secretkey, $this->iterations, 64, true);
		$signature = base64_encode($hash);
		
		//  Change Password
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->_root_url.'partner/password');
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'x-amb-signature: '.$signature));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $password);
		$result = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->status->code===0){
			return $data_return  = array(
				'status' => true ,
				'new_password' => $new_password 
			);
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->status->message,
			);
		}
		
		return $data_return;
	}
	
	/**
	 * Get Login Token
	 *
	 * @param string  $pgslotuser  Username to get Token
	 * @return float|false LoginToken or false if failed
	 */
	public function get_token($pgslotuser){
		
		$post = array("username" => $pgslotuser, "agent" => $this->agent_username);
		$password = json_encode($post);
		$hash = hash_pbkdf2('sha512', $password, $this->secretkey, $this->iterations, 64, true);
		$signature = base64_encode($hash);
		
		//  Launch Game
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->_root_url.'partner/launch');
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'x-amb-signature: '.$signature));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $password);
		$result = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->status->code===0){
			$data_return = array(
				'status' => true,
				'player_username' =>  $pgslotuser,
				'token' => '',
				'url' => $json_result->data->url
			);
			return $data_return;
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->status->message,
			);
		}
	}

	public function edit_user($pgslotuser, $pgslotedit_type, $password, $name, $tel, $memo) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {

		} else { // Fail to login to agent website
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}
	
	private function generate_username(){
		$last = date('ym').sprintf('%03d', rand(0, 999));
		$ref = 'skb';
		$username = $ref.$last;
		return $username;
	}
	
	private function _convert_gc_to_thb($in) {
		$out = $in * $this->_gc_thb_xr; // Convert GC to THB
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}

	private function _convert_thb_to_gc($in) {
		$out = $in * $this->_thb_gc_xr; // Convert THB to GC
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}
}