<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}
require '../cloudflare-bypass-master/src/autoload.php';
use CloudflareBypass\RequestMethod\CFCurl;

class Interface_scr {

	protected $CI;

	private $_root_url = 'https://kiosk.918kiss.com/';
	private $_gc_thb_xr = 10; // Exchange rate from 1 Game credit to Thai Baht
	private $_thb_gc_xr = 0.1; // Exchange rate from 1 Thai Baht to Game credit

	public function __construct() {
		$this->CI = &get_instance();
	}

	/**
	 * Set agent user credential for login to Ufa agent website
	 *
	 * @param string $username  Set agent username
	 * @param string $password  Set agent password
	 */
	public function set_agent_login($username, $password) {
		$this->agent_username = $username;
		$this->agent_password = $password;
		$this->is_login = false;
		$this->secondPassWd='888999';
	}

	/**
	 * Login with agent user credential
	 *
	 * @return boolean Successfully login or not
	 */
	private function _agent_login() {
		@unlink($this->cookie);

		$postdata = "userName=".$this->agent_username."&passWd=".rawurlencode($this->agent_password)."&action=login&country=N%2FA&city=N%2FA";
		curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'login/WebUserLogin.ashx');
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
		curl_setopt($this->ch, CURLOPT_REFERER, $this->_root_url.'Login.aspx?rt='.(float)rand()/(float)getrandmax());
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 120); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($this->ch, CURLOPT_POST, 1); 
		$return = curl_exec($this->ch);
		//print_r($return); die();
		// var_dump($return);		
		curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'com/com_CheckPrivatePwd.aspx?accName='.$this->agent_username.'&?rid=5dmb34ldFa'); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
		curl_setopt($this->ch, CURLOPT_REFERER, $this->_root_url.'Login.aspx?rt='.(float)rand()/(float)getrandmax());
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 120); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		$return = curl_exec($this->ch);
		//print_r($return); die();
		// var_dump($return);
		$postdata = "userName=".$this->agent_username."&secondPassWd=".$this->secondPassWd."&action=CheckSecondPwd&CurDateTime=".time();	
		curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'login/WebUserLogin.ashx'); 
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
		curl_setopt($this->ch, CURLOPT_REFERER, $this->_root_url.'com/com_CheckPrivatePwd.aspx?accName='.$this->agent_username.'&?rid=5dmb34ldFa');
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 120); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie); 
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($this->ch, CURLOPT_POST, 1); 
		$return = curl_exec($this->ch);		
		//print_r($return); die();
		// var_dump($return);
		
		$json_result = json_decode($return);

		if ($json_result->success == true && $json_result->msg == "successful operation.") {
			return $this->is_login = true;
		} else {
			return $this->is_login = false;
		}
	}

	/**
	 * Check agent user currently login or not.
	 * If not login then try to login to website
	 *
	 * @return boolean Currently login or not
	 */
	public function check_agent_login() {
		$this->cookie = FCPATH . "temp/scr/cookie-" . strtolower($this->agent_username) . ".txt";

		$this->ch = curl_init();

		$curl_cf_wrapper = new CFCurl(array(
			'max_retries'   => 5,                   // How many times to try and get clearance?
			'cache'         => false,               // Enable caching?
			'cache_path'    => __DIR__ . '/cache',  // Where to cache cookies? (Default: system tmp directory)
			'verbose'       => false                 // Enable verbose? (Good for debugging issues - doesn't effect cURL handle)
		));
		
		$postdata = "action=CheckLogin&CurDateTime=".time();
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 120); 
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'ashx/login/CheckLogin.ashx');		
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($this->ch, CURLOPT_POST, 1);		
		$return = $curl_cf_wrapper->exec($this->ch); // Done! NOTE: HEAD requests not supported!		
		//$html = curl_exec($this->ch);
		$json_result = json_decode($return);
		//print_r($json_result); die();
		// var_dump($return);
		
		if ($json_result->msg=='noData'||$json_result->msg=='no Data'||$json_result->msg=='Re logged in') {
			return $this->is_login = $this->_agent_login();
		} else {
			return $this->is_login = true;
		}
	}

	/**
	 * Edit member credit
	 * When adjust or Deposit or Withdrawal Scr user credit
	 *
	 * @param string $scr_user  Username to edit credit
	 * @param string $scr_edit_type  Edit credit type : 1=Deposit , 2=Withdrawal
	 * @param float $scr_credit_edit  Credit amount
	 * @return array  Status indicate success or fail and basic credit information
	 */
	public function edit_credit($scr_user, $scr_edit_type, $scr_credit_edit) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			$agent_credit_before = $this->get_agent_credit(); // Get current agent credit balance
			$arr_player_credit = $this->get_player_credit($scr_user); // Get current user credit balance
			$credit_balance = $arr_player_credit['credit_balance']; // Get current user credit balance			
			$credit_before = $credit_balance; // Set user balance before deposit or withdraw credit

			$max_value = $this->_convert_thb_to_gc($agent_credit_before);
			$score_num = $this->_convert_thb_to_gc($scr_credit_edit);

			if ($scr_edit_type == 1) { // Deposit credit
				$score_num = number_format($score_num,2,'.','');
			} else if ($scr_edit_type == 2) { // Withdrawal credit
				$score_num = '-'.number_format($score_num,2,'.','');
			} else { // Unknown or Unsupported credit edit type
				return $data_return = array(
					'status' => false,
					'status_message' => 'Unknown or Unsupported credit edit type',
				);
			}

			// Set score
			$postdata = "action=setServerScore&scoreNum=".$score_num."&userName=".$scr_user."&MaxNum=".$max_value."&CurDateTime=".time();
			curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'ashx/account/setScore.ashx');	
			curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
			curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0"); 
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 120); 
			curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1); 
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1); 
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
			curl_setopt($this->ch, CURLOPT_POST, 1); 
			$return = curl_exec($this->ch);
			$json_result = json_decode($return);
			// print_r($return);
			// var_dump($return);

			if($json_result->success===true){	
				return $data_return = array(
					'status' => true,
					'credit_before' => $credit_before,
					'credit_edit' => $scr_credit_edit,
					'agent_name' => $this->agent_username,
					'agent_credit_before' => $agent_credit_before,
				);
			} else {
				return $data_return = array(
					'status' => false,
					'status_message' => $json_result->msg,
				);
			}
		} else { // Fail to login to agent website
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}

	/**
	 * Get agent credit balance
	 *
	 * @return float|false  Current agent credit balance or false if failed
	 */
	public function get_agent_credit() {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			$postdata = "action=GetCurrScore&CurDateTime=".time();
			curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'ashx/getData/GetCurrScore.ashx');
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
			curl_setopt($this->ch, CURLOPT_POST, 1); 
			$return = curl_exec($this->ch);		
			$json_result = json_decode($return);
			// print_r($return);
			// var_dump($return);
			if($json_result->success===true){
				$credit = $this->_convert_gc_to_thb($json_result->results->ScoreNum); // convert GC to THB
				return number_format($credit, 2, '.', '');
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	/**
	 * Get user credit balance
	 *
	 * @param string  $scr_user  Username to get credit
	 * @return float|false  Current user credit balance or false if failed
	 */
	public function get_player_credit($scr_user) {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			$postdata = "action=getUserInfo&userName=".$scr_user."&Type=setServerScore";
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'ashx/account/account.ashx');
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
			curl_setopt($this->ch, CURLOPT_POST, 1);		
			$return = curl_exec($this->ch);
			$json_result = json_decode($return);
			// print_r($return);
			// var_dump($return);
			if($json_result->success===true){
				$credit_balance = $this->_convert_gc_to_thb($json_result->ScoreNum); // convert GC to THB
				$data_return = array(
					'status' => true,
					'player_username' =>  $scr_user,
					'credit_game' => trim(preg_replace("/[^0-9\.]/", '', '0.00')),
					'credit_balance' => trim(preg_replace("/[^0-9\.]/", '', $credit_balance))
				);
				return $data_return;
			}else{
				return $data_return = array(
					'status' => false,
					'status_message' => 'Unable to get data'
				);
			}
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unable to get data'
			);
		}
	}
	
	/**
	 * Create new 918Kiss user
	 * @param float $credit  Innitial Credit
	 * @return array  Status indicate success or fail. And user credential if success
	 */	
	public function create_user_auto($credit = 0, $contact = NULL) {
		
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to create new user',
		);

		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {			
			$check_login = $this->check_agent_login(); // Check is login to Pussy agent website yet.
			
		}

		if ($check_login) {

			// Get Data AddPlayer
			curl_setopt($this->ch, CURLOPT_TIMEOUT, 120);
			curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'com/com_AddPlayer.aspx?sid='.$this->agent_username.'&action=addPlayer&rid=5dmb34ldFa');
			$html = curl_exec($this->ch);
			
			$dom = new DOMDocument(); // create DOM object
			@$dom->loadHTML($html);// load it's all html contents			
			//$s_playerID = $dom->getElementById('s_playerID')->nodeValue; // s_playerID
			$script = $dom->getElementsByTagName('script')->item(9)->nodeValue;
			
			if($script){
				//preg_match_all('#value="(.*?)"#is', $script, $matches);
				preg_match_all('#val\("(.*?)"#is', $script, $matches);
				preg_match_all('#maxValue = "(.*?)"#is', $script, $maxvalue);
				if(count($matches)==2){
														
					$scr_username = str_replace(array('val("','"'),array('',''),$matches[0][0]);
					$max_value = $maxvalue[1][0]; //$this->get_agent_credit(); // Get current agent credit balance
					$scr_password = 'Cola888abc';
		
					// AddPlayer
					$postdata = 'action=addUser&agent='.str_replace('sub','',$this->agent_username).'&userName='.$scr_username.'&PassWd='. $scr_password.'&Name='.rawurlencode('-').'&Tel=-&Memo=&UserType=1&scoreNum=0&MaxNum='.$max_value.'&CurDateTime='.time();				
					curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'ashx/account/account.ashx');						
					curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
					curl_setopt($this->ch, CURLOPT_POST, 1);						
					$html = curl_exec($this->ch);
					$html = json_decode($html);								
					$msg = '';	
					if($html->success===true){
						return $data_return = array(
							'status' => true,
							'username' => $scr_username,
							'password' => $scr_password,
						);
					} else {
						return $data_return = array(
							'status' => false,
							'status_message' => 'Failed to create new user',
						);
					}
				}
			}
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}

		return $data_return;
	}
	
	public function change_password($scr_user, $new_password=NULL, $contact='') {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to change password',
		);

		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {
			$scr_user = trim($scr_user);
								
			// Edit Player
			$postdata = 'action=EditAccount&agent='.str_replace('sub','',$this->agent_username).'&userName='.$scr_user.'&flag=1&PassWd='.rawurlencode($new_password).'&Name='.rawurlencode('-').'&Tel='.rawurlencode($contact).'&Memo=&CurDateTime='.time();
			curl_setopt($this->ch, CURLOPT_URL, $this->_root_url.'ashx/account/AccountInfo.ashx');
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata); 
			curl_setopt($this->ch, CURLOPT_POST, 1);
			curl_exec($this->ch); 
			$html = curl_exec($this->ch);
			$html = json_decode($html);
			
			if($html->success===true){
				return $data_return  = array(
					'status' => true ,
					'new_password' => $new_password 
				);
			}
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}

	public function edit_user($scr_user, $scr_edit_type, $password, $name, $tel, $memo) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {

		} else { // Fail to login to agent website
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}

	private function _convert_gc_to_thb($in) {
		$out = $in * $this->_gc_thb_xr; // Convert GC to THB
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}

	private function _convert_thb_to_gc($in) {
		$out = $in * $this->_thb_gc_xr; // Convert THB to GC
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}
}