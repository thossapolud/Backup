<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Interface_gclub {

	protected $CI;

	public function __construct() {
		$this->CI = &get_instance();

		$this->url = 'http://act.gclub168.com/manage/jxs/';
	}

	/**
	 * Set agent user credential for login to Gclub agent website
	 *
	 * @param string $username  Set agent username
	 * @param string $password  Set agent password
	 */
	public function set_agent_login($username, $password) {
		$this->agent_username = $username;
		$this->agent_password = $password;
		$this->is_login = false;
	}

	/**
	 * Login with agent user credential
	 *
	 * @return boolean Successfully login or not
	 */
	private function _agent_login() {
		@unlink($this->cookie);

		$url = 'http://act.gclub168.com/manage/jxs/';
		$postdata = "languages=En&user=" . $this->agent_username . "&pass=" . $this->agent_password;
		$url_login = $url . "login.jsp";
		curl_setopt($this->ch, CURLOPT_URL, $url_login);
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($this->ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0");
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 60);
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie);
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie); // <-- add this line
		curl_setopt($this->ch, CURLOPT_REFERER, $url);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($this->ch, CURLOPT_POST, 1);
		curl_exec($this->ch);
		$postdata = "enable=1&orderby=3&ad_sc=1&pages=1&append=Add&setss=1";
		$url_grab = $url . 'member/members.jsp';
		curl_setopt($this->ch, CURLOPT_URL, $url_grab);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($this->ch, CURLOPT_POST, 1);
		$html = curl_exec($this->ch);

		@$dom = new DOMDocument(); // create DOM object
		@$dom->loadHTML($html); // load it's all html contents
		@$table = @$dom->getElementsByTagName('table')->item(2);

		if ($table) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check agent user currently login or not.
	 * If not login then try to login to website
	 *
	 * @return boolean Currently login or not
	 */
	public function check_agent_login() {
		$this->cookie = FCPATH . "temp/gclub/cookie-" . strtolower($this->agent_username) . ".txt";

		$this->ch = curl_init();
		$url = 'http://act.gclub168.com/manage/jxs/';
		$url_grab = $url . 'member/members.jsp';
		$postdata = "enable=1&orderby=3&ad_sc=1&pages=1&append=Add&setss=1";
		curl_setopt($this->ch, CURLOPT_URL, $url_grab);
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_POST, 1);
		$html = curl_exec($this->ch);

		$dom = new DOMDocument();
		@$dom->loadHTML($html);
		$table = @$dom->getElementsByTagName('table')->item(2);

		if ($table) {
			return true;
		} else {
			return $this->_agent_login();
		}
	}

	/**
	 * Edit member credit
	 * When adjust or Deposit or Withdrawal Gclub user credit
	 *
	 * @param string $gclub_user  Username to edit credit
	 * @param string $gclub_edit_type  Edit credit type : 1=Deposit , 2=Withdrawal
	 * @param float $gclub_credit_edit  Credit amount
	 * @return array  Status indicate success or fail and basic credit information
	 */
	public function edit_credit($gclub_user, $gclub_edit_type, $gclub_credit_edit) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);

		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Gclub agent website yet.
		}

		if ($check_login) {
			$agent_credit_before = $this->get_agent_credit(); // Get current agent credit balance

			$d = $this->update_gclub_auto($gclub_user);
			extract($d);
			$type = $gclub_edit_type; // 1= เติม 2 = ตัด
			$credit = $gclub_credit_edit;
			$postdata = "agent_id=$gclub_agent_token&id=$gclub_token&c_fid=$gclub_agent_token&c_id=$gclub_token&types=$type&number=$credit&Remark=";
			$url_editcredit = $this->url . 'member/members_update.jsp';
			curl_setopt($this->ch, CURLOPT_URL, $url_editcredit);
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			curl_setopt($this->ch, CURLOPT_POST, 1);
			$html = curl_exec($this->ch);
			$dom = new DOMDocument(); // create DOM object
			@$dom->loadHTML($html); // load it's all html contents
			$tableval = $dom->getElementsByTagName('table')->item(3)->nodeValue;
			$find = 'successful';
			$pos = strpos($tableval, $find);
			if ($pos !== false) {
				// return true;
				return $data_return = array(
					'status' => true,
					'credit_before' => $credit_before,
					'credit_edit' => $gclub_credit_edit,
					'agent_name' => $this->agent_username,
					'agent_credit_before' => $agent_credit_before,
				);
			} else {
				return false;
			}
		}

		return $data_return;
	}

	/**
	 * Get agent credit balance
	 *
	 * @return float|false  Current agent credit balance or false if failed
	 */
	public function get_agent_credit() {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Gclub agent website yet.
		}

		if ($check_login) {
			$postdata = "enable=1&orderby=3&ad_sc=1&pages=1&append=Add&setss=1";
			$url_grab = $this->url . 'member/members.jsp';
			curl_setopt($this->ch, CURLOPT_URL, $url_grab);
			curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie);
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($this->ch, CURLOPT_POST, 1);
			$html = curl_exec($this->ch);
			$dom = new DOMDocument();
			@$dom->loadHTML($html);
			$inputs = $dom->getElementsByTagName('input');
			foreach ($inputs as $input) {
				if ($input->getAttribute('name') == 'F_Now_XinYong') {
					$agent_credit = $input->getAttribute('value');
					break;
				}
			}
			return $agent_credit;

			// return number_format($credit, 2, '.', '');
		} else {
			return false;
		}
	}

	/**
	 * Get user credit balance
	 *
	 * @param string  $gclub_user  Username to get credit
	 * @return float|false  Current user credit balance or false if failed
	 */
	public function get_user_credit($gclub_user) {
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Gclub agent website yet.
		}

		if ($check_login) {
			for ($p = 1; $p <= 99; $p++) {
				$postdata = "enable=1&orderby=3&ad_sc=1&pages=" . $p . "&append=Add&setss=1";
				$url_grab = $this->url . 'member/members.jsp';
				curl_setopt($this->ch, CURLOPT_URL, $url_grab);
				curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
				curl_setopt($this->ch, CURLOPT_POST, 1);
				$html = curl_exec($this->ch);
				$dom = new DOMDocument(); // create DOM object
				@$dom->loadHTML($html); // load it's all html contents
				$table2 = $dom->getElementsByTagName('table')->item(2); // get table contents.
				$stringtable2 = $dom->saveHTML($table2); // save html table 1
				$trs = $table2->getElementsByTagName('tr'); // get this row
				$trs_row = $trs->length;
				$i = 1;
				if ($trs_row > 2) {
					foreach ($table2->getElementsByTagName('tr') as $tr) {
						if ($i != 1 && $i != $trs_row) {
							$tds = $tr->getElementsByTagName('td'); // get the columns in this row
							$urlitem = parse_url($tds->item(6)->getElementsByTagName('a')->item(3)->getAttribute('href'));
							parse_str($urlitem['query'], $query);
							// $num_member++;
							if ($gclub_user == trim($tds->item(1)->nodeValue)) {
								// echo $stringtable2;
								$credit = trim($tds->item(3)->nodeValue);
								$credit = preg_replace("/[^0-9\.]/", '', $credit);
								if (is_numeric($credit)){
									return number_format($credit, 2, '.', '');
								} else {
									return false;
								}
							}
						}
						$i++;
					}
				} else {
					return false;
				}
			}
			return false;	
		} else {
			return false;
		}
	}

	// get token for edit credit
	private function update_gclub_auto($gclub_user) {
		for ($p = 1; $p <= 99; $p++) {
			$postdata = "enable=1&orderby=3&ad_sc=1&pages=" . $p . "&append=Add&setss=1";
			$url_grab = 'http://act.gclub168.com/manage/jxs/member/members.jsp';
			curl_setopt($this->ch, CURLOPT_URL, $url_grab);
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $postdata);
			curl_setopt($this->ch, CURLOPT_POST, 1);
			$html = curl_exec($this->ch);
			$dom = new DOMDocument(); // create DOM object
			@$dom->loadHTML($html); // load it's all html contents
			$table2 = $dom->getElementsByTagName('table')->item(2); // get table contents.
			$stringtable2 = $dom->saveHTML($table2); // save html table 1
			$trs = $table2->getElementsByTagName('tr'); // get this row
			$trs_row = $trs->length;
			$i = 1;
			if ($trs_row > 2) {
				foreach ($table2->getElementsByTagName('tr') as $tr) {
					if ($i != 1 && $i != $trs_row) {
						$tds = $tr->getElementsByTagName('td'); // get the columns in this row
						$urlitem = parse_url($tds->item(6)->getElementsByTagName('a')->item(3)->getAttribute('href'));
						parse_str($urlitem['query'], $query);
						// $num_member++;
						if ($gclub_user == trim($tds->item(1)->nodeValue)) {
							// echo $stringtable2;
							$data['gclub_user'] = trim($tds->item(1)->nodeValue);
							$data['credit_before'] = trim($tds->item(3)->nodeValue);
							$data['gclub_token'] = $query['id'];
							$data['gclub_agent_user'] = $this->agent_username;
							$data['gclub_agent_token'] = $query['agent_id'];
							return $data;
						}
					}
					$i++;
				}
			} else {
				return false;
			}
		}
		return false;
	}
}