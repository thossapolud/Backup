<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Interface_gateway {

	protected $CI;

	public function __construct() {
		$this->CI = &get_instance();
	}

	public function set_agent_login($dealer, $username, $password, $authcode=NULL, $secretkey=NULL) {
		$this->dealer = $dealer;
		$this->agent_username = $username;
		$this->agent_password = $password;
		$this->useapi = 'Y'; // สำหรับ 918kiss
		$this->authcode=$authcode;
		$this->secretkey=$secretkey;

		switch ($this->dealer) {
			case "Ufa":
				$this->CI->load->library('interface_ufabet');
				$this->CI->interface_ufabet->set_agent_login($this->agent_username, $this->agent_password);
				break;
			case "Royal":
				$this->CI->load->library('interface_royalcasino');
				$this->CI->interface_royalcasino->set_agent_login($this->agent_username, $this->agent_password);
				break;
			case "Gclub":
				$this->CI->load->library('interface_gclub');
				$this->CI->interface_gclub->set_agent_login($this->agent_username, $this->agent_password);
				break;
			case "918kiss":
				if($this->useapi=='Y'){
					$this->CI->load->library('interface_scrapi');
					$this->CI->interface_scrapi->set_agent_login($this->agent_username, $this->agent_password, $this->authcode, $this->secretkey);
					break;
				}else{
					$this->CI->load->library('interface_scr');
					$this->CI->interface_scr->set_agent_login($this->agent_username, $this->agent_password);
					break;
				}
			case "Pussy888":
				$this->CI->load->library('interface_pussy');
				$this->CI->interface_pussy->set_agent_login($this->agent_username, $this->agent_password);
				break;
			case "Solomon":
				$this->CI->load->library('interface_solomon');
				$this->CI->interface_solomon->set_agent_login($this->agent_username, $this->agent_password, $this->authcode, $this->secretkey);
				break;
			case "Pgslot":
				$this->CI->load->library('interface_pgslot');
				$this->CI->interface_pgslot->set_agent_login($this->agent_username, $this->agent_password, $this->authcode, $this->secretkey);
				break;
		}
	}

	public function check_agent_login() {
		switch ($this->dealer) {
			case "Ufa":
				return $this->CI->interface_ufabet->check_agent_login();
				break;
			case "Royal":
				return $this->CI->interface_royalcasino->check_agent_login();
				break;
			case "Gclub":
				return $this->CI->interface_gclub->check_agent_login();
				break;
			case "918kiss":
				if($this->useapi=='Y'){
					return $this->CI->interface_scrapi->check_agent_login();
					break;
				}else{
					return $this->CI->interface_scr->check_agent_login();
					break;
				}
			case "Pussy888":
				return $this->CI->interface_pussy->check_agent_login();
				break;
			case "Solomon":
				return $this->CI->interface_solomon->check_agent_login();
				break;
			case "Pgslot":
				return $this->CI->interface_pgslot->check_agent_login();
				break;
			default:
				return false;
		}
	}

	public function edit_credit($username, $topup_type, $credit) {
		switch ($this->dealer) {
			case "Ufa":
				return $this->CI->interface_ufabet->edit_credit($username, $topup_type, $credit);
				break;
			case "Royal":
				return $this->CI->interface_royalcasino->edit_credit($username, $topup_type, $credit);
				break;
			case "Gclub":
				return $this->CI->interface_gclub->edit_credit($username, $topup_type, $credit);
				break;
			case "918kiss":
				if($this->useapi=='Y'){
					return $this->CI->interface_scrapi->edit_credit($username, $topup_type, $credit);
					break;
				}else{
					return $this->CI->interface_scr->edit_credit($username, $topup_type, $credit);
					break;
				}
			case "Pussy888":
				return $this->CI->interface_pussy->edit_credit($username, $topup_type, $credit);
				break;
			case "Solomon":
				return $this->CI->interface_solomon->edit_credit($username, $topup_type, $credit);
				break;
			case "Pgslot":
				return $this->CI->interface_pgslot->edit_credit($username, $topup_type, $credit);
				break;
			default:
				return array(
					'status' => false,
					'status_message' => 'Invalid dealer. Or this feature not implement for this dealer yet.',
				);
		}
	}

	public function get_agent_credit() {
		switch ($this->dealer) {
			case "Ufa":
				return $this->CI->interface_ufabet->get_agent_credit();
				break;
			case "Royal":
				return $this->CI->interface_royalcasino->get_agent_credit();
				break;
			case "Gclub":
				return $this->CI->interface_gclub->get_agent_credit();
				break;
			case "918kiss":
				if($this->useapi=='Y'){
					return $this->CI->interface_scrapi->get_agent_credit();
					break;
				}else{
					return $this->CI->interface_scr->get_agent_credit();
					break;
				}
			case "Pussy888":
				return $this->CI->interface_pussy->get_agent_credit();
				break;
			case "Solomon":
				return $this->CI->interface_solomon->get_agent_credit();
				break;
			case "Pgslot":
				return $this->CI->interface_pgslot->get_agent_credit();
				break;
			default:
				return false;
		}
	}

	public function get_user_credit($username) {
		switch ($this->dealer) {
			case "Ufa":
				return $this->CI->interface_ufabet->get_user_credit($username);
				break;
			case "Royal":
				return $this->CI->interface_royalcasino->get_user_credit($username);
				break;
			case "Gclub":
				return $this->CI->interface_gclub->get_user_credit($username);
				break;
			case "918kiss":
				if($this->useapi=='Y'){
					return $this->CI->interface_scrapi->get_user_credit($username);
					break;
				}else{
					return $this->CI->interface_scr->get_user_credit($username);
					break;
				}
			case "Solomon":
				return $this->CI->interface_solomon->get_user_credit($username);
				break;
			case "Pgslot":
				return $this->CI->interface_pgslot->get_user_credit($username);
				break;
			default:
				return false;
		}
	}

	public function get_player_credit($username) {
		switch ($this->dealer) {
			case "Ufa":
				return $this->CI->interface_ufabet->get_player_credit($username);
				break;
			case "Pussy888":
				return $this->CI->interface_pussy->get_player_credit($username);
				break;
			case "918kiss":
				if($this->useapi=='Y'){
					return $this->CI->interface_scrapi->get_player_credit($username);
					break;
				}else{
					return $this->CI->interface_scr->get_player_credit($username);
					break;
				}
			case "Solomon":
				return $this->CI->interface_solomon->get_player_credit($username);
				break;
			case "Pgslot":
				return $this->CI->interface_pgslot->get_player_credit($username);
				break;
			default:
				return false;
		}
	}

	public function refresh_player_credit($username) {
		switch ($this->dealer) {
			case "Ufa":
				return $this->CI->interface_ufabet->refresh_player_credit($username);
				break;
			default:
				return array('status' => true);
		}
	}

	public function create_user_auto($credit, $user_contact=NULL, $username=NULL) {
		switch ($this->dealer) {
			case "Ufa":
				return $this->CI->interface_ufabet->create_user_auto($credit, $user_contact, $username);
				break;
			case "Pussy888":
				return $this->CI->interface_pussy->create_user_auto($credit, $user_contact);
				break;
			case "918kiss":
				if($this->useapi=='Y'){
					return $this->CI->interface_scrapi->create_user_auto($credit, $user_contact);
					break;
				}else{
					return $this->CI->interface_scr->create_user_auto($credit, $user_contact);
					break;
				}
			case "Solomon":
				return $this->CI->interface_solomon->create_user_auto($credit, $user_contact);
				break;
			case "Pgslot":
				return $this->CI->interface_pgslot->create_user_auto($credit, $user_contact);
				break;
			default:
				return array(
					'status' => false,
					'status_message' => 'Invalid dealer. Or this feature not implement for this dealer yet.',
				);
		}
	}

	public function change_password($username, $new_password=NULL, $contact='') {
		switch ($this->dealer) {
			case "Ufa":
				return $this->CI->interface_ufabet->change_password($username, $new_password);
				break;
			case "Pussy888":
				return $this->CI->interface_pussy->change_password($username, $new_password, $contact);
				break;
			case "918kiss":
				if($this->useapi=='Y'){
					return $this->CI->interface_scrapi->change_password($username, $new_password, $contact);
					break;
				}else{
					return $this->CI->interface_scr->change_password($username, $new_password, $contact);
					break;
				}
			case "Solomon":
				return $this->CI->interface_solomon->change_password($username, $new_password, $contact);
				break;
			case "Pgslot":
				return $this->CI->interface_pgslot->change_password($username, $new_password, $contact);
				break;
			default:
				return array(
					'status' => false,
					'status_message' => 'Invalid dealer. Or this feature not implement for this dealer yet.',
				);
		}
	}
	
	public function get_token($username) {
		switch ($this->dealer) {
			case "Solomon":
				return $this->CI->interface_solomon->get_token($username);
				break;
			case "Pgslot":
				return $this->CI->interface_pgslot->get_token($username);
				break;
			default:
				return array(
					'status' => false,
					'status_message' => 'Invalid dealer. Or this feature not implement for this dealer yet.',
				);
		}
	}

	public function create_agent() {
		switch ($this->dealer) {
			case "Royal":
				return $this->CI->interface_royalcasino->create_agent();
				break;
			default:
				return array('status' => true);
		}
	}

	public function init_bind_agent() {
		switch ($this->dealer) {
			case "Royal":
				$this->CI->interface_royalcasino->check_agent_login();
				return $this->CI->interface_royalcasino->init_bind_agent();
				break;
			default:
				return array(
					'status' => false,
					'status_message' => 'This dealer do not need this feature.',
				);
		}	
	}

}