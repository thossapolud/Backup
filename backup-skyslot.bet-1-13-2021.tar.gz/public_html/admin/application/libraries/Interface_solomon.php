<?php if (!defined('BASEPATH')) {exit('No direct script access allowed');}

class Interface_solomon {

	protected $CI;

	private $_root_url = 'https://ag.solomon.bet/api/';
	private $_gc_thb_xr = 10; // Exchange rate from 1 Game credit to Thai Baht
	private $_thb_gc_xr = 0.1; // Exchange rate from 1 Thai Baht to Game credit

	public function __construct() {
		$this->CI = &get_instance();
	}

	/**
	 * Set agent user credential for login to Ufa agent website
	 *
	 * @param string $username  Set agent username
	 * @param string $password  Set agent password
	 */
	public function set_agent_login($username, $password, $authcode=NULL, $secretkey=NULL) {
		$this->agent_username = $username;
		$this->agent_password = $password;
		$this->is_login = false;		
		$this->authcode=$authcode;
		$this->secretkey=$secretkey;
	}
	
	/**
	 * Check agent user currently login or not.
	 * If not login then try to login to website
	 *
	 * @return boolean Currently login or not
	 */
	public function check_agent_login() {
		return $this->is_login = true;
	}

	/**
	 * Edit member credit
	 * When adjust or Deposit or Withdrawal Scr user credit
	 *
	 * @param string $solomonuser  Username to edit credit
	 * @param string $solomonedit_type  Edit credit type : 1=Deposit , 2=Withdrawal
	 * @param float $solomoncredit_edit  Credit amount
	 * @return array  Status indicate success or fail and basic credit information
	 */
	public function edit_credit($solomonuser, $solomonedit_type, $solomoncredit_edit) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		
		$agent_credit_before = $this->get_agent_credit(); // Get current agent credit balance
		$arr_player_credit = $this->get_player_credit($solomonuser); // Get current user credit balance
		$credit_balance = $arr_player_credit['credit_balance']; // Get current user credit balance			
		$credit_before = $credit_balance; // Set user balance before deposit or withdraw credit

		//$max_value = $this->_convert_thb_to_gc($agent_credit_before);
		//$score_num = $this->_convert_thb_to_gc($solomoncredit_edit);

		if ($solomonedit_type == 1) { // Deposit credit
			$score_num = number_format($solomoncredit_edit,2,'.','');
			$method = 'de';
		} else if ($solomonedit_type == 2) { // Withdrawal credit
			$score_num = '-'.number_format($solomoncredit_edit,2,'.','');
			$method = 'wi';
		} else { // Unknown or Unsupported credit edit type
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unknown or Unsupported credit edit type',
			);
		}
		
		$postdata = "upl_username=".$solomonuser."&key_api=".$this->secretkey;
		$postdata .= "&method=$method&credit=$score_num";
		$url = $this->_root_url.'editPlayerCredit';
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($chapi, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($chapi, CURLOPT_POST, 1);	
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->errorCode===0){
			return $data_return = array(
				'status' => true,
				'credit_before' => $credit_before,
				'credit_edit' => $solomoncredit_edit,
				'agent_name' => $this->agent_username,
				'agent_credit_before' => $agent_credit_before,
			);
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->errorMessage,
			);
		}
		
		return $data_return;
	}

	/**
	 * Get agent credit balance
	 *
	 * @return float|false  Current agent credit balance or false if failed
	 */
	public function get_agent_credit(){		
		$credit = 0;
		$postdata = "key_api=".$this->secretkey;
		$url = $this->_root_url.'getAgentBalance';
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($chapi, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($chapi, CURLOPT_POST, 1);		
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->errorCode===0){
			//$credit = $this->_convert_gc_to_thb($json_result->creditBalance); // convert GC to THB
			$credit = $json_result->creditBalance;
			return number_format($credit, 2, '.', '');
		}else{
			return false;
		}
	}
	
	/**
	 * Get user credit balance
	 *
	 * @param string  $solomonuser  Username to get credit
	 * @return float|false  Current user credit balance or false if failed
	 */
	public function get_player_credit($solomonuser) {
		$credit_balance = 0;
		$postdata = "key_api=".$this->secretkey."&upl_username=".$solomonuser;
		$url = $this->_root_url.'getPlayerBalance';		
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($chapi, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($chapi, CURLOPT_POST, 1);	
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->errorCode===0){
			//$credit_balance = $this->_convert_gc_to_thb($json_result->creditBalance); // convert GC to THB
			$credit_balance = $json_result->creditBalance;
			$data_return = array(
				'status' => true,
				'player_username' =>  $solomonuser,
				'credit_game' => trim(preg_replace("/[^0-9\.]/", '', '0.00')),
				'credit_balance' => trim(preg_replace("/[^0-9\.]/", '', $credit_balance))
			);
			return $data_return;
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unable to get data'
			);
		}
	}
	
	/**
	 * Create new Solomon user
	 * @param float $credit  Innitial Credit
	 * @return array  Status indicate success or fail. And user credential if success
	 */	
	public function create_user_auto($credit = 0, $contact = NULL) {
		
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to create new user',
		);
				
		//  Password
		$solomonpassword = 'Skyslot7abc';		
		//  AddPlayer
		$postdata = "upl_password=".$solomonpassword."&key_api=".$this->secretkey;
		$postdata .= "&upld_nickname=&upld_bank=&upld_bankno=&upld_tel=&upld_desc=";
		$url = $this->_root_url.'addNewPlayer';
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($chapi, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($chapi, CURLOPT_POST, 1); 		
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->errorCode===0){
			return $data_return = array(
				'status' => true,
				'username' => $json_result->uplUsername,
				'password' => $solomonpassword,
			);
		} else {
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->errorMessage,
			);
		}

		return $data_return;
	}
	
	public function change_password($solomonuser, $new_password=NULL, $contact='') {
		
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to change password',
		);
		
		$postdata = "upl_username=".$solomonuser."&upl_password=$new_password&key_api=".$this->secretkey;
		$postdata .= "&upld_nickname=&upld_bank=&upld_bankno=&upld_tel=&upld_desc=";
		$url = $this->_root_url.'editPlayerInfo';		
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);		
		curl_setopt($chapi, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($chapi, CURLOPT_POST, 1);
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->errorCode===0){
			return $data_return  = array(
				'status' => true ,
				'new_password' => $new_password 
			);
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => $json_result->errorMessage,
			);
		}
		return $data_return;
	}
	
	/**
	 * Get Login Token
	 *
	 * @param string  $solomonuser  Username to get Token
	 * @return float|false LoginToken or false if failed
	 */
	public function get_token($solomonuser){
		$postdata = "key_api=".$this->secretkey."&upl_username=".$solomonuser;
		$url = $this->_root_url.'getLoginToken';		
		$chapi = curl_init($url);
		curl_setopt($chapi, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($chapi, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($chapi, CURLOPT_POSTFIELDS, $postdata); 
		curl_setopt($chapi, CURLOPT_POST, 1);	
		$result = curl_exec($chapi);
		$http_code = curl_getinfo($chapi, CURLINFO_HTTP_CODE);
		curl_close($chapi);
		$json_result = json_decode($result);
		if($http_code==200&&$json_result->errorCode===0){
			$data_return = array(
				'status' => true,
				'player_username' =>  $solomonuser,
				'token' => $json_result->token,
				'url'=> ''
			);
			return $data_return;
		}else{
			return $data_return = array(
				'status' => false,
				'status_message' => 'Unable to get token'
			);
		}
	}

	public function edit_user($solomonuser, $solomonedit_type, $password, $name, $tel, $memo) {
		$data_return = array(
			'status' => false,
			'status_message' => 'Failed to edit user credit',
		);
		if ($this->is_login) {
			$check_login = $this->is_login;
		} else {
			$check_login = $this->check_agent_login(); // Check is login to Ufa agent website yet.
		}

		if ($check_login) {

		} else { // Fail to login to agent website
			return $data_return = array(
				'status' => false,
				'status_message' => 'Failed to login with this agent credential',
			);
		}
		return $data_return;
	}

	private function _convert_gc_to_thb($in) {
		$out = $in * $this->_gc_thb_xr; // Convert GC to THB
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}

	private function _convert_thb_to_gc($in) {
		$out = $in * $this->_thb_gc_xr; // Convert THB to GC
		$out = floor($out * 100) / 100; // Floor 2 decimal
		return $out;
	}
}