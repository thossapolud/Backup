<?php   if (!defined('BASEPATH')) exit('No direct script access allowed');

if( ! function_exists( 'hide_phone' ) ){
	function hide_phone($phone) {
		return substr($phone, 0, -4) . "****";
	}
}

if( ! function_exists( 'conv_ws_type' ) ){
	function conv_ws_type($type){
		switch($type){
			case 'deposit' :
				$type_text = 'ฝาก';
			break;
			case 'withdraw' :
				//$type_text = '<span class="label label-danger">ถอน</span>';
				$type_text = 'ถอน';
			break;
			case 'transfer' :
				$type_text = 'โยก';
			break;
			default:
				$type_text = '';
		}
		return $type_text;
	}
}

if( ! function_exists( 'conv_bankname' ) ){
	function conv_bankname($bank){
		switch(strtoupper($bank)){
			case 'KBANK' :
				$bankname = 'ธนาคารกสิกรไทย';
			break;
			case 'SCB' :
				$bankname = 'ธนาคารไทยพาณิชย์';
			break;			
			case 'BBL' :
				$bankname = 'ธนาคารกรุงเทพ';
			break;
			case 'KTB' :
				$bankname = 'ธนาคารกรุงไทย';
			break;
			case 'TMB' :
				$bankname = 'ธนาคารทหารไทย';
			break;
			case 'BAY' :
				$bankname = 'ธนาคารกรุงศรีอยุธยา';
			break;
			case 'GSB' :
				$bankname = 'ธนาคารออมสิน';
			break;
			case 'ISBT' :
				$bankname = 'ธนาคารอิสลาม';
			break;
			case 'GHB' :
				$bankname = 'ธนาคารอาคารสงเคราะห์';
			break;
			case 'CIMBT' :
				$bankname = 'ธนาคารซีไอเอ็มบีไทย';
			break;
			case 'TBANK' :
				$bankname = 'ธนาคารธนชาต';
			break;
			case 'LHBANK' :
				$bankname = 'ธนาคารแลนด์แอนด์เฮ้าส์';
			break;			
			case 'SCBT' :
				$bankname = 'ธนาคารสแตนดาร์ดชาร์เตอร์ด';
			break;
			case 'TISCO' :
				$bankname = 'ธนาคารทิสโก้';
			break;
			case 'CITI' :
				$bankname = 'ธนาคารซิตี้แบงก์';
			break;
			case 'HSBC' :
				$bankname = 'ธนาคารฮ่องกงและเซี่ยงไฮ้';
			break;
			case 'KK' :
				$bankname = 'ธนาคารเกียรตินาคิน';
			break;
			case 'UOBT' :
				$bankname = 'ธนาคารยูโอบี';
			break;
			case 'ICBC' :
				$bankname = 'ธนาคารไอซีบีซี';
			break;
			case 'TCRB' :
				$bankname = 'ธนาคารไทยเครดิต';
			break;
			case 'BAAC' :
				$bankname = 'ธนาคารเพื่อการเกษตรฯ';
			break;
			default:
				$bankname = '';
		}
		return $bankname;
	}
}

if( ! function_exists( 'conv_bankwithdrawnum' ) ){
	function conv_bankwithdrawnum($bank){
		switch(strtoupper($bank)){
			case 'KBANK' :
				$banknum = '004';
			break;
			case 'SCB' :
				$banknum = '014';
			break;		
			case 'BBL' :
				$banknum = '002';
			break;
			case 'KTB' :
				$banknum = '006';
			break;
			case 'TMB' :
				$banknum = '011';
			break;
			case 'BAY' :
				$banknum = '025';
			break;
			case 'GSB' :
				$banknum = '030';
			break;
			case 'ISBT' :
				$banknum = '066';
			break;
			case 'GHB' :
				$banknum = '033';
			break;
			case 'CIMBT' :
				$banknum = '022';
			break;
			case 'TBANK' :
				$banknum = '065';
			break;
			case 'LHBANK' :
				$banknum = '073';
			break;			
			case 'SCBT' :
				$banknum = '020';
			break;
			case 'TISCO' :
				$banknum = '067';
			break;
			case 'CITI' :
				$banknum = '017';
			break;
			case 'HSBC' :
				$banknum = '031';
			break;
			case 'KK' :
				$banknum = '069';
			break;
			case 'UOBT' :
				$banknum = '024';
			break;
			case 'ICBC' :
				$banknum = '070';
			break;
			case 'TCRB' :
				$banknum = '071';
			break;
			case 'BAAC' :
				$banknum = '034';
			break;
		}
		return $banknum;
	}
}

if( ! function_exists( 'conv_banknumtobank' ) ){
	function conv_banknumtobank($banknum){
		switch($banknum){
			case '004' :
				$bank = 'KBANK';
			break;
			case '014' :
				$bank = 'SCB';
			break;
			case '002' :
				$bank = 'BBL';
			break;
			case '006' :
				$bank = 'KTB';
			break;
			case '011' :
				$bank = 'TMB';
			break;
			case '025' :
				$bank = 'BAY';
			break;
			case '030' :
				$bank = 'GSB';
			break;
			case '066' :
				$bank = 'ISBT';
			break;
			case '033' :
				$bank = 'GHB';
			break;
			case '022' :
				$bank = 'CIMBT';
			break;
			case '065' :
				$bank = 'TBANK';
			break;
			case '073' :
				$bank = 'LHBANK';
			break;			
			case '020' :
				$bank = 'SCBT';
			break;
			case '067' :
				$bank = 'TISCO';
			break;
			case '017' :
				$bank = 'CITI';
			break;
			case '031' :
				$bank = 'HSBC';
			break;
			case '069' :
				$bank = 'KK';
			break;
			case '024' :
				$bank = 'UOBT';
			break;
			case '070' :
				$bank = 'ICBC';
			break;
			case '071' :
				$bank = 'TCRB';
			break;
			case '034' :
				$bank = 'BAAC';
			break;
			default :
				$bank = '';
			break;
		}
		return $bank;
	}
}

if( ! function_exists( 'conv_ws_status' ) ){
	function conv_ws_status($status){
		switch($status){
			case 0 :
				$status_text = '<span class="label label-default">รอตรวจ</span>';
				//$status_text = 'รอตรวจ';
			break;
			case 1 :
				$status_text = '<span class="label label-success">เสร็จสิ้น</span>';
				//$status_text = 'ตรวจแล้ว';
			break;
			case 2 :
				$status_text = '<span class="label label-danger">ยกเลิก</span>';
				//$status_text = 'ยกเลิก';
			break;
			case 3 :
				$status_text = '<span class="label label-info">รอจัดการ</span>';
			break;
			case 4 :
				$status_text = '<span class="label label-primary">ประมวลผล</span>';
			break;
			case 5 :
				$status_text = '<span class="label label-warning">ไม่สำเร็จ</span>';
			break;
			default:
				$status_text = '';
		}
		return $status_text;
	}
}

if( ! function_exists( 'duration' ) ){
	function duration($begin,$end){
		$remain=intval(strtotime($end)-strtotime($begin));
		$wan=floor($remain/86400);
		$l_wan=$remain%86400;
		$hour=floor($l_wan/3600);
		$l_hour=$l_wan%3600;
		$minute=floor($l_hour/60);
		$second=$l_hour%60;	
		$text = '';
		if($wan>0){
			$text .= $wan." วัน ";
		}
		if($hour>0){
			$text .= $hour." ชั่วโมง ";
		}
		if($minute>0){
			$text .= $minute." นาที ";
		}
		if($second>0){
			$text .= $second." วินาที";
		}
		
		if($minute>5){
			return '<span class="badge badge-error">'.$text.'</span>';
		}else{
			return '<span class="badge badge-default">'.$text.'</span>';
		}
	}
}

if( ! function_exists( 'duration_minute' ) ){
	function duration_minute($begin,$end){
		$minute = 0;
		if($begin!=''&&$end!=''){
			$remain=intval(strtotime($end)-strtotime($begin));
			$minute=floor($remain/60);
		}
		return $minute;
	}
}